# vibecoder-skills

**A 40-skill pack that makes an AI agent behave like a 10-year senior engineer while still talking to you like a human.**

You describe what you want. Your agent builds it. The problem is never "can it write code" — the problem is
*it writes demo code*. It picks whatever stack it saw most recently, skips rate limiting, stores secrets in
the client, ships a button you can click eight times, and calls it secure because you asked it to be "100% secure".

`vibecoder-skills` fixes that. Every skill is a hard-won checklist, a set of copy-paste patterns, and a list of
plain-language questions your agent must ask you *before* it writes a line of code.

---

## What's inside

| Group | Skills | What you stop worrying about |
|---|---|---|
| 🧠 **core** | 5 | Wrong stack, vague requirements, chaotic repos, agent guessing instead of asking |
| 🔒 **security** | 6 | XSS, CSRF, SSRF, IDOR, SQLi, leaked keys, broken auth, ransomware-in-a-CI |
| 🎨 **ux** | 8 | Apps that feel cheap: no loading states, buttons that double-submit, empty screens, inaccessible UI, desktop-only layouts, blank pages, fake data, no dark mode, raw server errors |
| ⚙️ **engineering** | 7 | Spaghetti APIs, lost data, silent failures, no tests, slow pages, unsafe migrations, bloated tables and surprise provider bills |
| 🚀 **delivery** | 6 | Broken deploys, surprise $4k bills, failed payments, no rollback, no backups |
| 📱 **platform** | 4 | Mobile store rejection, unsigned desktop installers, AI features that leak prompts and burn money |
| 🧹 **quality** | 4 | Untouchable code, no handover docs, launch-day chaos, unreadable READMEs |

**Total: 40 skills. Each one priced at $100 of real value. You get all of them.**

---

## The catalog

### 🧠 core — start here

| Skill | The $100 problem it solves |
|---|---|
| [`vibecoder-orchestrator`](skills/core/vibecoder-orchestrator/SKILL.md) | The conductor. Reads your request, decides which of the 39 other skills apply, and refuses to skip the important ones. Install this one first. |
| [`discovery-interview`](skills/core/discovery-interview/SKILL.md) | Turns "make me a booking app" into a real brief. Asks about *people and money*, not databases — because you don't care about databases. |
| [`stack-selection`](skills/core/stack-selection/SKILL.md) | Stops the agent from defaulting to whatever it likes. Chooses the stack from *your* situation: traffic, budget, timeline, who maintains it, what you already know. |
| [`vibe-guardrails`](skills/core/vibe-guardrails/SKILL.md) | Teaches the agent how to talk to a non-engineer, how to never leak your secrets or your private context, and how to say "I don't know" instead of inventing. |
| [`project-blueprint`](skills/core/project-blueprint/SKILL.md) | The repo layout, naming rules, and file contracts that let any agent (or human) jump into a 6-month-old project and be productive in 10 minutes. |

### 🔒 security — the part vibe coders never get right

| Skill | The $100 problem it solves |
|---|---|
| [`appsec-hardening`](skills/security/appsec-hardening/SKILL.md) | **The flagship.** XSS, CSRF, SSRF, IDOR, SQL injection, path traversal, open redirect, cookie theft, file uploads, mass assignment, brute force, insecure storage — with the actual fix for each, in the three stacks people really use. |
| [`auth-and-access`](skills/security/auth-and-access/SKILL.md) | Login, sessions, OAuth, "log in with Google", password reset that isn't a free account takeover, RBAC, MFA. Where 80% of real breaches start. |
| [`secrets-management`](skills/security/secrets-management/SKILL.md) | API keys, `.env` files, tokens in git history, rotation, CI secrets, and exactly what to do the minute a key leaks. |
| [`api-abuse-defense`](skills/security/api-abuse-defense/SKILL.md) | Rate limiting, input validation, abuse and bot traffic, SSRF at the API layer, webhook forgery, and the difference between "rate limit per instance" and "rate limit that actually works". |
| [`data-privacy-and-pii`](skills/security/data-privacy-and-pii/SKILL.md) | What personal data you're collecting by accident, what you must delete when asked, what must never appear in a log or a URL, and how to not spy on your own users. |
| [`dependency-and-supply-chain`](skills/security/dependency-and-supply-chain/SKILL.md) | Malicious packages, typosquatting, lockfiles, CVEs, `npm install` as a remote code execution button, and CI pipelines that can publish as you. |

### 🎨 ux — because the UI *is* the product

| Skill | The $100 problem it solves |
|---|---|
| [`frontend-craft`](skills/ux/frontend-craft/SKILL.md) | Loading states, skeletons, disabled-while-submitting buttons, timeouts, retries, optimistic updates, race conditions, toasts that don't lie. The difference between "vibe coded" and "real product". |
| [`distinctive-visual-style`](skills/ux/distinctive-visual-style/SKILL.md) | Kills the AI-generated look: twenty tells, eight moves, seven tests, and five complete style recipes (Paper & Ink, Swiss, Warm Analog, Dense Technical, High-Contrast Minimal) with real CSS. |
| [`design-system-and-visual-language`](skills/ux/design-system-and-visual-language/SKILL.md) | Tokens, spacing, type, color, one component library, consistent states. Makes five screens built on five different days look like one product. |
| [`ux-writing-and-onboarding`](skills/ux/ux-writing-and-onboarding/SKILL.md) | Empty states, error messages humans can act on, first-run experience, microcopy that converts. Words are the cheapest feature you'll ever ship. |
| [`accessibility-and-inclusive-design`](skills/ux/accessibility-and-inclusive-design/SKILL.md) | Keyboard-only, screen readers, contrast, focus states, motion, forms. Also: the thing that quietly gets you sued or disqualified from enterprise deals. |
| [`responsive-mobile-first`](skills/ux/responsive-mobile-first/SKILL.md) | **Zero blank pages.** Enforces true mobile-first (320px → desktop), fluid layouts, 44px tap targets, and a zero-tolerance completeness audit: no dead links, blank routes, broken images, or demo mock data — production-ready or not shippable. |
| [`ux-upgrade-audit`](skills/ux/ux-upgrade-audit/SKILL.md) | **The full UX scan.** Inventories every page, runs 8 pass/fail audits (buttons, type, layout, color, states, responsive, a11y, consistency), and produces a file:line-graded report with copy-paste fixes — then upgrades everything on your "fix all". |
| [`global-ui-reformat`](skills/ux/global-ui-reformat/SKILL.md) | **Paste into any codebase, reformat everything.** Standalone global pass: dark mode (system + no FOUC), skeletons for every loading state, human errors with retry (never raw 500), and animated onboarding modals + coach marks — 320px→1440px verified. |

### ⚙️ engineering — the code that survives contact with users

| Skill | The $100 problem it solves |
|---|---|
| [`production-readiness`](skills/engineering/production-readiness/SKILL.md) | The launch gate. A brutal pass/fail audit of a demo app before real users touch it. |
| [`backend-api-design`](skills/engineering/backend-api-design/SKILL.md) | Endpoints, error contracts, idempotency, pagination, versioning, and why "just return 200 with an error string" will cost you a weekend. |
| [`data-model-and-migrations`](skills/engineering/data-model-and-migrations/SKILL.md) | Schema design, the indexes you're missing, zero-downtime migrations, backups you've actually tested restoring. |
| [`testing-and-verification`](skills/engineering/testing-and-verification/SKILL.md) | Not 100% coverage theater. The 12 tests that catch 90% of disasters, plus how to verify without a test suite. |
| [`errors-logs-and-monitoring`](skills/engineering/errors-logs-and-monitoring/SKILL.md) | You will ship bugs. This is how you find out in 4 minutes from a log instead of 4 days from an angry email. |
| [`performance-and-caching`](skills/engineering/performance-and-caching/SKILL.md) | Budgets, N+1 queries, image weight, caching layers, and "it's fast on my machine" syndrome. |
| [`database-efficiency`](skills/engineering/database-efficiency/SKILL.md) | Lean tables (2 columns not 7 for a like), smallest correct types, index intent not bloat, provider choice with exit plan, and resource ceilings — zero-risk, zero-bloat production databases. |

### 🚀 delivery — getting it live and keeping it alive

| Skill | The $100 problem it solves |
|---|---|
| [`deploy-and-environments`](skills/delivery/deploy-and-environments/SKILL.md) | Where to host it, how to get dev/staging/prod, CI that doesn't leak secrets, and deploys that don't take the app down. |
| [`reliability-and-incidents`](skills/delivery/reliability-and-incidents/SKILL.md) | Backups, rollback, kill switches, feature flags, status page, and a one-page runbook for 3am. |
| [`payments-and-billing`](skills/delivery/payments-and-billing/SKILL.md) | Stripe done properly: webhooks, idempotency, double-charging, refunds, trials, dunning, and never trusting the client about price. |
| [`third-party-integrations`](skills/delivery/third-party-integrations/SKILL.md) | Email, SMS, storage, maps, AI, whatever. Retries, timeouts, circuit breakers, and surviving someone else's outage. |
| [`cost-guardrails`](skills/delivery/cost-guardrails/SKILL.md) | Quotas, budgets, billing alerts, and the specific settings that stop a $4,000 morning. Works for cloud *and* LLM spend. |
| [`seo-and-growth-basics`](skills/delivery/seo-and-growth-basics/SKILL.md) | Metadata, OG images, sitemaps, Core Web Vitals, analytics that respect privacy, and a landing page that ranks. |

### 📱 platform — web is not the only target

| Skill | The $100 problem it solves |
|---|---|
| [`mobile-app-delivery`](skills/platform/mobile-app-delivery/SKILL.md) | React Native / Expo / Flutter: signing, store review, push notifications, OTA updates, offline-first, permissions, app secrets (mobile has nowhere to hide them). |
| [`desktop-app-delivery`](skills/platform/desktop-app-delivery/SKILL.md) | Electron / Tauri: code signing, notarization, auto-update, installers, sandboxing, and not shipping your whole node_modules to users. |
| [`ai-features-in-production`](skills/platform/ai-features-in-production/SKILL.md) | LLM features that don't leak your prompt, don't let users hijack it, don't cost $900 overnight, and degrade gracefully when the model is down. |
| [`saas-architecture`](skills/platform/saas-architecture/SKILL.md) | Multi-tenancy, plans and limits, feature flags, admin backoffice, and the data model that lets you sell tomorrow what you build today. |

### 🧹 quality — month three and beyond

| Skill | The $100 problem it solves |
|---|---|
| [`code-review-and-audit`](skills/quality/code-review-and-audit/SKILL.md) | A repeatable review pass + a shareable audit report. Run it on code you wrote, code the AI wrote, or code you inherited. |
| [`refactor-and-maintainability`](skills/quality/refactor-and-maintainability/SKILL.md) | How to clean up without breaking things: seams, characterization tests, debt budget, when to stop. |
| [`launch-and-handoff`](skills/quality/launch-and-handoff/SKILL.md) | Launch-day runbook, docs a non-technical owner can use, and the 30-day post-launch plan. |
| [`write-documentation`](skills/quality/write-documentation/SKILL.md) | **Say "write docs" → get docs that teach use.** Usage-first README: overview, workflows, API/CLI, examples, FAQ — with "run locally" only if it's an open-source tool. No invented features, every bullet has a file:line. |

---

## Get started in three steps

1. **Install the pack** into your agent (`./scripts/install.sh --agent claude`, or see [INSTALL.md](INSTALL.md)).
2. **Fill in your profile once** — copy [`_shared/VIBECODER-PROFILE.md`](_shared/VIBECODER-PROFILE.md) to your
   project root and answer what you can. It tells the agent who you are, what you're building, and the things
   it must never do without asking (deploy, spend money, delete data, share your keys).
3. **Describe what you want in one sentence** and let it ask you questions. If it starts writing code before
   asking who the users are, the skills aren't loaded.

That's it. The rest of the pack loads itself — `vibecoder-orchestrator` decides which skills each request needs.

## Install

See [INSTALL.md](INSTALL.md). Short version: the skills are plain folders with a `SKILL.md` file, so they work
with Claude Code, Cursor, Codex CLI, Windsurf, Cline, Amp, and anything else that reads project instructions.
There's a one-line installer and a "copy-paste into your AGENTS.md" fallback.

```bash
./scripts/install.sh --agent claude      # ~/.claude/skills
./scripts/install.sh --agent cursor      # .cursor/skills
./scripts/install.sh --agent codex       # ~/.codex/skills + AGENTS.md
./scripts/install.sh --agent all-claude  # everything, flattened
```

---

## How the group works together

```
        ┌──────────────────────────────┐
 you ──►│   vibecoder-orchestrator     │  reads the request, picks the skills
        └──────────────┬───────────────┘
                       ▼
        ┌──────────────────────────────┐
        │   discovery-interview        │  plain-language questions → brief
        └──────────────┬───────────────┘
                       ▼
        ┌──────────────────────────────┐
        │   stack-selection            │  pick the stack from the situation
        └──────────────┬───────────────┘
                       ▼
   ┌─────────┬─────────┴──────┬──────────┬─────────┐
   ▼         ▼                ▼          ▼         ▼
security   ux         engineering    delivery   platform
   │         │                │          │         │
   └─────────┴────────┬───────┴──────────┴─────────┘
                      ▼
        ┌──────────────────────────────┐
        │   production-readiness       │  the launch gate
        └──────────────┬───────────────┘
                       ▼
        ┌──────────────────────────────┐
        │   launch-and-handoff         │  ship it + keep it alive
        └──────────────────────────────┘
```

Every skill is also usable **alone**. Drop `appsec-hardening` into an existing project and run it.
That's the point: buy one, use one; buy the pack, and they compound.

---

## The one rule behind all of them

> **An agent should never choose for you when it can ask you — and it should never ask you a technical
> question when it can ask a human one.**

"Should we use Redis or per-instance rate limiting?" is a bad question.
"Do you expect a few hundred people a day, or could a post go viral and bring 10,000 at once?" is a good one.
Every skill in this pack follows that rule.

---

## Licensing / selling

You're free to sell these individually or bundled. Suggested bundles:

| Bundle | Contents | Price |
|---|---|---|
| **Survival** | core (5) | $297 |
| **Don't Get Hacked** | security (6) | $397 |
| **Feels Expensive** | ux (8) | $497 |
| **Production Ready** | engineering + delivery (13) | $697 |
| **The 10-Year Engineer** | all 40 + updates | $1,497 |

Each folder carries its own `SKILL.md` with `name` and `description` frontmatter, so it drops into any
agent that supports the open `SKILL.md` convention with zero conversion.

---

Built for the people who ship on vibes and wake up responsible for real users.
