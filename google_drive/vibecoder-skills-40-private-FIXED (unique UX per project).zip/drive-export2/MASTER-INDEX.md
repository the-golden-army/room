# vibecoder-skills — Master Index (40 skills + anti-repetition fix)

Say: "Read skills/ux/distinctive-visual-style/SKILL.md — make my UX distinctive, not the same as last project"
Or: "Read skills/quality/write-documentation/SKILL.md and write docs for this project"

## What changed 2026-10-23
- FIX: ux/distinctive-visual-style no longer repeats — must propose 3 distinct directions (different ancestor/palette/type/radius/layout from R1-R5), human picks, REJECTED recorded in docs/STYLE.md, never default to R1
- FIX: ux/global-ui-reformat + design-system tokens are shape-only — must derive product-specific palette from ancestor

All 40 skills:
core (5): orchestrator, discovery-interview, stack-selection, vibe-guardrails, project-blueprint
security (6): appsec-hardening, auth-and-access, secrets-management, api-abuse-defense, data-privacy-and-pii, dependency-and-supply-chain
ux (8): frontend-craft, distinctive-visual-style [FIXED], design-system-and-visual-language [FIXED], ux-writing-and-onboarding, accessibility-and-inclusive-design, responsive-mobile-first, ux-upgrade-audit, global-ui-reformat [FIXED]
engineering (7): production-readiness, backend-api-design, data-model-and-migrations, testing-and-verification, errors-logs-and-monitoring, performance-and-caching, database-efficiency
delivery (6): deploy-and-environments, reliability-and-incidents, payments-and-billing, third-party-integrations, cost-guardrails, seo-and-growth-basics
platform (4): mobile-app-delivery, desktop-app-delivery, ai-features-in-production, saas-architecture
quality (4): code-review-and-audit, refactor-and-maintainability, launch-and-handoff, write-documentation

Branch: arena/f8176760-skills @ 18bd699 — Total 40 skills
18bd699 fix(ux): distinctive style no longer repeats — enforce 3-direction choice
