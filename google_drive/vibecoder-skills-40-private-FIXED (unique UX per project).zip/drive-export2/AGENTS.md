# vibecoder-skills — repo router

This repository is a **skill library**, not an application. There is no code to run here.

## If you are an AI agent working in this repo

You are probably being asked to add, edit, or review a skill. Rules:

1. **Never change an existing skill's `name` frontmatter.** It's a stable identifier; other repos and bundles
   reference it. Changing it breaks installs.
2. **Keep `description` frontmatter in third person and trigger-oriented.** It is the only thing the agent reads
   when deciding whether to load a skill. Write what it does *and* when to use it. Max ~1024 chars.
3. **Every skill keeps the same body skeleton** so the pack feels like one product:
   `Promise → When to use → The 60-second version → Steps → Non-negotiables → Ask the human →
   Decision table → Patterns → Anti-patterns → Definition of done → Works with`.
4. **Plain language only.** The reader is a vibe coder. Ban "idempotency", "SSR", "N+1", "TTL" without a
   one-line plain translation the first time it appears.
5. **Every skill asks questions a non-engineer can answer.** Never "should we shard the DB?"; instead
   "how many people might use this on a busy day, roughly?"
6. **Checklists must be pass/fail**, not aspirational. "Consider security" is not a checklist item.
7. **Code snippets must be copy-paste runnable** in at least one of: Next.js/React + TypeScript,
   Python/FastAPI, Node/Express. Say which.
8. **No telemetry, no phone-home, no `npm install` of anything unvetted in examples.** This pack teaches
   supply-chain safety; it must model it.

## If you are a human

Read [`README.md`](README.md) for the catalog and [`INSTALL.md`](INSTALL.md) to install into your agent.

## Layout

```
skills/
  core/       conductor, discovery, stack choice, agent behavior, repo layout
  security/   appsec, auth, secrets, abuse, privacy, supply chain
  ux/         frontend craft, design system, UX writing, accessibility
  engineering/production readiness, APIs, data, tests, observability, performance
  delivery/   deploy, reliability, payments, integrations, cost, SEO
  platform/   mobile, desktop, AI features, SaaS architecture
  quality/    review/audit, refactor, launch & handoff
_shared/      shared assets (the vibe coder profile template)
scripts/      installer
```

## Adding a new skill

1. Create `skills/<group>/<skill-name>/SKILL.md`.
2. Start the file with frontmatter: `name`, `description`, and a `metadata:` block with
   `category`, `version`, `value`.
3. Copy the body skeleton from any existing skill.
4. Add one row to the catalog table in `README.md`.
5. Add the skill to `scripts/install.sh`'s implicit discovery (it globs `skills/*/*/SKILL.md`, so nothing to do)
   and to `skills/core/vibecoder-orchestrator/references/skill-index.md`.
6. Commit: `git commit -m "feat(skills): add <skill-name>"`.
