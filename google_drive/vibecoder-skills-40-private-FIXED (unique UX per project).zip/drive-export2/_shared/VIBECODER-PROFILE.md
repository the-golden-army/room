# My Vibe Coder Profile

**Copy this file to the root of every project you build** (or into your home folder as
`~/.claude/VIBECODER-PROFILE.md`) and fill it in once. Every skill in the `vibecoder-skills` pack, and
`vibe-guardrails` in particular, is designed to read it so your agent stops re-asking the same questions
and stops treating you like a staff engineer.

You do **not** need to answer everything. Blank means "ask me".

---

```markdown
# VIBECODER PROFILE

## 1. Who I am
- Name / how to address me:
- I write code: [ ] never  [ ] a little  [ ] comfortably  [ ] I'm technical, just not in this stack
- I'm comfortable with the terminal: [ ] no  [ ] a bit  [ ] yes
- When something breaks I want: [ ] the fix, no explanation  [ ] the fix + one-line why
                                [ ] a short explanation  [ ] teach me, I want to learn

## 2. What I'm building
- One sentence:
- This is: [ ] a side project  [ ] a portfolio piece  [ ] a business  [ ] an internal tool
           [ ] something I'm selling to clients
- It makes money: [ ] no  [ ] yes, subscriptions  [ ] yes, one-off payments  [ ] ads/other
- If it disappeared for a day, the cost to me would be:
  [ ] nothing  [ ] annoying  [ ] losing money  [ ] contractual trouble

## 3. The reality constraints (these decide the stack, not me)
- Timeline: [ ] this weekend  [ ] a week  [ ] a month  [ ] ongoing, no rush
- Budget I can spend monthly on hosting/services: $______ (0 is a valid answer)
- Budget I can spend total before it must earn: $______
- I already pay for / already know: ___________ (host, domain, a database, a tool...)
- I will maintain this myself: [ ] yes  [ ] no, I'll hand it to someone  [ ] no idea

## 4. Who uses it
- Roughly how many people on a normal day: ______
- Worst realistic case (a post goes viral, a launch, Black Friday): ______
- Are they logged in, or public? [ ] public  [ ] logged in  [ ] both
- Do they pay? [ ] no  [ ] yes
- Do they upload things (photos, files, CSVs)? [ ] no  [ ] yes
- Is any of the data sensitive (health, money, IDs, kids, private messages)? [ ] no  [ ] yes: ______
- Does it need to work on: [ ] desktop web  [ ] mobile web  [ ] iOS app  [ ] Android app
                           [ ] Mac/Windows desktop app

## 5. My red lines (the agent must never violate these)
- Never push to main / never deploy without asking me first: [ ] yes  [ ] no, just do it
- Never install a package I haven't approved: [ ] yes  [ ] no
- Never send my code, keys, or .env contents to a third-party service: [ ] yes  [ ] no
- Never add analytics/tracking without telling me: [ ] yes  [ ] no
- Never delete or rewrite a database without showing me the command first: [ ] yes  [ ] no
- I want to be asked before: [ ] spending money  [ ] adding a dependency  [ ] changing the stack
                             [ ] touching anything that already works

## 6. How to talk to me
- Explain technical choices in: [ ] one plain sentence  [ ] a short paragraph  [ ] full detail
- When there's a tradeoff, I want: [ ] your recommendation + why  [ ] the options, I'll pick
- If you're not sure: [ ] ask me  [ ] pick the safe default and tell me you did
- Hard words I want you to always translate: ___________ (e.g. "idempotent", "migration", "cache")
```

---

## Notes

- Section 5 is the one that matters most. It's the difference between "the agent deleted my production
  database" and "the agent showed me the command and waited".
- Your profile is **not** code. It is never committed to a public repo, never sent to a third party, and
  never used to build a profile of you. See `data-privacy-and-pii` for why that boundary matters.
- If you work with clients, keep one profile per client. Most "the AI got it wrong" stories are actually
  "the AI had no idea what this project was for".
