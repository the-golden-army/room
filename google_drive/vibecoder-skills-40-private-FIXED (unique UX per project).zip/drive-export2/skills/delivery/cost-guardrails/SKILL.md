---
name: cost-guardrails
description: Use before launch, when adding any metered service (AI, SMS, serverless, egress, email), and immediately after any surprise bill. Sets hard spending caps, per-account quotas, budget alerts at 50/80/100%, caching and batching that cut usage, and the specific settings on common platforms that stop a $4,000 morning. Also covers AI token costs, which are the newest way small projects go bankrupt overnight.
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# cost-guardrails

## Promise

You know what the app costs per month, you know what it costs at 10x, and no single user, bot, or bug can
spend more than you've decided in advance.

## When to use

- Before launch (Gate 8 of `production-readiness`)
- Adding anything metered: AI/LLM calls, SMS, emails, serverless invocations, bandwidth, storage
- "The bill was way higher than I expected"
- Before a campaign, a launch, or anything that could spike traffic
- When a product is free or has a free tier (free users cost money)
- Any time you're about to give an API key to a system that runs automatically

## When NOT to use

- Fixed-cost hosting with no metered components (still set a billing alert; take 2 minutes)

## The 60-second version

```
1. CAPS ON EVERY METERED SERVICE. Provider-level spend limits first — they're the only ones that
   can't be bypassed by a bug in your code.
2. BILLING ALERTS at 50% / 80% / 100% of your budget, to an email a human reads.
3. PER-USER QUOTAS on anything that costs money per use (AI, SMS, exports, emails).
4. GLOBAL KILL SWITCH on the expensive paths — one env var, no deploy.
5. CACHE the expensive calls. The cheapest API call is the one you don't make.
6. LOG the cost of every expensive operation, so you can see who/what is spending.
7. KNOW THE UNIT ECONOMICS: what does one active user cost you per month?
8. CHECK THE FREE TIER'S ACTUAL LIMITS — and what happens when you exceed them.
```

## Step 1 — Where the money actually goes

| Cost | Typical surprise |
|---|---|
| **AI / LLM tokens** | One viral user, or a loop, or a prompt that grows → hundreds of dollars overnight |
| **Egress / bandwidth** | Usually the hidden giant. Storage is cheap; sending bytes out is not |
| **Serverless invocations** | A bot hitting your endpoint 1M times; a cron that runs per-instance |
| **Database** | Hosting cost scales with size/compute; a runaway table or an unindexed query multiplies it |
| **SMS / phone** | Cents per message, and international rates are much higher |
| **Email** | Cheap until you're on a high tier for volume you didn't expect |
| **Object storage** | Grows forever if nothing deletes; versions and deleted-but-retained objects count |
| **Log/error tracking** | Volume-based; a log loop can cost more than the app |
| **Third-party APIs** | Per-call pricing on maps, search, enrichment, KYC |

**The two classic disasters:**
1. **The loop.** A retry loop, a cron that schedules itself, or a webhook that triggers itself → 100,000
   calls before anyone notices.
2. **The free user.** A free tier with no quota → someone uses it 10,000 times because it's free.

## Step 2 — Caps (in this order)

### 1. Provider-level spend limits (the only real safety net)

| Provider | Setting |
|---|---|
| OpenAI / Anthropic / most AI | Hard monthly spend limit + per-key limits in the dashboard |
| AWS | Budgets + a billing alarm; IAM policies limiting expensive instance types |
| GCP | Budgets + alerts; quota limits per API |
| Vercel | Spend Management → hard cap |
| Cloudflare | Notifications + rate limiting; Workers have a daily request cap option |
| Twilio | Usage triggers that disable sending at a threshold |
| Any | A virtual/one-time card with a limit, if the provider has no cap feature |

Set these **before** you write the feature. Your code-level quota can have a bug; the provider's cap can't.

### 2. Application-level quotas

```ts
// Per-user daily quota on an expensive operation (atomic)
const key = `quota:ai:${userId}:${today()}`;
const used = await redis.incr(key);
await redis.expire(key, 48 * 3600);
if (used > plan.aiCallsPerDay) {
  await redis.decr(key);                                  // don't charge them for a rejected call
  return Response.json({ error: "You've used today's AI credits." }, { status: 429 });
}

// Global daily kill switch: one env var, no deploy
if (Number(await redis.get("spend:ai:today")) > Number(process.env.AI_DAILY_CENTS_CAP)) {
  log("error", "ai.global_cap_hit", { spentCents });
  return Response.json({ error: "This feature is temporarily unavailable." }, { status: 503 });
}
```

### 3. Rate limits

Every expensive endpoint gets one (see `api-abuse-defense`). A bot is the most likely cause of a surprise bill.

### 4. Alerts

```
50% of budget  → email (informational)
80% of budget  → email + a human decision ("is this growth or a bug?")
100% of budget → the provider's own alert + a hard stop if possible
Anomaly        → "today's spend is 3x yesterday's" (most providers can do this)
```

Route alerts to a human's inbox, not a channel that's muted. Verify by triggering one.

## Step 3 — Reduce usage (usually where the real money is)

Before you optimize code, check the design:

| Lever | Typical saving |
|---|---|
| **Caching** | Huge. Cache AI responses for identical inputs; cache geocoding; cache anything deterministic |
| **Cheaper model / tier** | Use the small model by default, the big one only when needed |
| **Shorter prompts** | Trim the system prompt; send only the relevant context, not the whole document |
| **Batching** | One request with 50 items instead of 50 requests |
| **Streaming** | Doesn't cut cost, but it cuts perceived slowness and abandoned requests |
| **Debouncing** | One search call per keystroke is 10x the cost of one per pause |
| **Pagination** | Don't fetch 10,000 rows to show 20 |
| **Compression + CDN** | Often the single biggest cut in a bandwidth bill |
| **Image optimization** | Resize + WebP: frequently 70-90% smaller |
| **Deleting old data** | Logs, uploads, and old versions you'll never read |
| **Lazy/conditional loading** | Don't run the expensive thing unless the user asked for it |

```ts
// Cache expensive deterministic calls
const cacheKey = `ai:summary:${sha256(text)}`;
const cached = await redis.get(cacheKey);
if (cached) return JSON.parse(cached);
const result = await ai.summarize(text);
await redis.setex(cacheKey, 3600, JSON.stringify(result));
return result;
```

## Step 4 — AI costs specifically (the newest way to go bankrupt)

```
BEFORE YOU SHIP AN AI FEATURE:
[ ] A hard monthly spend cap on the provider account
[ ] A separate API key per environment (never reuse the prod key in development)
[ ] A per-user daily quota (and a lower one for free users)
[ ] A max token limit per request, and a max input length
[ ] Log every call: user, model, input tokens, output tokens, estimated cost, latency
[ ] A global daily cap with a kill switch
[ ] Timeouts and no infinite retry loops
[ ] Caching for repeated/identical requests
[ ] The cheapest model that gives an acceptable answer; escalate only when needed
[ ] Alerts at 50/80/100% of the AI budget
[ ] A monthly review: what did AI actually cost per active user?
```

```ts
// Estimate cost before the call, reject if it's too big
const est = estimateTokens(prompt) * PRICE_PER_TOKEN[model];
if (est > MAX_CENTS_PER_CALL) return Response.json({ error: "That request is too large." }, 400);
```

Rule of thumb: **know your cost per active user per month.** If a $10/month user costs you $6 in AI, you
don't have a business; you have a subsidy. Measure it.

## Step 5 — Know your numbers

Write these in `docs/COSTS.md` and review monthly:

| Metric | Why |
|---|---|
| Fixed monthly cost | Hosting, DB, domains, tools |
| Variable cost per user | Bandwidth + storage + AI + emails |
| Cost per active user per month | The number that decides whether the pricing works |
| Cost at 10x traffic | Does the model break, or does it scale linearly? |
| The single biggest line item | Where an optimization actually pays |
| What happens at the free-tier ceiling | Slowdown, hard stop, or a surprise invoice? |

```markdown
# Costs — reviewed 2026-10-20
Fixed:  Vercel $20 + Neon $19 + Resend $0 + Sentry $0 + domain $1  = $40/mo
Variable: AI ~$0.02/user/mo · bandwidth ~$0.01/user/mo · storage ~$0.005/user/mo
Cost per active user: ~$0.04/mo against a $12/mo plan → healthy margin
10x traffic estimate: ~$220/mo fixed+variable (no cliff identified)
Biggest line item: AI (72% of variable). Optimization target: caching summaries.
Caps set: AI $50/mo hard · Vercel $100/mo · alerts 50/80/100% → owner@example.com
```

## Step 6 — The free tier trap

If you offer a free tier:

- [ ] A quota on every expensive operation (not just a rate limit — a *daily/monthly* amount)
- [ ] Email verification (kills casual abuse)
- [ ] A cap on storage per free account
- [ ] The free tier's cost per user is known and acceptable
- [ ] A clear upgrade path when someone hits the limit (that's the point of a free tier)
- [ ] Idle/free accounts don't consume resources (no background jobs for inactive users)

## Non-negotiables

1. **Provider spend caps set before launch**, on every metered service.
2. **Billing alerts at 50/80/100%**, going to a human.
3. **A per-account quota on every money-consuming operation.**
4. **A global kill switch for the expensive paths** (one env var, no deploy).
5. **Every expensive call is logged with its estimated cost.**
6. **The cost per active user per month is known** (and compared to revenue).
7. **Caching is applied to deterministic expensive calls.**
8. **Rate limits on every public expensive endpoint.**
9. **Separate API keys and caps per environment.**
10. **Costs are reviewed monthly** — the first month of every quarter, at minimum.

## Ask the human

1. "What can you afford to spend per month on running this? What's the number where you'd shut it down?"
2. "Are you planning a free tier or a free trial?" *(both cost money — free tiers cost the most)*
3. "How do you feel about a hard cap that turns a feature off if it's hit? Or would you rather get a warning and decide?"
4. "Who should get the billing alerts — just you, or someone else too?"
5. "Is there any part of this that uses AI? Those costs can move fast, so let's cap them on day one."

Never ask: "what's your budget in GCP labels?", "should we use reserved instances?", "what's your egress
optimization strategy?" — decide, then report the numbers.

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| No spend caps anywhere | One bug = a four-figure bill | Provider caps first, always |
| Billing alerts to a dead inbox | You find out from the bank | Alert a human; test it |
| Free tier with no quota | Someone uses it 10,000 times | Per-account daily quotas |
| Retry loops with no cap | 100k calls overnight | Cap attempts; circuit breaker |
| No logging of expensive ops | You can't tell who spent what | Log cost per call |
| Caching nothing | Paying repeatedly for the same answer | Cache deterministic calls |
| Always using the biggest model | 20x the cost for no perceived gain | Small model by default |
| Ignoring egress | The biggest line on the bill | CDN + compression + right-sized images |
| One API key for dev and prod | Dev experiments bill the prod account | Separate keys and caps |
| "We'll optimize when it's a problem" | It's a problem at 3am on the 1st | Caps and quotas now |
| Not knowing cost per user | You can't price the product | Measure it monthly |

## Definition of done

- [ ] Every metered provider has a hard monthly spend cap
- [ ] Billing alerts at 50/80/100%, to a human, tested once
- [ ] Per-account quotas on AI, SMS, exports, emails, and uploads
- [ ] A global kill switch for expensive paths, tested
- [ ] Rate limits on every public expensive endpoint
- [ ] Expensive deterministic calls are cached
- [ ] Every expensive operation logged with an estimated cost
- [ ] `docs/COSTS.md`: fixed, per-user variable, cost per active user, 10x estimate
- [ ] Separate keys and caps per environment
- [ ] A monthly cost review is in someone's calendar

## Works with

- `ai-features-in-production` — AI is the most volatile line item
- `api-abuse-defense` — quotas and rate limits are the enforcement layer
- `performance-and-caching` — efficiency is money
- `production-readiness` — Gate 8
- `secrets-management` — a leaked AI key is a direct financial loss
- `deploy-and-environments` — hosting cost and platform caps
