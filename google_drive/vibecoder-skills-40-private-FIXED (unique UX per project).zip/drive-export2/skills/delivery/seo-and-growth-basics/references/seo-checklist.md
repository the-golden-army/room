# SEO checklist + metadata snippets

---

## Pre-launch technical checklist

```
INDEXING
[ ] Public pages render on the server (content present in `curl` output, not injected by JS)
[ ] robots.txt exists, allows crawling, and points to the sitemap
[ ] sitemap.xml exists, auto-generated, includes all public pages, excludes private ones
[ ] sitemap submitted to Google Search Console (and Bing Webmaster Tools, it's 2 minutes)
[ ] Staging/preview URLs are noindex + behind auth (check: site:staging.example.com in Google → 0 results)
[ ] No `noindex` left on production pages from development
[ ] HTTPS with a valid certificate; HTTP redirects to HTTPS
[ ] One canonical host (www or apex — pick one and 301 the other)
[ ] Canonical tags self-referencing on every page

METADATA
[ ] Unique <title> per page (50-60 chars, includes what it is + who for)
[ ] Unique meta description per page (140-160 chars, written to be clicked)
[ ] Open Graph: og:title, og:description, og:image (1200x630), og:url, og:type, og:site_name
[ ] Twitter card: summary_large_image
[ ] Favicon (and an apple-touch-icon)
[ ] <html lang> set
[ ] One <h1> per page, matching the promise of the page
[ ] Images have alt text (also an accessibility requirement)

STRUCTURE
[ ] Clean, lowercase, hyphenated URLs
[ ] Descriptive internal link anchor text (not "click here")
[ ] Every public page reachable within 3 clicks from the homepage
[ ] 404 page exists, is helpful, and links back to useful places
[ ] Redirects in place for any URL that changed (301, not 302)
[ ] Pagination uses real URLs (page/2), and canonical points to itself, not to page 1

CONTENT
[ ] Each page targets one search intent
[ ] No thin/duplicate pages (tag archives, empty categories → noindex or remove)
[ ] Structured data where relevant (Organization, Product, Article, FAQ) and validated
[ ] Blog/content pages have an author and a date where that matters for trust

SPEED & MOBILE
[ ] Lighthouse mobile: Performance > 90, SEO = 100, Accessibility > 95
[ ] LCP < 2.5s, INP < 200ms, CLS < 0.1
[ ] Responsive: works at 320px, touch targets >= 44px
[ ] Viewport meta tag present, zoom not disabled

MEASUREMENT
[ ] Google Search Console verified (and Bing)
[ ] Analytics installed, privacy-respecting, 5 key events defined and verified firing
[ ] A conversion funnel defined (visit → signup → activation)
```

---

## Metadata snippets

### Next.js (App Router)

```tsx
// app/layout.tsx — site-wide defaults
export const metadata = {
  metadataBase: new URL("https://example.com"),
  title: { default: "Flexbook — class booking for small gyms", template: "%s | Flexbook" },
  description: "Members book classes in 30 seconds. Automatic reminders cut no-shows in half.",
  openGraph: { siteName: "Flexbook", locale: "en_US", type: "website" },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
};

// app/features/reminders/page.tsx — per page
export const metadata = {
  title: "Automatic class reminders that cut no-shows",
  description: "SMS and email reminders sent 24 hours before each class. Studios report 40% fewer no-shows.",
  alternates: { canonical: "https://example.com/features/reminders" },
  openGraph: { images: ["/og/reminders.png"] },
};

// app/sitemap.ts
export default function sitemap() {
  return [
    { url: "https://example.com/", lastModified: new Date() },
    { url: "https://example.com/pricing", lastModified: new Date() },
    { url: "https://example.com/features/reminders", lastModified: new Date() },
  ];
}

// app/robots.ts
export default function robots() {
  return { rules: { userAgent: "*", allow: "/" }, sitemap: "https://example.com/sitemap.xml" };
}
```

### Plain HTML

```html
<title>Automatic class reminders that cut no-shows | Flexbook</title>
<meta name="description" content="SMS and email reminders sent 24 hours before each class. Studios report 40% fewer no-shows.">
<link rel="canonical" href="https://example.com/features/reminders">

<meta property="og:title" content="Automatic class reminders that cut no-shows">
<meta property="og:description" content="SMS and email reminders, 24 hours before every class.">
<meta property="og:image" content="https://example.com/og/reminders.png">   <!-- 1200x630 -->
<meta property="og:url" content="https://example.com/features/reminders">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Flexbook">
<meta name="twitter:card" content="summary_large_image">

<link rel="icon" href="/favicon.ico">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
```

### Blocking a staging site

```html
<meta name="robots" content="noindex, nofollow">
```
Plus: HTTP auth or an IP allowlist on the whole environment. Never rely on `noindex` alone.

---

## Verify it works

```bash
# Is the content in the HTML a crawler sees?
curl -s https://example.com/ | grep -o "<h1[^>]*>.*</h1>" | head -1

# robots + sitemap
curl -s https://example.com/robots.txt
curl -s https://example.com/sitemap.xml | head -20

# Redirects go to the canonical host, once, with 301
curl -sIL http://example.com/ | grep -iE "^HTTP|^location"

# Headers
curl -sI https://example.com/ | grep -iE "content-type|strict-transport|x-robots-tag"
```

Then the real test: **paste the URL into Slack, WhatsApp, and iMessage and look at the preview.** That's
what most people will actually see, and tools won't tell you it's broken.

---

## Landing page copy skeleton

```
H1        [What it is] for [specific audience]. [The main result.]
          e.g. "Class booking for small gyms. Members book in 30 seconds; you get your evenings back."

SUB       One sentence: how it works, or the biggest objection handled.
          "No app download, no contracts. Set up in an afternoon."

CTA       [Start free] or [Book a 15-min demo]        ← ONE button
MICRO     "Free for 50 members. No card needed."      ← removes the risk

PROOF     "Trusted by 240 studios" or one real quote with a name and a photo
VISUAL    The actual product, showing the core screen

── below the fold ──
PROBLEM   "Chasing no-shows, double bookings, and late payments? You're not alone, and it's not your fault."
HOW        1. Add your classes   2. Share your link   3. Get paid automatically   (+3 screenshots)
BENEFITS  3-4 outcomes, each with a screenshot and a one-line explanation
PROOF     3 testimonials with names, roles, and a specific result
PRICING   Clear tiers, what's included, no hidden fees, a money-back line
OBJECTIONS Security, data ownership, migration, cancellation, support hours
FAQ       6 real questions
FINAL CTA The same button again
```
