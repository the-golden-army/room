---
name: seo-and-growth-basics
description: Use when building a public website, landing page, blog, or marketplace — anything that needs people to find it. Covers being indexable in the first place (rendering, sitemap, robots), titles and meta descriptions, Open Graph share previews, structured data, clean URLs, Core Web Vitals, privacy-respecting analytics, and the anatomy of a landing page that converts. Includes the specific mistakes that make AI-built sites invisible to Google.
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# seo-and-growth-basics

## Promise

People can find it, share it, and understand it in five seconds — and you can see which of that is working.

## When to use

- Any public-facing site: marketing page, landing page, blog, docs, marketplace, directory, portfolio
- "How do I get people to find this?" / "Why isn't it on Google?" / "The share preview looks broken"
- Before launching a public site
- Writing a landing page or redoing one that doesn't convert
- Setting up analytics
- Migrating or redesigning a site (don't lose the rankings)

## When NOT to use

- A login-walled app (do the bare minimum: a good `/` page, a share image, and app analytics)

## The 60-second version

```
1. BE INDEXABLE. If the content only exists after JavaScript runs in the browser, you're gambling.
   Render on the server (SSG/SSR) for anything you want found.
2. ONE UNIQUE <title> AND META DESCRIPTION PER PAGE. Written for a human, containing the words
   they'd search for.
3. CLEAN URLS: /pricing, not /page?id=7&ref=x. Lowercase, hyphenated, short, readable.
4. OPEN GRAPH: a share image (1200x630), title, description. Test it in a real chat app.
5. SITEMAP.XML + ROBOTS.TXT, submitted to Google Search Console.
6. FAST. Core Web Vitals count: LCP < 2.5s, INP < 200ms, CLS < 0.1.
7. ANALYTICS that respect privacy, tracking the 3-5 events that matter.
8. A LANDING PAGE that says what it is, who it's for, and what to do — above the fold.
```

## Step 1 — Be indexable (the thing AI-generated SPAs get wrong)

| Setup | Indexable? |
|---|---|
| Static site generator (Astro, Next static, Hugo) | ✅ Best |
| Server-rendered (Next.js SSR, Remix, Nuxt, Rails) | ✅ Good |
| Client-only SPA (Vite + React, no prerender) | ⚠️ Risky — Google can render JS, but it's slower, partial, and other crawlers can't |
| Content behind a login | ❌ And that's fine |
| A page that requires JS to show anything at all | ❌ Usually no |

If you already built a client-only SPA and need SEO: add prerendering (SSG for the public routes), or use a
prerender service, or move the public pages to SSG. This is a real migration, so decide early.

```bash
# Is it actually indexable? Look at what the crawler sees.
curl -s https://example.com/ | head -60          # is the content in the HTML?
curl -s https://example.com/robots.txt
curl -s https://example.com/sitemap.xml
# Or: Search Console → URL Inspection → View crawled page
```

## Step 2 — Metadata (per page, unique)

```tsx
// Next.js App Router — per page
export const metadata = {
  title: "Gym class booking software for small studios | Flexbook",
  description: "Let members book classes in 30 seconds, pay online, and get automatic reminders. Free for your first 50 members.",
  alternates: { canonical: "https://flexbook.example.com/" },
  openGraph: {
    title: "Booking software for small studios",
    description: "Members book in 30 seconds. You get your evenings back.",
    url: "https://flexbook.example.com/",
    siteName: "Flexbook",
    images: [{ url: "https://flexbook.example.com/og.png", width: 1200, height: 630, alt: "Flexbook class schedule" }],
    type: "website",
  },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
};
```

| Element | Rule |
|---|---|
| `<title>` | 50-60 chars. What it is + who it's for. Unique per page. |
| Meta description | 140-160 chars. A sentence a human would want to click. Not keyword soup. |
| Canonical | Self-referencing on every page; prevents duplicate-content splitting |
| OG image | 1200x630 PNG/JPG, under 1MB, readable at thumbnail size, with the value proposition on it |
| `robots` | `noindex` on staging, on thank-you pages, and on anything thin. Verify staging is blocked. |
| Language | `<html lang="en">` and `hreflang` if you have translations |
| Headings | One `<h1>` with the main promise; `<h2>`s that match how people scan |

## Step 3 — Structure

```
/                     landing page (the promise + the CTA)
/pricing              clear plans, no hidden fees
/features/<name>      one page per main use case (these are what actually rank)
/blog/<slug>          content that answers real questions
/about, /contact      trust
/legal/privacy, /legal/terms
/sitemap.xml          auto-generated
/robots.txt           + a sitemap reference
```

URL rules: lowercase, hyphens not underscores, no dates where avoidable, no `/p/123`, keep them stable.
**If you must change a URL, 301 it** to the new one. Broken redirects are the fastest way to lose rankings.

## Step 4 — Structured data (cheap, and it changes how you appear)

```html
<script type="application/ld+json">
{ "@context": "https://schema.org", "@type": "SoftwareApplication",
  "name": "Flexbook", "applicationCategory": "BusinessApplication",
  "offers": { "@type": "Offer", "price": "29.00", "priceCurrency": "USD" } }
</script>
```

Worth adding: `Organization`/`LocalBusiness` (name, address, phone, logo, opening hours),
`Product`/`SoftwareApplication` with `aggregateRating` (only if the reviews are real), `Article` for blog
posts, `FAQPage` for FAQ sections, `BreadcrumbList`. Validate at `search.google.com/test/rich-results`.

## Step 5 — Speed (it's a ranking factor and a conversion factor)

Everything in `performance-and-caching`, and specifically:

| Metric | Target | Biggest lever |
|---|---|---|
| LCP | < 2.5s | Hero image size/format, server response time, font loading |
| INP | < 200ms | Less JS, no long tasks, defer third-party scripts |
| CLS | < 0.1 | Image/video dimensions, no injected banners above content |

Run Lighthouse on **mobile** — mobile-first indexing means Google judges you by the phone experience.

## Step 6 — Analytics that respect privacy

| Need | Pick |
|---|---|
| "How many visitors and where from?" | Plausible, Umami, Fathom, Simple Analytics (cookieless, no banner needed) |
| Product analytics (funnels, retention) | PostHog (self-host or EU cloud), or the cookieless tools above |
| Error tracking | Sentry (separate concern — see `errors-logs-and-monitoring`) |
| Avoid by default | Session recording, heatmaps, cross-site trackers — ask before adding |

Set up Google Search Console (free) for any public site. It tells you what people search before they find
you, and it's the only real SEO feedback loop.

Track **3-5 events**, not 50:

```
1. signup_started
2. signup_completed        ← the money event
3. core_action_completed   ← the thing the product is for
4. checkout_started
5. plan_upgraded
```

Then one funnel: visit → signup_started → signup_completed → core_action_completed. Where do people drop?
Fix that step. That's growth, and it's a lot cheaper than more traffic.

## Step 7 — The landing page that converts

Above the fold (what you see without scrolling):

```
1. HEADLINE: what it is and who it's for — in words a customer would use
   "Class booking for small gyms. Members book in 30 seconds; you get your evenings back."
2. SUBHEAD: one sentence on how it works, or the main objection handled
3. ONE CTA: a button with a verb. "Start free" or "Book a demo". One, not three.
4. PROOF: a number, a logo wall, or one real quote
5. A VISUAL: the actual product, not an abstract illustration
```

Then below the fold:

```
6. The problem, stated better than the visitor could state it
7. How it works — 3 steps, with screenshots
8. Features framed as outcomes ("never chase payments again", not "Stripe integration")
9. Social proof: 3 specific testimonials with names, photos, and a result
10. Pricing: clear, no "contact us" unless it's genuinely enterprise
11. Objections: security, migration, cancellation, support response time
12. FAQ: the 6 questions sales keeps answering
13. Final CTA, repeated
```

Copy rules:
- Write at a 8th-grade reading level. Short sentences. Concrete over clever.
- Say what it **does**, not what it **is** ("we're a cutting-edge platform" says nothing)
- Use the customer's own words — get them from support emails, reviews, and sales calls
- Every feature becomes a benefit: "automatic reminders" → "stop chasing no-shows"
- Numbers beat adjectives: "saves 6 hours a week" beats "saves time"

## Step 8 — Content (the slow, real version of SEO)

- **One page per search intent.** "gym booking software" and "how to reduce class no-shows" are different pages
- Answer the question in the first two paragraphs, then elaborate
- Write for the person, not the crawler. Keyword stuffing stopped working in 2012
- Internal links: every page links to 2-4 related pages, with descriptive anchor text
- Update rather than abandon: a refreshed page beats a new thin one
- Expect 3-6 months. Anything promising faster is selling something

## The AI-built-site mistakes

| Mistake | Fix |
|---|---|
| Client-only SPA, no server rendering | SSG/SSR for public pages |
| Every page has the same `<title>` | Unique per page |
| No meta description at all | 140-160 chars, human-written |
| No OG image → share previews are blank | 1200x630 image per important page |
| No sitemap, no robots.txt | Generate both; submit in Search Console |
| Staging site indexed (and outranking production) | `noindex` + auth on staging |
| Headline says nothing ("Welcome to our platform") | Say what it does and for whom |
| Three CTAs above the fold, none obvious | One |
| Walls of lorem-ipsum-shaped filler | Concrete, specific copy |
| No analytics, so nobody knows what works | 5 events + Search Console |
| `Disallow: /` left in robots.txt from development | Check it before launch |
| No HTTPS or a broken certificate | Fix before anything else |

## Non-negotiables

1. **Public pages are server-rendered** (or prerendered) so crawlers see real content.
2. **Every page has a unique title and description.**
3. **An OG image exists** and has been tested in a real share sheet.
4. **`sitemap.xml` and `robots.txt` exist**, and the sitemap is submitted.
5. **Staging is not indexable.**
6. **Core Web Vitals pass on mobile.**
7. **Analytics are privacy-respecting** and track the 5 events that matter.
8. **One clear CTA above the fold.**
9. **URLs are clean, stable, and 301-redirected if changed.**
10. **Search Console is set up** — it's free and it's the feedback loop.

## Ask the human

1. "How do you expect people to find this — Google search, social media, word of mouth, or ads?"
2. "Who exactly is this for? If you had to describe one ideal customer, what do they do all day?"
3. "What words would they type into Google to find something like this?" *(write down the actual phrases)*
4. "What's the one action you want someone to take on the homepage?"
5. "Do you have any testimonials, numbers, or customer stories we can put on the page?"
6. "Are you okay with analytics, and do you want the kind that needs a cookie banner?" *(recommend: the private kind)*
7. "Is there a competitor whose site you like? What specifically works about it?"

Never ask: "do you want JSON-LD?", "what's your keyword density target?", "should we nofollow external links?"

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| "Build it and they will come" | Nobody comes | Distribution is half the product |
| SEO as an afterthought on a JS-only SPA | Invisible or poorly indexed | Decide rendering early |
| Keyword stuffing | Ranks worse, reads terribly | Write for humans |
| Buying links / link farms | Penalties | Earn links with useful content |
| Vague headline ("innovative solutions") | Nobody knows what you do | Say it plainly |
| 5 CTAs | Zero CTAs | One |
| No proof | Nobody believes you | Numbers, names, screenshots |
| Staging indexed | Competes with your real site | `noindex` + auth |
| Broken redirects after a redesign | Rankings gone | Map old → new with 301s |
| Tracking everything | Analysis paralysis, privacy risk | 5 events |
| Ignoring mobile | Most traffic and all indexing is mobile | Mobile-first everything |

## Definition of done

- [ ] Public pages render server-side; content is in the HTML (`curl` proves it)
- [ ] Unique title + description per page; canonical set
- [ ] OG image (1200x630) tested in a real share preview (Slack/WhatsApp/iMessage)
- [ ] `sitemap.xml` + `robots.txt` live; sitemap submitted to Search Console
- [ ] Staging blocked from indexing
- [ ] Core Web Vitals pass on mobile Lighthouse
- [ ] Structured data added where relevant and validated
- [ ] Analytics installed (privacy-respecting), 5 events defined and firing
- [ ] Landing page: one promise, one CTA, proof, pricing, FAQ
- [ ] URLs clean; any changed URL 301-redirected
- [ ] HTTPS with a valid certificate

## Reference

[`references/seo-checklist.md`](references/seo-checklist.md) — the copy-paste technical checklist plus
Next.js/HTML metadata snippets.

## Works with

- `performance-and-caching` — Core Web Vitals are both
- `ux-writing-and-onboarding` — the landing page copy
- `design-system-and-visual-language` — the OG image and visual consistency
- `data-privacy-and-pii` — analytics, consent, and tracking
- `stack-selection` — the rendering decision that determines whether SEO is possible
- `production-readiness` — the pre-launch pass
