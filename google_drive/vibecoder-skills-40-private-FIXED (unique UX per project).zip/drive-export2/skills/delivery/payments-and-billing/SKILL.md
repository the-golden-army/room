---
name: payments-and-billing
description: Use whenever money moves — adding checkout, subscriptions, trials, coupons, invoices, refunds, or a pricing page. Covers choosing a provider, computing prices on the server (never trusting the browser), the webhook events you must handle, idempotency so nobody is charged twice, failed-payment recovery, refunds and disputes, tax handling, and the go-live checklist. The most expensive thing to get wrong in a small product.
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# payments-and-billing

## Promise

People pay, get access immediately, get a receipt, and never get charged twice. You can see every
transaction, handle a refund without panic, and survive a failed payment.

## When to use

- Adding checkout, subscriptions, one-off payments, or a pricing page
- "Add payments" / "let people pay me" / "charge monthly"
- Trials, coupons, upgrades, downgrades, cancellations
- Refunds, disputes, chargebacks
- Invoices, receipts, VAT/sales tax
- Going from test mode to live
- Anything where the client sends a price (stop, read the money rules)

## When NOT to use

- Free products (still read the entitlement section — you'll add billing later)

## The 60-second version: the ten money rules

```
1. NEVER trust an amount from the browser. Look the price up on the server.
2. Money is an integer of the smallest unit (cents). Never a float.
3. Use a hosted checkout (Stripe Checkout) — you never touch card data, and PCI scope stays tiny.
4. Webhooks are how you learn the truth. Verify the signature. Always.
5. Webhook handlers must be idempotent — providers retry, sometimes for days.
6. Access is granted by YOUR database, updated from webhooks — not by a redirect after checkout.
7. Log every money event. If you can't reconstruct it, you can't support it.
8. Handle failure: card declined, payment failed, subscription past due, canceled, refunded, disputed.
9. Receipts and invoices are not optional; they're why people trust you.
10. Tax is real. Either use Stripe Tax, use a merchant of record, or get advice. Don't ignore it.
```

## Step 1 — Choose the provider (decide, don't ask)

| Situation | Pick | Why |
|---|---|---|
| Default for most products | **Stripe** | Best docs, best tooling, hosted checkout, customer portal, tax tooling |
| Don't want to handle VAT/sales tax | **Paddle** or **Lemon Squeezy** | Merchant of record: they handle tax and compliance, you take a bigger cut |
| Marketplace / paying out to others | **Stripe Connect** | Split payments, onboarding, payouts |
| Simple one-off payments, no subscriptions | Stripe Payment Links | No code at all |
| Local/in-person | SumUp, Square | Hardware |

Don't build your own card handling. Don't store card numbers. Don't let card data touch your server —
hosted checkout fields (Stripe Checkout / Elements) keep you out of PCI scope almost entirely.

## Step 2 — The money rules (enforced, not suggested)

```ts
// ✅ Server looks up the price and sends Stripe a PRICE ID, not an amount
const plan = await db.plan.findUniqueOrThrow({ where: { id: planId } });
const session = await stripe.checkout.sessions.create({
  mode: "subscription",
  line_items: [{ price: plan.stripePriceId, quantity: 1 }],   // server-side ID
  customer: customerId,
  success_url: `${APP_URL}/welcome?session_id={CHECKOUT_SESSION_ID}`,
  cancel_url: `${APP_URL}/pricing`,
  client_reference_id: userId,      // so you know who this belongs to
  metadata: { userId, planId },
});

// ❌ Never
const { amount } = req.body;                        // attacker sends amount: 1
stripe.charges.create({ amount: req.body.amount }); // and pays one cent
```

Storage: `amount_cents integer not null check (amount_cents >= 0)` + `currency char(3)`.
Never `float`, never `money` type, never store "12.00" as a decimal for accounting.

## Step 3 — The data model for billing

Keep a **local mirror** of what matters. Your app must be able to answer "does this user have access?"
without calling Stripe.

```sql
CREATE TABLE subscriptions (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id              uuid NOT NULL REFERENCES users(id),
  stripe_subscription_id text UNIQUE,
  stripe_customer_id   text NOT NULL,
  plan_id              uuid NOT NULL REFERENCES plans(id),
  status               text NOT NULL,   -- trialing|active|past_due|canceled|unpaid|incomplete
  current_period_end   timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  created_at           timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX subscriptions_user_active ON subscriptions (user_id) WHERE status IN ('trialing','active');

CREATE TABLE invoices (            -- mirrored from Stripe for display + support
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  stripe_invoice_id text UNIQUE,
  amount_cents integer NOT NULL, currency char(3) NOT NULL,
  status text NOT NULL,            -- paid|open|void|uncollectible
  hosted_invoice_url text, created_at timestamptz NOT NULL DEFAULT now()
);
```

**Entitlements** — one function, used everywhere:

```ts
export async function hasAccess(userId: string, feature: string): Promise<boolean> {
  const sub = await db.subscription.findFirst({
    where: { userId, status: { in: ["trialing", "active"] } },
  });
  if (!sub) return false;
  if (sub.currentPeriodEnd && sub.currentPeriodEnd < new Date()) return false;   // safety net
  const plan = await db.plan.findUniqueOrThrow({ where: { id: sub.planId } });
  return plan.features.includes(feature);
}
```

Check entitlements **server-side, on every request** that grants something valuable. A paywall that's only
in the UI is a free product.

## Step 4 — Webhooks (the truth arrives here)

```ts
// app/api/webhooks/stripe/route.ts
export async function POST(req: Request) {
  const raw = await req.text();                                  // RAW body, before any parsing
  const sig = req.headers.get("stripe-signature")!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (e) {
    log("warn", "stripe.bad_signature", { ip: req.headers.get("x-forwarded-for") });
    return new Response("invalid signature", { status: 400 });
  }

  // Idempotency: record the event id; if it's already there, we've handled it
  try { await db.processedEvent.create({ data: { id: event.id } }); }
  catch { return new Response("duplicate", { status: 200 }); }

  try {
    switch (event.type) {
      case "checkout.session.completed":      await onCheckoutComplete(event.data.object); break;
      case "customer.subscription.created":
      case "customer.subscription.updated":   await syncSubscription(event.data.object); break;
      case "customer.subscription.deleted":   await onCancel(event.data.object); break;
      case "invoice.payment_succeeded":       await onInvoicePaid(event.data.object); break;
      case "invoice.payment_failed":          await onPaymentFailed(event.data.object); break;
      case "charge.refunded":                 await onRefund(event.data.object); break;
      case "charge.dispute.created":          await onDispute(event.data.object); break;   // alert a human!
      default: log("debug", "stripe.unhandled_event", { type: event.type });
    }
  } catch (e) {
    log("error", "stripe.handler_failed", { eventId: event.id, type: event.type, error: String(e) });
    return new Response("handler error", { status: 500 });   // 500 → Stripe retries
  }

  return new Response(null, { status: 200 });   // ack fast; do heavy work in a job if needed
}
```

Rules:
- Verify the signature against the **raw** body. Parsing first breaks the signature
- Return 200 fast; queue anything slow
- Handle events **out of order** (they don't arrive in order) — sync state, don't assume sequences
- Dedupe by event ID with a unique constraint
- Return 500 only for errors a retry could fix
- Log every event type; alert on `charge.dispute.created` and repeated `invoice.payment_failed`
- Use the **Stripe CLI** to replay events locally during development
- In production, check the Stripe dashboard's webhook attempts page when something looks wrong

Events you must handle: `checkout.session.completed`, `customer.subscription.created|updated|deleted`,
`invoice.payment_succeeded|payment_failed`, `charge.refunded`, `charge.dispute.created`.

## Step 5 — After the payment (the flow that gets forgotten)

```
1. User completes hosted checkout → Stripe redirects to success_url
2. Webhook arrives → you grant access (DB), send a receipt email, log it
3. User lands on success_url → the page POLLS or waits for the entitlement
   ⚠️ The redirect can arrive BEFORE the webhook. Never grant access on the redirect alone.
4. Success page shows: what they bought, what's next, a link to the receipt
5. Receipt email from Stripe (enable it in Stripe settings) or from you
```

Handle the race: on the success page, poll `/api/me/subscription` for a few seconds, and show a friendly
"we're confirming your payment…" state. Never "payment not found" panic.

## Step 6 — Failure and recovery

| Event | What the user sees | What you do |
|---|---|---|
| Card declined at checkout | "Your bank declined the card. No charge was made. Try another card." | Nothing to do; Stripe handles it |
| Subscription payment fails | "We couldn't take your payment. Update your card to keep access." | Email immediately; Stripe retries on its schedule; restrict access after N days |
| Subscription past due | Access still on, with a visible warning | Nag by email; link to the billing portal |
| Subscription canceled | Access until period end, then read-only | Keep data for 30+ days; tell them how to resume |
| Refund requested | Refund in Stripe → webhook → revoke access if it was a full refund | Log it; email confirmation |
| Dispute/chargeback | A human must respond with evidence | Alert immediately; respond before the deadline |

**Dunning** (recovering failed payments): enable Stripe's automatic retry and email sequence, add your own
in-app banner, and make "update card" one click via the Stripe customer portal. Most failed payments are
expired cards, not unwilling customers — recovering them is the cheapest revenue you'll ever make.

## Step 7 — Refunds, disputes, tax

- **Refunds:** issue in Stripe (never by cash transfer), let the webhook revoke access, email confirmation.
  Have a written refund policy and link it at checkout
- **Disputes:** respond with evidence (receipt, logs, delivery proof, IP, timestamps). This is why you log
  money events. Prevention: clear product name on the statement, an obvious way to contact you, fast refunds
- **Tax:** VAT (EU/UK), sales tax (US states), GST (AU/NZ). Options: Stripe Tax (you remain the seller),
  or a merchant of record (Paddle/Lemon Squeezy handle it). Don't wing it — pick one and document it
- **Invoices:** must include your legal entity, the customer's details, tax IDs, and a sequential number
  where required. Stripe can generate and email them
- **Accounting:** keep the records your jurisdiction requires (often 7-10 years), even after account deletion

## Step 8 — Test mode → live checklist

```
[ ] Live keys in production env only; test keys everywhere else
[ ] Webhook endpoint created in LIVE mode, with the live signing secret (different from test!)
[ ] A real $1 (or minimum-amount) live payment completed end to end, then refunded
[ ] Receipt email verified as delivered (check spam — configure SPF/DKIM/DMARC first)
[ ] Customer portal link works and lets a user update their card
[ ] Cancellation flow tested: cancel → access until period end → access removed
[ ] Failed payment tested with Stripe's test card 4000 0000 0000 0341
[ ] Dispute alert routed to a human
[ ] Prices and products match what the pricing page says (a mismatch is a legal problem)
[ ] Refund policy and terms linked at checkout
[ ] Tax configured (Stripe Tax or merchant of record)
[ ] Statement descriptor recognizable (reduces disputes)
[ ] Billing alerts: any dispute, any 3 failed payments in 10 minutes
```

## Non-negotiables

1. **The server computes the price.** Never accept an amount, currency, or discount from the client.
2. **Money is integer minor units.**
3. **Webhook signatures are verified** against the raw body, on every request.
4. **Webhook handlers are idempotent.**
5. **Access is granted by your database from webhook state**, never by a redirect.
6. **Every money event is logged**, with the Stripe IDs.
7. **Card data never touches your server** (hosted checkout / Elements).
8. **Failed payments, disputes and refunds have defined behavior** and alert a human.
9. **Entitlements are checked server-side** on every protected action.
10. **A live payment was completed and refunded** before you announce the launch.

## Ask the human

1. "How do you want to get paid — once, monthly, or both? And are there different levels?"
2. "Roughly how much does one customer pay? Are we talking $10 or $1,000?" *(affects fraud and dispute handling)*
3. "Where are your customers? Different countries mean different tax rules." *(Stripe Tax vs merchant of record)*
4. "What's your refund policy? Even 'no refunds' is a policy — it just needs to be visible."
5. "Do you need invoices with your company details and tax number?"
6. "If a payment fails, should people lose access immediately, or get a grace period?"
7. "Do you sell to businesses that need a proper invoice, or mostly to individuals?"

Never ask: "Stripe or Braintree?", "should we use webhooks or polling?", "what's your dunning schedule?"

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| Price sent from the browser | Anyone pays 1 cent | Server looks up the price ID |
| `float` for money | Rounding errors in invoices | Integer cents |
| Granting access on the success redirect | Race conditions; webhooks can be delayed | Grant from the webhook; poll on the page |
| No signature verification | Anyone can POST "payment succeeded" | Verify, always |
| Processing webhooks twice | Double access, double emails | Idempotency by event ID |
| Not handling failed payments | Silent churn | Dunning + in-app banner |
| Paywall only in the UI | Free product for anyone who opens devtools | Server-side entitlement check |
| Storing card numbers | PCI nightmare | Never; use hosted fields |
| No receipt | Chargebacks, angry customers | Stripe receipts or your own |
| Ignoring tax | A letter from a tax authority | Stripe Tax or merchant of record |
| Test keys in production | Payments silently do nothing | Separate keys per env; verify in the dashboard |
| No plan for refunds | Ad-hoc, inconsistent, expensive | Written policy + a one-click process |

## Definition of done

- [ ] Prices live server-side; the client sends only an identifier
- [ ] Money stored as integer minor units with a currency
- [ ] Hosted checkout (or Elements); no card data on your server
- [ ] Webhooks: signature verified, idempotent, all required events handled, retries safe
- [ ] Subscription state mirrored locally; entitlements checked server-side
- [ ] Failed-payment flow: in-app warning + email + one-click card update
- [ ] Cancellation, refund and dispute flows defined; disputes alert a human
- [ ] Receipts/invoices sent and verified as delivered
- [ ] Tax approach chosen and configured
- [ ] One real live payment completed, verified, and refunded
- [ ] Billing events logged with Stripe IDs; money dashboard/query exists

Full webhook handler + go-live checklist: [`references/stripe-recipes.md`](references/stripe-recipes.md).

## Works with

- `appsec-hardening` — webhook forgery is a top vulnerability
- `api-abuse-defense` — idempotency and webhook security
- `saas-architecture` — plans, seats, entitlements, tenant billing
- `data-privacy-and-pii` — invoices contain personal data; retention matters
- `reliability-and-incidents` — payment incidents are S1
- `errors-logs-and-monitoring` — alerting on failed payments and disputes
