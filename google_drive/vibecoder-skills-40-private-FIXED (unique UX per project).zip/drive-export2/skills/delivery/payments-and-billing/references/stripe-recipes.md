# Stripe recipes (copy-paste shapes)

Adapt to your stack; keep the *shape*. All money is integer minor units.

---

## 1. Client wrapper (one place, with a timeout)

```ts
// lib/stripe.ts
import Stripe from "stripe";
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
  timeout: 10_000,
  maxNetworkRetries: 2,       // idempotent GETs/creates only
});
```

---

## 2. One-off payment (Checkout Session)

```ts
export async function createCheckout(req: Request) {
  const user = await requireUser(req);
  const { planId, seats = 1 } = z.object({ planId: z.string().uuid(), seats: z.number().int().min(1).max(50) })
    .parse(await req.json());

  const plan = await db.plan.findUniqueOrThrow({ where: { id: planId } });   // server-side price

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const c = await stripe.customers.create({ email: user.email, metadata: { userId: user.id } });
    customerId = c.id;
    await db.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } });
  }

  const session = await stripe.checkout.sessions.create({
    mode: plan.interval ? "subscription" : "payment",
    customer: customerId,
    line_items: [{ price: plan.stripePriceId, quantity: seats }],   // NOT an amount
    allow_promotion_codes: true,
    billing_address_collection: "auto",
    tax_collection: { enabled: true },                // if using Stripe Tax
    automatic_tax: { enabled: true },
    success_url: `${APP_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${APP_URL}/pricing`,
    client_reference_id: user.id,
    metadata: { userId: user.id, planId, seats: String(seats) },
  });

  log("info", "checkout.created", { userId: user.id, planId, sessionId: session.id });
  return Response.json({ url: session.url }, { status: 201 });
}
```

---

## 3. Subscription sync (handles out-of-order events)

```ts
export async function syncSubscription(sub: Stripe.Subscription) {
  const userId = sub.metadata.userId
    ?? (await db.user.findFirst({ where: { stripeCustomerId: sub.customer as string } }))?.id;
  if (!userId) { log("error", "stripe.no_user_for_subscription", { subId: sub.id }); return; }

  const priceId = sub.items.data[0]?.price.id;
  const plan = await db.plan.findFirst({ where: { stripePriceId: priceId } });
  if (!plan) { log("error", "stripe.unknown_price", { priceId }); return; }

  const periodEnd = sub.items.data[0]?.current_period_end;

  await db.subscription.upsert({
    where: { stripeSubscriptionId: sub.id },
    create: {
      userId, planId: plan.id, stripeSubscriptionId: sub.id,
      stripeCustomerId: sub.customer as string, status: sub.status,
      currentPeriodEnd: periodEnd ? new Date(periodEnd * 1000) : null,
      cancelAtPeriodEnd: sub.cancel_at_period_end,
    },
    update: {
      planId: plan.id, status: sub.status,
      currentPeriodEnd: periodEnd ? new Date(periodEnd * 1000) : null,
      cancelAtPeriodEnd: sub.cancel_at_period_end,
    },
  });
  log("info", "subscription.synced", { userId, subId: sub.id, status: sub.status, planId: plan.id });
}
```

---

## 4. Failed payment (dunning)

```ts
export async function onPaymentFailed(invoice: Stripe.Invoice) {
  const userId = await userIdFromCustomer(invoice.customer as string);
  if (!userId) return;

  await db.subscription.updateMany({
    where: { stripeCustomerId: invoice.customer as string },
    data: { status: "past_due" },
  });

  await sendEmail(userId, "payment-failed", {
    amount: formatMoney(invoice.amount_due, invoice.currency),
    updateCardUrl: await billingPortalUrl(userId),
    attemptCount: invoice.attempt_count,
  });

  log("warn", "payment.failed", { userId, invoiceId: invoice.id, attempt: invoice.attempt_count });
  // Alert a human on attempt >= 2
}
```

---

## 5. Billing portal (self-serve: update card, cancel, download invoices)

```ts
export async function POST(req: Request) {
  const user = await requireUser(req);
  const session = await stripe.billingPortal.sessions.create({
    customer: user.stripeCustomerId!,
    return_url: `${APP_URL}/settings/billing`,
  });
  return Response.json({ url: session.url });
}
```

Ship this. It removes 80% of billing support ("how do I update my card / cancel / get a receipt").

---

## 6. Refund

```ts
export async function POST(req: Request) {
  const admin = await requireRole(req, "admin");
  const { paymentIntentId, amountCents, reason } = z.object({
    paymentIntentId: z.string(), amountCents: z.number().int().positive().optional(),
    reason: z.enum(["requested_by_customer", "duplicate", "fraudulent"]),
  }).parse(await req.json());

  const refund = await stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount: amountCents,             // omit for a full refund
    reason,
  });

  await db.auditLog.create({ data: {
    actorId: admin.id, action: "refund.issued",
    targetId: paymentIntentId, metadata: { amountCents, reason, refundId: refund.id },
  }});
  log("info", "refund.issued", { adminId: admin.id, paymentIntentId, amountCents, refundId: refund.id });
  return Response.json({ refundId: refund.id, status: refund.status });
}
```

Then handle `charge.refunded` in the webhook to revoke access and email the customer.

---

## 7. Test cards

| Card | Result |
|---|---|
| `4242 4242 4242 4242` | Success |
| `4000 0000 0000 0002` | Generic decline |
| `4000 0000 0000 9995` | Insufficient funds |
| `4000 0000 0000 0341` | Succeeds, then fails on later subscription payments |
| `4000 0000 0000 3220` | 3D Secure required |
| `4000 0000 0000 0259` | Dispute risk / fraudulent |

Any future expiry, any CVC, any ZIP. Use `stripe listen --forward-to localhost:3000/api/webhooks/stripe`
in development, and `stripe events resend <event_id>` to replay.

---

## 8. Go-live checklist (print this)

```
BEFORE THE FIRST REAL CUSTOMER
[ ] Business details completed in Stripe (legal entity, address, support email, phone)
[ ] Bank account connected and a payout test done
[ ] Statement descriptor set (what customers see on their card statement)
[ ] Live products/prices created and matched to the pricing page
[ ] Customer emails enabled in Stripe (receipts, failed payments, trial endings)
[ ] Sending domain verified (SPF, DKIM, DMARC) so receipts don't go to spam
[ ] Webhook endpoint registered in LIVE mode with the live signing secret in production env
[ ] Tax: Stripe Tax enabled, or using a merchant of record
[ ] Refund policy + terms of service linked at checkout
[ ] Support email reachable and monitored
[ ] Live $1 payment completed end to end, then refunded
[ ] Cancellation flow tested with a real subscription
[ ] Dispute alert routed to a human inbox
[ ] Billing dashboard/query: revenue today, active subscriptions, failed payments
[ ] Console access restricted to named people, MFA on
```

---

## 9. The money query set you'll need

```sql
-- Revenue today
SELECT sum(amount_cents)/100.0 AS revenue, currency
FROM invoices WHERE status='paid' AND created_at >= current_date GROUP BY currency;

-- Active subscriptions
SELECT p.name, count(*) FROM subscriptions s JOIN plans p ON p.id = s.plan_id
WHERE s.status IN ('trialing','active') GROUP BY p.name;

-- Failed payments in the last 7 days
SELECT user_id, count(*), max(created_at) FROM invoices
WHERE status='open' AND created_at > now() - interval '7 days' GROUP BY user_id ORDER BY 2 DESC;

-- Churn last month
SELECT count(*) FROM subscriptions
WHERE status='canceled' AND updated_at > now() - interval '30 days';
```
