---
name: reliability-and-incidents
description: Use when preparing for failure — before launch, after an outage, or when the human asks "what happens if this breaks?". Covers backups you have actually restored, single points of failure, kill switches and feature flags, graceful degradation when Stripe or an AI provider is down, severity levels, incident comms templates, a status page, the 3am runbook, and blameless postmortems. Turns "I hope it doesn't break" into "I know exactly what I'd do".
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# reliability-and-incidents

## Promise

Nothing is perfectly reliable. This is about failing well: noticing fast, stopping the bleeding in minutes,
recovering predictably, and never making the same mistake twice.

## When to use

- Before launch (Gate 3 and Gate 6 of `production-readiness`)
- "What happens if it goes down?" / "What if Stripe is down?" / "What if we lose the database?"
- **During an incident** — jump to the response section
- After an incident — the postmortem
- When a dependency, a region, or a single server is a single point of failure
- When the app starts handling money or other people's critical work

## When NOT to use

- Projects where downtime genuinely costs nothing (but still do backups)

## The 60-second version: the reliability ladder

```
1. PREVENT   backups + tested restore, no single points of failure, safe deploys, limits
2. DETECT    uptime check, synthetic critical path, error alerts (see errors-logs-and-monitoring)
3. RESPOND   a severity level, a one-page runbook, a kill switch, an owner
4. RECOVER   rollback, restore, failover, degrade gracefully
5. LEARN     a blameless postmortem with one concrete action item
```

## Step 1 — What "reliable enough" means (SLO-lite)

Don't promise 100%. Promise something you can measure and survive.

| Availability | Downtime allowed | Right for |
|---|---|---|
| 99% | ~7 hours/month | Side projects, internal tools |
| 99.9% | ~43 minutes/month | Most small SaaS. A realistic target. |
| 99.95% | ~22 minutes/month | Paid products with business users |
| 99.99% | ~4 minutes/month | Needs real redundancy and real work |

More useful than uptime: **how much data can you lose** (RPO) and **how fast can you be back** (RTO).

```
RPO (Recovery Point Objective): how much data can we lose?  → backup frequency
RTO (Recovery Time Objective):  how fast must we be back?   → restore + rollback speed
```

Write both down for the project: *"RPO: 1 hour. RTO: 30 minutes."* Every decision follows from those two
numbers. If RPO is "5 minutes" you need continuous backup/PITR; if it's "24 hours" a nightly dump is fine.

## Step 2 — Backups (and the restore you must test)

| Question | Answer to write down |
|---|---|
| What's backed up? | Database ✅, uploaded files ✅, config/secrets (separately) ✅ |
| How often? | Matches the RPO |
| Where? | A different provider/region than the primary |
| Encrypted? | Yes |
| Who can restore? | Named people, MFA, and they've practised |
| Retention? | 7-30 days + any legal requirement |
| **Last restore test?** | **Date, by whom, result.** Quarterly, minimum. |

```bash
# The restore drill (run it, don't just read it)
pg_dump "$DATABASE_URL" > backup-$(date +%F).sql
createdb restore_test && psql restore_test < backup-$(date +%F).sql
psql restore_test -c "SELECT count(*) FROM users; SELECT max(created_at) FROM bookings;"
# Does the data look right and recent? Then:
dropdb restore_test
```

Also: **backups of things that aren't the database.** Object storage (versioning + a bucket replication or
a periodic sync), configuration, DNS records, and anything that only exists in one person's laptop.

## Step 3 — Single points of failure

Walk the path a request takes and find everything that has no backup:

| Component | Single point? | Mitigation |
|---|---|---|
| App server | Yes, if 1 instance | Run 2+, or accept it and document it |
| Database | Yes, usually | Managed service with automated failover; know the failover time |
| Object storage | Rarely | Provider-managed durability |
| DNS | Yes | A registrar with a good record; don't touch it casually |
| Email provider | Yes | Have a second provider configured, or queue and retry |
| Payment provider | Yes | Can't avoid; make sure failure is graceful and visible |
| AI provider | Yes | Fallback model/provider, or a graceful "AI is unavailable" |
| One person who knows how to deploy | **Very common** | The runbook + a rehearsal with someone else |
| TLS certificate | Yes if manual | Auto-renewal + an expiry alert |

You don't have to fix them all. You have to **know** them and have decided. Write the list in
`docs/RUNBOOK.md` with "accepted, because…" next to each.

## Step 4 — Kill switches and graceful degradation

Build these before you need them:

```ts
// 1. Maintenance mode: one env var, no deploy needed
if (process.env.MAINTENANCE_MODE === "true" && !isAdmin(user)) {
  return new Response(maintenancePageHtml, { status: 503, headers: { "Retry-After": "3600" } });
}

// 2. Feature flags: turn off one risky feature without a deploy
if (!flags.isEnabled("new-checkout", user)) return renderOldCheckout();

// 3. Graceful degradation: the dependency is down, the app isn't
try {
  summary = await ai.summarize(text);
} catch {
  summary = null;                      // the page still renders, just without the AI part
  log("warn", "ai.unavailable", { provider: "openai" });
}

// 4. Circuit breaker: stop hammering a dead dependency
if (breaker.isOpen("stripe")) return queueForLater(job);   // retry when it recovers
```

Design question for every third-party dependency: **"if this is down, what does my user see?"**
For each one, pick: fail the action with a clear message / queue and retry / degrade the feature / use a
fallback provider. Anything is better than a 500 or a silent failure.

## Step 5 — During an incident

**Sequence, in this order:**

```
1. DECLARE IT.            Say "this is an incident, severity X". Don't fix quietly at 2am.
2. STOP THE BLEEDING.     Roll back / kill switch / maintenance mode / block the attack.
                          Restore service first, diagnose second.
3. COMMUNICATE.           Even one line: "We know X is broken, we're working on it, next update in 30 min."
4. FIX FORWARD or ROLL BACK — whichever is faster and safer. Usually roll back.
5. VERIFY.                Run the smoke test. Watch the error rate for 15 minutes.
6. CLOSE IT.              Tell people it's fixed, and what you're doing so it doesn't recur.
7. POSTMORTEM.            Within 48 hours. Blameless. One action item, with an owner and a date.
```

### Severity levels

| Sev | Meaning | Response | Examples |
|---|---|---|---|
| **S1** | Down, or data loss, or money actively wrong for many users | Drop everything. Page the owner. Update every 30 min. | Site down, payments failing, data breach |
| **S2** | A core feature is broken for some users, or all users are degraded | Fix within hours, communicate same-day | Login broken, uploads failing, emails not sending |
| **S3** | Minor feature broken, workaround exists | Fix this week | A report is wrong, a filter misbehaves |
| **S4** | Cosmetic, or an internal annoyance | Backlog | A typo, a layout glitch |

### Comms templates

```
INTERNAL / STATUS PAGE (during)
"Investigating — We're aware that [symptom] and we're looking into it. Next update in 30 minutes.
 14:02 UTC"

"Identified — The cause is [one line, plain]. We're rolling back the release now. 14:20 UTC"

"Monitoring — A fix is live. We're watching error rates. 14:55 UTC"

"Resolved — [What happened] is fixed. All systems normal. We'll publish a short write-up. 15:10 UTC"

TO AFFECTED USERS (after)
"Hi [name],
 Between 14:00 and 14:55 UTC today, [what broke] wasn't working.
 What happened: [one plain sentence, no blame, no jargon]
 What we did: [rolled back / restored / fixed]
 Your data: [explicitly: nothing was lost / these records were affected]
 What we're changing: [one concrete thing]
 Sorry about that. [Name]"
```

Never: blame a person, speculate publicly about a cause before you know it, or go silent.

## Step 6 — The 3am runbook

`docs/RUNBOOK.md` is written for a tired person who didn't build the thing. Structure:

```
1. HOW TO TELL IT'S REAL        → uptime alert? error spike? a human? check the status page + error tracker
2. THE FIVE-MINUTE TRIAGE       → is it the DB? the last deploy? a dependency? traffic?
3. STOP THE BLEEDING (in order) → maintenance mode → feature flag → rollback → scale → disable payments
4. THE EXACT COMMANDS           → copy-paste, no thinking required
5. KNOWN FAILURE MODES          → symptom → likely cause → first check → fix
6. ESCALATION                   → who to call, in what order, with numbers
7. BACKUPS & RESTORE            → where they are, how to restore, last test date
8. ACCESS                       → where every credential lives (not the values)
```

Test the runbook by handing it to someone who's never seen the project and asking them to follow it.

## Step 7 — The postmortem (blameless, short)

```markdown
# Incident: [what users experienced] — 2026-10-20

## Summary
Between 14:00 and 14:55 UTC, checkout was unavailable for all users (~40 attempted purchases).
Cause: a deploy included a migration that renamed a column still read by the previous build.

## Impact
- 40 failed checkouts, 0 incorrect charges
- No data loss
- Duration: 55 minutes

## Timeline
13:58  Deploy v1.8.0 shipped (migration + code in one step)
14:02  Error-rate alert fired (we noticed automatically ✅)
14:05  Declared S1; started rollback
14:20  Rollback complete; error rate returning to normal
14:55  Smoke test passed; incident closed

## What went well
- Alerting fired within 4 minutes
- Rollback worked as documented

## What went wrong
- Migration and code shipped together (we knew better; the checklist wasn't followed)
- No staging test of the migration against production-shaped data

## Action items
1. [ ] Split migrations into their own pipeline step — owner: X, by 2026-10-27
2. [ ] Add a migration check to the pre-deploy checklist — owner: Y, by 2026-10-24
3. [ ] Test migrations on a production-shaped staging dump — owner: X, by 2026-11-03

## Not a root cause
"This was a human error" is not a root cause. The process allowed it — that's what we fixed.
```

## Non-negotiables

1. **Backups exist, and a restore has been tested** within the last quarter.
2. **Every incident gets a severity and an owner**, even when the team is one person.
3. **Stop the bleeding before diagnosing.** Restore service, then find out why.
4. **Rollback is the default fix.** Investigate afterwards.
5. **Communicate early and honestly**, even when you have nothing new to say.
6. **Kill switches and feature flags exist** for risky features.
7. **Every dependency has a documented "what if it's down" answer.**
8. **Postmortems are blameless** and end with action items that have owners and dates.
9. **The runbook is tested by someone who didn't write it.**
10. **Single points of failure are listed and either fixed or consciously accepted in writing.**

## Ask the human

1. "If this went down for a full day, what would it cost you — money, trust, contracts?"
2. "How much data could you lose before it's a disaster — an hour, a day, a week?"
3. "How fast do you need it back — minutes, or is a few hours survivable?"
4. "Who should I contact if something's wrong and you're not available?"
5. "Are you okay with a short maintenance window now and then, or does it need to be always-on?"
6. "Is there any part of this that absolutely cannot fail — even if everything else does?"

Never ask: "what's your RPO/RTO?", "active-active or active-passive?", "do you want a status page?"

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Backups configured, restore never tested | You discover the backup is empty during the outage | Quarterly restore drill |
| Fixing in production under pressure | Makes it worse, no record | Roll back, then fix properly |
| No communication during an outage | Users assume you're dead | Update every 30 min, even with nothing new |
| Postmortem that blames a person | People hide mistakes next time | Fix the process |
| "It won't happen again" with no action item | It happens again | One concrete change, with an owner |
| No kill switch | Every fix requires a deploy | Flags + maintenance mode |
| All eggs in one provider/region with no plan | One outage = your outage | Document it; mitigate the critical ones |
| Only one person can deploy or restore | That person's holiday is your outage | Runbook + rehearsal |
| Silence after an incident | Users churn quietly | Tell them what happened and what changed |
| Restoring from a backup without verifying | You restore the wrong/empty snapshot | Verify, then restore |

## Definition of done

- [ ] RPO and RTO written down; backups match them
- [ ] A restore has been performed successfully within the last quarter (date recorded)
- [ ] Backups cover: database, uploaded files, and config; stored offsite; encrypted
- [ ] Single points of failure listed, with mitigations or written acceptance
- [ ] Kill switch (maintenance mode) and feature flags exist and have been tested
- [ ] Every third-party dependency has a documented degraded-mode behavior
- [ ] `docs/RUNBOOK.md` exists: triage, stop-the-bleeding commands, known failure modes, escalation
- [ ] Severity levels and comms templates written and available
- [ ] Status page (or a status section on your site) ready to use
- [ ] Postmortem template in the repo; every incident gets one within 48 hours
- [ ] Someone other than the author has followed the runbook successfully

## Works with

- `production-readiness` — Gates 3 and 6
- `deploy-and-environments` — safe deploys and rollback
- `errors-logs-and-monitoring` — how you find out
- `data-model-and-migrations` — backup before destructive changes
- `secrets-management` — access during an incident
- `launch-and-handoff` — the launch-day runbook
- `payments-and-billing` — money incidents are the worst kind
