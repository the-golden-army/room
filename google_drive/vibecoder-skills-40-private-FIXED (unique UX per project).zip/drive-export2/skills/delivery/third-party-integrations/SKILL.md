---
name: third-party-integrations
description: Use whenever the app talks to an external service — email, SMS, storage, AI, maps, search, payments, calendar, CRM, or any HTTP API. Covers wrapping each integration in one module, timeouts, retries with backoff and jitter, idempotency, circuit breakers, error classification, inbound webhooks, provider rate limits, graceful degradation when the provider is down, and how to test without sending real emails or spending real money.
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# third-party-integrations

## Promise

Your app keeps working when someone else's service doesn't. No infinite hangs, no double-sends, no silent
failures, no surprises when a provider has a bad day.

## When to use

- Adding any external API (email, SMS, storage, AI, maps, search, CRM, calendars, Slack)
- "It's slow" or "it hangs" — often an outbound call with no timeout
- A provider outage, or a provider changing/rate-limiting you
- Duplicate emails / duplicate charges (retry without idempotency)
- Reviewing why an integration is unreliable
- Planning an exit from a vendor

## When NOT to use

- Calling your own internal services (same principles, lower stakes)

## The 60-second version: the eight rules

```
1. ONE MODULE per integration. Never scatter `fetch("https://api.vendor.com")` through the codebase.
2. TIMEOUT every call. 5-10s for interactive, more for batch. No call may hang forever.
3. RETRY only what's safe: network errors, 429, 5xx. Never blindly retry a non-idempotent write.
4. BACKOFF + JITTER: 300ms → 600ms → 1.2s, plus randomness. Never hammer a struggling service.
5. IDEMPOTENCY: every write carries a key, so a retry doesn't send a second email or charge twice.
6. CLASSIFY errors: retryable vs permanent vs "needs a human". Log accordingly.
7. DEGRADE gracefully: decide in advance what the user sees when this provider is down.
8. OBSERVE: log every outbound call with provider, operation, status, and duration.
```

## Step 1 — Wrap it (the single most valuable habit)

```ts
// lib/email.ts — the ONLY file that talks to the email provider
import { Resend } from "resend";

const client = new Resend(process.env.EMAIL_API_KEY);

export async function sendEmail(input: {
  to: string; subject: string; template: string; data: Record<string, unknown>;
  idempotencyKey?: string;
}) {
  const started = Date.now();
  try {
    const res = await withTimeout(
      client.emails.send({
        to: input.to,
        subject: input.subject,
        react: renderTemplate(input.template, input.data),
        headers: input.idempotencyKey ? { "Idempotency-Key": input.idempotencyKey } : undefined,
      }),
      10_000,
    );
    log("info", "email.sent", { provider: "resend", template: input.template, ms: Date.now() - started });
    return { ok: true as const, id: res.data?.id };
  } catch (e) {
    log("error", "email.failed", { provider: "resend", template: input.template, error: classify(e) });
    return { ok: false as const, error: classify(e) };
  }
}
```

Benefits: swapping providers is one file; mocking in tests is one module; adding a timeout, retry, or
circuit breaker is one change instead of forty.

## Step 2 — The resilient call

```ts
// lib/http.ts
export async function resilientFetch(
  url: string,
  init: RequestInit & { timeoutMs?: number; retries?: number; idempotencyKey?: string } = {},
) {
  const { timeoutMs = 8000, retries = 3, idempotencyKey, ...rest } = init;
  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        ...rest,
        signal: ctrl.signal,
        headers: { ...rest.headers, ...(idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {}) },
      });

      if (res.ok) return res;

      // Retry only on the conditions that are worth retrying
      const retryable = res.status === 429 || res.status >= 500;
      if (!retryable || attempt === retries) {
        throw new IntegrationError(`HTTP ${res.status}`, { status: res.status, retryable: false });
      }
      await sleep(backoff(attempt, res.headers.get("retry-after")));
    } catch (e) {
      lastError = e;
      if (!isRetryable(e) || attempt === retries) break;
      await sleep(backoff(attempt));
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError;
}

const backoff = (attempt: number, retryAfter?: string | null) =>
  retryAfter ? Number(retryAfter) * 1000
             : Math.min(8000, 300 * 2 ** attempt) + Math.random() * 300;   // + jitter
```

**Jitter matters.** Without it, every client retries at the same instant and turns a brief provider blip
into a self-inflicted DDoS.

## Step 3 — Classify errors

| Class | Examples | Action |
|---|---|---|
| **Retryable** | timeout, connection reset, 429, 500/502/503/504 | Retry with backoff |
| **Permanent** | 400, 401, 403, 404, 422 | Fail fast; log; alert if unexpected |
| **Rate limited** | 429 with `Retry-After` | Respect the header; queue; slow down globally |
| **Needs a human** | provider account suspended, invalid API key, quota exhausted | Alert immediately, don't retry |
| **Partial** | 207, or a batch where some items failed | Process the successes, retry the failures |

Never retry a non-idempotent write without an idempotency key. "We sent the email twice" is always this bug.

## Step 4 — Circuit breaker (stop hammering a dead service)

```ts
// Simple in-process breaker: fine for a single instance
const state = new Map<string, { failures: number; openUntil: number }>();

export async function withBreaker(name: string, fn: () => Promise<Response>) {
  const s = state.get(name);
  if (s && s.openUntil > Date.now()) throw new IntegrationError(`${name} circuit open`, { retryable: true });

  try {
    const res = await fn();
    state.set(name, { failures: 0, openUntil: 0 });
    return res;
  } catch (e) {
    const cur = state.get(name) ?? { failures: 0, openUntil: 0 };
    cur.failures++;
    if (cur.failures >= 5) cur.openUntil = Date.now() + 30_000;   // stop trying for 30s
    state.set(name, cur);
    throw e;
  }
}
```

For multi-instance apps, keep the breaker state in Redis. Without one, a provider outage turns your whole
app slow: every request waits for a timeout before failing.

## Step 5 — Background the slow stuff

Anything that can take more than a second, or that the user doesn't need to wait for, goes in a job:

```
Request: validate → persist intent (status: pending) → enqueue job → return 202/200
Worker:  call provider → update record (status: sent/failed) → retry with backoff → alert after N failures
```

```sql
CREATE TABLE jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,              -- 'send_email', 'generate_pdf'
  payload jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',   -- pending|running|done|failed
  attempts int NOT NULL DEFAULT 0,
  run_after timestamptz NOT NULL DEFAULT now(),
  last_error text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX jobs_pending ON jobs (status, run_after) WHERE status IN ('pending','failed');
```

A `jobs` table + one worker process is enough for 95% of apps. You don't need Kafka.

## Step 6 — Inbound webhooks from providers

Same rules as `payments-and-billing` and `api-abuse-defense`:

```
[ ] Verify the signature (or a shared secret / HMAC) on every request
[ ] Raw body before parsing
[ ] Dedupe by the provider's event ID (unique constraint)
[ ] Respond 200 fast; queue the work
[ ] Return 500 for errors a retry could fix; 200 for permanent ones (or you'll be retried forever)
[ ] Log every webhook; alert on a failure streak
[ ] Handle out-of-order delivery (sync state, don't assume sequence)
[ ] Rate limit the endpoint against unknown callers; IP-allowlist if the provider publishes ranges
```

## Step 7 — Provider-specific gotchas

| Integration | The thing that bites |
|---|---|
| **Email** | SPF/DKIM/DMARC or it lands in spam. Handle bounces and complaints or your domain gets blacklisted. Separate transactional from marketing. Don't send from a no-reply address people can't answer. |
| **SMS / WhatsApp** | Costs real money per message → hard rate limits and quotas. Opt-in is legally required in most places. Watch for international pricing. |
| **Object storage** | Buckets are private by default (keep it that way). Signed URLs with short expiry. Set CORS correctly or uploads fail mysteriously. Egress bandwidth is the hidden bill. |
| **AI / LLM** | Timeouts are long (stream it). Costs scale with usage (cap it). Providers have outages (have a fallback). Never send data you can't afford to leak. See `ai-features-in-production`. |
| **Maps / geocoding** | Billable per request → cache aggressively. Terms often forbid storing results permanently. |
| **Search service** | Indexing is eventually consistent. Reindexing takes time — plan for it. Have a fallback to DB search. |
| **Calendar (Google/Microsoft)** | OAuth scopes are broad; refresh tokens expire. Two-way sync has conflict resolution. Timezones will hurt you. |
| **Slack / chat** | Webhook URLs are secrets. Rate limits per channel. Verify the signing secret. |
| **Any webhook sender** | They retry for up to 3 days. Your endpoint must stay idempotent that whole time. |

## Step 8 — Test without side effects

```
[ ] Every integration is behind an interface, so tests can mock it
[ ] Sandbox/test credentials for every provider (Stripe test keys, a dev email domain)
[ ] No test can send a real email, SMS, or payment — enforce it with a guard in CI env
[ ] A "provider down" test: force a failure and confirm the app degrades gracefully
[ ] A "provider slow" test: force a timeout and confirm the request doesn't hang
[ ] Contract tests: assert on what you send and what you parse (catch upstream shape changes)
```

## Step 9 — The exit plan

Before you're locked in, write down: how would I leave?

- The vendor's data export format and whether it's complete
- What's coupled (data model, auth, SDK calls spread through the codebase — the wrapper prevents this)
- The migration cost in days
- The alternative provider

Keep the integration behind the wrapper and the exit cost stays small.

## Non-negotiables

1. **One module per integration.** No scattered `fetch` calls to vendors.
2. **Every outbound call has a timeout.**
3. **Retries use backoff + jitter**, and only for retryable errors.
4. **Every write is idempotent** (a key, or a unique constraint).
5. **Errors are classified** and logged with provider, operation, status, and duration.
6. **A degraded mode exists for every dependency** — decided in advance, not invented during an outage.
7. **Secrets for providers are per-environment and rotatable** (see `secrets-management`).
8. **Provider rate limits are respected**, and you queue instead of hammering.
9. **Tests never trigger real side effects.**
10. **Every inbound webhook is signature-verified and deduped.**

## Ask the human

1. "Which outside services does this need to talk to? Let's list them — email, payments, storage, anything else."
2. "If one of them went down for a day, what should your users see: an error, a delay, or a feature that's just missing?"
3. "Are there any of these you're already paying for, or already using somewhere else?"
4. "How much are you okay spending per month across all of these?" *(caps follow from this)*
5. "Is there data you'd never want sent to an outside company?" *(some integrations must be self-hosted or skipped)*

Never ask: "axios or fetch?", "exponential or decorrelated jitter?", "should we add a service mesh?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| `fetch(vendor)` scattered across 30 files | Provider swap = a rewrite | One wrapper module |
| No timeout | One hung provider takes the whole app down | Timeout every call |
| Retry in a tight loop | You DDoS the provider (and yourself) | Backoff + jitter, capped |
| Retrying a non-idempotent write | Duplicate emails/charges | Idempotency key |
| Catching and ignoring errors | Silent failure; nobody knows | Classify, log, alert |
| Assuming the provider is always up | No plan when it isn't | Degraded mode, written down |
| Real API calls in tests | Costs money, sends emails, pollutes data | Mock the wrapper |
| No logging of outbound calls | "It failed and we don't know why" | Log provider, op, status, duration |
| Trusting webhook payloads without verification | Anyone can trigger actions | Verify signatures |
| Storing provider responses forever | Often violates terms, and it rots | Cache with a TTL, respect the terms |
| No plan for provider rate limits | Sudden 429 storms | Queue + respect `Retry-After` |

## Definition of done

- [ ] Every integration is behind one wrapper module with a timeout and typed errors
- [ ] Retries: backoff + jitter, retryable errors only, capped attempts
- [ ] All writes are idempotent; duplicate delivery is handled
- [ ] Errors classified; every call logged with provider, operation, status, duration
- [ ] Circuit breaker or equivalent on anything that can hang
- [ ] Slow/non-blocking work runs in background jobs with retry and a dead-letter path
- [ ] Inbound webhooks verified, deduped, fast-acked, logged, alerting on failure streaks
- [ ] A degraded-mode answer exists for every dependency (written in `docs/RUNBOOK.md`)
- [ ] Tests mock the wrappers; no test can send a real email/SMS/payment
- [ ] Provider rate limits and quotas known, respected, and monitored

## Works with

- `payments-and-billing` — the most important integration you'll have
- `ai-features-in-production` — AI providers, with cost and safety on top
- `reliability-and-incidents` — dependency outages
- `secrets-management` — where the API keys live
- `api-abuse-defense` — inbound webhook security
- `errors-logs-and-monitoring` — integration failure alerting
- `cost-guardrails` — per-call costs add up fast
