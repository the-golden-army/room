---
name: deploy-and-environments
description: Use when taking an app from localhost to a real URL — choosing a host, setting up dev/staging/production, wiring CI/CD, configuring domains, DNS and TLS, handling database migrations during deploy, and making deploys repeatable and reversible. Covers zero-downtime basics, preview deploys for reviewing changes, secrets in CI, and the rollback you will eventually need at the worst possible moment.
metadata:
  category: delivery
  version: 1.0.0
  value: "$100"
  group: delivery
---

# deploy-and-environments

## Promise

Shipping is boring. One command, repeatable, reversible, and the same every time — whether it's a Tuesday
morning or a Friday emergency.

## When to use

- First deploy of anything
- "Where should I host this?", "How do I put it online?", "How do I point my domain at it?"
- Setting up CI/CD, staging, or preview environments
- A deploy broke something and you need a safer process
- Adding a database migration to a running app
- Moving hosts, adding a region, or handling a domain/DNS change

## When NOT to use

- Local development setup (that's `project-blueprint`)

## The 60-second version

```
1. FOUR ENVIRONMENTS (minimum three): local → preview (per branch) → staging → production.
   Staging is production's twin: same shape, fake data, separate keys.
2. DEPLOY IS ONE COMMAND, run by a machine, not by you at a keyboard.
3. CI runs: install from lockfile → lint → test → build → (migrate) → deploy → smoke test.
4. DATABASE MIGRATIONS run as a separate, explicit step — never silently as part of the app boot.
5. SECRETS live in the host/CI, never in the repo. Per environment.
6. ROLLBACK is one command and has been rehearsed before you need it.
7. DOMAIN: DNS + TLS with auto-renewal + a calendar reminder for the domain itself.
8. PREVIEW DEPLOYS per pull request, so changes are seen before they're merged.
```

## Step 1 — Choose the host (decide, don't ask)

| Situation | Pick | Notes |
|---|---|---|
| Next.js / modern frontend, want zero ops | Vercel, Netlify, Cloudflare Pages | Preview deploys for free. Watch the bill at scale. |
| Full-stack app with a DB, want simple | Railway, Render, Fly.io | One service, one database, predictable pricing |
| Want cheap + control | A VPS (Hetzner $5-20/mo) + Coolify or Dokku | Cheapest at scale, most responsibility |
| Containers, need portability | Fly.io, Railway, or any host running your Dockerfile | Dockerfile = no lock-in |
| Enterprise / compliance / existing cloud | AWS/GCP/Azure with a platform layer | Only when someone requires it |
| Static site | Cloudflare Pages, Netlify, GitHub Pages | Free, fast, no server to break |
| Need a specific country (data residency) | Pick a host with that region | Say so in the brief |

Selection checklist: does it have **preview deploys**, **automatic TLS**, **one-click rollback**,
**a spending cap**, **a region near your users**, and **logs you can read without SSH**? Those six features
are worth more than any benchmark.

## Step 2 — The four environments

| Env | Purpose | Data | Keys | Who can deploy |
|---|---|---|---|---|
| **Local** | Development | Fake, seeded | Dev keys | You |
| **Preview** | Review a branch before merge | Fake/seeded | Test keys | Anyone with a PR |
| **Staging** | Final check before production | Production-*shaped*, anonymized | Test keys | You + CI |
| **Production** | Real users | Real | Live keys | CI only (ideally) |

Rules:
- **Never point production code at a staging database** (or vice versa). One env var, one value, per env
- **Staging must resemble production**: same build, same env var names, same migrations. The only
  differences are the data and the keys
- **Production data never goes to staging or local.** If you need realistic data, anonymize a dump
- **Protect production deploys**: require tests green, require a review, and log who deployed what

## Step 3 — The pipeline

```yaml
# .github/workflows/ci.yml
name: CI
on: [push, pull_request]

jobs:
  check:
    runs-on: ubuntu-latest
    permissions: { contents: read }
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci                        # from the lockfile, never `npm install`
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test
      - run: npm run build
      - run: npx osv-scanner --lockfile=package-lock.json

  deploy-staging:
    if: github.ref == 'refs/heads/main'
    needs: check
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build
      - run: npm run db:migrate            # explicit step, before the new code serves traffic
        env: { DATABASE_URL: ${{ secrets.STAGING_DATABASE_URL }} }
      - run: npm run deploy:staging
      - run: ./scripts/smoke-test.sh "$STAGING_URL"   # verify, don't assume

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment: production               # requires approval, holds the prod secrets
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build
      - run: npm run db:migrate
        env: { DATABASE_URL: ${{ secrets.PRODUCTION_DATABASE_URL }} }
      - run: npm run deploy:production
      - run: ./scripts/smoke-test.sh "$PROD_URL"
```

Order matters: **build → test → migrate → deploy → verify.** Migrations go before the deploy when they're
additive (the expand phase) and after when they're contractive. Never let the app boot with a schema it
doesn't understand.

## Step 4 — Migrations in a live system

```
[ ] The migration is backward compatible with the currently running code
    (the old code must keep working while the new code rolls out)
[ ] It follows expand → backfill → contract across releases (see data-model-and-migrations)
[ ] It's a separate pipeline step, visible in the logs, not hidden in app startup
[ ] It's idempotent (safe to re-run)
[ ] A backup exists before any destructive part
[ ] It was run against production-shaped data first
[ ] Deployments and migrations are never both "figure it out at runtime"
```

## Step 5 — Zero-downtime basics

- **Health checks:** the platform waits for `/api/health` before sending traffic to a new instance
- **Graceful shutdown:** on SIGTERM, stop accepting new requests, finish in-flight ones, then exit
- **Rolling deploys:** at least 2 instances so one can restart while the other serves
- **Drain connections:** close DB/Redis pools cleanly on shutdown
- **Serve old assets during rollout:** keep hashed asset filenames, and keep the previous build's assets
  available for a few minutes (users on the old page shouldn't 404)

```ts
// Graceful shutdown
process.on("SIGTERM", async () => {
  server.close(async () => { await db.$disconnect(); process.exit(0); });
  setTimeout(() => process.exit(1), 10_000);   // don't hang forever
});
```

## Step 6 — Domains, DNS, TLS

```
1. Buy/renew the domain at a registrar YOU control, with MFA, auto-renew ON, and a calendar reminder
2. Point DNS at the host (A/ALIAS for root, CNAME for www and subdomains)
3. Issue TLS (automatic on Vercel/Netlify/Cloudflare; Let's Encrypt elsewhere) and verify auto-renewal
4. Force HTTPS + HSTS; redirect one canonical host (www → apex, or the reverse — pick one)
5. Emails: SPF, DKIM and DMARC on the sending domain, or every password reset lands in spam
6. Remove dangling CNAMEs (subdomain takeover risk)
7. Record: registrar login, expiry date, DNS provider, and who owns it — in docs/RUNBOOK.md
```

## Step 7 — Rollback (before you need it)

```
Roll back CODE:   vercel rollback / git revert <sha> && git push / redeploy the previous image tag
Roll back MIGRATION: only the contract phase is reversible — which is why you did expand/contract
Roll back CONFIG: revert the env var in the dashboard, redeploy
Roll back a FEATURE: flip the feature flag (fastest, safest — build the flag in from the start)
```

Write the exact commands in `docs/RUNBOOK.md`. Then **rehearse once** on staging. A rollback you've never
performed is a rollback that will fail at 3am.

## Step 8 — Preview deploys

The highest-value cheap practice in modern deployment: every pull request gets a URL.

```
- Review the actual change, not the diff
- Share with a non-technical human: "click this and tell me if it feels right"
- Run the smoke test against the preview before merging
- Each preview gets its own test database and test keys
```

## Non-negotiables

1. **Deploys are automated.** No manual FTP, no `git pull` on a server, no "let me SSH in and fix it".
2. **CI installs from the lockfile.**
3. **Tests run before deploy; a red build doesn't ship.**
4. **Migrations are an explicit, logged step.**
5. **Secrets live in the host/CI, per environment, never in the repo.**
6. **Rollback is one command, documented, and rehearsed.**
7. **Production is protected**: review + green tests + audit trail of who deployed what.
8. **Staging exists and is used** before anything reaches production.
9. **Every deploy is verified by a smoke test**, not by "it looks fine".
10. **Domain, DNS and TLS ownership is documented** with renewals in a calendar.

## Ask the human

1. "Where do you want this to live, and do you already pay for hosting anywhere?"
2. "What domain do you want, and do you already own it? Who's the login with?"
3. "Do you want changes to go live as soon as you push, or do you want to approve each release?"
4. "How much can this cost per month? Should I design for the free tier, or is a small bill fine?"
5. "Is there anyone who should be able to see a change before it goes live?" *(preview deploys)*
6. "If a release goes wrong, how fast does it need to be undone — minutes, or is an hour okay?"

Never ask: "blue-green or canary?", "Dockerfile or buildpacks?", "which CI provider?" — decide and explain
in one line.

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| Deploying by pushing to production and hoping | No verification, no rollback | CI + smoke test |
| `git pull` on the server as the deploy process | Drift, mystery state | Automated deploy |
| Editing files directly on the production server | The next deploy wipes it; nobody knows what changed | Change in git, always |
| No staging; "we'll test in prod" | Users are your QA | Staging or preview deploys |
| Running migrations automatically on app boot | Two instances racing, partial states | Explicit pipeline step |
| Destructive migration + code deploy in one step | Old code breaks instantly | Expand/contract |
| Secrets in CI logs | Leaked | Mask, least privilege, OIDC |
| No rollback plan | A bad deploy becomes an outage | Rehearsed rollback |
| Deploys on Friday afternoon | Ruined weekend | Morning, mid-week |
| No idea who deployed what | No accountability | CI logs + release tags |
| Domain in someone else's account | You lose the domain one day | Your registrar, your name, MFA, auto-renew |

## Definition of done

- [ ] One-command deploy, run by CI, from a clean checkout
- [ ] CI: install from lockfile → lint → typecheck → test → build → migrate → deploy → smoke test
- [ ] Local / preview / staging / production exist, with separate databases and keys
- [ ] No production data outside production
- [ ] Secrets in the host/CI only; per environment; not in the repo or the logs
- [ ] Health endpoint used by the platform; graceful shutdown implemented
- [ ] Rollback command documented in `docs/RUNBOOK.md` and rehearsed on staging
- [ ] Domain + TLS + auto-renewal verified; DNS records owned by the human; renewals in a calendar
- [ ] Email authentication (SPF/DKIM/DMARC) configured for the sending domain
- [ ] Feature flags or a kill switch for risky changes
- [ ] `docs/RUNBOOK.md` says exactly how to deploy, verify, and roll back

## Works with

- `reliability-and-incidents` — what happens when a deploy goes wrong
- `secrets-management` — where the keys live per environment
- `production-readiness` — Gate 6
- `testing-and-verification` — the smoke test that verifies the deploy
- `data-model-and-migrations` — the migration step
- `cost-guardrails` — hosting cost and caps
- `project-blueprint` — the runbook lives in `docs/`
