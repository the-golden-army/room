---
name: testing-and-verification
description: Use before saying "it works" — when adding tests to a vibe-coded project, when there are no tests and you still need confidence, or after a bug reaches production. Defines the small set of tests that actually catch disasters (critical paths, money, auth, ownership, data integrity), the verification ladder for projects with no test suite, how to use fake data safely, and how to keep tests from becoming flaky noise.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# testing-and-verification

## Promise

You know it works because you proved it — with tests where they're worth writing, and with a repeatable
verification script everywhere else. Not because it looked fine when you clicked it once.

## When to use

- Before any launch (Gate 1 of `production-readiness`)
- Adding or changing anything involving money, auth, permissions, or data integrity
- "How do I know this works?" / "Did you test it?"
- A bug reached production and you want to stop it recurring
- Inheriting a codebase with no tests
- You're about to refactor (tests are what make refactoring safe)

## When NOT to use

- Prototypes you'll delete this week (but do verify the critical path manually)

## The 60-second version: the 12 tests that catch 90% of disasters

If you write nothing else, write these:

```
AUTH & ACCESS
 1. A user can sign up, verify, log in, and log out
 2. A user CANNOT read another user's resource (IDOR) — for every resource type
 3. A non-admin CANNOT reach an admin route
 4. Login is rate limited (11 rapid attempts → 429)

MONEY
 5. A payment creates exactly one charge, even if submitted twice (idempotency)
 6. The amount charged comes from the server, not the request (tamper the price → rejected)
 7. A webhook is rejected without a valid signature
 8. A failed payment does NOT grant access

DATA
 9. Creating the core record persists it and reading it back returns what was written
10. Deleting a user removes (or anonymizes) their data everywhere
11. A unique business rule is enforced (double booking, duplicate email, etc.)

CRITICAL PATH
12. Signup → do the core action → see the result → it persists after a refresh
```

Twelve tests. That's a weekend's work for most apps, and it covers the things that end companies.

## Step 1 — Decide what deserves a test

| Test it | Don't test it |
|---|---|
| Money and payments | The framework's own behavior |
| Authentication and permissions | Simple getters and setters |
| Anything with a business rule ("one booking per class") | Third-party libraries |
| Data integrity (constraints, cascades) | Markup and styling details |
| The critical user paths | Configuration constants |
| Anything that would embarrass you if broken | Code that's about to be deleted |
| A bug you just fixed (regression test) | 100% of everything |

**Coverage is a bad target.** 80% coverage of getters is worthless; 20% coverage of payments is priceless.
Aim for *coverage of risk*.

## Step 2 — The shape of the test suite (for solo builders)

Forget the pyramid; you're one person. Use a **barbell**:

```
        ┌─────────────────────────────────┐
  FEW   │  Unit tests on pure logic       │  pricing, permissions, date math, parsing
        └─────────────────────────────────┘
        ┌─────────────────────────────────┐
  MOST  │  Integration / API tests        │  hit the real endpoints with a test DB
        └─────────────────────────────────┘
        ┌─────────────────────────────────┐
  FEW   │  End-to-end tests               │  3-5 critical paths in a real browser
        └─────────────────────────────────┘
```

Most of your tests should be **API/integration tests**: they're fast, they don't break when you restyle a
button, and they actually cover the logic that matters (auth, validation, permissions, money).

```ts
// tests/bookings.test.ts — integration test, real DB (test schema), real HTTP handler
import { describe, it, expect, beforeEach } from "vitest";

describe("POST /api/bookings", () => {
  beforeEach(async () => { await resetDb(); });

  it("creates a booking for a logged-in user", async () => {
    const user = await createUser({ email: "a@b.co" });
    const cls  = await createClass({ capacity: 10 });

    const res = await POST(buildRequest("/api/bookings", {
      method: "POST",
      user,
      body: { classId: cls.id, seats: 2 },
    }));

    expect(res.status).toBe(201);
    const booking = await db.booking.findFirst({ where: { userId: user.id } });
    expect(booking?.seats).toBe(2);
  });

  it("rejects another user's class id gracefully (404, not 500)", async () => { /* ... */ });

  it("uses the server's price, not the client's", async () => {
    const res = await POST(buildRequest("/api/bookings", { user, body: { classId, seats: 1, priceCents: 1 } }));
    const booking = await db.booking.findFirst();
    expect(booking.priceCents).toBe(cls.priceCents);   // 1 cent was ignored
  });

  it("doesn't create a second booking when the same request is retried", async () => {
    const key = "idem-123";
    await POST(req({ body, headers: { "idempotency-key": key } }));
    await POST(req({ body, headers: { "idempotency-key": key } }));
    expect(await db.booking.count()).toBe(1);
  });
});
```

```ts
// tests/e2e/booking.spec.ts — Playwright, the critical path
test("a member books a class and sees it in their schedule", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Email").fill(TEST_USER.email);
  await page.getByLabel("Password").fill(TEST_USER.password);
  await page.getByRole("button", { name: "Sign in" }).click();

  await page.getByRole("link", { name: "Classes" }).click();
  await page.getByRole("button", { name: "Book" }).first().click();
  await expect(page.getByText("You're booked")).toBeVisible();

  await page.reload();
  await expect(page.getByText("You're booked")).toBeVisible();      // it persisted
});
```

## Step 3 — The verification ladder (when there are no tests)

No test framework? Fine. Climb as far as the project justifies:

| Rung | What | Time |
|---|---|---|
| 0 | Click through it yourself, in a deployed environment, in a private window | 5 min |
| 1 | A written checklist of the critical paths (`docs/SMOKE-TEST.md`) so it's repeatable | 20 min |
| 2 | A `curl`/HTTP script that exercises the API end to end (see reference) | 1 hour |
| 3 | A scripted browser check (Playwright) for the 3-5 critical paths | half a day |
| 4 | Those checks running in CI on every push | + 1 hour |
| 5 | Synthetic monitoring in production (a check every 5-15 min) | + 1 hour |

Rungs 0-2 are mandatory before launch. Rungs 3-5 depend on the stakes: if downtime costs money, climb.

The smoke test is also your **post-deploy check** — run it after every release, before you announce anything.

## Step 4 — Test data

- **Never production data.** Generate fake data (Faker, or a 20-line generator)
- Seed a deterministic fixture set so tests are reproducible
- Reset the database between tests (`TRUNCATE ... CASCADE`, or a transaction rollback)
- Use a real but separate database — not mocks of the database (mocks hide SQL errors and constraint bugs)
- Mock **external** services (Stripe, email, AI) — you don't want tests that spend money or send emails
- One test user per role: `user@test`, `admin@test`, `otheruser@test` (for IDOR tests you need two)

```ts
// tests/helpers/factories.ts
export const makeUser = (over: Partial<User> = {}) => ({
  id: crypto.randomUUID(),
  email: `user+${crypto.randomUUID().slice(0, 8)}@test.local`,
  role: "member",
  emailVerified: true,
  ...over,
});
```

## Step 5 — Keep tests from becoming the problem

| Rule | Why |
|---|---|
| No `sleep(2000)` | Use `waitFor` / `expect.poll` — sleeps are the #1 source of flakiness |
| Each test sets up its own data | Shared state makes order-dependent failures |
| Tests run in CI on every push | A test nobody runs is decoration |
| A flaky test gets fixed or deleted within a day | Flaky tests teach people to ignore red |
| Test behavior, not implementation | Refactoring shouldn't break tests |
| Assert on user-visible outcomes | "The booking appears" beats "the function returned true" |
| Fast: the suite runs in under 5 minutes | Slow suites get skipped |

## Step 6 — The regression habit

Every bug that reaches production gets **one test** that would have caught it. Named after the bug:

```ts
it("does not double-charge when the Pay button is tapped twice (regression: #142)", ...)
```

Six months later you'll have 40 tests, all of them written because something actually went wrong. That's
the most valuable test suite in the world, and it cost you nothing extra.

## Non-negotiables

1. **"It works" requires evidence** — a test, a script, or a documented manual pass.
2. **Money, auth, permissions and data integrity always have tests.**
3. **Never use production data in tests.**
4. **Every bug that escapes gets a regression test.**
5. **Tests run in CI on every push**, and a red build doesn't get merged.
6. **No flaky tests tolerated** — fix or delete within a day.
7. **Critical paths are verified in a deployed environment**, not just locally.
8. **Coverage is a number, not a goal.** Cover risk, not lines.

## Ask the human

1. "If this broke and nobody noticed for a week, what's the worst that could happen?" *(that's what to test)*
2. "Is there any part of this that involves money or other people's private information?" *(test it first)*
3. "How much time do you want me to spend on tests? I'd suggest the 12 critical ones and nothing else for now."
4. "Do you want me to run the checks automatically every time you change something, or only before a release?"
5. "Have you been bitten by a bug here before? Tell me about it — I'll write a test for exactly that."

Never ask: "unit or integration tests?", "what coverage target?", "Jest or Vitest?", "TDD or test-after?".

## Anti-patterns

| Anti-pattern | Why it's bad | Do instead |
|---|---|---|
| Chasing 100% coverage | Wastes time on trivia, misses the risky parts | Cover risk |
| Testing implementation details | Every refactor breaks the suite | Test observable behavior |
| Mocking the database | Hides real SQL and constraint bugs | Use a real test database |
| `await sleep(2000)` | Flaky and slow | Wait for a condition |
| Tests that depend on each other | One failure cascades | Independent setup per test |
| Tests using real Stripe/email | Costs money, sends emails | Mock external services |
| "We'll add tests after launch" | After launch is when you're busy | The 12 tests now |
| A red test ignored for weeks | The suite loses all value | Fix or delete immediately |
| Testing only locally | Production config differs | Verify in a deployed environment |
| Snapshot tests of everything | Noise, blind approvals | Snapshot only stable output (emails, API contracts) |
| No test for the bug you just fixed | It will come back | One regression test, every time |

## Definition of done

- [ ] The 12 critical tests exist (or are explicitly marked N/A with a reason)
- [ ] Every money/auth/permission/data-integrity path has a test
- [ ] Tests use fake data and a separate database; no production data anywhere
- [ ] External services are mocked; no test can spend money or email a real person
- [ ] A smoke test (`docs/SMOKE-TEST.md` or a script) runs against a deployed environment after every release
- [ ] Tests run in CI on every push; a red build blocks merging
- [ ] No known flaky tests; the suite runs in under 5 minutes
- [ ] Every production bug from this project has a regression test named after it
- [ ] I have actually seen the tests fail (proving they're not vacuous)

## Works with

- `production-readiness` — Gate 1 is built on this
- `backend-api-design` — the contract the tests assert against
- `errors-logs-and-monitoring` — what catches what tests miss
- `refactor-and-maintainability` — tests are what make refactoring safe
- `ci` discipline in `dependency-and-supply-chain`
- `deploy-and-environments` — where the smoke test runs

## Reference

[`references/smoke-test-script.md`](references/smoke-test-script.md) — a copy-paste smoke test you can run
against any deployed app, plus a CI wiring example.
