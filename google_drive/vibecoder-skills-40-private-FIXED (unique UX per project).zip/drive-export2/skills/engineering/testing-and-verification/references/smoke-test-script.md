# Smoke test script (copy-paste)

A single bash script that answers "is the deployed app actually working?" in ~20 seconds.
Run it after every deploy, before you tell anyone the release is live.

Works with no test framework at all. Adapt the URLs and the credentials.

---

## `scripts/smoke-test.sh`

```bash
#!/usr/bin/env bash
# Smoke test: verifies the critical paths against a DEPLOYED environment.
# Usage: ./scripts/smoke-test.sh https://staging.example.com
set -uo pipefail

APP="${1:?Usage: smoke-test.sh <base-url> [email] [password]}"
EMAIL="${2:-$SMOKE_EMAIL}"
PASS="${3:-$SMOKE_PASSWORD}"
COOKIES="$(mktemp)"
PASS_COUNT=0; FAIL_COUNT=0

pass() { echo "  ✅ $1"; PASS_COUNT=$((PASS_COUNT+1)); }
fail() { echo "  ❌ $1  (got: $2)"; FAIL_COUNT=$((FAIL_COUNT+1)); }

check() { # check <label> <expected> <actual>
  if [[ "$2" == "$3" ]]; then pass "$1"; else fail "$1" "$3, expected $2"; fi
}

echo "Smoke testing $APP"

# 1. App is up
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "$APP/")
check "Home page responds" "200" "$code"

# 2. Health endpoint
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$APP/api/health")
check "Health check" "200" "$code"

# 3. Security headers present
hdrs=$(curl -sI --max-time 10 "$APP/")
grep -qi "x-content-type-options" <<<"$hdrs" && pass "nosniff header" || fail "nosniff header" "missing"
grep -qi "strict-transport-security" <<<"$hdrs" && pass "HSTS header" || fail "HSTS header" "missing"

# 4. Protected route without a session must be 401
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$APP/api/bookings")
check "Protected API rejects anonymous" "401" "$code"

# 5. Login
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 -c "$COOKIES" \
  -X POST "$APP/api/auth/login" -H 'content-type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS\"}")
check "Login succeeds" "200" "$code"

# 6. Wrong password must be rejected (and not 200)
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 \
  -X POST "$APP/api/auth/login" -H 'content-type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"definitely-wrong\"}")
check "Wrong password rejected" "401" "$code"

# 7. Authenticated read works
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 -b "$COOKIES" "$APP/api/bookings")
check "Authenticated read" "200" "$code"

# 8. IDOR: someone else's resource must 404 (set OTHER_ID in env)
if [[ -n "${OTHER_ID:-}" ]]; then
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 -b "$COOKIES" "$APP/api/bookings/$OTHER_ID")
  check "Cannot read another user's booking" "404" "$code"
fi

# 9. Validation is enforced server-side
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 -b "$COOKIES" \
  -X POST "$APP/api/bookings" -H 'content-type: application/json' -d '{"seats": 99999}')
check "Invalid input rejected" "400" "$code"

# 10. Rate limiting works on login
rate=0
for i in $(seq 1 25); do
  c=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 \
    -X POST "$APP/api/auth/login" -H 'content-type: application/json' \
    -d '{"email":"rate@test.local","password":"wrong"}')
  [[ "$c" == "429" ]] && rate=1 && break
done
[[ $rate -eq 1 ]] && pass "Login rate limit kicks in" || fail "Login rate limit" "no 429 in 25 attempts"

# 11. No secrets in the page source
body=$(curl -s --max-time 10 "$APP/")
if grep -qE "sk_live_[A-Za-z0-9]{10,}|AKIA[0-9A-Z]{16}" <<<"$body"; then
  fail "No secrets in HTML" "a key pattern was found"
else
  pass "No secrets in HTML"
fi

# 12. Leaky paths are 404
for p in /.git/config /.env /backup.sql; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$APP$p")
  check "$p not reachable" "404" "$code"
done

rm -f "$COOKIES"
echo
echo "────────────────────────────"
echo "PASS: $PASS_COUNT   FAIL: $FAIL_COUNT"
[[ $FAIL_COUNT -eq 0 ]] || exit 1
```

---

## Wire it into CI (post-deploy verification)

```yaml
# .github/workflows/deploy.yml (excerpt)
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm test          # the test suite
      - run: npm run deploy              # your deploy command
      - name: Smoke test the deployment
        run: ./scripts/smoke-test.sh "$APP_URL" "$SMOKE_EMAIL" "$SMOKE_PASSWORD"
        env:
          APP_URL: ${{ vars.APP_URL }}
          SMOKE_EMAIL: ${{ secrets.SMOKE_EMAIL }}
          SMOKE_PASSWORD: ${{ secrets.SMOKE_PASSWORD }}
          OTHER_ID: ${{ vars.OTHER_ID }}
      - name: Roll back on failure
        if: failure()
        run: npm run rollback
```

---

## The manual checklist version

When you have nothing automated, walk this after every deploy. Five minutes.

```
[ ] Open the app in a private window. It loads. No console errors.
[ ] Sign up with a brand-new email → verification email arrives → verify → land in the product
[ ] Do the core action → see the result → refresh → it's still there
[ ] Log out → try the core action's URL directly → you're bounced to login
[ ] Log in as a second user → try to open the first user's record by ID → not found
[ ] Submit an empty required form → clear field-level errors, values preserved
[ ] Pay with a test card → access granted → receipt email arrives
[ ] Trigger a password reset → email arrives → link works → old session is dead
[ ] Open on a phone → layout works, buttons are tappable
[ ] Check the error tracker: no new error types in the last 15 minutes
```

Write the result in `docs/HANDOFF.md` with the date. "I clicked around" is not a record;
"I ran the checklist, 10/10, 2026-10-20" is.
