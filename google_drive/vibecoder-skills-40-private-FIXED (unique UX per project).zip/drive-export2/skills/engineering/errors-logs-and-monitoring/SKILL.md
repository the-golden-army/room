---
name: errors-logs-and-monitoring
description: Use when anything can fail in production — before launch, after an incident, or when the human says "it crashed and I don't know why". Sets up four layers: error tracking that pages a human, structured logs that make sense, uptime and synthetic checks that notice before users do, and alerts tuned so they mean something. Includes what to log, what never to log, correlation IDs, and the five numbers worth watching.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# errors-logs-and-monitoring

## Promise

When something breaks, you know in minutes — from your own systems, with enough context to fix it — instead
of days later from an angry email that says "it doesn't work".

## When to use

- Before launch (Gate 4 of `production-readiness`)
- "It crashed and I don't know why"
- After any incident ("we had no idea it was down")
- Adding a payment, webhook, AI call, or background job — anything that fails invisibly
- Setting up a new environment
- Debugging something you can't reproduce locally

## When NOT to use

- Never. Every deployed app needs at least the minimum viable version.

## The 60-second version: four layers

```
1. ERRORS     an exception tracker that groups, de-duplicates, and emails you (Sentry, Rollbar, GlitchTip)
2. LOGS       structured events with a request ID, searchable, retained 30+ days
3. SIGNALS    uptime check + synthetic transaction + a health endpoint
4. ALERTS     a human notification on: error spike, site down, payments failing, webhooks failing
```

Minimum viable for a solo project: **error tracking + an uptime check + one email alert**. That's 30 minutes
of setup and it covers the situations that actually hurt.

## Step 1 — Error tracking

```ts
// instrumentation.ts (Next.js) or your app's entry point
import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  release: process.env.GIT_SHA,            // so you know which deploy broke it
  tracesSampleRate: 0.1,                   // 10% of traffic for performance data
  sendDefaultPii: false,                   // never ship personal data to the tracker
  beforeSend(event) {
    // Scrub anything sensitive that slipped in
    if (event.request?.cookies) delete event.request.cookies;
    if (event.request?.headers) {
      delete event.request.headers.authorization;
      delete event.request.headers.cookie;
    }
    return event;
  },
  ignoreErrors: [/ResizeObserver loop/, /Network request failed/],  // known noise
});
```

Rules:
- **Verify it works**: trigger a test error in production and confirm you receive it
- **Tag releases** so you can see "this started in v1.4.2"
- **Upload source maps** so the stack trace points at your code, not minified garbage
- **Group and triage weekly**: fix the top error, ignore the known-noisy ones explicitly
- **Scrub PII** (see `data-privacy-and-pii`)
- Don't let the error budget become wallpaper: if you have 500 unread errors, the tool has failed.
  Fix the top 3, mute the noise, keep it near zero.

Catch errors at every boundary:

```ts
// Unhandled client errors
window.addEventListener("unhandledrejection", e => captureException(e.reason));
// React error boundary (see frontend-craft)
// API handler catch-all (see backend-api-design)
// Background job failures → log + alert, with the job payload (scrubbed)
```

## Step 2 — Structured logs

```ts
// lib/logger.ts
type Level = "debug" | "info" | "warn" | "error";

export function log(level: Level, event: string, fields: Record<string, unknown> = {}) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    event,                       // a stable, greppable name: "booking.created"
    requestId: requestContext.getStore()?.id,
    userId: requestContext.getStore()?.userId,
    ...fields,
  };
  process.stdout.write(JSON.stringify(entry) + "\n");   // one JSON object per line
}

// Usage — log the EVENT, with IDs. Never dump whole objects.
log("info", "booking.created", { bookingId: b.id, classId: b.classId, amountCents: b.amountCents });
log("warn", "login.failed", { emailHash: sha256(email).slice(0, 12), ip });
log("error", "payment.failed", { userId: u.id, code: e.code, requestId });
```

| Log this | Never log this |
|---|---|
| Event names + IDs | Passwords, tokens, API keys, session cookies |
| User ID, request ID, job ID | Full email addresses (hash them) |
| Durations, counts, amounts | Full request bodies |
| Error type + message + stack | Card numbers, IDs, health data |
| Decisions ("plan upgraded") | Anything a user typed |
| Third-party call results (status, latency) | Third-party response bodies with personal data |

**Correlation IDs** are what turn logs into debugging. Generate one per request, pass it through every log
line and every outbound call, and return it in the error response so a user's screenshot identifies the
exact request.

```ts
// One middleware, applied to everything
export function withRequestContext(handler) {
  return async (req, ...rest) => {
    const id = req.headers.get("x-request-id") ?? crypto.randomUUID();
    return requestContext.run({ id, userId: null }, () => handler(req, ...rest));
  };
}
```

Log levels: `error` = something broke; `warn` = suspicious but handled; `info` = things that matter
(money, auth, lifecycle); `debug` = off in production.

## Step 3 — Signals (notice before your users do)

| Signal | Tool | What it catches |
|---|---|---|
| Uptime check | UptimeRobot, BetterStack, Pingdom, Checkly | The whole app is down |
| Synthetic transaction | Playwright/Checkly running the critical path every 15 min | Login broke, checkout broke |
| Health endpoint | `GET /api/health` → 200 + DB check | The app is up but the database isn't |
| Cron/job heartbeat | A dead-man's switch (Healthchecks.io) | Background jobs silently stopped |
| Certificate expiry | Most uptime tools, or a calendar reminder | TLS expired — a classic |

```ts
// app/api/health/route.ts
export async function GET() {
  try {
    await db.$queryRaw`SELECT 1`;                       // is the database reachable?
    return Response.json({ status: "ok", uptime: process.uptime(), version: process.env.GIT_SHA });
  } catch (e) {
    log("error", "health.database_unreachable", { error: String(e) });
    return Response.json({ status: "degraded" }, { status: 503 });
  }
}
```

The health check must be **cheap and unauthenticated** — it's for machines. Never let it leak secrets
(no env dumps, no version banners, no config).

## Step 4 — Alerts that mean something

Alert on **symptoms** (what the user experiences), not causes (CPU is high).

| Alert | Threshold | Why |
|---|---|---|
| Site down | 2 consecutive failed checks, 2 min apart | Obvious |
| Error rate | > 1% of requests over 5 min | Something broke in the last deploy |
| New error type | Any error seen for the first time | Catches regressions immediately |
| Failed payments | Any 3 in 10 min | Money is broken right now |
| Failed webhooks | 3 consecutive failures | Subscriptions silently not activating |
| Failed emails | > 5% over an hour | Password resets aren't arriving |
| Auth failures | 50 in 10 min | Attack or a broken login form |
| Rate-limit hits | 100 in 10 min | Someone's hammering you |
| Job dead | Heartbeat missed by 2x the interval | Background work stopped |
| Quota | Any account at 90% of its quota | About to cost money or break a user |
| Certificate | Expires in < 14 days | Preventable outage |

Rules:
- **Every alert goes to a human's inbox or phone.** A dashboard nobody watches isn't alerting
- **Every alert is actionable.** If the response is "ignore it", delete the alert
- **Prove the wiring**: trigger each alert once and confirm it arrives
- **Start narrow, widen later.** Three false alarms and you'll mute the channel forever
- **Alert fatique kills monitoring** — tune weekly for the first month

## Step 5 — The five numbers worth a dashboard

```
1. Requests per minute        — is anyone here? did traffic die?
2. Error rate (%)             — is it broken?
3. Response time (p50 / p95)  — is it slow for some people?
4. Signups / core actions     — is the business working?
5. Money today                — did payments stop?
```

Add more only when you have a question the five can't answer.

## Step 6 — Debugging with logs (the workflow)

```
1. Get the request ID (from the user's error message, the error tracker, or your own reproduction)
2. Filter logs by that ID → see the whole story of that one request
3. Find the first error, not the last one (cascading errors hide the root cause)
4. Reconstruct: what did the user do, what did the server see, what did the third party return?
5. Reproduce in staging with the same input
6. Fix + write a regression test (see testing-and-verification)
```

## Non-negotiables

1. **Errors are captured somewhere a human will see them** — and proven with a test error.
2. **Alerts go to a person**, not just a dashboard.
3. **Logs are structured** (JSON), with a request ID, and searchable.
4. **No PII in logs or error reports.** Verify, don't assume.
5. **Every alert is actionable**; noise is deleted, not tolerated.
6. **Uptime + a synthetic check on the critical path**, not just "is the server up".
7. **Health endpoint is cheap**, checks the database, and leaks nothing.
8. **Log retention ≥ 30 days**, so you can investigate last month's complaint.
9. **Releases are tagged** in the error tracker, so you can see when a problem started.
10. **Silent failures are treated as bugs** — a failed webhook with no alert is a bug.

## Ask the human

1. "If this broke at 3am, how would you want to find out — email, text, or a message in Slack?"
2. "What's the thing that, if it silently failed, would cost you the most?" *(that's the first alert)*
3. "How long are you okay not knowing that something's wrong — 5 minutes, an hour, or until a customer tells you?"
4. "Who should get the alert besides you?" *(a co-founder, a contractor, a virtual assistant)*
5. "Are you okay with an external service seeing your error data? If not, we'll self-host." *(GlitchTip, self-hosted Sentry)*

Never ask: "Sentry or Rollbar?", "what's your error budget?", "do you want distributed tracing?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| `console.log("here")` as observability | Unsearchable, gone on restart | Structured events |
| Error tracker installed but never verified | You find out it was misconfigured during an outage | Trigger a test error |
| Alerts to a channel nobody reads | Effectively no alerting | Email/phone to a named human |
| 200 alerts a day | All of them get ignored | Alert on symptoms, tune aggressively |
| No request ID | You can't reconstruct what happened | One middleware, one ID |
| Logging whole request objects | PII and secrets in the log store | Allowlisted fields |
| "The logs are on the server" with 1 day retention | Last week's complaint is uninvestigable | 30+ days, searchable |
| Monitoring only the homepage | Login is broken but the homepage is fine | Synthetic critical path |
| No alerting on payments/webhooks | Revenue silently stops | Alert on money, always |
| Alerts on CPU/disk instead of user experience | Pages you for nothing | Symptom-based alerts |
| No health endpoint, only "is port 80 open" | App up, database down, looks healthy | Real health check |

## Definition of done

- [ ] Error tracking installed, source maps uploaded, releases tagged, **and a test error was received**
- [ ] PII scrubbing verified by reading a real captured event
- [ ] Structured logging with request IDs, searchable, retained ≥30 days
- [ ] `/api/health` exists, checks the database, is cheap, leaks nothing
- [ ] Uptime check + a synthetic check of the critical path (login → core action)
- [ ] Alerts: site down, error-rate spike, failed payments, failed webhooks, failed emails, auth-failure spike
- [ ] Every alert proven to arrive; routed to a human
- [ ] Dashboard (or a single query) for: traffic, error rate, latency, signups, money
- [ ] Background jobs have a heartbeat/dead-man's switch
- [ ] `docs/RUNBOOK.md` says where to look first when something's wrong

## Works with

- `production-readiness` — Gate 4
- `reliability-and-incidents` — what you do when the alert fires
- `backend-api-design` — the error contract surfaces the request ID
- `data-privacy-and-pii` — what must never be logged
- `performance-and-caching` — latency numbers come from here
- `testing-and-verification` — tests catch what logs can't
