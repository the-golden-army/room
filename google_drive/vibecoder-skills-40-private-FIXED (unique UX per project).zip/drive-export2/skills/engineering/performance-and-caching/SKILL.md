---
name: performance-and-caching
description: Use when something is slow, before a launch, before a traffic spike, or when the human says "it feels sluggish". Sets performance budgets, finds the actual bottleneck (N+1 queries, missing indexes, oversized bundles, unoptimized images, uncached reads), applies caching at the right layer with sane invalidation, and load-tests the critical path well enough to know what happens on a busy day.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# performance-and-caching

## Promise

The app is fast for real users on real devices — and you know what happens on your busiest possible day,
because you tested it instead of hoping.

## When to use

- "It's slow" / "it feels sluggish" / "it takes forever to load"
- Before launch (Gate 5 of `production-readiness`)
- Before a launch, a campaign, or a viral moment
- After adding a feature that fetches a lot of data
- Cloud or AI costs are climbing (inefficiency costs money twice)
- Lists that grow over time (they always start fast and end slow)

## When NOT to use

- Before you've measured anything. **Measure first, always.**
- On code that's about to be deleted

## The 60-second version: budgets

```
PAGE LOAD (mobile, 4G)
  Largest Contentful Paint (LCP)   < 2.5s    — the main thing is visible
  Interaction to Next Paint (INP)  < 200ms   — taps feel instant
  Cumulative Layout Shift (CLS)    < 0.1     — nothing jumps
  Time to First Byte (TTFB)        < 800ms   — the server isn't the problem

WEIGHT
  JavaScript (gzipped, per route)  < 200KB   (300KB is a warning, 500KB is a problem)
  Images per page                  < 800KB total, each correctly sized
  Fonts                            < 100KB, subset, woff2

SERVER
  API responses (p95)              < 300ms for reads, < 1s for writes
  Database queries (p95)           < 50ms; anything > 200ms gets investigated
  N+1 queries                      0, on every list view
```

If you can't measure it, you can't improve it. Lighthouse (mobile profile) + your APM/error tracker's
performance data + a slow-query log. Start there.

## Step 1 — Measure, then fix the biggest thing

Performance work is a loop, not a checklist:

```
1. MEASURE    Lighthouse (mobile) + real-user data + slow query log
2. FIND       what's actually slow? (the waterfall, the query log, the bundle analyzer)
3. FIX        the single biggest contributor
4. VERIFY     measure again; did the number move?
5. REPEAT     until the budget is met, then stop
```

**Fix in this order** — it's roughly order of impact per hour of work:

```
1. Fewer requests      (N+1 queries, chatty APIs, redundant fetches)
2. Smaller payloads    (images, bundle size, payload trimming, compression)
3. Caching             (CDN, HTTP cache, query cache, memoization)
4. Faster queries      (indexes, query shape, denormalization where it pays)
5. Async work          (move slow stuff off the request path)
6. More hardware       (last, and cheapest relative to your time in most cases)
```

## Step 2 — The N+1 query (the most common real problem)

```ts
// ❌ 1 query for the list, then 1 per row = 1 + 50 queries
const bookings = await db.booking.findMany({ where: { userId } });
for (const b of bookings) {
  b.class = await db.class.findUnique({ where: { id: b.classId } });   // in a loop!
}

// ✅ 2 queries, total
const bookings = await db.booking.findMany({
  where: { userId },
  include: { class: true },       // a JOIN
});

// ✅ or select only what you use
const bookings = await db.booking.findMany({
  where: { userId },
  select: { id: true, createdAt: true, class: { select: { name: true, startsAt: true } } },
});
```

Find them: enable query logging in development and count the queries per request. If a list page fires
more than ~5 queries, look closer. Prisma's `log: ["query"]`, Django's `django-debug-toolbar`, SQLAlchemy's
`echo=True` — whatever your stack has.

## Step 3 — Indexes and query shape

```sql
EXPLAIN ANALYZE SELECT * FROM bookings WHERE user_id = '...' ORDER BY created_at DESC LIMIT 20;
-- "Seq Scan on bookings" on a large table → you need an index
CREATE INDEX CONCURRENTLY bookings_user_created_idx ON bookings (user_id, created_at DESC);
```

- Index every foreign key and every column you filter or sort by
- Composite indexes: put equality filters first, then the sort column
- `SELECT` only the columns you need — `SELECT *` on a wide table is a real cost
- Paginate with a cap; never return 10,000 rows
- Aggregate in the database (`COUNT`, `SUM`), not in application code
- For dashboards: precompute or materialize; don't scan a million rows on every page load

## Step 4 — Caching layers (and when each is worth it)

| Layer | What it's for | Invalidation |
|---|---|---|
| **Browser / CDN** | Static assets, images, fonts | Filename hashing (`app.abc123.js`) + long `max-age` |
| **HTTP cache** | Public, non-personal responses | `Cache-Control`, `ETag`, `stale-while-revalidate` |
| **Full-page / ISR** | Marketing pages, public listings | Time-based revalidation (60s-1h) or on-demand |
| **Data / query cache** | Expensive reads everyone shares | TTL + explicit invalidation on write |
| **In-process memo** | Per-request dedupe (same query twice in one request) | Per-request lifetime |
| **Client cache** | Refetch-on-focus, optimistic updates | TanStack Query / SWR with stale times |

```ts
// HTTP caching for a public, non-personal response
res.setHeader("Cache-Control", "public, max-age=0, s-maxage=60, stale-while-revalidate=300");

// Client-side data cache (TanStack Query)
const { data } = useQuery({
  queryKey: ["classes"],
  queryFn: fetchClasses,
  staleTime: 60_000,          // don't refetch for 60s
  refetchOnWindowFocus: true, // ...but do when the user comes back
});
```

**Rules of caching:**
- **Never cache personalized data in a shared cache.** A CDN-cached page containing one user's name is a
  data leak. Set `Cache-Control: private, no-store` on anything user-specific
- **Every cache entry needs an invalidation story.** A cache with no invalidation is a bug generator
- **Start with the biggest win**: usually images, then the slowest query, then the bundle
- **Don't cache what's cheap.** Caching a 2ms query adds complexity and staleness for nothing
- **Beware the cache stampede**: when a hot key expires, everyone hits the database at once. Use a lock,
  or `stale-while-revalidate`

## Step 5 — Front-end weight

| Lever | How |
|---|---|
| Images | Modern formats (WebP/AVIF), correct dimensions, `srcset` for responsive, lazy-load below the fold, explicit width/height to prevent layout shift |
| JS bundle | Bundle analyzer → find the 300KB surprise; lazy-load routes and heavy components; check for duplicate versions of the same library |
| Fonts | `woff2`, `font-display: swap`, subset, self-host, preload the one that matters |
| CSS | Ship only what's used (Tailwind does this); avoid render-blocking imports |
| Third-party scripts | The hidden killer: chat widgets, analytics, tag managers. Load them `async`/`defer`, or not at all |
| Rendering | Stream or skeleton the shell; don't block the whole page on one slow query |

```bash
npx @next/bundle-analyzer      # or webpack-bundle-analyzer / vite-bundle-visualizer
npx lighthouse https://app --preset=desktop --view
```

## Step 6 — Server-side

- **Connection pooling** (PgBouncer, or the ORM's pool). Exhausted connections look like a total outage
- **Move slow work off the request**: email, PDFs, AI, imports, thumbnails → background jobs with 202
- **Timeouts on every outbound call** (no call may hang forever)
- **Compress responses** (gzip/brotli) — usually one line at the proxy
- **Stream large responses** instead of buffering them in memory
- **Rate limit and cap** expensive endpoints (see `api-abuse-defense`)

## Step 7 — Know what happens on a busy day

You don't need a full load-testing rig. You need an answer to "what happens at 10x today's traffic?"

```bash
# hey — 200 requests, 20 concurrent
hey -n 200 -c 20 -H "Authorization: Bearer $TOKEN" https://app.example.com/api/bookings

# k6 — a short script that models the critical path
import http from "k6/http";
import { check, sleep } from "k6";
export const options = { vus: 50, duration: "60s" };
export default function () {
  const r = http.get("https://staging.example.com/api/bookings", { headers: { Authorization: `Bearer ${__ENV.TOKEN}` } });
  check(r, { "status 200": r => r.status === 200, "under 500ms": r => r.timings.duration < 500 });
  sleep(1);
}
```

Interpreting results:

| Observation | Meaning | Action |
|---|---|---|
| Errors appear at 20 concurrent | A pool/limit is exhausted | Pooling, timeouts, queue |
| Latency grows steadily with concurrency | You're CPU/DB bound | Query/index work, caching, scale up |
| Latency is flat but high | A fixed cost per request (cold start, a slow third-party call) | Caching, async work |
| DB CPU pegged, app idle | Query problem | Indexes, query shape |
| Everything fine until a cliff | A hard limit (connections, memory, file descriptors) | Raise the limit, then pool |

Then write the number down: *"Tested to 50 concurrent users; p95 stayed under 400ms. Beyond ~100 we need
[X]."* That's the difference between a scalpel and a guess.

## Non-negotiables

1. **Measure before you optimize**, and measure again after.
2. **Zero N+1 queries on list views.**
3. **Every foreign key and hot filter is indexed.**
4. **Images are modern-format, correctly sized, and don't shift the layout.**
5. **No user-specific content in a shared cache.**
6. **Every cache entry has an invalidation story.**
7. **Budgets are numbers, not feelings** — and they're checked before launch.
8. **Slow work is off the request path.**
9. **You know the app's behavior at 10x today's traffic**, because you tested it.
10. **Stop when the budget is met.** Optimization past "fast enough" is waste.

## Ask the human

1. "How slow is too slow for you? Is a 2-second load fine, or does this need to feel instant?"
2. "Are your users mostly on phones, on laptops, or on spotty connections somewhere specific?"
3. "What's the busiest you can imagine this getting — and would that be a great day or a disaster?"
4. "Is there one screen that feels worse than the others?" *(start there — it's usually the real complaint)*
5. "Do you get charged for how much data or how many requests you serve?" *(if yes, efficiency is money)*

Never ask: "LRU or LFU eviction?", "should we use a CDN?", "what's your acceptable p99?" — decide and report.

## Anti-patterns

| Anti-pattern | Cost | Do instead |
|---|---|---|
| Optimizing without measuring | Weeks spent on the wrong thing | Profile first |
| Caching everything "to be safe" | Stale data, bugs, complexity | Cache the measured hot spots |
| Caching personalized pages publicly | Data leak between users | `private, no-store` |
| No invalidation strategy | Users see old data forever | TTL + explicit invalidation on write |
| Premature microservices/kafka for speed | Slower, not faster | Fix the query first |
| Adding a cache before fixing the N+1 | You cache a slow thing | Fix the query, then cache if needed |
| Optimizing a page nobody uses | Wasted time | Optimize the top 3 screens |
| 5MB hero image | Kills mobile | Compress, resize, WebP |
| Loading eight third-party scripts | Each one blocks the page | Audit and cut |
| "It's fast on my machine" | Your machine isn't a phone on 4G | Test throttled, on a device |
| Scaling hardware before fixing queries | Expensive and temporary | Index + query shape first |

## Definition of done

- [ ] Budgets defined and measured with Lighthouse (mobile) on the 3 main screens
- [ ] LCP < 2.5s, INP < 200ms, CLS < 0.1 on mobile for the main screens
- [ ] JS bundle < 200KB gzipped per route (or a documented reason)
- [ ] Images modern-format, sized, lazy-loaded, with dimensions
- [ ] No N+1 on any list view (verified by counting queries)
- [ ] Indexes on all FKs and hot filters; `EXPLAIN ANALYZE` shows index scans
- [ ] Caching applied where measured, with a written invalidation rule; nothing personalized is shared-cached
- [ ] Slow work is off the request path (jobs/queues)
- [ ] Load-tested at 10x expected concurrency; results written down
- [ ] Re-measured after the fixes (the number moved, in writing)

## Works with

- `frontend-craft` — perceived performance (skeletons, optimistic UI)
- `data-model-and-migrations` — indexes and query shape
- `backend-api-design` — pagination and payload size
- `errors-logs-and-monitoring` — the p95 numbers come from there
- `cost-guardrails` — efficiency is money on serverless
- `production-readiness` — Gate 5
