---
name: production-readiness
description: Use before any launch, before handing a project to a client, and whenever someone asks "is this done?" or "can real users use this?". A brutal pass/fail audit that turns a working demo into a real product: critical paths, security gate, data safety, error handling, performance, operations, legal, and the demo-to-product gap. Produces a launch certificate with open items and accepted risks.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# production-readiness

## Promise

You stop guessing whether it's ready. You run the gate, you get a list, and you know exactly what's
between you and real users.

## When to use

- **Before every launch** — including "just a soft launch to a few people"
- "Is this production ready?" / "Can I send this to users?" / "I think we're done"
- Handing a project to a client or another developer
- After a big feature, before announcing it
- When you feel the itch to say "it works" — that's the trigger

## When NOT to use

- Mid-development checkpoints (use the individual skills instead)
- A hackathon demo that will be thrown away (but still don't leak secrets)

## The 60-second version: demo vs product

| A demo… | A product… |
|---|---|
| Works when you click the right things | Works when people click the wrong things |
| Has one user (you) | Handles many users, at once, with different data |
| Runs on your machine | Runs on a server you can't see, and restarts itself |
| Has data you don't care about | Has data people will be upset to lose |
| Errors are visible in your terminal | Errors are visible in your logs, with an alert |
| Security is "who would hack me?" | Security is "bots already found it" |
| Deploy is `git push` and hope | Deploy is repeatable, reversible, and observed |
| Nobody depends on it | Someone's money or job depends on it |

Most AI-built projects are excellent demos. This skill is the list that closes the gap.

## Step 1 — Name the critical paths first

You cannot test "everything". Write the 3-7 journeys that matter, then test only those, end to end.

```
1. Visitor → signs up → verifies email → lands in the product
2. User → does the core action → sees the result
3. User → pays → gets access → gets a receipt
4. Admin → logs in → does the admin thing
5. User → forgets password → gets back in
6. User → deletes their account → data is gone
```

For each: does it work, on a fresh account, on a phone, with a slow connection, **and** when something fails
halfway? A critical path that only works on the happy path is not ready.

## Step 2 — Run the gate

Full checklist: [`references/launch-gate.md`](references/launch-gate.md). The summary:

### 🔴 Gate 1 — It works (blocking)
- [ ] Every critical path tested end to end by a real click/request, not by reading code
- [ ] Tested on a fresh account with no data (not just your dev account full of fixtures)
- [ ] Tested in a private window (no cache, no login state)
- [ ] Tested on mobile viewport / a real phone
- [ ] Tested on a throttled connection
- [ ] No `console.log`, `TODO`, `FIXME`, or `debugger` left in the code
- [ ] No hardcoded localhost URLs, no dev keys, no mock data in production paths

### 🔴 Gate 2 — It's safe (blocking)
- [ ] `appsec-hardening` audit run; zero 🔴 items
- [ ] No secret in the repo, the build output, or the client bundle
- [ ] Auth: ownership checks everywhere; rate limits on login/reset; passwords hashed
- [ ] Uploads validated and stored outside the web root
- [ ] Errors generic to users, detailed in logs
- [ ] HTTPS enforced; security headers present

### 🔴 Gate 3 — Data survives (blocking)
- [ ] Backups exist, are automated, and **a restore has been tested**
- [ ] Every destructive migration is reversible, or has a tested rollback
- [ ] No `DROP`/`TRUNCATE` reachable by the app's database user
- [ ] Deletion works (if the product promises deletion)
- [ ] Test data is not in production; production data is not in test

### 🟠 Gate 4 — Failure is visible
- [ ] Errors are captured somewhere you'll look (Sentry or equivalent)
- [ ] Logs exist for the critical paths and for money actions
- [ ] Uptime check pings the app and alerts you
- [ ] Failed payments, failed emails, and failed webhooks alert you
- [ ] You have been notified by your own alerting at least once (proving it's wired)

### 🟠 Gate 5 — Performance
- [ ] Main pages load in under 2-3 seconds on a phone
- [ ] No N+1 queries on the main list views (check the query log)
- [ ] Images optimized and sized
- [ ] Tested with 10-50x your expected concurrent users, even crudely
- [ ] Expensive operations are queued, not inline

### 🟠 Gate 6 — Operations
- [ ] Deploy is one command and repeatable
- [ ] Rollback works and has been rehearsed
- [ ] Staging (or a preview deploy) exists and was used for this release
- [ ] `docs/RUNBOOK.md` exists: how to deploy, roll back, and stop the bleeding
- [ ] Domain, DNS, TLS certificate and renewal are understood and owned by someone
- [ ] Status/maintenance page possible without a deploy

### 🟡 Gate 7 — Legal & trust
- [ ] Privacy policy matches what the code does
- [ ] Terms, if you take money
- [ ] Cookie/consent only if you actually track
- [ ] Company/contact details reachable
- [ ] Refund/cancellation path exists if you charge

### 🟡 Gate 8 — Business continuity
- [ ] Someone other than you can deploy (or you've documented it well enough to)
- [ ] The domain and hosting accounts are in your name, with MFA, and you know how to renew
- [ ] Billing alerts set on every paid service
- [ ] You know the monthly cost and what happens at 10x traffic

## Step 3 — Score it

| Result | Decision |
|---|---|
| Any 🔴 open | **Do not launch.** Fix it. Seriously — this is the whole point. |
| Any 🟠 open | Launch to a small known group only. Fix within a week. |
| Any 🟡 open | Launch. Fix before you promote it publicly. |
| All clear | Launch, and write the launch runbook (`launch-and-handoff`). |

## Step 4 — Write the certificate

`docs/PRODUCTION-READINESS.md` — dated, with the commit hash. This document is what you show a client,
an investor, or a nervous co-founder.

```markdown
# Production readiness — 2026-10-20 — commit a1b2c3d

Decision: LAUNCH (soft launch to 20 known users)

## Critical paths tested
| Path | Result | Notes |
|---|---|---|
| Signup → verify → first booking | PASS | tested on iPhone Safari + Chrome desktop |
| Pay → access granted → receipt email | PASS | Stripe test mode + one live $1 test |
| Password reset | PASS | 15-min expiry verified |
| Delete account | PASS | files + email tool + analytics all deleted |

## Gate results
🔴 0 open · 🟠 2 open · 🟡 5 open

## Open 🟠 items (fix by 2026-10-27)
1. No uptime alerting yet → setting up a check today
2. Restore-from-backup tested only on staging → prod restore test scheduled Sunday

## Accepted risks (approved by <name>)
- No MFA at launch; user base is <50 known people. Revisit at 500 users.
- Single region; a regional outage means downtime. Acceptable for now.

## Not tested
- Load beyond 50 concurrent users
- Penetration test by a third party
- Desktop app builds
```

## The ten things that most often block a launch

1. **A secret in the build output or git history** — rotate and clean before anything else
2. **No ownership checks** — user A can see user B's data
3. **No error tracking** — you'll learn about bugs from angry emails
4. **Backups that were never restored** — they're not backups until you've restored one
5. **Hardcoded localhost / dev API URLs** — works locally, dead in production
6. **No rate limit on login** — credential stuffing in week one
7. **Forms that fail silently** — the user thinks it worked; nothing happened
8. **No rollback** — the first bad deploy becomes an outage
9. **Emails not configured (SPF/DKIM)** — every email lands in spam, including password resets
10. **No idea what it costs per month** — the second month's invoice is a surprise

## Non-negotiables

1. **Untested is not done.** A feature you haven't clicked through isn't a feature.
2. **Zero 🔴 items at launch.** No exceptions, no "we'll fix it right after".
3. **A restore has been tested**, not just a backup configured.
4. **Rollback has been rehearsed**, not just "possible".
5. **You can see failures** without a user telling you.
6. **The critical paths are written down** and each one has a pass/fail.
7. **Accepted risks are written down with a name and a date** — an unwritten risk is an argument later.
8. **"Not tested" is recorded** — never imply coverage you don't have.

## Ask the human

1. "What's the worst thing that could happen if this breaks on day one?" *(focuses the gate)*
2. "Who are the first people who'll use this — people you know, or strangers from the internet?"
3. "If it went down tonight, how would you find out — and could you fix it yourself?"
4. "How much data would you be upset to lose? An hour's worth, a day's, or none at all?" *(sets backup frequency)*
5. "What's your budget if something goes wrong — can you spend money to fix it fast?"
6. "Is there a date you've promised this to someone? What happens if it slips a week?"

Never ask: "do you want a staging environment?", "should we set up Sentry?", "blue-green or canary?" —
just do the sensible thing and tell them.

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| "It works on my machine, ship it" | Production is not your machine | Test in a deployed environment |
| Testing only with your dev account full of data | New-user bugs invisible | Fresh account, empty state |
| Testing only the happy path | The failure path is what users hit | Test failures deliberately |
| Running the gate the morning of launch | Panic, cut corners, ship anyway | Run it a week before |
| Treating the checklist as advisory | It's a gate; that's the point | Zero 🔴 or don't launch |
| Backups "configured" | Unverified backups fail when needed | Restore one, on a schedule |
| No rollback plan | A bad deploy becomes an outage | Rehearse the rollback |
| Launching on a Friday | You'll spend the weekend on it | Tuesday morning, after a quiet night |
| Big-bang launch to everyone | Everything breaks at once | Soft launch → 10 users → 100 → open |
| "We'll add monitoring after launch" | You're flying blind on the riskiest day | Monitoring before users |

## Definition of done

- [ ] All critical paths identified and tested end to end, by clicking, in a deployed environment
- [ ] Zero 🔴 items; 🟠 items have an owner and a date; 🟡 items are listed
- [ ] Backups automated **and** a restore tested
- [ ] Error tracking live and proven (you've received a test alert)
- [ ] Rollback rehearsed
- [ ] `docs/RUNBOOK.md` and `docs/PRODUCTION-READINESS.md` exist and are current
- [ ] Cost per month known, with billing alerts set
- [ ] Accepted risks written with a name and a date
- [ ] "Not tested" section written honestly
- [ ] A human (not the agent) has signed off on the launch decision

## Works with

- **Everything in the pack** — this is the gate they all lead to
- `appsec-hardening` — Gate 2
- `testing-and-verification` — how to test the critical paths
- `reliability-and-incidents` — backups, rollback, runbook
- `deploy-and-environments` — Gate 6
- `launch-and-handoff` — what happens on launch day
- `code-review-and-audit` — the code-level version of this pass
