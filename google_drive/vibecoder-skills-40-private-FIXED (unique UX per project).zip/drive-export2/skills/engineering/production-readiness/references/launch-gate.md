# The launch gate (full checklist)

Copy into `docs/PRODUCTION-READINESS.md`, mark `PASS` / `FAIL` / `N/A`, add a note for every FAIL.
Date it and record the commit hash. Anything 🔴 FAIL blocks the launch.

---

## 🔴 1. It works

```
[ ] Every critical path listed and tested end to end by actually doing it
[ ] Tested with a FRESH account (empty state, no fixtures)
[ ] Tested in a private/incognito window
[ ] Tested on a real phone (or at least a mobile viewport + touch emulation)
[ ] Tested on throttled network (Slow 3G) — loading states appear, nothing hangs forever
[ ] Tested the failure path of each critical path (server error, invalid input, timeout)
[ ] Core action works twice in a row, and 10 times in a row
[ ] Browser back/forward/refresh behave sensibly everywhere
[ ] Deep links / shared URLs work when opened directly
[ ] Data entered survives a validation error
[ ] No console errors in the browser on the main screens
[ ] No `console.log` / `debugger` / `TODO` / `FIXME` / commented-out code left behind
[ ] No hardcoded localhost, dev API URL, mock data, or test flag in production paths
[ ] NODE_ENV=production (or equivalent) actually set in the deployed environment
[ ] Every environment variable the app needs is set in the deployed environment
[ ] The app boots from a clean clone with only the documented setup steps
```

## 🔴 2. It's safe

```
[ ] appsec-hardening audit run; zero critical items open
[ ] No secret in the repo (scanned), in git history, in the build output, or in the client bundle
[ ] Auth: every resource access checks ownership server-side (IDOR test with two accounts)
[ ] Rate limits on: login, signup, password reset, and any expensive/paid endpoint
[ ] Passwords hashed with argon2id/bcrypt; reset tokens single-use, hashed, short-lived
[ ] Cookies: HttpOnly + Secure + SameSite
[ ] CSRF protection on state-changing requests
[ ] Uploads: type validated by content, size capped, renamed, stored outside the web root
[ ] Webhooks signature-verified and idempotent
[ ] Errors generic to users (no stack traces, no SQL, no internal paths)
[ ] HTTPS enforced; HSTS; no mixed content
[ ] Security headers: CSP, X-Content-Type-Options, X-Frame-Options/frame-ancestors, Referrer-Policy
[ ] Admin/staff routes protected by role on the server, not just hidden in the UI
[ ] Dependencies: lockfile committed, no known critical CVEs
[ ] Debug/admin tooling (adminer, graphql introspection, swagger) not publicly reachable
[ ] /.git, /.env, /backup, /node_modules return 404
```

## 🔴 3. Data survives

```
[ ] Automated backups enabled on the database
[ ] A RESTORE has been performed successfully (staging at minimum; prod ideally)
[ ] Backup retention window known and documented
[ ] Destructive migrations are reversible or have a tested rollback
[ ] The app's database user cannot drop the schema
[ ] Production data is not used in development or staging
[ ] Test/fixture data is not present in production
[ ] Deletion (if promised) removes data from: DB, object storage, email tool, analytics
[ ] Object storage buckets are private; access is via signed URLs
[ ] File uploads have a size and count limit per user
[ ] Deleting a user cascades correctly (no orphan rows that leak data)
[ ] No PII in logs, URLs, or analytics events
```

## 🟠 4. Failure is visible

```
[ ] Error tracking installed (Sentry or equivalent) and receiving events
[ ] A test error has been triggered and seen in the dashboard
[ ] Structured logs exist for the critical paths
[ ] Logs include a request/user correlation ID
[ ] Uptime check pings the app and alerts a human email address
[ ] Alerts configured: error-rate spike, failed payments, failed webhooks, failed emails
[ ] Alerting has fired at least once (proving the wiring, not just the config)
[ ] Log retention >= 30 days
[ ] No PII in logs
[ ] Someone is named as the person who sees the alerts
```

## 🟠 5. Performance

```
[ ] Main pages load in under 2-3s on a phone (run Lighthouse on mobile)
[ ] No N+1 queries on list views (checked the query log or a slow-query report)
[ ] Database indexes exist on the fields you filter and join on
[ ] Images are modern formats, correctly sized, lazy-loaded below the fold
[ ] JS bundle reviewed; nothing enormous shipped for no reason
[ ] Expensive work (email, PDF, AI, import) runs in the background, not in the request
[ ] Tested with at least 10x expected concurrent traffic, crudely (even a simple load script)
[ ] API responses are paginated with a cap
[ ] Caching on: static assets, and any expensive read that can tolerate staleness
[ ] Timeouts set on all outbound calls
```

## 🟠 6. Operations

```
[ ] Deploy is one command, repeatable, and documented in docs/RUNBOOK.md
[ ] Rollback procedure documented AND rehearsed
[ ] Staging or preview environment used for this release
[ ] CI runs tests/lint/build on every push
[ ] Domain + DNS understood; renewal date known; owner assigned
[ ] TLS certificate valid and auto-renewing (check the expiry date)
[ ] Ability to show a maintenance page without a deploy
[ ] Feature flags or a kill switch for risky new features
[ ] Health-check endpoint exists
[ ] Someone other than the author can deploy (or the runbook makes it possible)
[ ] On-call reality check: what happens at 3am? (write the answer in the runbook)
```

## 🟡 7. Legal & trust

```
[ ] Privacy policy live and matching what the code actually does
[ ] Terms of service (if money, or user-generated content)
[ ] Cookie banner — only if you actually use non-essential cookies
[ ] Contact route: an email address a human reads
[ ] Refund / cancellation path exists if you charge money
[ ] Subprocessor list known (hosting, email, payments, analytics, AI)
[ ] Data retention rules set per data type
[ ] Footer has the basics: privacy, terms, contact
```

## 🟡 8. Money & continuity

```
[ ] Monthly cost known for: hosting, DB, email, AI, storage, error tracking, misc
[ ] Billing alerts set on every paid service
[ ] Spend caps set where available (especially AI providers)
[ ] Revenue path tested end to end with a real (small) live payment
[ ] Accounting/invoice data retained per local law
[ ] Domain/hosting accounts are in the owner's name with MFA on
[ ] Renewal dates in a calendar with reminders
[ ] If you disappeared for a month, would the app keep running? (write the answer)
```

---

## The 30-minute "quick gate" (for small releases)

```
[ ] Critical path clicked through once, on a deployed URL, in a private window
[ ] No secret in the diff (git diff | grep for keys)
[ ] No console errors on the changed screens
[ ] Error tracker shows no new error types after 10 minutes of real use
[ ] Rollback still works
[ ] The person who owns the app knows what changed
```

---

## Launch day sequence

See `launch-and-handoff` for the full runbook. Short version:

```
T-1 day   run this gate, fix 🔴, write the certificate, tell users what's coming
T-0       deploy in the morning, smoke test the critical paths, watch errors for 30 min
T+0:30    announce to the smallest audience first
T+2h      check: errors, signups, payments, support inbox
T+24h     review: what broke, what confused people, what to fix first
T+7d      re-run the quick gate; fix the top 3 complaints
```
