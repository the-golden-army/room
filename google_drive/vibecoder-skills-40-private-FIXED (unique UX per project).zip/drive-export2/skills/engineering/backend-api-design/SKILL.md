---
name: backend-api-design
description: Use when creating or changing any endpoint — REST route, server action, RPC, or webhook — and when the frontend and backend need to agree on data shape. Defines URL conventions, correct status codes, one error contract, validation at the door, pagination/filtering/sorting, idempotency for anything that must not happen twice, versioning, long-running work as background jobs, and API docs. Prevents the silent contract failures that make AI-built apps impossible to debug.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# backend-api-design

## Promise

One consistent contract between the front end and the back end. Every request has a predictable shape,
every error says what's wrong in a way the UI can render, and nothing important can happen twice by accident.

## When to use

- Creating or changing any endpoint
- The frontend and backend disagree about data shape (the classic AI-generated bug)
- "It returns 200 but nothing happened"
- Adding a public API for customers or third parties
- Adding anything that must not run twice (payments, emails, bookings)
- Before writing the frontend for a feature

## When NOT to use

- Purely internal function calls inside one module (but keep the same error philosophy)

## The 60-second version

```
1. URLs are nouns: /api/bookings, /api/bookings/:id. Plural. Two levels deep, max.
   Actions that aren't CRUD: POST /api/bookings/:id/cancel (verb at the end).
2. Methods mean something: GET reads, POST creates, PUT/PATCH updates, DELETE removes.
3. Status codes are honest. 200 ok, 201 created, 400 bad input, 401 no session,
   403 not allowed, 404 not found/not yours, 409 conflict, 429 too many, 500 our fault.
   Never 200 with { success: false }.
4. ONE error shape for every error: { error: { code, message, fields? } }
5. Validate at the door with a schema. Reject unknown fields. Bound arrays and page sizes.
6. Paginate every list. Cap it. Return the total or a cursor.
7. Anything that must not happen twice takes an idempotency key (or a unique constraint).
8. Anything slow returns 202 + a job id, and the client polls or gets a webhook.
```

## Step 1 — URLs and methods

```
GET    /api/bookings            list (paginated, filterable, sortable)
POST   /api/bookings            create          → 201 + Location + the created object
GET    /api/bookings/:id        read one        → 200 or 404
PATCH  /api/bookings/:id        partial update  → 200
PUT    /api/bookings/:id        replace         → 200 (rarely needed)
DELETE /api/bookings/:id        delete          → 204 or 200
POST   /api/bookings/:id/cancel non-CRUD action → 200
GET    /api/teams/:id/members   nested list     → 200 (two levels max)
```

Rules:
- Plural nouns, kebab-case, no verbs in the path (except the trailing action)
- **Nest at most one level.** `/teams/:id/members` is fine; `/teams/:id/members/:mid/posts/:pid` is not
- Query string is for filtering, not for the resource: `?status=active&limit=20&cursor=...`
- Version in the path only for genuinely public APIs: `/api/v1/...`. For your own frontend, don't version —
  change both sides together
- Every endpoint authenticates unless it's explicitly public. Public is a decision, not a default

## Step 2 — Status codes (the honest table)

| Code | When | Body |
|---|---|---|
| 200 | Success with a body | the resource or result |
| 201 | Created | the created resource (+ `Location` header) |
| 202 | Accepted, work happening in the background | `{ jobId, statusUrl }` |
| 204 | Success, no body (usually DELETE) | empty |
| 400 | Invalid/malformed input | error contract with `fields` |
| 401 | No session / bad token | `{ error: { code: "unauthenticated" } }` |
| 403 | Authenticated but not allowed | generic message (or 404, to avoid confirming existence) |
| 404 | Not found **or** not yours | generic message |
| 409 | Conflict: duplicate, state clash, version mismatch | error with what to do |
| 422 | Valid syntax, invalid meaning (optional; 400 is fine instead) | error with `fields` |
| 429 | Rate limited | error + `Retry-After` header |
| 500 | Our fault | generic message; full detail in logs with a correlation ID |

**The cardinal sin:** `HTTP 200` with `{ "success": false, "error": "..." }`. It breaks every client's
error handling, every monitoring tool, and every retry library. Don't.

## Step 3 — One error contract

Every error, from every endpoint, in the same shape:

```ts
type ApiError = {
  error: {
    code: string;              // machine-readable, stable: "validation_failed", "not_found"
    message: string;           // human-readable, safe to display
    fields?: Record<string, string>;  // per-field messages for forms
    requestId?: string;        // so support can find it in the logs
  };
};
```

```ts
// lib/api.ts — one helper, used everywhere
export function apiError(status: number, code: string, message: string, fields?: Record<string, string>) {
  return Response.json({ error: { code, message, fields, requestId: currentRequestId() } }, { status });
}

// Usage
if (!parsed.success) return apiError(400, "validation_failed", "Some details need fixing.",
  Object.fromEntries(parsed.error.issues.map(i => [String(i.path[0]), i.message])));
if (!booking)         return apiError(404, "not_found", "We couldn't find that booking.");
```

Rules:
- `code` is stable and machine-readable; `message` is for humans and may change
- `message` is **safe to show a user** — no internals, no SQL, no stack
- Detail goes to the logs with the `requestId`; the client can quote the ID to support
- Validation errors map to field names the form uses
- Never leak whether a resource exists to an unauthorized caller (404, not 403)

## Step 4 — Validation at the door

```ts
const createBookingSchema = z.object({
  classId: z.string().uuid(),
  seats: z.number().int().min(1).max(10),
  note: z.string().max(500).optional(),
}).strict();

export async function POST(req: Request) {
  const requestId = crypto.randomUUID();
  const body = await req.json().catch(() => null);
  const parsed = createBookingSchema.safeParse(body);
  if (!parsed.success) return apiError(400, "validation_failed", "Some details need fixing.", fieldErrors(parsed.error));
  ...
}
```

Share the schema between the frontend and the backend — one definition, one truth. That's how you avoid
"the API accepts it but the form doesn't".

## Step 5 — Lists: pagination, filtering, sorting

```ts
// Offset (simple, fine up to ~100k rows)
GET /api/bookings?status=active&sort=-created_at&limit=20&offset=0
→ { data: [...], pagination: { total: 143, limit: 20, offset: 0, hasMore: true } }

// Cursor (better for large/deep lists and infinite scroll)
GET /api/bookings?limit=20&cursor=eyJpZCI6IjEyMyJ9
→ { data: [...], nextCursor: "…" | null }
```

Rules:
- Always paginate. Always cap `limit` (default 20, max 100)
- Allowlist sortable columns — never pass user input into `ORDER BY`
- Validate and bound every filter (status enum, date range, max length)
- Return the total (if cheap) or a cursor — the UI needs to know when to stop
- Stable sort: always add a tiebreaker (`ORDER BY created_at DESC, id DESC`) or pages will skip rows

## Step 6 — Idempotency (never do it twice)

Anything that creates money, sends an email, or books a slot must be safe to retry.

```ts
// Client generates a key per user action; server dedupes
const key = req.headers.get("idempotency-key") ?? crypto.randomUUID();

const existing = await db.idempotencyRecord.findUnique({ where: { key } });
if (existing) return Response.json(existing.response, { status: existing.status });

const result = await doTheThing();
await db.idempotencyRecord.create({ data: { key, response: result, status: 201 } });
return Response.json(result, { status: 201 });
```

Cheaper alternative that works for most cases: **a unique constraint that makes the duplicate impossible.**

```sql
-- One booking per user per class. The database enforces it; the app can't forget.
CREATE UNIQUE INDEX bookings_user_class ON bookings (user_id, class_id) WHERE status != 'cancelled';
```

Then handle the constraint violation as "already booked" instead of a 500. Prefer database constraints
over application checks — the database never has a bad day.

## Step 7 — Long-running work

Anything over ~2-3 seconds should not be a synchronous request.

```
POST /api/reports → 202 { jobId: "job_123", statusUrl: "/api/jobs/job_123" }
GET  /api/jobs/job_123 → { status: "pending" | "done" | "failed", resultUrl?: "..." }
```

Or: accept, process in the background, and notify by email/websocket when done.
Always: the client gets an immediate acknowledgement, and work is retried on failure with a job queue
(a `jobs` table + a worker is enough for most apps).

## Step 8 — Auth, and what the API returns

- Authenticate every endpoint by default; make public ones explicit
- Authorize per resource, not per route (see `auth-and-access`)
- **Return only what the caller may see.** No `SELECT *` straight to JSON — pick fields
- Never return password hashes, tokens, internal flags, or other users' data in a list response
- Different shapes for public vs internal: a public `/v1/me` shouldn't leak roles or internal IDs

## Step 9 — Documentation

Even for your own frontend, write it down:

```yaml
# openapi.yaml (or generated from zod/types)
/api/bookings:
  post:
    summary: Create a booking
    requestBody: { ... }
    responses:
      '201': { description: Created }
      '400': { description: Validation failed }
      '409': { description: Already booked }
```

Minimum viable: a `docs/API.md` table of endpoint / method / auth / request / response / errors.
Five minutes of writing saves an hour of guessing in three months.

## Non-negotiables

1. **Status codes are honest.** No `200` with a failure body.
2. **One error shape everywhere**, with a machine code and a human message.
3. **Validate at the door**, with bounds and no unknown fields.
4. **Every list is paginated and capped.**
5. **Anything irreversible is idempotent** — by key or by unique constraint.
6. **Errors are safe to display; details go to logs with a correlation ID.**
7. **Only return data the caller is allowed to see.**
8. **Slow work is a job, not a request.**
9. **Sortable and filterable columns are allowlisted.**
10. **The contract is written down** before the frontend is built against it.

## Ask the human

1. "Will anything other than your own app use this — a mobile app, a customer, a partner?" *(public API = versioning + docs + stricter limits)*
2. "Is there any action here that would be bad if it happened twice?" *(those get idempotency first)*
3. "Roughly how many items could end up in the main list — tens, thousands, millions?" *(pagination strategy)*
4. "If something takes more than a few seconds, should the user wait on the page, or get told when it's ready?"
5. "What should happen if two people try to do the same thing at the exact same moment?" *(race conditions are business rules, not bugs)*

Never ask: "REST or GraphQL?", "offset or cursor pagination?", "do you want OpenAPI?".

## Anti-patterns

| Anti-pattern | Why it hurts | Do instead |
|---|---|---|
| `200 OK` + `{ success: false }` | Breaks every client's error handling | Correct status code |
| A different error shape per endpoint | The UI can't handle errors generically | One contract |
| `POST /api/getBookings` | Verbs in URLs, GET semantics over POST | `GET /api/bookings` |
| Returning the whole DB row | Leaks hashes, flags, other tenants' fields | Pick fields explicitly |
| No pagination | 10,000 rows in one response | Paginate + cap |
| Check-then-insert for uniqueness | Race → duplicates | Unique constraint + handle the error |
| `ORDER BY` from user input | SQL injection / slow queries | Allowlist columns |
| Returning 500 for user errors | Pages the on-call for a typo | 400 with field errors |
| Slow work inline | Timeouts, retries, duplicate work | 202 + job |
| Changing the response shape silently | The frontend breaks at 2am | Version, or change both together |
| No error on partial failure | User thinks it all worked | All-or-nothing, or explicit partial result |
| Endpoint that's public "for now" | It stays public | Auth by default |

## Definition of done

- [ ] Every endpoint: correct method, honest status codes, one error shape
- [ ] All input validated with a shared schema, bounded, unknown fields rejected
- [ ] All lists paginated, capped, and sortable only on allowlisted columns
- [ ] Every irreversible action is idempotent (key or unique constraint)
- [ ] Slow operations return 202 with a job/status URL
- [ ] Responses contain only fields the caller is allowed to see
- [ ] Auth + ownership enforced per resource
- [ ] Rate limits on public and expensive endpoints
- [ ] `docs/API.md` (or OpenAPI) exists and matches the code
- [ ] Every endpoint tested with: a valid request, an invalid request, and an unauthorized request

## Works with

- `frontend-craft` — the client consumes this contract
- `auth-and-access` — who may call what
- `api-abuse-defense` — rate limits, quotas, validation
- `data-model-and-migrations` — the schema behind the endpoints
- `errors-logs-and-monitoring` — the correlation ID connects client errors to server logs
- `third-party-integrations` — when the API you're calling is someone else's
