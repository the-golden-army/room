---
name: database-efficiency
description: Use when designing any table, choosing a database, adding an index, or reviewing a schema that already exists. Prevents the most expensive mistake in vibe-coded apps — bloated tables, missing indexes, random provider choice — by teaching lean schema design (2 columns where 7 waste space), index strategy, provider selection, and production-zero-risk resource management. Use when someone says "is this schema good", "which database should I use", "it's slow", or "storage is getting expensive".
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# database-efficiency

## Promise

A database that costs as little as possible, performs as fast as needed, and never surprises you at 3am.
No wasted columns, no missing indexes, no mystery provider bill, no data you can't recover.
Every byte has a reason to exist.

> **Scope:** `data-model-and-migrations` teaches you *how to model and migrate safely*.
> This skill teaches you *how to keep that model lean, fast, and cheap in production* — resource-by-resource.

## When to use

- Creating any table, column, or relationship
- Reviewing an AI-generated schema (they always add 4 columns you don't need)
- Choosing a database or migrating providers (Postgres, MySQL, Supabase, Neon, PlanetScale, Turso, Mongo, Redis)
- Adding or questioning an index
- Storage, rows, or provider bill growing faster than users
- "It's slow" on a filtered list, search, or dashboard
- Setting retention, archiving, or partitioning
- Before launch, before scaling, or when hiring a DBA is not an option

## When NOT to use

- Changing application logic with zero schema impact
- One-off analytics queries that don't affect the live app
- You already have a dedicated DBA making these calls — let them lead

## The 60-second version

```
1. LEAN TABLES       Every column must earn its place. 2 columns beat 7 when 5 never get read.
2. RIGHT TYPE        Pick the smallest type that is still correct. Don't pay for generality you don't use.
3. INDEX INTENTIONALLY  Index what you query, not what you own. Each index costs write speed + storage.
4. RIGHT PROVIDER    The database is the one choice you can't easily undo. Choose for your actual shape.
5. MEASURE FIRST     No guessing. EXPLAIN ANALYZE, pg_stat, and provider metrics before you change anything.
6. MANAGE RESOURCES  Connections, storage, IOPS, bloat, and retention — all have ceilings. Enforce them in code.
7. ZERO-RISK OPS     Backups + tested restore, safe migrations, constraints in DB, and no silent data loss.
```

> **We don't have infinite space.** Every extra column × every row × every index × every replica = real money and real slowness.

## Steps

### Step 1 — Make every table pass the lean test

Before approving any schema, run this filter on **every column**:

```
1. Who reads this column? Name the screen, query, or job. No reader → no column.
2. Who writes it? Name the code path. No writer → no column.
3. Could it be derived? If `full_name` = `first_name + last_name`, store the parts, compute the display.
4. Could it be metadata of another row? `liked_at` belongs on the like row, not as a cached counter with 5 drift-prone columns.
5. Does it change history? If you only store `product_id` on an order, every price edit rewrites history. Snapshot what time-sensitive facts need.
```

**The like table example you named:**

```sql
-- ❌ 7 columns: vibe-coded bloat — pays storage + write cost forever
CREATE TABLE likes_bloated (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  post_id UUID NOT NULL REFERENCES posts(id),
  username TEXT,              -- already in users
  post_title TEXT,            -- already in posts
  liked_at TIMESTAMPTZ DEFAULT now(), -- just created_at
  is_liked BOOLEAN DEFAULT true,      -- if row exists = liked. Boolean is redundant.
  like_count INT DEFAULT 0              -- cached aggregate that drifts; compute or maintain via trigger
);
-- 7 columns, 3 redundant, 1 drift-prone counter, 2 denormalized copies that go stale

-- ✅ 2 columns (+ metadata you actually need, once)
CREATE TABLE likes (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, post_id) -- composite PK = uniqueness + index for free. No separate id needed.
);
-- Need the count? SELECT COUNT(*) WHERE post_id = $1  — or a materialized view if it must be fast
-- Need "liked?"  SELECT 1 FROM likes WHERE user_id = $1 AND post_id = $2
```

**Rules for lean tables:**

| Principle | How |
|---|---|
| **Store IDs, not copies** | `post_likes` stores `post_id + user_id`. The post title lives in `posts`. Join when you need it. Duplicating it means every title edit needs a cascade update you will forget. |
| **Composite PK for pure joins** | `PRIMARY KEY (a_id, b_id)` — no `id uuid` needed. One constraint does uniqueness + indexing. Saves 16 bytes/row + its index. |
| **No booleans for existence** | Row exists = true. Don't add `is_liked`. Don't add `is_active` when your query can filter on `WHERE status = 'active'`. |
| **No cached counters without a plan** | `like_count` drifts. If you need fast counts, use a trigger-maintained counter on `posts` *or* `COUNT(*)` with the right index — pick one, document which, and test the drift. |
| **Snapshots only for time-sensitive facts** | Order price at purchase time? Snapshot `price_cents + currency` on the order row. Liking a post? Never snapshot the title. |
| **Timestamps: two plus intent** | `created_at` + `updated_at` (via trigger). Add `deleted_at` only for soft-delete with a hard-delete job. Never `liked_at` when it's just `created_at`. |

Audit any existing table in 2 minutes:

```sql
-- Find columns that are probably bloat (zero non-null values, or never read)
SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'likes';
SELECT COUNT(*) as rows, COUNT(DISTINCT username) as distinct_usernames FROM likes_bloated; -- if 0, delete it
-- Find duplicate indexes
SELECT * FROM pg_stat_user_indexes WHERE relname = 'likes';
-- Find tables that are just joins but have a surrogate id
SELECT * FROM pg_constraint WHERE contype = 'p';
```

### Step 2 — Pick the smallest correct type (not the most convenient)

Type choice is storage × rows × indexes × I/O. On 10M rows, `TEXT` where `CHAR(2)` works, or `BIGINT` where `INT` works, is not "future proof" — it's a monthly bill.

| Decision | Lean choice | When to go bigger |
|---|---|---|
| **IDs** | `uuid` (16B) only if exposed in URLs or cross-DB merges. Else `bigint` (8B) — half the size. `int` (4B) if <2B rows expected. | Never `text` for an ID. |
| **Text** | `text` + length check in app is fine for Postgres. But for bounded codes use `char(2)` country, `char(3)` currency, `varchar(20)` phone — they document intent and save per-row padding. | — |
| **Numbers** | `integer` for counts, `smallint` for 0-32k ranges (like `seats` ≤ 1000). `numeric` only for exact decimals where `integer cents` doesn't fit. | `bigint` when you will plausibly exceed 2B. |
| **Money** | `integer` cents + `char(3)` currency. Never `float`, never `money` type. | Only when sub-cent precision required → `numeric(12,4)` |
| **Time** | `timestamptz` always. UTC. Never `timestamp without timezone`. | — |
| **Booleans** | `boolean NOT NULL DEFAULT false` | — |
| **JSON** | Only for truly schemaless blobs you *never* filter/sort on. If you filter it, it's a column. | Add `GIN` partial index only if you must query inside it |
| **Enums** | `text CHECK (status IN (...))` until 5+ values stable. Real `enum` type locks you on renames. | Convert to enum when values are truly fixed |
| **Arrays** | Avoid `text[]` for relations. That's a join table. | Only for ordered lists that are never queried relationally |

```sql
-- ✅ tight, intentional
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status TEXT NOT NULL CHECK (status IN ('confirmed','cancelled')) DEFAULT 'confirmed',
  seats SMALLINT NOT NULL CHECK (seats BETWEEN 1 AND 10), -- smallint: 2B vs 4B, constraint documents rule
  price_cents INT NOT NULL CHECK (price_cents >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- ❌ wasteful
CREATE TABLE bookings_bloated (
  id TEXT PRIMARY KEY, -- text id = bigger, no gen, app must supply
  status TEXT,         -- no check → garbage rows enter silently
  seats BIGINT,        -- 8B for a number that is 1-10
  metadata JSONB,      -- dumping ground that grows forever and never gets indexed
  notes TEXT, bio TEXT, extra_info TEXT -- 3 nullable columns nobody reads
);
```

### Step 3 — Index with intention (every index is a tax)

Each index costs: **storage + slower writes + vacuuming + backup size**. An index you never use is just a monthly bill.

**Index what you actually query. Nothing more.**

| Index this | Example |
|---|---|
| Every foreign key | `WHERE post_id = $1` on a join table |
| Every column in `WHERE` on hot queries | `WHERE user_id = $1 AND status = 'confirmed'` |
| Every column in `ORDER BY` on hot queries | `ORDER BY created_at DESC` |
| Uniqueness the business cares about | One active booking per user per class |
| — | — |
| **Never index this** | Why |
| A boolean alone (`is_published`) | Low selectivity, seq scan anyway |
| Every column "just in case" | Slows inserts/updates, grows to 40 unused |
| Duplicate leftmost prefix of composite | `ON (user_id)` when `ON (user_id, created_at)` already covers it |

```sql
-- ✅ intentional indexes — match real queries
CREATE INDEX bookings_user_created_idx ON bookings (user_id, created_at DESC); -- feed: WHERE user_id ORDER BY created_at
CREATE UNIQUE INDEX bookings_active_uniq ON bookings (user_id, class_id) WHERE status = 'confirmed';
CREATE INDEX posts_created_idx ON posts (created_at DESC) WHERE published = true; -- partial: only the active set

-- ❌ index bloat — real apps have 2x more indexes than needed
CREATE INDEX likes_username_idx ON likes_bloated (username); -- column shouldn't exist
CREATE INDEX bookings_id_idx ON bookings (id); -- PK already indexed
CREATE INDEX bookings_status_idx ON bookings (status); -- low selectivity alone, unless partial
```

**Verify before and after — no guessing:**

```sql
EXPLAIN ANALYZE SELECT * FROM bookings WHERE user_id = '...' ORDER BY created_at DESC LIMIT 20;
-- Want: "Index Scan" not "Seq Scan" on big tables. Note the ms before/after.

-- Find unused indexes (run on prod replica, after a full business cycle)
SELECT schemaname, relname, indexrelname, idx_scan, pg_size_pretty(pg_relation_size(indexrelid))
FROM pg_stat_user_indexes WHERE idx_scan = 0 AND schemaname = 'public' ORDER BY pg_relation_size(indexrelid) DESC;

-- Find missing indexes (slow queries)
SELECT query, calls, mean_exec_time FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;
```

Add indexes **concurrently** on live tables — never lock production:

```sql
CREATE INDEX CONCURRENTLY bookings_user_created_idx ON bookings (user_id, created_at DESC);
DROP INDEX CONCURRENTLY bookings_old_idx;
```

### Step 4 — Choose the provider for your actual shape (not by hype)

The provider/database is the one choice you can't easily undo. Pick by your **situation facts**, not by what the agent likes.

**First: which engine?**

| Your shape | Engine | Why |
|---|---|---|
| Default, you don't have a special need — and you want hiring, tooling, and escape routes | **Postgres** | JSON, search, queue-ish, vectors, geo — stays relevant at every stage. Most apps never leave. |
| Tiny app, embedded, offline-first, mobile/desktop sync | **SQLite** (+ Litestream/Turso for sync) | Zero ops. Thousands of real products run on it. |
| Document-shaped, rapidly changing fields you truly don't query relationally | **Mongo / DocumentDB** | Only when you actually need nested docs per record and relational joins would be painful. Still: Postgres JSONB covers 80% of this. |
| Cache, sessions, leaderboards, rate-limit counters | **Redis / Upstash / Dragonfly** | As a *cache beside* Postgres, never as the only store. |
| Wide-column, massive write throughput | **DynamoDB / Scylla / Cassandra** | You'll know — if you don't know, you don't need it. |
| Analytics over huge datasets | Postgres → warehouse (BigQuery/ClickHouse) when queries hurt | Don't start with a warehouse. |

**Then: which host for Postgres? Score on these axes — the brief tells you which matter:**

| Axis | What the human said | Provider that wins |
|---|---|---|
| **$0 until revenue** | "What can you spend? $0" | **Neon** free tier, **Supabase** free tier, or SQLite + files |
| **Hireable / portable** | "I'll hand to a contractor later" | Any vanilla Postgres (**Neon, Supabase, Railway, Render, RDS**). Avoid deep lock-in. |
| **Global / serverless / edge** | "Users worldwide, cold starts hurt" | **Neon** (branching, serverless driver), **Turso** (SQLite at edge), **PlanetScale** (MySQL vitess) |
| **You want admin + storage + auth + realtime in one** | "I don't want 5 services" | **Supabase** (Postgres + Auth + Storage + Realtime) — but know the coupling |
| **Enterprise / compliance / VPC** | "Contracts / legal" stakes | **RDS / Cloud SQL / Azure Postgres** — VPC, PITR, audit logs, SLA |
| **You already know it** | "I used Firebase before" | **Firebase/Firestore** only if you accept migration cost — never by accident. Ask the human first. |
| **Offline / embedded** | "Works on a plane" | **SQLite / Turso / LiteFS** |

```markdown
Decision: Postgres on Neon (free tier)
Because: ~100 daily users, spike to ~1k at launch, $0 budget until revenue,
  solo maintainer who may hire help (vanilla Postgres = hireable)
Rejected: Mongo — no document use case; RDS — overkill + not free; Firebase — vendor-shaped data model
Revisit when: >10k daily actives, or >50GB, or need read replicas / VPC
```

Record this in `docs/DECISIONS.md` with a **"Revisit when"** trigger — otherwise you re-litigate forever.

### Step 5 — Manage the resources you actually pay for

Storage is not infinite. Neither are connections, IOPS, or vacuuming. Enforce ceilings *in code*, not in hope.

| Resource | Where it bites | What to enforce |
|---|---|---|
| **Storage** | Every extra column × every row × every replica × every backup | Lean tables (Step 1) + smallest correct types (Step 2) + retention policy + archiving |
| **Rows (table bloat)** | Soft-delete forever, logs forever, session forever | TTL: sessions 30d, notifications 90d, logs 30d — hard-delete job, not just `deleted_at` |
| **Connections** | Serverless = 1 connection per request = "too many clients" | Single pooler (PgBouncer / Neon pooler / Supabase pooler), `max_connections` at provider + app `pool_size` tuned so `instances × pool < max` |
| **IOPS / slow queries** | Missing index, N+1, unbounded pagination | `LIMIT` + cursor, no `SELECT *` in hot paths, EXPLAIN on every list endpoint |
| **Bloat / dead tuples** | `UPDATE` churn, soft-delete without vacuum | Autovacuum tuned, or scheduled `VACUUM` on hot tables; archive instead of endless updating |
| **Bandwidth / egress** | Large payloads, heavy assets stored in DB | Store files in object storage (S3/R2), store only the URL/key in the DB |
| **Backups / replicas** | 50GB of `logs` and `events` nobody reads, replicated 3x | Archive to cheap storage (S3 Glacier) after N days; don't replicate what you don't need live |

**Retention pattern (the one vibe-coded apps never have):**

```sql
-- Keep live tables small; move old data out on a schedule, not when it's too late
-- 1. Archive job (nightly, batched so it doesn't lock)
DELETE FROM notifications
WHERE created_at < now() - interval '90 days'
AND id IN (SELECT id FROM notifications WHERE created_at < now() - interval '90 days' LIMIT 1000);
-- 2. Or archive to cheap storage first, then delete: COPY to S3/R2 as parquet, then delete
-- 3. Document the rule: "notifications kept 90d, bookings kept 7y per legal, sessions 30d"

-- Guardrail: hard limits in code so storage can't surprise you
// Never: SELECT * FROM events — will OOM at 100k rows
const page = await db.event.findMany({ take: 50, cursor: cursor, orderBy: { created_at: 'desc' }});
```

```ts
// ✅ enforce retention at write time — not in a forgotten cron
await db.notification.create({ data: { userId, body, expiresAt: addDays(now(), 90) }});
// nightly job: DELETE WHERE expiresAt < now()

// ✅ pool sizing — do the math once, write it down
// Provider allows 100 connections, 3 instances × pool 20 = 60 → safe. 3 × 50 = 150 → outage.
const poolSize = Number(process.env.DB_POOL_SIZE ?? 10);
```

### Step 6 — Zero-risk operations (the production gate)

Lean means nothing if a migration deletes prod.

```md
Before any destructive migration:
- [ ] Backup exists AND restore was tested this quarter
- [ ] Migration tested on prod-shaped data (not 10 rows)
- [ ] Reversible or has a tested forward fix
- [ ] Batched for >10k rows (no giant UPDATE)
- [ ] Low-traffic window, command shown with blast radius, wait for "go"
- [ ] Expand→backfill→contract for renames/type changes (never rename+drop in one release)
```

And constraints live in the **database**, not just the app:

```sql
-- The DB never forgets to check. The app does.
ALTER TABLE bookings ADD CONSTRAINT seats_range CHECK (seats BETWEEN 1 AND 10);
ALTER TABLE users ADD CONSTRAINT email_unique UNIQUE (email);
ALTER TABLE bookings ADD CONSTRAINT price_nonneg CHECK (price_cents >= 0);
-- Handle violations gracefully in code: 409 "already booked", not 500
```

## Non-negotiables

1. **Every column earns its keep.** No reader = no column. No writer = no column. No `like_count` without a plan for drift.
2. **Smallest correct type.** `int` where int works, `smallint` where 0-10, `uuid` only when IDs face URLs/merges. Never `float` for money, never `text` for an ID.
3. **Composite PK on pure join tables.** `PRIMARY KEY (a_id, b_id)` — no surrogate `id` wasting 16B/row plus its index.
4. **Every FK is indexed, every hot filter/sort is indexed — and no more.** Each index costs writes + storage. Verify with `EXPLAIN`.
5. **No duplicate or unused indexes.** Check `pg_stat_user_indexes` quarterly; drop the zeros.
6. **Schema measured before change.** `EXPLAIN ANALYZE` before and after, not hope.
7. **Provider chosen from situation, not habit.** Postgres unless you have a reason. Reason = brief fact, not preference.
8. **Resources have ceilings in code.** Pool size so `instances × pool < max`, pagination `LIMIT`, retention job, `max_rows` guards.
9. **Backups + tested restore before every destructive migration.** Expand→backfill→contract for renames.
10. **Data stays out of `app/` mocks.** No hardcoded arrays in components; real queries → real empty states. Seeded data lives in `scripts/seeds.*` only.
11. **Storage is monitored.** `pg_database_size`, `pg_total_relation_size`, table row counts, slow-query log — dashboarded or checked weekly, not during an outage.

## Ask the human

**One question at a time** — conversational, never a form.

Ask in this order, each with a default, skipping what you already learned:

1. "What are the main things this app keeps — like bookings, users, payments? Just name them roughly — I'll map the rest. — Not sure? Say 'you pick' and I'll propose from what you've told me."
2. "Roughly how many people on a busy day, and how long do we keep their history — forever or can we archive after a few months?"
3. "What does this store that's sensitive — health, money, IDs, kids? Affects encryption + what never goes in logs."
4. "What can you spend per month on the database? $0 is totally fine — I'll pick a free tier and tell you the ceiling."
5. "Is there an existing database or provider you want to stick with, or should I choose from scratch?"
6. "If we moved to a new provider later, how painful would that be — 'no problem' or 'please avoid'? Decides how portable we keep it."
7. "Could two people try to do the same thing at once — grab the last seat, buy the last item? Decides where we need strict constraints."

**How to ask:** Acknowledge the last answer in one short line, then one question with its inline default. Never a numbered list, never two at once. If they already answered ("~50 people a day") don't re-ask — state: "So I'll size for ~50/day — correct me if I'm wrong."

Never ask: "SQL or NoSQL? Postgres or MySQL? Normalized or denormalized? B-tree or GIN? Partition or shard?" — those are your job. Ask about people, money, time, and stakes.

## Anti-patterns

| Anti-pattern | Real cost | Do instead |
|---|---|---|
| 7 columns for a like when 2 suffice | Storage × rows × replicas × indexes × vacuum = bill + slowness forever | `PRIMARY KEY (user_id, post_id)` — 2 IDs, optional `created_at` |
| `id uuid` on every join table | 16B/row + its index + a second unique index on the pair — 2 indexes where 1 composite PK works | Composite PK |
| Duplicating `username`/`title` into likes | Stale copies; every rename needs a cascade you will forget | Join |
| Cached `like_count` with no sync | Drift: counter says 42, actual is 38. User notices. | `COUNT(*)` with index → materialized view/trigger only when proven slow |
| `float` for price, `money` type, local `timestamp` | Rounding errors, DST bugs, legal trouble | `integer cents` + `char(3)` currency, `timestamptz` UTC |
| `text[]` or CSV `tag_ids` column | Unqueryable, no FK, no index, unfixable reporting | Join table |
| Comma-separated IDs, JSON for filterable data | Slow, unindexed, type-unsafe | Real columns + real indexes |
| Index everything "just in case" | 40 unused indexes, slow writes, big backups | Index FKs + hot queries, verify with `pg_stat_user_indexes` |
| No index on FK | Postgres does **not** auto-index FKs → full scans on deletes/joins | Always index FKs |
| Booleans indexed alone | Low selectivity → planner ignores it anyway | Partial index: `WHERE status = 'confirmed'` |
| `SELECT *` on hot lists | Payload bloat + egress + OOM at 100k rows | Select needed columns + `LIMIT 50` + cursor |
| No pagination | OOM, slow TTFB, kills mobile on 4G | Cursor pagination, `take 50`, never `skip` at large offsets |
| Storing files/images in DB as `bytea`/`base64` | DB becomes slow file server, backups balloon | Object storage (S3/R2) + URL in DB |
| Soft-delete forever, never hard-delete | Table grows to millions of dead rows. Still scanned, still backed up, GDPR problem | TTL + nightly hard-delete job + archive to cheap storage |
| No retention policy | Notifications from 2019 still in prod | Document per-table TTL, enforce with job |
| "The cheapest provider" chosen by vibes | Free tier with 500MB limit → outage at launch | Score provider on 6 axes (budget, spike, portable, team, compliance, existing). Write `DECISIONS.md` with "Revisit when". |
| No backup restore test | "We have backups" — that fail on restore day | Restore test quarterly, command in `RUNBOOK.md` |
| Migration rename+drop in one release | Old code breaks instantly, no rollback | Expand→backfill→contract across releases |
| Measuring nothing | Guessing indexes, guessing provider, guessing when it's slow | `EXPLAIN ANALYZE` before/after, `pg_stat_statements`, provider dashboard |

## Definition of done

- [ ] Every table audited: each column has a named reader + writer, no redundant copies, no drift-prone counters without a sync plan
- [ ] Join tables use composite `PRIMARY KEY (a_id, b_id)` — no surrogate `id` on pure joins
- [ ] Types are smallest correct: `int`/`smallint` where they fit, `timestamptz` UTC, `integer cents + currency`, no `float` for money, no `text` IDs
- [ ] Indexes on every FK + every hot `WHERE`/`ORDER BY` — and no unused/duplicate indexes (`pg_stat_user_indexes` clean)
- [ ] Hot queries verified with `EXPLAIN ANALYZE` — "Index Scan" on large tables, not "Seq Scan"
- [ ] Provider chosen with a written decision: engine + host + why + rejected + "Revisit when" in `docs/DECISIONS.md`
- [ ] Pool sizing documented: `instances × pool < max_connections` with buffer — not `pool 50 × 3 instances = outage`
- [ ] Retention + archiving documented per table: `sessions 30d → delete`, `notifications 90d → archive`, etc. — job exists and runs
- [ ] No `SELECT *` on hot paths, no unbounded lists — pagination (`LIMIT` + cursor) on every list, `max_rows` guards
- [ ] Files/images in object storage, not `bytea` — DB stores only URL/key
- [ ] Constraints in DB: `NOT NULL`, `UNIQUE`, `CHECK`, `FK` with deliberate `ON DELETE` — not just app checks
- [ ] Backups automated, offsite, encrypted, with a **tested restore this quarter** and command in `RUNBOOK.md`
- [ ] Destructive migrations follow expand→backfill→contract, batched, low-traffic, with blast radius shown
- [ ] Storage tracked: `pg_database_size` + per-table size + slow-query log reviewed weekly, not during an outage

## Works with

- `data-model-and-migrations` — the safe modeling + migration patterns this skill keeps lean and fast
- `performance-and-caching` — when the bottleneck is query shape, N+1, or cache vs index
- `cost-guardrails` — the budget, quota, and billing alert habits that catch provider creep
- `reliability-and-incidents` — backups, restore, PITR, and the disaster runbook
- `backend-api-design` — pagination (`LIMIT` + cursor) and `select` only what you need
- `production-readiness` — the launch gate that checks data safety and resource ceilings
- `saas-architecture` — multi-tenancy and per-tenant limits/resource isolation
- `security/data-privacy-and-pii` — what not to keep, what never goes in logs, and deletion obligations
- `project-blueprint` — the `docs/SCHEMA.md` + `docs/DECISIONS.md` where the schema and provider choice live

