---
name: data-model-and-migrations
description: Use whenever creating or changing a database schema, adding a field, writing a migration, adding an index, or worrying about losing data. Covers schema design that matches the product, the columns every table needs, keys and relationships, the indexes that actually matter, money and time storage, zero-downtime migration patterns (expand/contract), reversible changes, and backups you have actually restored.
metadata:
  category: engineering
  version: 1.0.0
  value: "$100"
  group: engineering
---

# data-model-and-migrations

## Promise

The data survives every change you make. No lost rows, no locked tables, no 3am panic because a migration
dropped the wrong column in production.

## When to use

- Designing a schema for a new feature or app
- Adding/removing/renaming a column or table
- Writing or reviewing a migration
- "The app is slow" — it's often a missing index
- Before a destructive change (deleting data, changing types)
- Setting up backups, or before a big data operation
- Reviewing an AI-generated schema (usually missing FKs, indexes and constraints)

## When NOT to use

- Changing application logic with no schema change

## The 60-second version

```
1. Model the real world: the nouns in the product become tables. If you can't name it, it's not an entity.
2. Every table: id, created_at, updated_at. Add deleted_at only if you truly need undo.
3. Foreign keys with explicit ON DELETE behavior. Never orphan rows that contain user data.
4. Constraints in the DATABASE, not just in the app: NOT NULL, UNIQUE, CHECK, FK.
   The database is the only thing that never forgets to check.
5. Index every foreign key and every column you filter or sort by. Not everything — just those.
6. Money: integer minor units (cents) + currency code. Never floats.
7. Time: timestamptz, stored UTC, rendered in the user's timezone.
8. Migrations are expand → backfill → contract. Never rename and drop in one step.
9. Back up before every destructive migration. Test that you can restore.
10. Never run a migration you haven't run on a copy of production-shaped data first.
```

## Step 1 — Design the schema from the product

Take the brief. Underline every noun. Those are your tables.

| In the brief | Becomes |
|---|---|
| "Members book classes" | `members`, `classes`, `bookings` |
| "A class has a trainer and a room" | `classes.trainer_id`, `classes.room_id` |
| "Bookings can be cancelled" | `bookings.status`, `bookings.cancelled_at` |
| "Members pay monthly" | `subscriptions`, `invoices` |
| "Admins can see everything" | `users.role` |

Then ask the questions that shape the schema:

| Question | Answer drives |
|---|---|
| Can a booking exist without a member? | `NOT NULL` on `member_id`, and `ON DELETE` behavior |
| Can one member book the same class twice? | A unique constraint (or not) |
| Do we need to know what the price was at the time, or the current price? | Snapshot the price on the booking — this one bites everyone |
| Can something be in two categories? | A join table, not a comma-separated string |
| Do we need history ("who changed what")? | An append-only `audit_log` table |
| Is it ever deleted, or just deactivated? | `status` + `deleted_at`, plus a deletion job |

**Snapshot, don't reference, anything that changes.** A booking stores the price, the class name, and the
trainer at the time of booking. If you only store `class_id`, every historical record changes when someone
edits the class. This is the single most common data-model mistake in booking/order systems.

## Step 2 — The anatomy of a table

```sql
CREATE TABLE bookings (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  class_id      uuid NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,

  -- snapshot of the facts at booking time (they can change later)
  price_cents   integer NOT NULL CHECK (price_cents >= 0),
  currency      char(3) NOT NULL DEFAULT 'USD',
  class_name    text NOT NULL,

  status        text NOT NULL DEFAULT 'confirmed'
                CHECK (status IN ('confirmed','cancelled','completed')),
  seats         integer NOT NULL DEFAULT 1 CHECK (seats > 0 AND seats <= 10),

  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  cancelled_at  timestamptz
);

-- The indexes that matter
CREATE INDEX bookings_user_created_idx   ON bookings (user_id, created_at DESC);
CREATE INDEX bookings_class_idx          ON bookings (class_id);
CREATE INDEX bookings_status_idx         ON bookings (status) WHERE status = 'confirmed';  -- partial
CREATE UNIQUE INDEX bookings_active_uniq ON bookings (user_id, class_id) WHERE status = 'confirmed';
```

### Column rules

| Decision | Rule |
|---|---|
| Primary key | `uuid` (or ULID) if IDs appear in URLs or may be merged; `bigint` if you want max performance and never expose them. Pick one. |
| Timestamps | `timestamptz` (Postgres), always UTC, always `NOT NULL DEFAULT now()` |
| `updated_at` | Set by the database (trigger) or the ORM — not by hand |
| Money | `integer` minor units (cents) + a `char(3)` currency. **Never `float`, never `money` type.** |
| Booleans | `NOT NULL DEFAULT false`. Name them `is_*` / `has_*` |
| Status | `text` + a `CHECK` constraint (readable, flexible), or an enum if you're sure |
| Text | `text` with a length check in the app; `varchar(n)` only when the limit is a real business rule |
| JSON | Great for genuinely fluid data. Never for something you query or report on |
| Soft delete | `deleted_at` **plus** a real deletion job. Soft delete alone is a privacy problem |
| Nullable | Only when "unknown" is meaningfully different from "none". Otherwise `NOT NULL DEFAULT ''` |

### Relationships

- Always declare the foreign key. Even if the ORM can do it in app code — the database enforces it
- `ON DELETE` must be deliberate per relationship:

| Behavior | Use when |
|---|---|
| `RESTRICT` / `NO ACTION` | Deleting the parent should be blocked (default for important data) |
| `CASCADE` | The child has no meaning without the parent (booking → booking_attendees) |
| `SET NULL` | The child can exist without it (nullable only) |
| Soft delete | You need to keep history and "undo" |

- Many-to-many: a join table with its own `id`, timestamps, and a unique constraint on the pair

## Step 3 — Indexes (which ones, and no more)

Add an index for:
- ✅ Every foreign key (Postgres does **not** do this automatically)
- ✅ Every column in a `WHERE`, `ORDER BY`, or `JOIN` on a hot query
- ✅ Every uniqueness rule the business cares about
- ✅ Partial indexes for "the active ones" queries (`WHERE status = 'active'`)
- ✅ Composite indexes matching your most common filter + sort order

Don't:
- ❌ Index every column "just in case" — each one slows writes and grows the database
- ❌ Add an index that duplicates the leftmost part of an existing composite index
- ❌ Index low-cardinality columns alone (a boolean) unless it's partial

Verify with `EXPLAIN ANALYZE` before and after. Guessing is how you end up with 40 unused indexes.

```sql
EXPLAIN ANALYZE SELECT * FROM bookings WHERE user_id = '...' ORDER BY created_at DESC LIMIT 20;
-- Look for: "Seq Scan" on a big table = you need an index. "Index Scan" = good.
```

## Step 4 — Migrations that don't lose data

**Every migration is reversible or has a tested forward fix.** Before you write one, ask:
*"If this runs on production and something goes wrong, what's the undo?"*

### The expand → backfill → contract pattern (for renames and type changes)

```
Release 1 (EXPAND):   add the new column/table as nullable. Deploy. Nothing uses it yet.
Release 2 (WRITE):    write to BOTH old and new. Backfill historical rows in batches.
Release 3 (READ):     read from the new one; keep writing both.
Release 4 (CONTRACT): stop writing the old one; drop it in a later release.
```

Four deploys instead of one — and zero downtime, zero data loss, and a rollback at every step.

### Safe operations (usually fine on a live table)

```
✅ ADD COLUMN nullable (no default)              — instant
✅ ADD COLUMN with a non-volatile default        — fast on PG 11+
✅ CREATE INDEX CONCURRENTLY                     — no table lock
✅ DROP INDEX CONCURRENTLY
✅ ADD CONSTRAINT ... NOT VALID, then VALIDATE   — avoids a long lock
✅ CREATE TABLE
```

### Dangerous operations (never during traffic, and never without a backup)

```
⚠️ ADD COLUMN NOT NULL without a default         — fails or locks on a populated table
⚠️ DROP COLUMN                                   — irreversible; deploy code that ignores it first
⚠️ RENAME COLUMN / TABLE                         — breaks running code instantly
⚠️ ALTER COLUMN TYPE                             — full table rewrite; can lock for minutes
⚠️ ADD CONSTRAINT (validated)                    — locks the table while scanning
⚠️ DROP TABLE / TRUNCATE                         — self-explanatory
⚠️ Backfilling millions of rows in one statement — long lock, replication lag
```

### The checklist for every destructive migration

```
[ ] Is there a backup, and has a restore been tested recently?
[ ] Can I run it on a copy of production data first? (do it — this is where you find the surprise)
[ ] Do I know how long it takes on production-sized data?
[ ] Is there a reverse migration, or a tested forward fix?
[ ] Have I removed all code that reads the old shape FIRST?
[ ] Is it batched (for backfills)?
[ ] Am I running it at a low-traffic time?
[ ] Do I have the exact command written down, shown to a human before running? (see vibe-guardrails)
```

```sql
-- Batch backfill, not one giant UPDATE
UPDATE bookings SET price_cents = 2000
WHERE id IN (SELECT id FROM bookings WHERE price_cents IS NULL LIMIT 1000);
-- repeat until 0 rows affected, with a small sleep between batches
```

## Step 5 — Data integrity lives in the database

The application changes. The schema remains. Put the rules where they can't be forgotten:

| Rule | Where |
|---|---|
| Email is unique | `UNIQUE` constraint (case-insensitive via `citext` or a lower() index) |
| Price can't be negative | `CHECK (price_cents >= 0)` |
| Status is one of a known set | `CHECK` or enum |
| Every booking has a user | `NOT NULL` + `FOREIGN KEY` |
| One active booking per user per class | Partial unique index |
| Deleting a user removes their data | FK `ON DELETE CASCADE` + a deletion job |

Handle the constraint violation gracefully in the app:

```ts
try { await db.booking.create({ data }); }
catch (e) {
  if (isUniqueViolation(e)) return apiError(409, "already_booked", "You're already booked into this class.");
  throw e;   // anything else is a real bug — log it and return 500
}
```

## Step 6 — Backups

| Question | Target |
|---|---|
| How often? | How much data can you lose? An hour of data → hourly or continuous (PITR) |
| Where? | A different physical location / provider than the database |
| Encrypted? | Yes, always |
| Who can restore? | Named people, with MFA |
| Retention? | 7-30 days typical; check legal requirements for financial records |
| **When was the last restore test?** | **This is the only question that matters.** |

```bash
# The test that must happen at least once (and then quarterly)
pg_dump "$DATABASE_URL" > /tmp/backup.sql           # or your provider's snapshot
createdb restore_test && psql restore_test < /tmp/backup.sql
psql restore_test -c "SELECT count(*) FROM users;"  # does the data look right?
dropdb restore_test
```

An untested backup is a hope, not a backup. Write the restore command in `docs/RUNBOOK.md` — you will not
remember it under pressure.

## Non-negotiables

1. **Every foreign key is declared, with deliberate `ON DELETE` behavior.**
2. **Every table has `id`, `created_at`, `updated_at`.**
3. **Money is integer minor units. Time is UTC.**
4. **Business rules are database constraints**, not just application checks.
5. **Every foreign key and hot filter/sort column is indexed.**
6. **Migrations are expand → backfill → contract.** No rename-and-drop in one release.
7. **Backup before every destructive migration** — and the restore path is known.
8. **Every migration is reversible or has a tested forward fix.**
9. **Test migrations against production-shaped data**, not 12 rows of fixtures.
10. **Never show a destructive command to a human without the blast radius and wait for "go".**

## Ask the human

1. "What are the main things this app keeps track of? Let's name them." *(entities)*
2. "If you deleted a customer, should their history disappear too, or stick around for the records?"
3. "Do you need to know what things cost back then, or what they cost now?" *(the snapshot question)*
4. "How much data would you be devastated to lose — an hour's worth, a day's, or a week's?" *(backup frequency)*
5. "Could two people ever try to do the same thing at the same moment — book the last seat, buy the last item?"
6. "Are there numbers here where being off by a cent matters?" *(money handling)*

Never ask: "UUIDv4 or UUIDv7?", "normalized or denormalized?", "should we add a partial index?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| No foreign keys ("the ORM handles it") | Orphan rows, silent corruption | Declare FKs |
| `float` for money | Rounding errors in someone's invoice | Integer cents |
| Storing local time without a timezone | Wrong times after every DST change | `timestamptz`, UTC |
| Storing a price only as a reference | Historical records change retroactively | Snapshot the value |
| Comma-separated IDs in a column | Unqueryable, unfixable | Join table |
| `DROP COLUMN` in the same release as the rename | Old code breaks instantly | Expand/contract |
| A migration tested on 10 rows | Locks production for 20 minutes | Test on production-shaped data |
| Backups configured, never restored | You find out during the outage | Restore test, quarterly |
| Index on everything | Slow writes, big DB | Index FKs + hot queries only |
| Editing production data by hand with no record | Nobody knows what changed | A scripted, reviewed, logged data fix |
| No `updated_at` | Impossible to debug "when did this change?" | Always, set automatically |
| Deleting rows to "clean up" | Gone forever | Soft delete + a real deletion job with approval |

## Definition of done

- [ ] Schema documented in `docs/SCHEMA.md` in plain words (what each table is for)
- [ ] Every table: id, created_at, updated_at; FKs declared with deliberate ON DELETE
- [ ] Money as integer minor units + currency; timestamps as UTC
- [ ] Business rules enforced by constraints (NOT NULL, UNIQUE, CHECK, FK)
- [ ] Indexes on every FK and every hot filter/sort — verified with `EXPLAIN ANALYZE`
- [ ] Migration is reversible or has a tested forward fix; tested on production-shaped data
- [ ] Destructive changes follow expand → backfill → contract across releases
- [ ] Backups automated, encrypted, offsite, with a tested restore within the last quarter
- [ ] Restore command written in `docs/RUNBOOK.md`
- [ ] No production data in development or test environments

## Works with

- `backend-api-design` — the API sits on this schema
- `production-readiness` — data safety is Gate 3
- `reliability-and-incidents` — backups, restore, disaster recovery
- `performance-and-caching` — indexes and N+1 queries
- `saas-architecture` — tenant modeling and isolation
- `data-privacy-and-pii` — retention, deletion, and PII columns
