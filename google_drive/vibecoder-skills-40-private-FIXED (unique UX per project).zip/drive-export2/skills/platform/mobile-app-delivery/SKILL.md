---
name: mobile-app-delivery
description: Use when building or shipping an iOS/Android app — choosing between Expo, React Native, Flutter, or a web app; handling auth, push notifications, offline data, over-the-air updates, app secrets, store review, signing and release. Covers the specific rules that get vibe-coded mobile apps rejected: "Sign in with Apple", account deletion, privacy manifests, in-app purchase rules, and the fact that anything in an app binary is public.
metadata:
  category: platform
  version: 1.0.0
  value: "$100"
  group: platform
---

# mobile-app-delivery

## Promise

Your app gets approved, works offline, notifies people without annoying them, and can be updated without
waiting a week for a review.

## When to use

- "I want an app in the App Store / Play Store"
- Building with Expo, React Native, Flutter, or Capacitor
- Adding push notifications, offline mode, camera/location, or in-app purchases
- Submitting for review, or dealing with a rejection
- Adding OTA updates, or planning a release process

## When NOT to use

- A web app that works fine on mobile (seriously — check first)

## Step 0 — Do you actually need an app?

| Situation | Answer |
|---|---|
| Content, booking, e-commerce, most SaaS | **A great mobile web app.** No store review, instant updates, one codebase. |
| Needs push notifications | Web push works on Android and (since iOS 16.4) on iOS for installed PWAs. Test it first. |
| Needs camera, offline, background location, Bluetooth, NFC, Apple/Google Pay | **Native app.** |
| You're selling digital goods | Note: stores take 15-30% and require their in-app purchase system. Sell on the web instead. |
| Users keep asking "is there an app?" | Build the web app first, then wrap it if the demand is real. |

Building mobile is roughly **2-3x the work** of web, plus review cycles and a yearly fee ($99 Apple,
$25 Google one-time). Say that out loud before starting.

## The 60-second version

```
1. USE EXPO (React Native) unless you have a reason not to. It removes 90% of native tooling pain.
2. THE API IS THE SECURITY BOUNDARY. Assume the app is fully compromised. No secrets in the binary.
3. TOKENS IN THE OS KEYSTORE (Keychain / Keystore), never AsyncStorage.
4. HANDLE OFFLINE: cache reads, queue writes, reconcile when back online.
5. PUSH: ask at the moment of value, not on first launch. Respect quiet hours.
6. OTA updates for JS/bundle changes; a store release for native changes.
7. STORE RULES that reject apps: no account deletion, no "Sign in with Apple" when other social
   logins exist, missing privacy manifest, no way to use the app without login, broken links.
8. TEST ON REAL DEVICES, on both platforms, on the oldest OS you support.
```

## Step 1 — Choose the stack

| Option | Pick when |
|---|---|
| **Expo (React Native)** | Default. You know React, you want OTA updates, you want one codebase, you don't want to open Xcode |
| **React Native (bare)** | You need a native module Expo doesn't support, or you have native experience |
| **Flutter** | You don't know React, or you want very custom UI with consistent behavior |
| **Native (Swift/Kotlin)** | You need deep OS integration, maximum performance, or platform-specific excellence |
| **Capacitor / web wrapper** | You already have a great mobile web app and want it in the store (be honest about the UX) |

Recommended: **Expo + TypeScript + your existing backend**. The mobile app is just another client.

## Step 2 — Security (mobile has nowhere to hide a secret)

| Rule | Why |
|---|---|
| **No secrets in the app.** No API keys, no service credentials, no signing secrets | Anyone can extract strings from the binary in minutes. Even obfuscated ones. |
| **Route third-party calls through your server** | Your server holds the key, authenticates the user, rate limits, and logs |
| **Tokens in the OS secure store** | `expo-secure-store` / Keychain (iOS) / Keystore (Android). Never `AsyncStorage` |
| **Certificate/SSL pinning** | Only if you have a specific threat model; it breaks debugging and can lock users out |
| **No sensitive data in logs or crash reports** | Crash reporters upload device logs |
| **Validate deep link parameters** | `myapp://reset?token=x` can be opened by any app on the device |
| **Biometric unlock** | A convenience layer over the token, not the security itself |
| **Jailbreak/root detection** | Only if you handle payments or sensitive data, and never as the only control |
| **The server re-checks everything** | Price, ownership, permissions — same as `appsec-hardening` |

```ts
// ✅ token in the secure store
import * as SecureStore from "expo-secure-store";
await SecureStore.setItemAsync("session", token, { keychainAccessible: SecureStore.WHEN_UNLOCKED });

// ❌ readable by anything with file access
await AsyncStorage.setItem("token", token);
```

## Step 3 — Auth on mobile

- Use the same backend auth as the web (session cookie works in a WebView; for native, use a bearer token
  in the secure store with refresh)
- OAuth ("Sign in with Google/Apple") opens a browser → redirect back via a **universal link / custom scheme**
- **Apple's rule:** if you offer any third-party social login (Google, Facebook), you MUST offer
  "Sign in with Apple" too. This is a top rejection reason
- Support "Hide My Email" (Apple's relay addresses) — don't assume the email is a real inbox
- Handle the app being killed mid-login (persist state before opening the browser)
- Refresh tokens silently; on failure, send to login with a clear reason
- Biometric re-auth for sensitive actions (payments, changing email)

## Step 4 — Offline and sync (users expect it)

```
READS:   cache the last known good data (SQLite / MMKV / AsyncStorage) → render instantly →
         refresh in the background → show "updated 10:42" or a subtle refresh indicator
WRITES:  queue the mutation locally with an idempotency key → show it optimistically →
         replay when online → reconcile conflicts
```

Rules:
- Every mutation carries a client-generated idempotency key, so a replay doesn't double-book
- Conflict resolution is a **business decision**: last-write-wins, server-wins, or ask the user. Pick one
  per data type and write it down
- Show connection state honestly ("You're offline — changes will sync")
- Never lose a queued write, even if the app is killed: persist the queue to disk
- Test: airplane mode → create → close app → open → online → it syncs

## Step 5 — Push notifications

| Rule | Why |
|---|---|
| Ask at the **moment of value** ("notify me when my booking is confirmed?"), not on first launch | First-launch prompts get denied ~70% of the time |
| Explain the value **before** the system prompt (a pre-prompt) | Doubles opt-in rates |
| Send less than you think | Every unnecessary notification costs you the permission |
| Respect quiet hours and the user's timezone | A 3am notification is uninstallation |
| Deep link to the relevant screen | A notification that opens the home screen is a dead end |
| Let users choose categories in settings | Granular control beats all-or-nothing |
| Handle the token lifecycle | Tokens rotate; update on every app launch; delete on logout |
| Test on a **real device** | Push does not work in the iOS simulator |

```ts
// Ask at the right moment
const { status } = await Notifications.requestPermissionsAsync();
if (status !== "granted") { /* don't nag; offer it again in settings later */ }
const token = (await Notifications.getExpoPushTokenAsync()).data;
await api.post("/api/push-tokens", { token, platform: Platform.OS });
```

## Step 6 — Updates: OTA vs store release

| Change type | Mechanism | Time |
|---|---|---|
| JS/TS, assets, UI | **OTA update** (EAS Update / CodePush) | Minutes |
| New native module, permission, SDK bump | Store release + review | Hours to days |
| Anything affecting binary behavior (entitlements, Info.plist) | Store release | Hours to days |

OTA rules:
- Always have a **rollback** to the previous OTA version (this is why OTA beats a web deploy in risk terms:
  you can un-ship instantly)
- Don't OTA a change that breaks compatibility with an older binary — use channels/runtime versions
- Test OTA on a real device before broadcasting
- Keep a small forced-update path for critical fixes

## Step 7 — Store submission (avoid the top rejections)

**Apple — the classics:**

| Rejection | Fix |
|---|---|
| No way to delete an account in-app | **Required** if you have account creation. Add it, and delete the data |
| Third-party social login without "Sign in with Apple" | Add it |
| Missing privacy manifest / inaccurate privacy labels | Declare the data you collect and why; match reality |
| Selling digital goods outside IAP | Use IAP, or sell on the web and consume in-app |
| App requires login for no reason | Allow browsing, or explain why in the review notes |
| Broken links, placeholder content, "lorem ipsum" | Ship something complete |
| Crashes on launch, or on iPad if you claim iPad support | Test both |
| Missing a privacy policy URL | Add one to the store listing and in-app |
| Using a private/untested API | Don't |
| Not supporting the latest SDK / missing required architecture | Build with the current SDK |

**Google Play:**

| Requirement | Note |
|---|---|
| Data Safety form | Declare collection, sharing, encryption, and deletion — and make it true |
| Target the recent API level | Play requires a recent target SDK each year |
| App signing by Play | Enroll; keep your upload key safe |
| Content rating questionnaire | Complete it honestly |
| Permission justification | Request the minimum; justify sensitive ones |
| Testing track | Use internal/closed testing before production |

**Both:** screenshots for every device size you support, a clear description, keywords in the subtitle,
a support URL, a marketing URL, and a privacy policy URL. Screenshots sell the app — make them show the
core screen with a one-line caption.

## Step 8 — Release process

```
1. Version bump (app version + build number — build number MUST increment every upload)
2. Build in the cloud (EAS Build) — no "works on my machine"
3. Test the release build on a real device (debug builds hide performance and permission issues)
4. Internal testing (TestFlight / Play internal) with 3-10 people
5. OTA the JS changes only after the native shell is live
6. Phased release (Google) / manual release (Apple) — watch crash rate for 24h
7. Keep the previous build ready to roll back
8. Write release notes users care about ("fixed the bug where reminders didn't arrive")
```

## Non-negotiables

1. **No secrets in the app binary.** Everything secret goes through your server.
2. **Tokens in the OS secure store**, never AsyncStorage.
3. **Offline is designed, not hoped for**: cached reads, queued writes, conflict rules.
4. **Push permission is asked at the moment of value**, and notifications are configurable.
5. **OTA updates with a rollback**, for everything that isn't native.
6. **In-app account deletion** if you have accounts.
7. **"Sign in with Apple"** if you offer any other social login.
8. **Privacy labels match what the app actually does.**
9. **Tested on real devices**, both platforms, on the oldest supported OS.
10. **The server enforces everything** — price, ownership, permissions, quotas.

## Ask the human

1. "Do you actually need an app, or would a really good mobile website do the job?" *(ask this first, honestly)*
2. "Do your users need the phone's camera, location, notifications, or offline access?"
3. "Are you okay with Apple and Google taking a cut of payments, or will people pay on your website?"
4. "Do you have an Apple developer account yet? It costs $99/year and takes a day to set up."
5. "Can you test on a real iPhone and a real Android phone? (Simulators aren't enough.)"
6. "Will people use this where the signal is bad?" *(drives the offline work)*

Never ask: "Expo or bare workflow?", "APNs or FCM directly?", "Hermes or JSC?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Shipping your web app in a WebView and calling it an app | Bad UX, store rejection | Native UI, or stay on the web |
| API keys in the bundle | Anyone can extract and abuse them | Proxy through your server |
| Tokens in AsyncStorage | Trivially readable | Secure store |
| Asking for push permission on first launch | Mass denial | Ask at value |
| No offline handling | App is unusable in a lift | Cache + queue |
| No account deletion | Rejection, and it's rude | Build it |
| Testing only in a simulator | Push, camera, permissions all behave differently | Real devices |
| OTA-updating a breaking change | Old binaries crash | Channels + compatibility checks |
| Uploading without bumping the build number | Rejected upload | Automate it |
| Ignoring the privacy manifest/nutrition labels | Rejection or removal | Fill them in truthfully |
| Assuming one codebase means one UI | iOS and Android users expect different things | Respect platform conventions |
| No crash reporting | You learn about crashes from 1-star reviews | Install it before launch |

## Definition of done

- [ ] Need for a native app validated (or a conscious decision recorded)
- [ ] No secrets in the binary; tokens in the OS secure store
- [ ] Server enforces auth, ownership, price, and quotas
- [ ] Offline: cached reads, queued writes with idempotency keys, sync and conflict rules tested in airplane mode
- [ ] Push: requested at the right moment, configurable, deep-links correctly, token lifecycle handled
- [ ] OTA updates working with a rollback path
- [ ] Store listings complete: screenshots for all sizes, description, keywords, privacy policy, support URL
- [ ] Apple: account deletion in-app, Sign in with Apple if any social login, privacy manifest accurate
- [ ] Google: Data Safety form accurate, target SDK current, permissions minimised
- [ ] Tested on a real iOS device and a real Android device, release build
- [ ] Crash reporting + analytics installed, privacy-respecting
- [ ] Previous build is a one-click rollback

## Works with

- `appsec-hardening` — the mobile-specific attack surface
- `auth-and-access` — mobile OAuth and token handling
- `secrets-management` — why the binary is public
- `stack-selection` — the web-vs-native decision
- `production-readiness` — the mobile additions to the gate
- `cost-guardrails` — push, maps, and AI usage from mobile
