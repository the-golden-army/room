---
name: desktop-app-delivery
description: Use when building or shipping a Mac, Windows or Linux app with Electron, Tauri, or similar. Covers when desktop is actually worth it, Tauri vs Electron, sandboxing and IPC security, code signing and notarization (so Gatekeeper and SmartScreen don't block your installer), auto-update with signature verification and rollback, local data storage, installers and size, and distribution outside the app stores.
metadata:
  category: platform
  version: 1.0.0
  value: "$100"
  group: platform
---

# desktop-app-delivery

## Promise

People download it, it installs without scary warnings, it updates itself safely, and it behaves like a
real desktop app rather than a website in a window.

## When to use

- "I want a Mac/Windows app"
- Building with Electron, Tauri, Neutralino, or Flutter desktop
- Setting up code signing, notarization, auto-update, or installers
- An installer is being blocked by Gatekeeper / SmartScreen
- Storing data locally, integrating with the OS (files, menus, tray, shortcuts, notifications)

## When NOT to use

- The product works fine in a browser (most do — check first)

## Step 0 — Do you need desktop?

| Real reason for desktop | Not a real reason |
|---|---|
| Access to the local filesystem, USB/serial devices, or hardware | "It feels more professional" |
| Works fully offline with local data | "I don't want a URL" |
| Deep OS integration (global shortcuts, menu bar, tray, file associations) | "Apps are more valuable" |
| Heavy local processing (video, audio, large datasets) | "Tauri is trendy" |
| Your customers' IT policy requires an installed app | — |

If none of the left column applies, ship a web app and spend the difference on the product.

## The 60-second version

```
1. TAURI by default (small, fast, memory-safe). ELECTRON when you need Node APIs or a big ecosystem.
2. SANDBOX IT: no Node integration in the renderer, context isolation ON, validate every IPC message,
   and a strict CSP. A desktop app runs with the user's full privileges.
3. SIGN EVERYTHING: Apple Developer ID + notarization, a Windows code-signing certificate.
   Unsigned installers get blocked, and users learn not to trust you.
4. AUTO-UPDATE with signature verification and a rollback channel. Test the updater before release.
5. STORE DATA in the OS app-data directory; secrets in the OS keychain; never next to the executable.
6. SHIP INSTALLERS per platform (.dmg/.pkg, .msi/.exe, .AppImage/.deb). Watch the size.
7. HANDLE OFFLINE: desktop users expect it to work on a plane.
8. LOG CRASHES locally and (with consent) remotely; give users a way to send diagnostics.
```

## Step 1 — Tauri vs Electron

| | Tauri | Electron |
|---|---|---|
| Size | ~5-15MB installer | ~80-150MB installer |
| Memory | Low (uses the OS webview) | Higher (bundles Chromium) |
| Backend | Rust | Node.js |
| Maturity | Newer, moving fast | Very mature, huge ecosystem |
| Consistency | Uses the OS webview (WebKit on macOS, WebView2 on Windows, WebKitGTK on Linux) — test per platform | Same Chromium everywhere |
| Pick it when | You want small/fast, and you can write a little Rust (or use the JS API) | You need Node native modules,mature plugins, or you already have an Electron app |

Both are legitimate. If you're unsure and don't need Node: **Tauri**.

## Step 2 — Security (a desktop app is privileged code)

The renderer (your UI) is untrusted — it's a browser showing possibly-remote content. The backend is
trusted and powerful. Keep them apart.

```ts
// Electron — the correct defaults
const win = new BrowserWindow({
  webPreferences: {
    nodeIntegration: false,        // ❌ never true
    contextIsolation: true,        // ❌ never false
    sandbox: true,
    webSecurity: true,
    preload: path.join(__dirname, "preload.js"),
  },
});

// preload.ts — expose a minimal, validated API. Never expose `ipcRenderer` raw.
contextBridge.exposeInMainWorld("api", {
  readFile: (p: string) => ipcRenderer.invoke("read-file", validatePath(p)),
  saveFile: (p: string, content: string) => ipcRenderer.invoke("save-file", validatePath(p), content),
});
```

```rust
// Tauri — allowlist only what you need
tauri::Builder::default()
  .invoke_handler(tauri::generate_handler![read_file, save_file])
  .run(tauri::generate_context!())
```

Checklist:

```
[ ] Node integration OFF in the renderer
[ ] Context isolation ON
[ ] Sandbox ON
[ ] A strict Content-Security-Policy (no unsafe-inline, no remote scripts)
[ ] Every IPC/desktop API call validated on the backend (paths, URLs, sizes, types)
[ ] No path traversal: resolve and check the prefix before touching the filesystem
[ ] Remote content is never loaded with privileges (or is fully sandboxed)
[ ] Auto-update verifies the signature before installing
[ ] No secrets in the bundle; user secrets in the OS keychain
[ ] Deep links / protocol handlers validate their parameters
[ ] Devtools not enabled in production builds
[ ] `node_modules` and source maps not shipped to users
[ ] Local HTTP servers (if any) bind to localhost only, with a random port and a token
```

## Step 3 — Signing and notarization (do this early)

| Platform | What you need | What happens without it |
|---|---|---|
| **macOS** | Apple Developer Program ($99/yr) → Developer ID Application certificate → notarize with `notarytool` | Gatekeeper blocks it: "app is damaged and can't be opened" |
| **Windows** | A code-signing certificate (OV or EV; EV gets SmartScreen reputation faster) | SmartScreen warning: "Windows protected your PC" |
| **Linux** | Usually nothing (checksums + a signed repo are good practice) | Nothing breaks, but publish checksums |

```bash
# macOS: sign, then notarize, then staple
codesign --deep --force --options runtime --sign "Developer ID Application: You (TEAMID)" MyApp.app
ditto -c -k --keepParent MyApp.app MyApp.zip
xcrun notarytool submit MyApp.zip --apple-id you@example.com --team-id TEAMID --password "$APP_PASSWORD" --wait
xcrun stapler staple MyApp.app
xcrun stapler validate MyApp.app
# Verify what a user will experience
spctl --assess --type open --verbose=4 MyApp.app
```

Rules:
- Sign the **inner app bundle first, then the installer**, outer-last
- Notarize every build you ship, including updates
- Use a timestamp server so signatures stay valid after the certificate expires
- Keep the certificate and its password in a secret manager, and never on a build machine you don't control
- Budget a few days the first time; it's a one-time ritual per project, then it's automated

## Step 4 — Auto-update

```
[ ] The updater verifies the update signature against your public key (built into the app)
[ ] Updates are served over HTTPS from a location you control
[ ] A rollback channel exists (if a release is bad, you can ship the previous version)
[ ] Delta updates if the binary is large
[ ] The user can defer/postpone, and you don't force-restart mid-work (or you warn first)
[ ] Release notes are shown before installing
[ ] The updater itself has been tested: install v1 → it offers v2 → v2 runs → it can be rolled back
[ ] Update checks are rate-limited and respectful (not on every launch, every second)
```

Test the updater **before** you need it. A broken updater means your users are stuck on the version with
the bug, and the only fix is a manual reinstall.

## Step 5 — Local data

| Data | Where |
|---|---|
| App data / database | The OS app-data directory (`appDataDir`, `~/Library/Application Support/<App>`, `%APPDATA%`) |
| User documents | Where the user chose, with the file association registered |
| Secrets / tokens | OS keychain (Keychain, Credential Manager, libsecret) |
| Cache | The OS cache directory, and it must be safe to delete |
| Logs | A log directory, rotated, accessible from a "Open logs" menu item |

- **Never write next to the executable** — Program Files and `/Applications` are often read-only for
  non-admin users, and it breaks code signing
- SQLite is the right default for structured local data
- Back up/export: give users a way to export their data (and it's often a legal expectation)
- Handle "the disk is full", "the file is locked", and "the folder was moved" gracefully

## Step 6 — Packaging and size

| Platform | Deliver |
|---|---|
| macOS | `.dmg` (drag-to-install) + a signed `.pkg` for managed deployments; universal (arm64 + x86_64) if you can |
| Windows | `.msi` for enterprises + an `.exe` installer (NSIS/WiX) for everyone else |
| Linux | `.AppImage` (universal), plus `.deb` and `.rpm` if you can |

Size budget: under 50MB is great, 100MB is acceptable for Electron, more is a complaint. Check what's in
the bundle — `node_modules` shipping to users is the classic mistake.

Also: an app icon in every size, a file association if relevant, a proper app name and version in the
metadata, and a "check for updates" menu item.

## Step 7 — UX expectations for desktop

- Works **offline** (desktop users notice immediately)
- Keyboard shortcuts, and they match the platform (Cmd vs Ctrl)
- Native menus, a tray icon where appropriate, and window state remembered
- File → Open/Save, drag-and-drop, and undo where it makes sense
- Notifications through the OS notification center
- Respects the OS theme (light/dark) and reduced-motion setting
- Startup time under 2-3 seconds; a splash screen if it must be longer
- A "Help → Send feedback" and "Help → Open logs" path, because you can't watch over their shoulder

## Step 8 — Distribution

- Your own site (primary): a download page that detects the platform, with checksums
- Mac App Store: optional, requires sandboxing (a real constraint), and takes a cut
- Microsoft Store / winget / Homebrew / Snap / Flatpak: nice reach, low effort for the ones that fit
- Enterprise: an `.msi`/`.pkg` and a documented silent-install path, plus a policy for updates
- Release notes and a changelog page that users can read without installing

## Non-negotiables

1. **Sandbox the renderer**: no Node integration, context isolation on, IPC validated.
2. **Sign and notarize everything** you ship, including updates.
3. **Auto-update verifies signatures** and has a rollback channel.
4. **No secrets in the bundle.** User secrets go in the OS keychain.
5. **Data lives in the OS app-data directory**, never next to the executable.
6. **The updater is tested** end to end before the first public release.
7. **It works offline.**
8. **Crash reporting exists**, with a user-visible way to send diagnostics.
9. **Installers are produced by CI**, not by someone's laptop.
10. **A strict CSP** applies to everything rendered.

## Ask the human

1. "Does this need to work without internet, or touch files on the computer? That's the real reason for desktop."
2. "Mac only, Windows only, or both? (Linux is usually a nice-to-have.)"
3. "Do you have an Apple developer account? It's $99/year and needed to sign Mac apps."
4. "How will people install it — download from your website, or through an app store?"
5. "Is this for a company that installs software on many machines?" *(changes packaging: MSI/PKG + policies)*
6. "How big is the data it keeps locally — a few settings, or gigabytes?"

Never ask: "Tauri or Electron?", "NSIS or WiX?", "AppImage or Snap?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| `nodeIntegration: true` | Any XSS = full machine access | Isolate, bridge, validate |
| Shipping an unsigned installer | Gatekeeper/SmartScreen blocks it; users bail | Sign + notarize |
| No auto-update | Users stuck on old versions forever | Signed updater with rollback |
| Writing data next to the executable | Permission errors, signature invalidation | OS app-data dir |
| Bundling all of `node_modules` | A 400MB installer | Prune, bundle, tree-shake |
| Assuming it's always online | Broken on planes and in hotels | Offline-first |
| No crash reporting | You only hear about crashes from angry emails | Local logs + opt-in reporting |
| Updater that can't roll back | A bad release is unfixable | Rollback channel |
| Hardcoded absolute paths | Breaks on other machines | OS path APIs |
| Building installers on a laptop | Non-reproducible, easy to forget a step | CI produces them |
| Testing only on your own machine | Other OS versions, permissions, and antivirus behave differently | Test on clean VMs |

## Definition of done

- [ ] Desktop is justified (a real reason recorded), or the decision is documented as a preference
- [ ] Renderer sandboxed: no Node integration, context isolation on, CSP strict, IPC validated
- [ ] Signed + notarized (macOS) and code-signed (Windows); verified with `spctl` and on a clean machine
- [ ] Auto-update: signature-verified, release notes, deferrable, rollback channel, **tested end to end**
- [ ] Data in the OS app-data directory; secrets in the keychain; export path available
- [ ] Installers produced by CI for every supported platform, with checksums
- [ ] Works offline; startup under 3 seconds
- [ ] Crash reporting and local logs; a "send diagnostics" path
- [ ] Tested on a clean machine for each OS (not just your dev machine)
- [ ] Release notes published where users can read them

## Works with

- `appsec-hardening` — desktop-specific attack surface
- `secrets-management` — nothing secret ships in a binary
- `data-privacy-and-pii` — local data is still personal data
- `deploy-and-environments` — CI builds the installers
- `production-readiness` — the desktop additions
- `stack-selection` — the web-vs-desktop decision
