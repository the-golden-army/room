---
name: saas-architecture
description: Use when building a product where companies or teams sign up — multiple users per account, roles, invitations, plans and limits, per-seat billing, or an admin area. Covers tenant isolation that actually holds (and the one query that leaks everything), the org/membership data model, entitlements and usage limits, the backoffice you will need in week two, safe support impersonation, and per-tenant export and deletion.
metadata:
  category: platform
  version: 1.0.0
  value: "$100"
  group: platform
---

# saas-architecture

## Promise

Two customers never see each other's data, everyone gets the plan they paid for, and you can support them
without becoming a database administrator at 11pm.

## When to use

- More than one person will use one account (a team, a company, a workspace)
- Selling plans with different limits or features
- Per-seat or per-usage billing
- Building an admin/backoffice
- "Can we have an admin panel?" / "Can I add my colleague?" / "Can I have two separate accounts?"
- Adding trials, upgrades, downgrades, or cancellation

## When NOT to use

- Single-user products (but read the entitlement section — you'll likely add plans later)

## The 60-second version

```
1. ONE SHARED DATABASE with a tenant (org) column on every tenant-owned table. Don't split databases
   per customer until you have a real reason — you'll know when you do.
2. SCOPE EVERY QUERY BY TENANT. A `where` clause that forgets `orgId` is the whole ballgame.
   Enforce it automatically (Prisma extension / row-level security / a repository layer), not by memory.
3. MEMBERSHIP TABLE: user ↔ org, with a role. Every request resolves the current org from the session.
4. ENTITLEMENTS are computed server-side, checked on every protected action, never in the UI alone.
5. LIMITS are enforced on write (count before create, inside a transaction), not by hiding a button.
6. INVITES: single-use, expiring, tied to an email, with the role fixed server-side.
7. AUDIT LOG: who did what, to what, when — from day one. You'll need it for your first dispute.
8. BUILT-IN BACKOFFICE by week two: search a user, see their org, impersonate (audited), refund, resend.
9. EXPORT AND DELETE per org — enterprise customers ask in the first week.
10. SUPPORT IMPERSONATION is logged, time-limited, and visible to the user.
```

## Step 1 — Tenancy model

| Model | When | Trade-off |
|---|---|---|
| **Shared DB, shared schema, `org_id` column** | Default for 99% of SaaS | Cheap, simple, one migration. Risk: a missing filter leaks across tenants |
| **Shared DB, row-level security (RLS)** | Postgres + you want the database to enforce it | Strong guarantee; more setup, more care with connection roles |
| **Schema per tenant** | Tens of tenants, heavy customization | Migrations get harder; don't start here |
| **Database per tenant** | Strict isolation requirements, enterprise contracts, data residency | Operational cost multiplies; only when a customer pays for it |

Start shared with `org_id`, and make the scoping automatic. That gets you to thousands of tenants.

## Step 2 — The data model

```sql
CREATE TABLE orgs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,             -- for URLs, if you use them
  plan_id uuid REFERENCES plans(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner','admin','member','viewer')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, user_id)               -- a user is in an org once
);

CREATE TABLE invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  email citext NOT NULL,
  role text NOT NULL CHECK (role IN ('admin','member','viewer')),
  token_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Every tenant-owned table carries org_id
CREATE TABLE projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX projects_org_idx ON projects (org_id, created_at DESC);
```

Rules:
- **Every tenant-owned table has `org_id`** — no exceptions, including logs, files, and settings
- `ON DELETE CASCADE` from org → its data, so deleting an org actually deletes it
- Users can belong to many orgs; the **current org** comes from the session/URL, never from the client body
- The last **owner** can't be removed or downgraded (a classic lockout bug)
- Keep a `deleted_at` on orgs if you need a grace period, but have a real deletion job

## Step 3 — Tenant scoping that can't be forgotten

```ts
// prisma-tenant.ts — inject org_id into every query on tenant-scoped models
const TENANT_MODELS = new Set(["Project", "Booking", "Invoice", "File"]);

export const tenantDb = prisma.$extends({
  query: {
    $allModels: {
      async $allOperations({ model, args, query }) {
        if (!TENANT_MODELS.has(model)) return query(args);
        const orgId = currentOrg.get();
        if (!orgId) throw new Error(`Tenant context missing for ${model}`);   // fail LOUD, not open
        args.where = { ...args.where, orgId };
        return query(args);
      },
    },
  },
});
```

```sql
-- Or let Postgres enforce it (belt and braces)
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON projects
  USING (org_id = current_setting('app.org_id')::uuid);
```

**Fail closed.** If the tenant context is missing, throw — never run an unscoped query. A missing filter
that returns nothing is a bug; one that returns everything is a breach.

```ts
// Every request resolves the org once, then everything downstream uses it
export async function requireOrgMember(req: Request, orgId: string, minRole: Role = "member") {
  const user = await requireUser(req);
  const m = await db.membership.findFirst({ where: { orgId, userId: user.id } });
  if (!m || ROLE_RANK[m.role] < ROLE_RANK[minRole]) throw new NotFoundError();  // 404, not 403
  currentOrg.enterWith(orgId);
  return { user, membership: m, orgId };
}

// Usage
export async function GET(req: Request, { params }: { params: { orgId: string } }) {
  const { user } = await requireOrgMember(req, params.orgId, "member");
  const projects = await tenantDb.project.findMany();   // automatically scoped
  return Response.json(projects);
}
```

## Step 4 — Entitlements and limits

```sql
CREATE TABLE plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,                    -- Free, Pro, Business
  price_cents integer NOT NULL,
  seats_included integer NOT NULL DEFAULT 1,
  projects_limit integer NOT NULL,       -- -1 = unlimited
  storage_gb_limit integer NOT NULL,
  ai_calls_per_day integer NOT NULL,
  features jsonb NOT NULL DEFAULT '[]'   -- ["sso","audit_log","api_access"]
);
```

```ts
// One function answers "may they do this?", used on the server everywhere
export async function checkLimit(orgId: string, resource: "projects" | "seats" | "storage_gb") {
  const org = await db.org.findUniqueOrThrow({ where: { id: orgId }, include: { plan: true } });
  const limit = org.plan[`${resource}_limit`];
  if (limit === -1) return { ok: true as const };
  const used = await countUsage(orgId, resource);
  return used < limit
    ? { ok: true as const, used, limit }
    : { ok: false as const, used, limit, message: `You've used all ${limit} ${resource} on the ${org.plan.name} plan.` };
}

// Enforce INSIDE the transaction that creates the thing
await db.$transaction(async (tx) => {
  const { ok, message } = await checkLimit(orgId, "projects");
  if (!ok) throw new LimitError(message);
  await tx.project.create({ data: { orgId, name } });
});
```

Rules:
- Check the limit **at the point of creation**, in a transaction, so two concurrent requests can't both win
- Hide the button **and** enforce server-side — the UI is a courtesy
- Show usage ("3 of 5 projects used") in the UI — surprise limits feel like a bait and switch
- Downgrades: don't delete data. Make things read-only and tell the user what to remove
- Trials: an end date, a clear countdown, and what happens at the end (read-only is kinder than a wall)
- Per-seat billing: charge on invite or on acceptance? (Recommend: on acceptance, prorated)

## Step 5 — Onboarding and invitations

```
1. Sign up → create the user AND an org (named after them, renamable)
2. Land them in the product with one obvious action (see ux-writing-and-onboarding)
3. Invite flow: enter email + role → create invitation (single-use, 7-day expiry, hashed token)
   → send an email with a link → on accept, verify the email matches (or allow if logged in as that email)
   → create the membership → mark the invitation accepted
4. Pending invitations are visible and revocable in settings
5. The last owner can't leave or be removed
6. Someone who's already a user gets added to the org; someone new signs up first, then lands in the org
```

Never: accept an invitation without checking the email, allow an open redirect after acceptance, or let an
invitation change its own role.

## Step 6 — The backoffice (build it in week two)

You will need this the first time someone says "I can't log in" or "refund me". A hidden, authenticated
`/admin` route group with:

```
[ ] Search users by email / org by name
[ ] See an org: plan, members, usage, subscription status, last activity
[ ] Impersonate a user (logged, time-limited, banner shown in the app)
[ ] Resend a verification or reset email
[ ] Issue a refund (logged, with a reason)
[ ] Change a plan manually (logged)
[ ] Cancel/reactivate a subscription
[ ] See recent audit-log entries for an org
[ ] A "danger zone": delete an org and all its data (double confirmation)
```

```ts
// Impersonation — the safe shape
await db.auditLog.create({ data: {
  actorId: admin.id, action: "impersonation.start", targetId: userId,
  metadata: { reason, orgId, expiresAt: addMinutes(new Date(), 30) },
}});
// The app shows a permanent banner: "You are viewing this account as Sam (support session, 28 min left)"
// Every action taken during impersonation is logged with the real actor.
```

## Step 7 — Audit log

```sql
CREATE TABLE audit_log (
  id bigserial PRIMARY KEY,
  org_id uuid REFERENCES orgs(id) ON DELETE SET NULL,
  actor_id uuid REFERENCES users(id) ON DELETE SET NULL,   -- keep the row even if the user is deleted
  action text NOT NULL,                 -- 'booking.cancel', 'member.remove', 'plan.change'
  target_type text, target_id text,
  metadata jsonb,
  ip inet, user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_org_idx ON audit_log (org_id, created_at DESC);
```

Log: logins, role changes, invitations, removals, plan and billing changes, deletions, exports, settings
changes, and every admin action. Keep it for at least a year. It's cheap, and the first time you need it
you'll be very glad it exists.

## Step 8 — Export and deletion (per org)

- **Export:** a background job producing JSON/CSV of everything the org owns; emailed as a download link
  with a short expiry. Enterprise customers ask for this in week one
- **Deletion:** delete the org → cascade to all its data → remove files from storage → delete contacts in
  the email tool → keep invoices for tax → log the deletion
- **User removal:** when a user leaves an org, their *membership* ends, but content they created usually
  stays (owned by the org). Decide this explicitly and write it in the docs

## Step 9 — Things that bite later

| Issue | Plan for it now |
|---|---|
| Noisy neighbour | One org running a huge export shouldn't slow everyone: queue it, cap concurrency per org |
| Subdomain per tenant (`acme.app.com`) | Adds DNS, TLS, and cookie-scope complexity. Only if customers ask |
| SSO / SAML | Enterprise will ask. Use a provider (WorkOS, Clerk) so it's a config change, not a project |
| Data residency | Some customers require a region. Know whether your host can do it |
| Feature flags per tenant | Useful for beta features and for "this one customer gets X". Store on the org |
| Usage metering for billing | Count what you'll bill on from day one, even if you don't bill on it yet |
| Free-tier abuse | Quotas per org, not just per user |

## Non-negotiables

1. **Every tenant-owned table has `org_id`.** No exceptions.
2. **Tenant scoping is automatic and fails closed.**
3. **Entitlements and limits are enforced server-side**, in the transaction that performs the action.
4. **Every request resolves the org from the session**, never from a client-sent body.
5. **Invitations are single-use, expiring, hashed, and role-fixed server-side.**
6. **The last owner can't be removed or downgraded.**
7. **Every privileged and admin action is in the audit log.**
8. **Impersonation is logged, time-limited, and visible to the user.**
9. **Export and deletion work per org**, not just per user.
10. **Two real orgs are used in testing**, and cross-tenant access is tested and fails.

## Ask the human

1. "Will one person use this alone, or will teams/companies sign up together?"
2. "What should different people inside one company be able to see and do? Owner, admin, regular member?"
3. "How do you want to charge — per person, per company, or by how much they use?"
4. "What are the plan levels, and what's different between them?" *(seats, projects, storage, features)*
5. "When someone's card fails, should their whole team lose access, or just the owner?"
6. "Do your customers ever ask you to delete their data, or to send them a copy of it?"
7. "Would you ever need to log in as a customer to help them?" *(that's impersonation — build it safely)*

Never ask: "single-tenant or multi-tenant?", "how do you want to model entitlements?", "row-level security
or application-level filtering?"

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| A query with no `org_id` filter | Cross-tenant data leak | Automatic scoping that fails closed |
| Trusting `orgId` from the request body | Anyone can pass any org | Resolve from the session; check membership |
| Limits enforced only in the UI | Free unlimited plan for anyone who curls | Enforce in the transaction |
| Deleting a user and losing all their content | Data loss for the org | Ownership belongs to the org, not the person |
| No audit log | You can't answer "who did this?" | Log from day one |
| Impersonation without logging or a banner | Trust and compliance disaster | Logged, time-limited, visible |
| No backoffice | You hand-edit the database at 11pm | Build the six screens in week two |
| Subdomains per tenant by default | DNS/TLS/cookie complexity for no demand | Only when asked |
| Per-tenant databases from day one | Operational burden, slow migrations | Shared schema + `org_id` |
| Plan changes that delete data | Angry customers | Read-only + clear messaging |
| Testing with one org only | Cross-tenant bugs reach production | Always test with two |

## Definition of done

- [ ] Every tenant-owned table has `org_id`, indexed, with cascade on delete
- [ ] Tenant scoping enforced automatically and failing closed; verified by a two-org test
- [ ] Memberships with roles; org resolved per request from the session
- [ ] Invitations single-use, expiring, hashed, email-checked, revocable
- [ ] Plans, limits and features enforced server-side, in transactions, with usage visible in the UI
- [ ] Audit log covers auth, roles, billing, deletions, exports, and admin actions
- [ ] Backoffice: search, view org, impersonate (audited + banner), refund, change plan, delete org
- [ ] Export and deletion work per org
- [ ] Impersonation is time-limited, logged, and visibly disclosed
- [ ] Cross-tenant access tested with two real orgs and confirmed to fail

## Works with

- `auth-and-access` — sessions, roles, membership checks
- `payments-and-billing` — plans, seats, subscriptions, dunning
- `data-privacy-and-pii` — per-org export, deletion, retention
- `data-model-and-migrations` — the schema
- `production-readiness` — the SaaS additions to the gate
- `errors-logs-and-monitoring` — audit events and admin action alerts
