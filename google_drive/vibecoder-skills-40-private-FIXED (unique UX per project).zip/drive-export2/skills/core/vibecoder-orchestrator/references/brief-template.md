# docs/BRIEF.md — copy-paste template

One page. If it doesn't fit, the project isn't understood yet.

```markdown
# BRIEF: <project name>

## 1. The point (2 sentences, no tech words)
<Who is this for, and what can they do afterwards that they couldn't do before?>

## 2. Success (how we know it worked)
- In 30 days: ______
- In 6 months: ______
- The one number that matters: ______

## 3. Who uses it
- Primary user: ______ (one person, described like a real human, not a persona slide)
- Their situation when they open this: ______
- Devices: [ ] desktop web  [ ] mobile web  [ ] iOS  [ ] Android  [ ] desktop app
- Logged in? [ ] yes  [ ] no

## 4. The three things it must do
1. ______
2. ______
3. ______
(Everything else is a "later" list. If a fourth thing is mandatory, one of these three is wrong.)

## 5. Scale & stakes
- Normal day: ______ users / ______ actions
- Best realistic case: ______
- If it's down a day: [ ] nobody notices  [ ] annoying  [ ] money lost  [ ] contracts broken

## 6. Data
- What we store about people: ______
- Sensitive? [ ] no  [ ] yes → ______
- Uploads? [ ] no  [ ] yes → what kind: ______
- How long we keep it: ______

## 7. Money
- How it earns: [ ] nothing yet  [ ] one-off  [ ] subscription  [ ] other
- If payments: provider ______, currencies ______, refund policy ______

## 8. Constraints
- Live by: ______
- Monthly budget: $______
- Must integrate with: ______
- Hard no's (things the user refuses): ______

## 9. Stack (fill in after stack-selection)
- Frontend: ______ — because ______
- Backend: ______ — because ______
- Database: ______ — because ______
- Hosting: ______ — because ______
- Auth: ______ — because ______
- Revisit when: ______

## 10. Out of scope for v1
- ______
- ______

## 11. Open questions
- ______ (owner: ______, needed by: ______)

## 12. Done means
<The exact sentence the user will say when this is finished. e.g. "A member can book a class,
pay, and get a confirmation email, and I can see the booking in my admin panel.">
```
