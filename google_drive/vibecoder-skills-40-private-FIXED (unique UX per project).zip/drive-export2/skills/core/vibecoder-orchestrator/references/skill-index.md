# Full skill index (40 skills)

Trigger phrases → skill. Load the skill file, don't just note the name.

## core

| Skill | Load when the request contains |
|---|---|
| `vibecoder-orchestrator` | anything non-trivial; always first |
| `discovery-interview` | "I want to build…", vague idea, new project, "not sure what I need" |
| `stack-selection` | "what should I use", "Next or Vite", "which database", "is X good", "should I rewrite" |
| `vibe-guardrails` | every session — how to talk, what never to do, what never to leak |
| `project-blueprint` | new repo, "organize this", "where should files go", onboarding another dev/agent |

## security

| Skill | Load when the request contains |
|---|---|
| `appsec-hardening` | "secure", "safe", "vulnerable", "pentest", "hack", "XSS", "CSRF", "injection", any public app |
| `auth-and-access` | login, signup, session, OAuth, "sign in with", password reset, roles, permissions, admin, MFA, 2FA, JWT |
| `secrets-management` | API key, token, `.env`, "where do I put my key", "I committed a secret", rotation |
| `api-abuse-defense` | rate limit, brute force, spam, bots, scraping, validation, SSRF, webhooks, file upload, CORS |
| `data-privacy-and-pii` | GDPR, privacy, personal data, "delete my account", analytics, tracking, cookies banner, logs with emails |
| `dependency-and-supply-chain` | npm install, package choice, CVE, "update dependencies", lockfile, audit, CI permissions |

## ux

| Skill | Load when the request contains |
|---|---|
| `frontend-craft` | button, form, loading, spinner, skeleton, error message, toast, modal, retry, timeout, slow feel |
| `design-system-and-visual-language` | styling, theme, colors, fonts, spacing, "make it look good", consistency, dark mode |
| `ux-writing-and-onboarding` | copy, microcopy, empty state, "no data yet", onboarding, first run, tour, help text |
| `accessibility-and-inclusive-design` | a11y, keyboard, screen reader, contrast, focus, aria, WCAG, any shipped UI |
| `distinctive-visual-style` | "looks AI-generated", "make it look designed", gradient text, emoji icons, card layout, hero, landing page, brand look, visual identity |
| `responsive-mobile-first` | responsive, mobile, phone, mobile-first, blank page, empty link, dead link, broken image, lorem, mock data, "works on mobile", 320px, horizontal scroll, thumb, tap target |
| `ux-upgrade-audit` | ux audit, upgrade ux, misstyled button, inconsistent button, spacing inconsistent, audit my app, full ux report, fix all, weak points, look inconsistent, code weak points, upgrade design |
| `global-ui-reformat` | global reformat, polish everything, make it production, dark mode, darkmode, skeleton, skeletons, loading skeleton, retry on error, server error, onboarding, coach marks, spotlight, tour, standalone, paste skill, reformat entire app |

## engineering

| Skill | Load when the request contains |
|---|---|
| `production-readiness` | "production ready", "can I launch", "is this done", "go live", "real users" |
| `backend-api-design` | endpoint, API, route, controller, status code, validation, pagination, versioning, idempotency |
| `data-model-and-migrations` | schema, table, column, index, migration, "add a field", foreign key, backup, restore |
| `testing-and-verification` | test, "how do I know it works", verify, E2E, unit test, "did you test it" |
| `errors-logs-and-monitoring` | logging, error tracking, Sentry, alerts, monitoring, "it crashed and I don't know why", uptime |
| `performance-and-caching` | slow, fast, optimize, cache, N+1, bundle size, images, loading time, Core Web Vitals |
| `database-efficiency` | database, postgres, supabase, neon, planetScale, turso, provider, index, storage, bloat, lean table, like table, 7 columns, resource, cost, retention, connection pool, EXPLAIN, production database |

## delivery

| Skill | Load when the request contains |
|---|---|
| `deploy-and-environments` | deploy, host, Vercel, Netlify, Railway, Fly, Docker, CI/CD, staging, domain, HTTPS |
| `reliability-and-incidents` | down, outage, rollback, backup, disaster, kill switch, incident, status page, SLA, on-call |
| `payments-and-billing` | Stripe, payment, checkout, subscription, invoice, refund, trial, coupon, price, webhook |
| `third-party-integrations` | external API, email, SMS, Resend, Twilio, SendGrid, S3, upload, webhook, retry, timeout |
| `cost-guardrails` | cost, bill, expensive, quota, budget, "the invoice was huge", usage limits, token spend |
| `seo-and-growth-basics` | SEO, meta, OG image, share preview, sitemap, robots, analytics, landing page, ranking |

## platform

| Skill | Load when the request contains |
|---|---|
| `mobile-app-delivery` | iOS, Android, App Store, Play Store, React Native, Expo, Flutter, push notification, OTA |
| `desktop-app-delivery` | Electron, Tauri, desktop app, installer, .dmg, .exe, code signing, notarize, auto-update |
| `ai-features-in-production` | LLM, GPT, Claude, Gemini, chatbot, embedding, RAG, prompt, streaming, AI cost, prompt injection |
| `saas-architecture` | multi-tenant, team, workspace, plan limits, feature flag, admin panel, seat, org, billing per user |

## quality

| Skill | Load when the request contains |
|---|---|
| `code-review-and-audit` | "review this", "check my code", "is this good", audit, "I inherited this", due diligence |
| `refactor-and-maintainability` | refactor, clean up, messy, spaghetti, "too big", split file, technical debt |
| `launch-and-handoff` | launch, ship, go live, handoff, runbook, "explain this to a client" |
| `write-documentation` | write docs, write documentation, write readme, document this project, how to use, open source docs, local setup, usage guide, API docs, examples, FAQ |

## Minimum viable installs

| You are… | Install |
|---|---|
| Building your first app | orchestrator, discovery-interview, stack-selection, vibe-guardrails, production-readiness |
| Building anything with users | + appsec-hardening, auth-and-access, secrets-management, frontend-craft |
| Selling to businesses | + saas-architecture, payments-and-billing, accessibility-and-inclusive-design, reliability-and-incidents |
| Building mobile/desktop | + mobile-app-delivery or desktop-app-delivery, errors-logs-and-monitoring |
| Adding AI features | + ai-features-in-production, cost-guardrails |
| Inheriting a codebase | + code-review-and-audit, refactor-and-maintainability |
