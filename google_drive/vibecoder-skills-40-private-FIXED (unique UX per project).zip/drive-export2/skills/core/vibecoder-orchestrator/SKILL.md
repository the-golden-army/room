---
name: vibecoder-orchestrator
description: Use at the start of ANY build, feature, refactor, deploy, or "make it secure" request in a vibe-coded project. Reads the request, decides which of the other vibecoder-skills to load, enforces the interview-then-architect-then-build-then-verify order, and blocks the agent from skipping the steps that cause production disasters. Install this skill first; it is the entry point for the whole pack.
metadata:
  category: core
  version: 1.0.0
  value: "$100"
  group: core
---

# vibecoder-orchestrator

## Promise

Turns a one-sentence idea ("build me a booking app") into a project that survives real users — by making
sure the right expertise is loaded at the right moment, and by making sure the agent **asks before it guesses**.

## When to use

Run this **first**, always, when:

- Starting a new app, feature, or "v1"
- Adding anything that touches money, logins, personal data, uploads, or the public internet
- Someone says "make it production ready", "make it secure", "make it scale", "it feels slow"
- Deploying, or moving from localhost to a real domain
- Handing a project to (or taking it from) another agent or developer
- You inherited an AI-generated codebase and don't know what's broken

## When NOT to use

- A one-line cosmetic change ("make this button blue") — just do it.
- Pure questions/explanations with no code change.
- Emergency: prod is down. Go straight to `reliability-and-incidents`.

## The 60-second version

If you remember nothing else, remember this order. **Never invert it.**

```
1. UNDERSTAND  → ask plain-language questions until the goal is unambiguous   [discovery-interview]
2. CHOOSE      → pick the stack from the situation, not from habit            [stack-selection]
3. DESIGN      → write the brief: screens, data, flows, limits, threats        [project-blueprint]
4. BUILD       → write code with the relevant craft skills loaded              [ux/*, engineering/*, security/*]
5. VERIFY      → run the launch gate before real users show up                 [production-readiness]
6. SHIP        → deploy safely, then watch it                                  [deploy-and-environments]
7. MAINTAIN    → review, refactor, hand over                                   [quality/*]
```

Skipping step 1 is why apps get rebuilt. Skipping step 5 is why they get pwned.

## How routing works

Read the request, score it, load the matching skills. **Load the skill files, don't just remember their
names** — the value is in the checklists, not in the title.

| If the request involves… | You MUST load |
|---|---|
| A new project or feature | `discovery-interview`, `stack-selection`, `project-blueprint` |
| Any stack/framework/tool decision | `stack-selection` |
| Logins, accounts, "log in with Google", roles, admin | `auth-and-access`, `appsec-hardening`, `secrets-management` |
| "make it secure", "is this safe", pentest prep | `appsec-hardening` (then `auth-and-access`, `api-abuse-defense`, `dependency-and-supply-chain`) |
| Forms, input, uploads, public API endpoints | `api-abuse-defense`, `appsec-hardening` |
| Payments, subscriptions, checkout, pricing | `payments-and-billing`, `appsec-hardening`, `reliability-and-incidents` |
| Personal data, emails, health, ID docs, EU users | `data-privacy-and-pii`, `appsec-hardening` |
| Screens, buttons, forms, loading, empty states | `frontend-craft`, `design-system-and-visual-language`, `ux-writing-and-onboarding` |
| Any UI at all | `accessibility-and-inclusive-design` (non-negotiable, it's 20 minutes of work) |
| API endpoints, background jobs, cron, queues | `backend-api-design`, `errors-logs-and-monitoring` |
| Database, schema changes, "add a field" | `data-model-and-migrations` |
| "it's slow", images, lists, dashboards | `performance-and-caching` |
| Deploy, host, domain, CI/CD, environments | `deploy-and-environments`, `secrets-management` |
| LLM/AI features, chatbots, "add AI" | `ai-features-in-production`, `cost-guardrails`, `appsec-hardening` |
| Mobile app (iOS/Android) | `mobile-app-delivery` |
| Desktop app (Mac/Windows/Linux) | `desktop-app-delivery` |
| SaaS, teams, plans, multi-user, admin panel | `saas-architecture`, `payments-and-billing` |
| Cost questions or a surprise bill | `cost-guardrails` |
| Testing, "how do I know it works" | `testing-and-verification` |
| Reviewing AI-written or inherited code | `code-review-and-audit` |
| Cleaning up a messy codebase | `refactor-and-maintainability` |
| Going live / launch day | `production-readiness`, `launch-and-handoff`, `reliability-and-incidents` |
| Third-party APIs (Stripe, email, maps, storage) | `third-party-integrations` |
| Marketing site, SEO, sharing previews | `seo-and-growth-basics` |

**Full index with trigger phrases: [`references/skill-index.md`](references/skill-index.md).**

## Steps

### Step 0 — Load the profile (10 seconds)

Look for `VIBECODER-PROFILE.md` in the project root, the home folder, or the agent's config dir.
If found: read it and honour it. Section 5 (**red lines**) is authoritative — if it says "never deploy
without asking", you stop and ask. If not found, run `discovery-interview`.

### Step 1 — Classify the request

Label it with one primary intent and list the secondary risks:

```
INTENT:   new-feature | new-project | fix | harden | deploy | refactor | review | scale
RISKS:    money | auth | pii | uploads | public-api | ai | mobile | desktop | saas | seo | cost
```

Anything in RISKS means a security skill is mandatory, whether or not the user asked.

### Step 2 — Interview, don't interrogate (1 question at a time)

Use `discovery-interview`. Rules:

- Questions are about **people, money, time, and consequences** — never about technology.
- **One question per message.** Acknowledge the previous answer in one line, ask the next with a default ("Not sure? Just say 'you pick' — I'll assume X").
- Skip what you already know — state your assumption and move on, don't re-ask.
- Accept "I don't know / skip / you pick" as a valid answer — take the safe default, note it, continue.
- **Never** dump a list, never ask 2 at once, never number them like an exam.
- **Never** ask: "SQL or NoSQL?", "REST or GraphQL?", "Should we use Redis?", "Monorepo or polyrepo?".
  Those are your job, and you have `stack-selection` for them.

### Step 3 — Produce the brief (before code)

Write `docs/BRIEF.md` from the template in [`references/brief-template.md`](references/brief-template.md).
Get a yes from the human. A brief is 1 page. If you can't fit the project on one page, you don't
understand it yet.

### Step 4 — Choose the stack, and justify it in one sentence each

Use `stack-selection`. Record the decision in `docs/DECISIONS.md` as:

```
Decision: <what>
Because:  <the situation fact that forced it>   ← must reference something the user told you
Rejected: <alternative> — because <reason>
Revisit:  <trigger that would change this, e.g. "at 10k daily users">
```

A decision with no "because" tied to a real fact is a guess. Guesses get rewritten.

### Step 5 — Build with the craft skills loaded

Load the relevant skills from the routing table *before* writing the first file. Apply in this priority
when they conflict:

```
1. Security      (a secure app that's ugly ships; an insecure app that's pretty doesn't)
2. Correctness   (data loss is worse than slow)
3. UX            (the user only sees the UI)
4. Performance   (only after 1-3 hold)
5. Elegance      (last, always)
```

### Step 6 — Verify before you say "done"

Run `production-readiness`. If it fails on a **red** item, do not declare done; say what failed and
what it takes to fix. Then `testing-and-verification` for the critical paths.

### Step 7 — Ship and watch

`deploy-and-environments` → `errors-logs-and-monitoring` → `launch-and-handoff`.

### Step 8 — Write the handoff note

Every session ends with a short note in `docs/HANDOFF.md`:

```
WHAT CHANGED:  <3 lines max>
WHAT I ASSUMED: <things you guessed — the human must confirm>
WHAT I DIDN'T DO: <known gaps>
WHAT TO CHECK:  <the 1-3 things most likely to be wrong>
NEXT:           <the single next step>
```

This is the single highest-value habit in the whole pack. It's how a vibe coder stays in control of a
codebase they can't fully read.

## Non-negotiables

1. **Ask before you guess, guess before you block.** Never stall waiting for an answer on something you
   can safely default — pick it, then flag it in "WHAT I ASSUMED".
2. **No technical questions to a non-technical human.** Translate or decide.
3. **Security is not a phase.** Any request touching auth, money, PII, uploads, or a public API loads a
   security skill at step 5, not after launch.
4. **Never install a dependency, spend money, deploy, or delete data** without explicit permission
   (unless the profile pre-authorises it).
5. **Never invent facts about the user's project.** No "your app probably uses Postgres". Read the code,
   or ask.
6. **Show the command before you run anything destructive.** Database drops, force push, `rm -rf`,
   credential rotation, DNS changes.
7. **One source of truth for every secret.** If a key appears in code, config, and CI, that's three leaks.
8. **If you're lost, stop and say so.** "I don't understand this codebase yet, here are 3 questions" beats
   600 lines of plausible garbage.

## Ask the human

**One question at a time** — this is a conversation, not a form. Each with a default (`"Not sure? Just say 'you pick'."`).

Order, using defaults to skip what you already know:

1. "Who's going to use this, and what are they trying to get done?" *(not "what are the requirements")*
2. "On a normal day, roughly how many people? And if something goes really well, biggest day you can picture?"
3. "If this broke for a full day, what would it cost you — nothing, annoying, losing money, or contracts?"
4. "Does anyone pay, and if so, how?" *(one-off / monthly / not yet)*
5. "Will people create accounts, or is it open to anyone?"
6. "Do people upload anything — photos, documents, spreadsheets?"
7. "Any info here you'd be in trouble for leaking?" *(health, money, IDs, kids, private messages)*
8. "When does this need to be live, and what can you spend per month to keep it running?"
9. "Will you maintain it yourself, or hand it to someone else?"
10. "What does 'done' look like to you — and anything you've seen in other apps you *don't* want?"

**How to ask:** Acknowledge previous answer ("Got it — so payments, 50/day, solo-maintained, noted"), then one question with an inline default. Never a numbered list. Never 2 at once. If the user gives 3 answers in one message, extract all three and ask only the next missing piece. If they say "just build it / skip / you pick", take defaults and build — flag assumptions in HANDOFF.

## Decision table — how much process for this task?

| Situation | Process |
|---|---|
| Typo, copy change, color tweak | Skip everything. Do it. |
| Small isolated feature, no data/money | Steps 0, 5, 8. One question max. |
| Feature touching existing data or users | Steps 0, 1, 2 (3 questions), 5, 6, 8 |
| New project from scratch | Full 0→8. No exceptions. |
| "Make it secure / production ready" | 0, 1, then `appsec-hardening` + `production-readiness` as an audit, then fix by severity |
| Deploying something that already works | 0, `production-readiness` (quick pass), `deploy-and-environments`, `errors-logs-and-monitoring` |
| Bug in production | 0, `errors-logs-and-monitoring` (find it), `reliability-and-incidents` (stop the bleeding), then fix |
| Inherited/unknown codebase | 0, `code-review-and-audit`, report, then ask what to fix first |

## Patterns

### The session opener (copy-paste)

```
Before I write anything, I'm loading the skills this project needs:
  → discovery-interview (what is this actually for?)
  → stack-selection (what should it be built with, and why)
  → appsec-hardening (you're handling logins/payments, so this is mandatory)
I'll ask you 6 questions about the people who'll use it and what happens if it breaks.
I will not ask you to choose databases or frameworks. Then I'll show you a one-page plan,
and only start building once you say go.
```

### The "I'm about to do something risky" pattern

```
⚠ I need to run this:
    psql $DATABASE_URL -c "ALTER TABLE users DROP COLUMN temp_legacy_id"
This permanently deletes a column from the production database. There is no undo
except from a backup — and I have verified a backup exists (docs/BACKUPS.md).
Type "go" to proceed, or "no" and I'll write a reversible migration instead.
```

### The "I don't know" pattern

```
I can't tell how your existing auth works — there are two different session
systems in the code (src/auth/session.ts and middleware.ts) and I don't know
which one is live. Before I touch login I need to know:
  a) Which one does your deployed app use?
  b) Is there a reason both exist?
Guessing here could lock everyone out, so I'm not going to.
```

## Anti-patterns

| Anti-pattern | Why it kills projects | Do instead |
|---|---|---|
| "Sure!" then 900 lines of code on a one-line prompt | It built the wrong thing confidently | 8 questions first, then a 1-page brief |
| Asking "Postgres or Mongo?" | The human has no basis to answer; it's a coin flip dressed as collaboration | Ask about data shape, answer it yourself |
| Loading all 34 skills for a button color change | Wastes context, agent goes numb | Route by the table; load only what applies |
| "I've added security" with no specifics | Unfalsifiable | Enumerate the specific defenses, or run `appsec-hardening` and paste the results |
| Declaring done without running the gate | 90% of "it works on my machine" | `production-readiness`, then paste pass/fail |
| Silently picking a stack because it's Tuesday | Rewrites in month 2 | `docs/DECISIONS.md` with a "because" tied to a fact |
| Rewriting working code to "clean it up" | Introduces bugs for zero user value | `refactor-and-maintainability`: only refactor what you're already changing |
| Ending a session with no handoff note | Context dies; next session starts from zero | `docs/HANDOFF.md`, always |

## Definition of done

A task is done when **all** of these are true:

- [ ] The human's actual goal is written down and confirmed (`docs/BRIEF.md` or a chat summary)
- [ ] Every guess I made is listed under "WHAT I ASSUMED"
- [ ] Relevant security skill applied; no secret in code; no unvalidated input reaching a database, a file path, a URL fetch, or an HTML template
- [ ] Every user-facing action has a loading state, an error state, and a success state
- [ ] The critical path (signup → core action → see result) works end to end, tested by me, not assumed
- [ ] Errors are logged somewhere I can read, with enough context to debug
- [ ] No orphan TODOs, no dead files, no `console.log` debugging left behind
- [ ] `docs/HANDOFF.md` updated
- [ ] I can explain the change in two plain sentences the human can repeat to someone else

## Works with

- **Every other skill in the pack** — this is the router.
- `vibe-guardrails` — how to phrase all of the above like a human being.
- `code-review-and-audit` — run at the end of any large session as a self-check.
- Empty repo? Start: `discovery-interview` → `stack-selection` → `project-blueprint`.
