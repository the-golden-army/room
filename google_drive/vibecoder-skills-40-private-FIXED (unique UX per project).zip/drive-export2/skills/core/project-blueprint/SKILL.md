---
name: project-blueprint
description: Use when creating a new repo, reorganizing a messy AI-generated codebase, or onboarding another developer or agent. Defines the folder layout, naming rules, module boundaries, the five documents every project needs, env/config conventions, and git hygiene — so anyone (human or agent) can open a six-month-old project and be productive in ten minutes. Also the antidote to "the AI built 40 files and I have no idea what any of them do".
metadata:
  category: core
  version: 1.0.0
  value: "$100"
  group: core
---

# project-blueprint

## Promise

A repo that explains itself. Six months from now — after five agents, three pivots and a rewrite — the next
person (or the next you) opens it and knows where things go, why they're there, and what not to touch.

## When to use

- Creating a project from scratch
- The codebase was generated in one shot and nobody knows what's in it
- Adding a second developer or handing the project over
- "Where should this file go?"
- Files are piling up at the root; imports are reaching across the app
- Before a big feature, so it lands in the right place

## When NOT to use

- A one-file script or a throwaway experiment (but still use the naming rules)
- Mid-incident — fix first, organize later

## The 60-second version

**Five documents** (in `docs/`), **four top-level folders**, **one rule about boundaries**:

```
docs/BRIEF.md       what this is for and who it's for        (1 page)
docs/DECISIONS.md   every big technical choice + the reason  (append-only)
docs/HANDOFF.md     what changed / assumed / check next      (rolling)
docs/RUNBOOK.md     how to run it, deploy it, and what to do when it breaks
docs/SCHEMA.md      the data, in plain words                 (optional but cheap)

app/ or src/        the product
tests/              the checks
scripts/            one-off and utility commands
docs/               the five documents above
```

**The boundary rule:** a feature folder owns its own files. Code in `billing/` may not reach into
`settings/` internals — it calls something public, or the shared thing moves to `lib/`.

## Steps

### Step 1 — Pick the layout that matches the stack

**Full-stack framework (Next.js, Remix, SvelteKit, Nuxt)**

```
/
├─ app/                     routes, pages, route handlers
│  ├─ (marketing)/          public pages
│  ├─ (app)/                logged-in area
│  │  ├─ dashboard/
│  │  ├─ settings/
│  │  └─ layout.tsx         auth check lives HERE, not in every page
│  └─ api/
│     ├─ webhooks/stripe/   unsigned-to-verified boundary
│     └─ health/            liveness probe
├─ components/              reusable UI (buttons, inputs, modal, table)
├─ features/                feature logic: billing/, bookings/, notifications/
│  └─ bookings/
│     ├─ actions.ts         server actions / mutations
│     ├─ queries.ts         reads
│     ├─ schema.ts          validation (zod/pydantic)
│     ├─ types.ts
│     └─ components/        feature-only UI
├─ lib/                     shared primitives: db, auth, email, logger, config
├─ db/                      migrations + schema
├─ tests/
├─ scripts/
└─ docs/
```

**API-only service**

```
/
├─ src/
│  ├─ routes/          one file per resource
│  ├─ services/        business logic (the part that matters)
│  ├─ models/ or db/   data access
│  ├─ middleware/      auth, validation, rate limit, logging
│  ├─ jobs/            background workers
│  ├─ lib/             shared
│  └─ config.ts        env parsed and validated ONCE, here
├─ migrations/
├─ tests/
└─ docs/
```

**Monorepo** — only if you truly ship two apps (web + mobile, web + API) from one repo:

```
apps/web/  apps/api/  packages/ui/  packages/shared/
```
If you can't say out loud why you need it, you don't. A monorepo adds a build system to maintain.

### Step 2 — Name things so a stranger can guess

| Thing | Rule | Example |
|---|---|---|
| Files | `kebab-case.ts`, except components `PascalCase.tsx` | `booking-form.tsx`, `BookingForm.tsx` |
| Folders | lowercase, plural for collections | `features/bookings/` |
| Functions | verb + noun | `createBooking()`, not `booking()` |
| Booleans | is/has/can/should | `isActive`, `hasPaid`, `canEdit` |
| Event handlers | `handle<Thing><Event>` | `handleSubmit`, `handleDeleteClick` |
| DB tables | plural snake_case | `bookings`, `booking_attendees` |
| DB columns | snake_case, `_at` for timestamps, `_id` for FKs | `created_at`, `user_id` |
| API routes | plural nouns, nesting for ownership | `/api/bookings/:id/attendees` |
| Env vars | SCREAMING_SNAKE, prefixed by purpose | `STRIPE_SECRET_KEY`, `DATABASE_URL` |
| Tests | mirror the file | `booking-form.test.tsx` next to the thing, or in `tests/` |
| Constants | SCREAMING_SNAKE | `MAX_UPLOAD_BYTES` |
| Types | PascalCase, no `I` prefix | `Booking`, not `IBooking` |

**Ban:** `utils.ts`, `helpers.ts`, `misc.ts`, `common/`, `stuff/`, `new-file.ts`, `final.ts`, `final2.ts`.
If you can't name it, you don't understand it yet. Name it `formatCurrency.ts`, not `utils.ts`.

### Step 3 — Enforce boundaries

Three layers, one direction:

```
UI (components/, app/)  →  features/  →  lib/  →  database / external APIs
        ↓ never ↑
```

- UI never talks to the database directly. It calls a feature function.
- Features never import each other's internals. Shared code moves down to `lib/`.
- `lib/` never imports from `features/` or UI. It's the bottom.
- Anything crossing a trust boundary (webhook, upload, public form) validates at the door.

Quick check: if `features/billing/` imports from `features/bookings/queries.ts`, that's a smell.
Either billing owns it, or the query belongs in `lib/`.

### Step 4 — Config and environment

One module owns configuration. Nothing else reads `process.env`.

```ts
// lib/config.ts — fails loudly at boot, not mysteriously at 3am
import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  DATABASE_URL: z.string().url(),
  STRIPE_SECRET_KEY: z.string().startsWith("sk_"),
  APP_URL: z.string().url(),
});

export const config = schema.parse(process.env);
```

Rules:
- `.env.example` lists every variable with a **fake but correctly-shaped** value and a one-line comment
- `.env`, `.env.local`, `.env*.local` are in `.gitignore` from commit one
- Never `process.env.SECRET!` scattered around — one typed config module
- Separate keys per environment. Production keys never touch a laptop. (See `secrets-management`.)

### Step 5 — Write the five docs

Use [`references/templates.md`](references/templates.md) for copy-paste README, `.env.example`,
`.gitignore`, and `RUNBOOK.md`.

Keep them short. A doc nobody reads is worse than no doc.
`BRIEF.md` is one page. `DECISIONS.md` is append-only. `HANDOFF.md` is rewritten each session.
`RUNBOOK.md` is written for a tired person at 3am: commands, not prose.

### Step 6 — Git hygiene from the first commit

```
main            always deployable
feature/x       one branch per change, deleted after merge
```

- Commit messages: `type: what and why` — `fix: stop double-charging when Pay is tapped twice`
- One logical change per commit. Not "wip", not "asdf", not "final final".
- Never commit: secrets, `.env`, build output, `node_modules`, local DB files, personal notes
- Add a pre-commit hook: lint + format + a secret scan (see `dependency-and-supply-chain`)
- Tag releases (`v1.4.0`) so rollback has something to roll back to

### Step 7 — Pass the ten-minute test

Ask someone (or a fresh agent session) to:

1. Clone the repo and run the app using only `README.md` → should take **under 10 minutes**
2. Add a small feature → they should know which folder it belongs in without asking
3. Find where a specific behavior lives → grep should find exactly one obvious place

If any of the three fails, the blueprint isn't done. Fix the docs or the layout — usually the layout.

## Non-negotiables

1. **No orphan files.** Every file is imported by something or is an entry point. Dead code gets deleted, not commented out.
2. **No `utils.ts` dumping ground.** Named modules or nothing.
3. **README must actually work.** Every command in it was run today.
4. **Secrets never in the repo.** `.gitignore` before the first key.
5. **One place for config.** Not five files reading env vars.
6. **Auth checks live at the boundary** (layout / middleware / route guard), not copy-pasted into 30 pages.
7. **Comments explain why, not what.** `// Stripe retries webhooks for 3 days, so this must be idempotent` ✅ `// loop over bookings` ❌
8. **Every folder deeper than 3 levels is a warning sign.** Flatten it.
9. **Tests live next to what they test**, or in a mirrored `tests/` tree. Not in a random `__tests__` at root.
10. **The docs are part of the deliverable.** A feature without a README update isn't finished.

## Ask the human

**One at a time, conversationally.** Never a list. Each ends with `Not sure? Say "you pick".`

1. "Will anyone besides you work on this code — another dev, agency, or another AI? If unsure, say 'you pick' — I'll assume solo for now."
2. "Do you want the simple layout (one folder per feature) or are you planning a mobile app too? → monorepo. Just say 'simple' if you're not sure."
3. "Is this repo going to be public, private, or shown to clients? Affects docs — private by default if you say 'you pick'."
4. "How do you want to run it locally — one command, or okay with a few steps?"
5. "Should I add comments in the code, or keep it clean and put explanations in the docs?"

**How:** Ask one, wait, acknowledge ("Got it — solo, private, noted"), then next. If they already told you during discovery ("it's just for me"), don't re-ask — assume: "I'll keep it simple and solo — correct me if wrong."

## Patterns

### The module file contract

Every feature folder gets at most these files. If you need more, it's two features.

```
features/bookings/
  schema.ts      what valid input looks like (zod / pydantic) — shared by UI and API
  types.ts       the shapes
  queries.ts     reads (only reads)
  actions.ts     writes (validates → authorizes → mutates → logs)
  components/    UI only this feature uses
  bookings.test.ts
```

`actions.ts` order is always: **validate → authorize → mutate → record**. Same order everywhere, so
reviewing any action is muscle memory.

### The "where does this go?" decision

| New thing | Goes to |
|---|---|
| Used by 2+ features | `lib/` |
| Used by one feature | that feature's folder |
| Used by one screen | next to that screen |
| A database query | the feature's `queries.ts` |
| A business rule | the feature's `actions.ts` / `services/` |
| An external API call | `lib/<service>.ts`, wrapped, with timeout + retry |
| A one-time cleanup | `scripts/`, dated, committed for the record |
| A type shared with the client | `types/` or the feature's `types.ts` |

### Rescuing an AI-generated mess (common case)

Don't rewrite. Triage in this order:

1. `git commit` everything first — you need a restore point.
2. Run a secret scan. Rotate anything found. *(30 min, do it first)*
3. Find the entry point. Add a README with "start here: `app/page.tsx`".
4. Delete obvious dead code (files not imported anywhere).
5. Group surviving files into `features/`, `components/`, `lib/` — **move, don't rewrite**.
6. Add the five docs with what you learned.
7. Only then refactor anything, and only what you're already changing.

Expect 1-2 hours, not a weekend.

## Anti-patterns

| Anti-pattern | Cost | Do instead |
|---|---|---|
| 40 files at the repo root | Nobody can find anything | Feature folders on day one |
| `utils.ts` with 900 lines | Everything depends on everything | Named modules |
| Every page re-checks auth | One missed page = a hole | Check at the layout/middleware boundary |
| Docs written once in week one and never touched | Lies | `HANDOFF.md` updated every session |
| Comments describing code | Noise, and they rot | Comments explaining *why* |
| Copy-pasted config in 6 files | Change one, break five | One typed config module |
| `node_modules` committed | Repo is 400MB | `.gitignore`, first commit |
| Monorepo for one app | Build tooling becomes the project | Single app |
| No README "because I know how it works" | Six months later, nobody does | Ten-minute test |
| Rewriting to organize | New bugs, same mess | Move files, commit between moves |

## Definition of done

- [ ] Clone → running app in under 10 minutes, following only the README
- [ ] Four top-level concerns separated: product code, tests, scripts, docs
- [ ] No file named `utils`, `helpers`, `misc`, `common`, or `final`
- [ ] `.gitignore` covers secrets, deps, build output, and local DBs; no secret in history
- [ ] Env vars validated in one config module; `.env.example` complete and fake
- [ ] `docs/BRIEF.md`, `DECISIONS.md`, `HANDOFF.md`, `RUNBOOK.md` exist and are current
- [ ] Auth/ownership checks happen at one boundary, not per page
- [ ] Every file is reachable from an entry point (no orphans)
- [ ] A fresh agent session can find any feature in under 30 seconds
- [ ] `git log` reads like a story someone could follow

## Works with

- `stack-selection` — the stack decides the exact folder names
- `discovery-interview` — brief → `docs/BRIEF.md`
- `vibe-guardrails` — the handoff note lives in `docs/HANDOFF.md`
- `secrets-management` — env conventions and secret scanning
- `data-model-and-migrations` — `docs/SCHEMA.md`
- `refactor-and-maintainability` — when the blueprint drifts
- `code-review-and-audit` — checks a repo against this blueprint
