# Copy-paste templates

## README.md

```markdown
# <Project name>

One sentence: what this is and who it's for.

## Run it locally

```bash
git clone <repo> && cd <repo>
cp .env.example .env       # fill in the values (see below)
npm install
npm run db:migrate
npm run dev                # http://localhost:3000
```

Requires Node 20+ and a Postgres database (any hosted one works).

## Where things live

| Path | What's in it |
|---|---|
| `app/` | pages and API routes |
| `features/` | one folder per feature: validation, reads, writes, UI |
| `components/` | reusable UI pieces |
| `lib/` | database, auth, email, config — the shared bottom layer |
| `db/` | migrations |
| `docs/` | BRIEF, DECISIONS, HANDOFF, RUNBOOK |

Adding a feature? Copy `features/<closest-thing>/`. Every write goes
validate → authorize → mutate → record.

## Environment

Copy `.env.example` to `.env`. Never commit `.env`.
Local dev keys only — production keys stay in the host's dashboard.

## Common commands

| Command | Does |
|---|---|
| `npm run dev` | start with hot reload |
| `npm test` | run the checks |
| `npm run db:migrate` | apply database changes |
| `npm run lint` | style + obvious mistakes |

## Deploy

Pushing to `main` deploys to production automatically after checks pass.
Staging is the `staging` branch. Full procedure: `docs/RUNBOOK.md`.

## When something breaks

`docs/RUNBOOK.md`. Start there, not here.
```

---

## .env.example

```bash
# ── App ────────────────────────────────────────────────
NODE_ENV=development
APP_URL=http://localhost:3000          # no trailing slash

# ── Database ───────────────────────────────────────────
DATABASE_URL=postgresql://user:password@localhost:5432/myapp_dev
# Production: use the pooled/SSL URL from your provider, never the same one locally.

# ── Auth ───────────────────────────────────────────────
AUTH_SECRET=replace-with-32-random-chars    # openssl rand -base64 32
# Signing key for sessions/cookies. Rotating it logs everyone out.

# ── Payments (Stripe — test keys locally) ──────────────
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
# Webhook secrets are per-endpoint and differ between local and production.

# ── Email ──────────────────────────────────────────────
EMAIL_API_KEY=re_xxx
EMAIL_FROM="My App <no-reply@example.com>"

# ── Error tracking ─────────────────────────────────────
SENTRY_DSN=                               # blank = disabled
```

Rules: every key present, every value obviously fake, one line on where to get the real one.

---

## .gitignore (baseline)

```gitignore
# secrets
.env
.env.*
!.env.example

# dependencies
node_modules/
.venv/
__pycache__/

# build output
dist/
build/
.next/
out/
*.tsbuildinfo

# local databases & uploads
*.sqlite
*.sqlite3
*.db
/public/uploads/*
!/public/uploads/.gitkeep

# logs
logs/
*.log
npm-debug.log*

# editors & OS
.vscode/*
!.vscode/settings.json
.idea/
.DS_Store
Thumbs.db

# coverage
coverage/
.nyc_output/
```

---

## docs/RUNBOOK.md

```markdown
# Runbook

Written for a tired person at 3am. Commands first, explanations second.

## Access
- Production host: <url> — login: <where the credentials live>
- Database: <how to connect, and who is allowed to>
- Error tracking: <url>
- Status page: <url>
- DNS: <registrar>

## Deploy
1. `git status` — clean?
2. `npm test` — green?
3. Merge to `main`. CI deploys. Watch <url>.
4. Smoke test: sign up → do the core action → see the result.

## Roll back
```bash
vercel rollback            # or: git revert <sha> && git push
```
Roll back first, investigate second.

## Stop the bleeding (in order)
1. **Kill switch**: set `MAINTENANCE_MODE=true` in the host dashboard → everyone sees a friendly page.
2. **Feature flag off**: turn off the feature that's misbehaving (flags: <url>).
3. **Roll back** to the last known good release (tags: `git tag`).
4. **Scale up** if it's load: <how>.
5. **Disable payments** if money is involved: Stripe dashboard → payments → pause.

## Known failure modes

| Symptom | Likely cause | First check | Fix |
|---|---|---|---|
| 500 on every page | bad deploy, missing env var | error tracker, then host logs | roll back |
| Login loop | expired/changed `AUTH_SECRET`, cookie domain | cookie config | rotate deliberately, tell users |
| Payments not completing | webhook failing | Stripe dashboard → webhooks → attempts | replay the event after fixing |
| Emails not arriving | provider quota or bad domain records | provider logs | check SPF/DKIM/DMARC |
| Site slow, DB pegged | missing index or a runaway query | slow query log | see performance skill |
| Disk full | logs or uploads | `df -h`, then the biggest folder | rotate logs, move uploads to object storage |

## Backups
- What: <what's backed up>
- How often: <schedule>
- Where: <location, and who can restore>
- **Last restore test: <date>** — an untested backup is not a backup.

## Escalation
1. You.
2. <name> — <phone> — owns <area>
3. <host support> — <url>
```

---

## docs/HANDOFF.md (rolling)

```markdown
# Handoff

## Session 2026-10-20

WHAT CHANGED
- Added class booking with Stripe checkout.

WHAT I ASSUMED
- Max 20 people per class. If unlimited, the capacity check needs removing.
- Emails are only in English for now.

WHAT I DIDN'T DO
- No waiting list when a class is full.
- No admin cancellation flow.

WHAT TO CHECK
1. /classes → book → pay with card 4242 4242 4242 4242 → you should land on /bookings and see it.
2. Refresh → the booking is still there.
3. Try booking a full class → you should get a clear message, not an error page.

NEXT
→ Waiting list for full classes.
```
