---
name: stack-selection
description: Use whenever a stack, framework, database, host, auth provider, or "what should I build this with" decision comes up — before the first file is created, and again before any rewrite. Chooses technology from the actual situation (users, stakes, budget, timeline, who maintains it, what the human already knows) instead of defaulting to whatever the agent saw most recently. Includes ready-made stack recipes and a decision-record format that prevents month-two rewrites.
metadata:
  category: core
  version: 1.0.0
  value: "$100"
  group: core
---

# stack-selection

## Promise

No more "why is this built in <framework the agent likes>?" and no more month-two rewrite.
The stack comes out of the situation, and every choice is written down with the reason attached.

## When to use

- Starting any project where nothing is built yet
- "Should I use Next.js or Vite?", "What database?", "Where should I host it?"
- Adding a major capability: auth, payments, realtime, mobile, desktop, AI, search
- Before a rewrite: "should we start over in <new framework>?"
- Reviewing an existing AI-built project: "is this stack right for what it became?"
- Performance or cost problems that trace back to an architectural choice

## When NOT to use

- The project already works and the user is happy — don't churn
- Choosing a library for one small utility (pick the boring one, move on)

## The 60-second version

Five inputs choose ~90% of the stack. Get these from `discovery-interview`, never from vibes:

| Input | Human question behind it |
|---|---|
| **Who discovers it** | Does it need to appear in Google, or is it behind a login / shared by link? |
| **How many, how spiky** | 50/day steady, or 10,000 in one afternoon? |
| **What breaks** | Nothing, money, contracts, or safety? |
| **Who maintains it** | You, a future hire, or nobody (throwaway)? |
| **What you already know** | What have you (or your agent) used before and been productive in? |

Then: **pick the most boring option that satisfies all five.** Boring is a feature. It's the option with
the most Stack Overflow answers, the most tutorials your agent has seen, the most managed hosting, and the
least chance you're debugging tooling at 1am instead of shipping your product.

## The bias you must fight

Agents default to whatever is most represented in their training data. Correct for it:

| Default bias | Check yourself |
|---|---|
| Reaching for Next.js for everything | Is this a login-protected app with no SEO need? A plain SPA + small API is simpler and cheaper. |
| Postgres for a 3-user tool | SQLite (or a hosted Postgres free tier) is fine; don't run infrastructure you don't need. |
| Microservices / queues / k8s for tiny apps | One deployable unit until you have a reason. Real reason, not "in case we scale". |
| The newest framework | Who will maintain it in 18 months? Is there a managed host with a one-click deploy? |
| Whatever is in the current directory | "It's already here" is not a reason. But "the app already runs on it and it works" *is*. |
| Rewriting because the code is messy | Messy ≠ wrong stack. See the rewrite test below. |
| Adding a cache/queue/search cluster early | Add it when you have a measured problem, with a number attached. |

## Steps

### Step 1 — Classify the project shape

| Shape | Typical ask | Default stack direction |
|---|---|---|
| **Marketing / landing / docs** | "a website for my business" | Static site generator (Astro, Next static, Eleventy) + a form endpoint. No database. |
| **Content / blog / SEO-driven** | "I want people to find me on Google" | SSG or SSR with good metadata; CMS optional. Never a client-only SPA. |
| **Logged-in web app (SaaS)** | "users sign up and manage their stuff" | Full-stack framework (Next/Remix/SvelteKit/Nuxt/Rails/Laravel) + hosted Postgres + managed auth |
| **Internal tool / admin** | "just for my team" | Same as SaaS but simpler: fewer states, prioritize speed, IP allowlist or SSO |
| **Public API / backend only** | "an API other things call" | FastAPI / Hono / Express / Go + Postgres + OpenAPI docs + rate limits from day one |
| **Mobile app** | "an app in the App Store" | Expo (React Native) or Flutter. Web app in a wrapper is a bad idea unless it's genuinely a web app. |
| **Desktop app** | "a Mac/Windows app" | Tauri (small, fast) or Electron (mature, batteries included) |
| **AI feature inside an app** | "add a chatbot / summarizer" | Keep the app stack; add the model via API; never rebuild the app around the model |
| **Realtime (chat, collab, live board)** | "multiple people see updates instantly" | Managed realtime (Supabase Realtime, Convex, Liveblocks, Pusher, Ably) before writing your own WebSocket layer |
| **E-commerce** | "sell products" | Shopify/Medusa/Saleor before building a cart. If it's a few products: Stripe Checkout + Payment Links. |
| **Marketplace / two-sided** | "connect providers and customers" | Boring monolith + Postgres; the complexity is in the domain, not the infra |
| **Portfolio / demo** | "show what I can do" | Static, free hosting, **still no secrets in the bundle**, still no unauthenticated write endpoints |

### Step 2 — Choose each layer (defaults, with the exception that flips them)

**Frontend**

| Situation | Pick | Skip it when |
|---|---|---|
| Needs Google/search or social share previews | Next.js, Nuxt, SvelteKit, Astro (SSR/SSG mode) | — |
| Login-walled app, no SEO | Vite + React/Vue/Svelte SPA, served statically, calls an API | You later need SEO |
| Content-heavy, mostly static | Astro / Eleventy / Hugo | You need lots of interactivity |
| You already know one | **That one.** Familiarity beats theoretical fit every time. | It's actively deprecated |
| Team is non-technical maintainer | Fewer build steps wins: Rails/Laravel server-rendered, or a hosted platform | — |

**Backend**

| Situation | Pick |
|---|---|
| You're JS/TS everywhere | Hono or Fastify (API), or the framework's route handlers (Next Route Handlers, Remix loaders) |
| Python / data & AI heavy | FastAPI (API) or Django (batteries: admin, auth, ORM, migrations — a huge win for solo builders) |
| You want the least code for auth + DB + storage + realtime | Supabase, Appwrite, Convex, Firebase (BaaS) — but read the lock-in note below |
| Max simplicity, typed, boring | Go + stdlib/`net/http` + sqlc |
| You love shipping CRUD fast | Rails, Laravel, Django — the "one person can build a whole product" stacks |

**Database — the honest table**

| Need | Pick | Why not the other |
|---|---|---|
| Default, you don't have a special need | **Postgres** | It does JSON, search, queues, vectors, geo. 99% of apps never need to leave. |
| Tiny app, embedded, desktop, mobile, offline | SQLite (with Litestream/Turso if you need sync) | Zero ops. Seriously: thousands of real products run on SQLite. |
| AI / embeddings | Postgres + pgvector | One less system to run than a separate vector DB |
| Realtime sync to browser, offline-first, no backend | Convex, Firebase, Supabase Realtime | Hand-rolled CRDTs are a months-long project |
| "It's unstructured / schema keeps changing" | **Still Postgres**, with a JSON column for the fluid part | "Schema-less" usually means "nobody wrote the schema down" |
| Wide-column / massive write throughput at scale | DynamoDB, Cassandra, Scylla | You'll know. If you don't, you don't need it. |
| Analytics / reporting over huge datasets | Postgres → then a warehouse (BigQuery/ClickHouse) when queries hurt | Don't start with a warehouse |

**ORM / data access:** Prisma (great DX, mind the query size), Drizzle (SQL-like, edge friendly),
SQLAlchemy (Python), ActiveRecord/Eloquent (Rails/Laravel). Rule: **you must be able to see the SQL**.
If you can't log the generated query, you can't debug the slow page.

**Auth — do not hand-roll**

| Situation | Pick |
|---|---|
| Need it working today, JS/TS | Clerk, Auth.js, Supabase Auth, Better Auth |
| Python | Django allauth, FastAPI-Users |
| Enterprise customers | Something with SSO/SAML: Clerk/WorkOS/Auth0 |
| "I'll write my own JWT auth" | **Don't.** See `auth-and-access` for the 14 things you'll get wrong. |

**Hosting**

| Situation | Pick |
|---|---|
| Next.js app, want zero ops | Vercel (or Netlify/Cloudflare Pages for others) |
| Full-stack app with a database, want cheap and simple | Railway, Render, Fly.io |
| Static site | Cloudflare Pages, Netlify, GitHub Pages |
| Want max control / lowest cost at scale | A VPS (Hetzner ~$5/mo) + Coolify or Dokku |
| Enterprise / compliance / existing cloud | AWS/GCP/Azure with a platform layer (not raw EC2) |
| Needs to be in a specific country (data residency) | Pick a host with that region, and say so in the brief |

⚠ **Hosting cost warning:** serverless bills scale with traffic, and traffic includes bots. If the user
said "$0/month" or "I'm worried about bills", prefer fixed-price hosting and set hard caps. See `cost-guardrails`.

**Payments:** Stripe (default), Paddle or Lemon Squeezy if you want someone else to handle tax
(merchant of record). Never build your own card handling. Never trust a price sent from the browser.

### Step 3 — Score the lock-in before committing

Every managed service is a trade: speed now, exit cost later. Write the exit cost down.

| Choice | Lock-in | Exit cost |
|---|---|---|
| Postgres | Very low | Easy — it's open source and portable. **This is why it's the default.** |
| Firebase / Firestore | High | Data model is vendor-shaped; migration is a project |
| Supabase | Medium | It's Postgres underneath — export works, but auth/realtime/storage are coupled |
| Vercel | Medium | Next.js runs anywhere, but some features are platform-specific |
| Clerk / Auth0 | Medium | User data export exists; session logic is coupled |
| AWS-only services (Dynamo, Lambda + IAM glue) | High | Rewrite to leave |
| Stripe | Medium | Card data is portable-ish; subscription logic is yours to rebuild |

Rule of thumb: **the database is the only thing you can't easily change later.** Keep it boring and portable.
Everything else above it is replaceable.

### Step 4 — Write the decision record

`docs/DECISIONS.md`. One block per significant choice. This is the artifact that makes the pack worth money —
six months later, nobody re-litigates a decision whose reason is written down.

```markdown
## 2026-10-20 — Database: Postgres (Neon free tier)
- Decision: Postgres, hosted on Neon.
- Because: user expects ~200 users/day with possible launch spikes to 3k,
  wants to keep costs at $0 until revenue, and may hand the project to a
  contractor later (Postgres is universally hireable).
- Rejected: SQLite — fine for the size, but user wants a second developer to
  be able to work on it concurrently. Firebase — data model lock-in.
- Revisit when: >10k daily actives, or >50GB, or we need read replicas.
```

### Step 5 — Sanity-check against reality

Before you commit, answer out loud:

1. Can the user (or their agent) deploy this with one command?
2. Can it run locally without a PhD?
3. If the maintainer disappears for 6 months, does it still boot?
4. Is every piece either (a) something the user already knows, or (b) something with a huge amount of public help available?
5. Does the monthly bill have a ceiling the user can survive?

Two "no"s and you picked wrong.

## Non-negotiables

1. **Situation drives the stack, never preference.** If you can't name the situation fact behind a choice, it's a preference.
2. **Postgres unless there's a specific reason.** "It might not scale" is not a reason; Postgres scales past anything you'll build this year.
3. **Never hand-roll auth, payments, or crypto.**
4. **Prefer managed over self-hosted** unless the user's budget or data rules say otherwise. Your time is the expensive resource.
5. **One deployable unit** until there's a measured reason for more.
6. **Keep the database portable.** It's the one irreversible choice.
7. **Check the exit before the entrance.** "How would I leave this?" before "this looks nice".
8. **Ask before adding infrastructure.** A cache, a queue, a search cluster, a second service — each is a new thing that can break at 3am.
9. **Familiarity counts as a real constraint.** A stack the user can debug beats a "better" one they can't.
10. **Don't choose a stack to impress anyone.** No resume-driven development in someone else's product.

## Ask the human

**One question at a time.** Each with a default — `Not sure? Just say "you pick".`

Ask in this order, skipping anything you already learned from `discovery-interview`:

1. "Do you want this to show up in Google search, or is it something people log into / you share directly? — if unsure, say 'you pick' and I'll assume logged-in app."
2. "Roughly how many people on a normal day — and if it takes off, biggest day you can picture?"
3. "What can you spend per month to keep it running? ($0 is totally fine, I'll plan for it.)"
4. "Is there anything you already use or already know that we should stick with?"
5. "Who's going to look after this after it's live — you, someone you hire, or nobody?"

**How to ask:** Acknowledge the previous answer, then one question with its default. Never dump all 5.

> Good: "Got it — so it's mostly logged-in, not SEO. Quick one: roughly how many people on a normal day?"
>
> Bad: numbered list of 5 questions at once.

Never ask: "SQL or NoSQL", "REST or GraphQL", "serverless or containers", "monolith or microservices",
"which ORM", "which state manager". Those are answered by the table above. If the human already answered one of the 5 during discovery, don't re-ask — state your assumption: "So for scale, you said ~50/day — I'll design for that, correct me if wrong."

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| Next.js for a login-only internal tool | SSR complexity, serverless cold starts, higher bill | SPA + small API, or a server-rendered framework |
| Kubernetes for an app with 40 users | Months of yak-shaving, zero features | One container on a $5 VPS |
| Kafka/RabbitMQ because "async is better" | Debugging distributed failures alone | A `jobs` table + a worker. Seriously. |
| GraphQL because REST is old | Caching and auth get harder for no user benefit | REST/JSON unless you have many very different clients |
| MongoDB because "we're agile" | No relations, no constraints, data rot | Postgres with a JSON column for the fluid bits |
| Rewriting in the new hot framework | 6 weeks lost, same bugs, new bugs | Rewrite test below |
| Microservices at idea stage | Network calls where function calls used to be | One app, clear module boundaries (see `refactor-and-maintainability`) |
| Choosing by GitHub stars | Abandoned dependency in a year | Choose by: maintained, boring, documented, hostable, hireable |
| "Let's build our own auth, it's just JWT" | Account takeover, credential stuffing, no revocation | Managed auth, or `auth-and-access` patterns line by line |
| Ignoring the user's existing stack | They can't fix anything themselves | Ask question 4 above. Always. |

## The rewrite test — should we start over?

Only rewrite if **at least two** are true:

- [ ] The current stack blocks a requirement you actually have *now* (not "might have")
- [ ] Adding a feature takes 3x longer than it should, and you can point to why
- [ ] You can't hire or find help for the current stack
- [ ] Security or compliance can't be met on it
- [ ] The app is small enough to rebuild in under 3 weeks, *and* you have those weeks

Otherwise: strangler pattern. New features in the new thing, old thing stays, migrate gradually.
Big-bang rewrites of working software are how solo projects die.

## Ready-made recipes

Full copy-paste recipes (package lists, file layout, deploy config) live in
[`references/stack-recipes.md`](references/stack-recipes.md): solo SaaS, landing page, internal tool,
mobile app, desktop app, AI feature, realtime app, marketplace, and the "$0/month" build.

## Definition of done

- [ ] Every layer (frontend, backend, DB, auth, hosting, payments) has a choice **and a "because" tied to a fact from the brief**
- [ ] `docs/DECISIONS.md` written with revisit triggers
- [ ] Database is portable (or the lock-in is a conscious, written decision with an exit plan)
- [ ] Monthly cost ceiling estimated and approved by the human
- [ ] Deploy path exists on day one (not "we'll figure it out later")
- [ ] The human can name the stack and explain why in their own words
- [ ] Nothing chosen purely because it's new

## Works with

- `discovery-interview` — supplies the facts that drive every row above
- `project-blueprint` — turns the chosen stack into a repo layout
- `deploy-and-environments` — validates the hosting choice
- `cost-guardrails` — validates the bill
- `saas-architecture` — for multi-tenant products
- `mobile-app-delivery` / `desktop-app-delivery` / `ai-features-in-production` — platform-specific choices
- `refactor-and-maintainability` — when tempted to rewrite
