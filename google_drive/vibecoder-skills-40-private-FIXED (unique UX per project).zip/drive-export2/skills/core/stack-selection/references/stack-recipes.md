# Stack recipes

Nine copy-paste starting points. Each is the **boring, cheap, well-documented** option for that shape.
Deviate with a written reason.

Every recipe assumes: TypeScript, Postgres, deploy-on-push, error tracking, and one database.

---

## 1. Solo SaaS (the default)

**For:** logged-in product, paying customers, one developer.

```
Frontend + API : Next.js (App Router), TypeScript, Tailwind
DB + ORM       : Postgres (Neon / Supabase / Railway) + Prisma or Drizzle
Auth           : Clerk, Auth.js, or Supabase Auth
Payments       : Stripe (Checkout + Customer Portal), webhook → DB
Email          : Resend or Postmark + React Email templates
Hosting        : Vercel (or Railway/Fly if you want a persistent server)
Errors         : Sentry
Analytics      : Plausible or PostHog (self-host option), privacy-friendly
Background jobs: a `jobs` table + one worker route (pg-boss / Inngest / Trigger.dev)
Files          : S3-compatible (Cloudflare R2, Backblaze B2) with signed URLs
```

Monthly at 0 users: **$0**. At 1,000 users: **$20-60**.

Rules: never read price from the client; webhook handlers must be idempotent; every mutation checks
ownership server-side (see `appsec-hardening`).

---

## 2. Landing page / marketing site

**For:** a business site, a product page, SEO matters.

```
Framework : Astro (or Next.js static export)
Content   : Markdown/MDX in the repo, or a headless CMS if a non-dev edits it
Forms     : a form endpoint service, or a serverless function with a honeypot + rate limit
Hosting   : Cloudflare Pages / Netlify / Vercel — free tier
Analytics : Plausible (cookieless) — not a tracker that needs a banner
SEO       : title, description, OG image, sitemap.xml, robots.txt, JSON-LD
```

No database. No auth. No client-side secrets. See `seo-and-growth-basics`.

---

## 3. Internal tool / admin panel

**For:** your team only. Optimize for build speed, not polish.

```
Stack    : whatever the main app uses, plus an admin route group behind a role check
        or Django (free admin CRUD) if the whole product is internal
Auth     : SSO or a shared identity provider; if none, email + strong password + MFA
Network  : IP allowlist if the team is in fixed locations
Audit    : log who changed what (see data-privacy-and-pii)
Deploy   : same pipeline as the app; protect /admin with more than "hidden URL"
```

Never ship an admin panel whose only protection is an unlinked URL. See `appsec-hardening` → IDOR.

---

## 4. Mobile app (iOS + Android)

**For:** something people install from a store.

```
Framework : Expo (React Native) — one codebase, over-the-air JS updates
        or Flutter if you want one codebase + max UI control
Backend   : same as the SaaS recipe; the app is just another client
Auth      : provider SDK with secure token storage (Keychain / Keystore — NEVER AsyncStorage)
Push      : Expo Notifications (or the provider's SDK)
Data      : offline-tolerant: cache reads, queue writes
Releases  : EAS Build + EAS Update (OTA), TestFlight → App Store, Play Internal → Production
```

Secrets in a mobile app are **public**. Anything secret lives on your server. See `mobile-app-delivery`.

Budget: Apple $99/yr, Google $25 once. Review: plan 2-7 days for the first submission.

---

## 5. Desktop app (Mac / Windows / Linux)

**For:** installable native-ish app.

```
Default   : Tauri (Rust shell + your web UI) — ~10MB installers, small memory
If you need Node APIs, mature plugins, or a huge ecosystem: Electron
Updater   : built-in updater, signed + verified, with a rollback channel
Signing   : Apple Developer ID + notarization (macOS), code signing cert (Windows)
Storage   : SQLite locally; sync to server if needed
Secrets   : OS keychain; never plaintext in app files
```

Unsigned installers get blocked by macOS Gatekeeper and Windows SmartScreen. Budget time for it.
See `desktop-app-delivery`.

---

## 6. AI feature inside an existing app

**For:** "add a chatbot / summarizer / search to my product".

```
Do NOT rebuild the app around the model.
Pattern  : your API route → provider SDK → streamed response → your UI
Guardrails: system prompt + input validation + output validation
          : treat model output as untrusted user input (never eval, never SQL-interpolate)
Cost     : per-user and per-day token caps, cached prompts, cheap model by default
Reliability: timeout, retry with backoff, graceful fallback ("AI is busy, try again")
Privacy  : know what you're sending; redact PII; check the provider's retention policy
Observability: log prompt version, tokens, cost, and latency per call
```

See `ai-features-in-production` and `cost-guardrails`.

---

## 7. Realtime / collaborative app

**For:** chat, live dashboards, multiplayer boards, cursors.

```
Don't write your own WebSocket layer first.
Pick one : Supabase Realtime (if already on Supabase)
         : Convex (sync engine + DB, great DX)
         : Liveblocks (presence + collaboration primitives)
         : Ably / Pusher (battle-tested pub/sub)
         : Socket.IO on your own server (only if you must self-host)
Always   : authenticate the socket, authorize every room/channel,
           rate limit messages, validate payloads, handle reconnect + backfill
```

The hard part is never the socket — it's auth on the channel, reconnect state, and history backfill.

---

## 8. Marketplace / two-sided platform

**For:** buyers and sellers, providers and customers.

```
Keep it a monolith. The complexity is in the business rules, not the infra.
Core     : Postgres with real foreign keys and transactions
Money    : Stripe Connect (split payments) — do not build ledger logic ad hoc
Trust    : every mutation checks "does this actor own this resource?" (IDOR defense)
Search   : Postgres full-text first; add a search service only when it hurts
Messaging: store as an append-only table; moderate before display if public
Admin    : dispute/refund tooling early — you'll need it in week two
```

See `saas-architecture` and `payments-and-billing`.

---

## 9. The $0/month build

**For:** side projects, demos, uncertain ideas — with a real cap, not hope.

```
Hosting   : Cloudflare Pages/Workers (generous free tier), or Vercel/Netlify hobby
DB        : Neon / Supabase / Turso free tier — know the row and egress limits
Files     : Cloudflare R2 (free egress) — the sneaky bill is usually egress, not storage
Email     : Resend free tier
Background: cron on the platform, not a dedicated worker
Hard caps : set provider spend limits, per-user rate limits, and a usage dashboard
Errors    : Sentry free tier
No        : no always-on servers, no self-hosted databases, no GPU, no LLM without a token cap
```

The $0 build still needs: auth checks, rate limits, input validation, and no secrets in the client.
Free tier ≠ throwaway; bots find free-tier apps too.

---

## Choosing between the two you're stuck on

| Stuck between | Tiebreaker |
|---|---|
| Next.js vs Vite SPA | Do you need Google/search/share previews? Yes → Next. No → Vite. |
| Prisma vs Drizzle | Edge/serverless + you like SQL → Drizzle. Best DX + you don't care about bundle → Prisma. |
| Supabase vs plain Postgres + your own API | Do you want auth/storage/realtime built in? Yes → Supabase. Want portability? → plain Postgres. |
| Stripe vs Paddle/Lemon Squeezy | Do you want to handle VAT/sales tax yourself? No → Paddle/Lemon Squeezy (merchant of record). |
| Tauri vs Electron | Need Node native modules or huge ecosystem → Electron. Otherwise → Tauri. |
| Expo vs Flutter | Know React → Expo. Want maximum UI control / don't know React → Flutter. |
| Monolith vs services | Can one person deploy it in one command? Keep the monolith. |
| Self-host vs managed | Is your time worth more than the bill? Usually yes → managed. |
