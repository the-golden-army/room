# Translation glossary — engineer words → human words

Use the right column with non-technical humans. First use of any term in a session gets the translation.

| Engineer says | Say this |
|---|---|
| Idempotent | Safe to run twice — doing it again changes nothing |
| Migration | A small script that reshapes the database without losing data |
| Rollback | Putting the old version back, like undo for a release |
| Cache / caching | Remembering the answer for a short time instead of recalculating it |
| Cache invalidation | Deciding when that remembered answer is out of date |
| Rate limit | A cap on how many times one person (or bot) can do something per minute |
| Throttle | Slowing someone down instead of blocking them |
| Timeout | Giving up after N seconds instead of waiting forever |
| Retry with backoff | Trying again, waiting a bit longer each time |
| N+1 query | Asking the database 1,000 tiny questions instead of one big one |
| Index | A lookup table that makes searching fast, like a book's index |
| Transaction | All-or-nothing: either every step happens, or none do |
| Race condition | Two things happening at once and tripping over each other |
| Deadlock | Two processes each waiting for the other to finish |
| Environment variable | A setting kept outside the code, so secrets aren't in the code |
| Secret / credential | A password for a machine — API key, token, database URL |
| Env file (`.env`) | The file where those machine passwords live locally |
| Client-side / front-end | In the user's browser — visible and editable by them. Never trusted |
| Server-side / back-end | On your machine — the only place rules can be enforced |
| Endpoint / route / API | A doorway into your app that software (not humans) uses |
| Payload | The data being sent |
| Schema | The shape of your data: what fields exist and what type they are |
| Validation | Checking the data is the right shape before trusting it |
| Sanitization | Cleaning dangerous content out of input |
| Escape | Rendering text as text, so it can't be executed as code |
| Authentication (authN) | Who are you? (logging in) |
| Authorization (authZ) | What are you allowed to do? (permissions) |
| Session | The proof you're still logged in after the first page |
| Token / JWT | A signed note saying who you are |
| MFA / 2FA | A second check, usually a code on your phone |
| OAuth / "Sign in with Google" | Letting a big company vouch for the user so you never store their password |
| RBAC | Roles: admin sees more than a regular member |
| Tenant | One customer's separate space inside a shared app |
| Monolith | The whole app shipped as one piece |
| Microservice | The app split into pieces that talk over the network |
| Queue / background job | Work done later, in the background, not while the user waits |
| Worker | The thing that does background jobs |
| Cron | A scheduled task ("every night at 3am") |
| Webhook | Another service calling you when something happens |
| Idempotency key | A unique tag so a repeated request is only processed once |
| Serverless | Code that runs only when called, billed per call |
| Cold start | The delay when idle code wakes up |
| Edge | Running your code in many cities so it's close to users |
| CDN | Copies of your files stored around the world for speed |
| Latency | How long a wait feels |
| Throughput | How much work gets done per second |
| Bottleneck | The one slow part holding everything up |
| Observability | Being able to see what your app is doing when you're not watching |
| Log | A diary the app writes for itself |
| Trace | The full path of one request through the system |
| Alert | A message that wakes you when something's wrong |
| Regression | Something that used to work and now doesn't |
| Refactor | Reshaping code without changing what it does |
| Technical debt | Shortcuts that will cost time later |
| Dependency / package | Someone else's code that yours relies on |
| Lockfile | The exact list of dependency versions, so installs are repeatable |
| CVE | A publicly known security hole in a package |
| Build | Turning your code into something that runs |
| Deploy / release | Putting the new version live |
| CI/CD | Robots that test and ship your code when you push |
| Staging | A private copy of the app for testing before real users see it |
| Feature flag | A switch to turn a feature on/off without redeploying |
| Kill switch | An emergency off button |
| Blue-green / canary | Releasing to a few users first, then everyone |
| Backup | A copy you can restore from |
| Restore | Actually getting the data back — the only test that matters |
| SLA / uptime | Promised availability, e.g. "99.9% of the time" |
| Incident | Something is broken in production, right now |
| Postmortem | A blameless write-up of what happened and what changes |
| PII | Personal information: name, email, phone, location, anything identifying |
| Encryption at rest / in transit | Scrambled while stored / while travelling |
| Hashing | One-way scrambling — you can't get the original back (for passwords) |
| Salting | Adding randomness before hashing so identical passwords look different |
| XSS | An attacker's code running in your users' browsers |
| CSRF | Tricking a logged-in user's browser into doing something they didn't ask for |
| SQL injection | Sneaking database commands into a text field |
| IDOR | Changing an ID in the URL and seeing someone else's data |
| SSRF | Tricking your server into fetching an attacker's (or internal) address |
| Path traversal | Using `../../` in a filename to reach files you shouldn't |
| Brute force | Trying thousands of passwords until one works |
| Enumeration | Using error messages to discover which accounts/emails exist |
| Principle of least privilege | Give the minimum access needed, nothing more |
| Defense in depth | Multiple layers, so one failure isn't fatal |
| Zero trust | Verify every request, even internal ones |

## Phrases to avoid entirely with non-engineers

| Don't say | Say |
|---|---|
| "It's a skill issue" | "Here's how to avoid that" |
| "That's not possible" | "That's possible, but it would take X and cost Y" |
| "Obviously…" / "Just…" | (delete the word) |
| "The tests are failing" | "Three things broke when I ran the checks; here's the first one in plain words" |
| "It works on my machine" | "It works for me, but I need to check it in the real setup" |
| "RTFM" | (never) |
| "That's out of scope" | "That's a good idea for after launch; here's why I'd wait" |
| "Legacy code" | "The older part of the app, built before <date>" |
