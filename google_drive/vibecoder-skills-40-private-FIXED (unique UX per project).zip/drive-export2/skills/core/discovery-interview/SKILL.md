---
name: discovery-interview
description: Use at the very start of a new project, feature, or vague request ("build me an app for X", "I want something like Uber but for Y"). Replaces technical requirements gathering with plain-language questions about people, money, scale and consequences, then converts the answers into a one-page brief and concrete technical decisions. Prevents the most expensive failure in vibe coding — building the wrong thing confidently.
metadata:
  category: core
  version: 1.0.0
  value: "$100"
  group: core
---

# discovery-interview

## Promise

You will never again write 900 lines of code for a request you didn't understand.
This skill turns a vague idea into a one-page brief that both the human and the agent agree on — using
questions a ten-year-old could answer, and answers that quietly determine the entire architecture.

## When to use

- Any new project or feature request that isn't trivially small
- The request is one sentence and could mean six different products
- "Make me something like <famous app>, but for <niche>"
- A client or stakeholder described an outcome, not a specification
- You catch yourself about to assume something important
- Someone asks "why is this taking so long / why did you build *that*?"

## When NOT to use

- Bug fixes, copy changes, obvious small tasks
- The user has already given you a written spec — verify it instead (jump to Step 5)

## The 60-second version

Seven blocks, **one question at a time**. Ask in this order, always with a default:

```
1. WHO     — who opens this, and what's happening in their life when they do?
2. JOB     — the one thing they must be able to do. Then the second.
3. SCALE   — a normal day, and the best day you can imagine.
4. STAKES  — if it's broken for a day, what does it cost you?
5. MONEY   — does anyone pay, and how?
6. DATA    — is there anything here you'd be in real trouble for leaking?
7. REALITY — when does it need to be live, what can you spend, who maintains it?
```

Then translate the answers into decisions (Step 3 table), write the brief, get a "yes", build.

> **The conversation rule (non-negotiable):** Ask **one question**, wait for the answer, acknowledge it in one short line, then ask the next. Never queue 2 questions. Never dump a list. The user should feel like they're chatting, not filling a form.

## The one rule

> **Never ask the human to solve an engineering problem. Ask them to describe their life.**

| ❌ Never ask | ✅ Ask instead | Why |
|---|---|---|
| "SQL or NoSQL?" | "Will the shape of the data keep changing as you figure this out, or is it pretty fixed?" | Humans know their uncertainty, not their storage engine |
| "Should we add Redis?" | "Could a post go viral and bring 10,000 people in one day, or is growth steady?" | Humans know their marketing plan, not their cache layer |
| "Monolith or microservices?" | "How many people will work on this code at the same time?" | Humans know their team size |
| "Do you need SSR?" | "Will this show up in Google search, or is it behind a login?" | Humans know who discovers them |
| "What's your auth strategy?" | "Do people need accounts, or can anyone just use it?" | Humans know their onboarding friction tolerance |
| "What's your retention policy?" | "If a customer emails you and says 'delete everything about me', can you?" | Humans know their promises |
| "Do you want CI/CD?" | "When you change something, do you want to just push and see it live, or review first?" | Humans know their risk appetite |

If you can't translate a technical question into a human one, **you don't need to ask it — decide it.**

## Steps

### Step 1 — Reflect back what you heard (30 seconds)

Before asking anything, say what you understood in one sentence:

```
"I hear: a booking page for your gym where members pick a class, pay, and get a reminder.
Before I build, six quick questions — none of them technical. If you're unsure on any,
say 'you pick' and I'll choose something sensible and tell you what I chose."
```

This one move catches most misunderstandings, because the human corrects you immediately.

### Step 2 — Ask the seven blocks (one question at a time)

This is a conversation, not a questionnaire. Follow these rules strictly:

1. **One question per turn.** Ask one, wait for the answer, then continue. Never batch.
2. **Acknowledge before asking.** Reflect the previous answer in ≤1 line ("Got it — gym members booking on their phone.") then ask the next.
3. **Always offer a default inline.** End every question with: `Not sure? Just say "you pick" — I'll assume <default> and tell you.`
4. **Skip what you already know.** If the answer is implied by a previous one, don't ask — state your assumption and move on: "You mentioned it's for your gym members, so I'll note that — unless I'm wrong?"
5. **Show progress lightly, not as an exam.** A subtle `— quick one, 2/7` is okay. Never show a numbered list of remaining questions.
6. **Allow escape at any time.** If the user says "skip / next / you pick / idk / just build it", take the default, note it, and continue. Never nag.
7. **Adapt.** If the answer changes the needed blocks, skip irrelevant ones. (No payments? Skip MONEY block. No user data? Shorten DATA.)

**Your messages should look like this:**

> Got it — so it's for gym members booking from their phone between classes. Quick one, 2/7:
>
> If this app could only do ONE thing, what would it be? Like "book a class" or "pay for a session"?
> Not sure? Just say "you pick" and I'll assume booking + payment.

**Not like this (never do this):**

> ❌ 1. Who's the main person using this?
> ❌ 2. How tech-comfortable are they?
> ❌ 3. Are there other users?
> ... (wall of 8 questions)

**The question bank below is your *reservoir*, not a script.** Pick the next most useful question from the current block, ask it alone, and only pull the next question after you have an answer. If two questions in the same block are already answered by one reply, don't re-ask.

#### Block 1 — WHO
1. "Who's the main person using this? Describe them like a real person — age-ish, what they're doing when they open it, what device is in their hand."
2. "Are they doing this for themselves, or on behalf of someone else (a client, a patient, a customer, their boss)?"
3. "How tech-comfortable are they? Would they find a 3-step signup annoying?"
4. "Is there anyone else who touches it — an admin, a staff member, you?"
*→ Defaults: unknown = "a normal person on a phone, moderate patience".*

#### Block 2 — JOB
5. "If this app could only do ONE thing, what would it be?"
6. "What's the second thing? What's the third?"
7. "What's the thing they do right before opening your app, and right after?" *(reveals integrations)*
8. "What are they doing today instead — spreadsheet, WhatsApp, paper, a competitor, nothing?"
*→ The "today instead" answer is the single best predictor of adoption.*

#### Block 3 — SCALE
9. "On a normal day, roughly how many people will use it? 10, 100, 1,000?"
10. "If something goes really well — a viral post, a press mention, a Black Friday — what's the biggest day you can realistically imagine?"
11. "Is usage spread through the day, or does it all hit at once (like ticket sales at 10am)?"
12. "Will it store a lot of stuff over time — photos, files, message history — or is it mostly small records?"
*→ Defaults: unknown = "assume under 1,000/day but design so a 10x spike doesn't fall over".*

#### Block 4 — STAKES
13. "If this is broken for a full day, what does it cost you: nothing, mild annoyance, lost money, or contracts/legal trouble?"
14. "Is there a moment where being slow is as bad as being broken?" *(checkout, live events, auctions)*
15. "What would you absolutely hate to see — a news story, an angry customer, lost data, or a security breach?"
*→ This answer sets how much process is justified. Never over-engineer a "nothing" project, never under-engineer a "contracts" one.*

#### Block 5 — MONEY
16. "Does anyone pay? One-off, monthly, or not yet?"
17. "If monthly: are there different levels, and what makes someone worth more?"
18. "Do you need invoices/receipts, refunds, or trials?"
19. "Roughly what does one customer pay you, and how do you take money today?"
*→ Any "yes" here loads `payments-and-billing` and makes `appsec-hardening` mandatory.*

#### Block 6 — DATA
20. "What information does this collect about people? Name, email, photos, location, messages, payments, health, ID documents?"
21. "Is any of it the kind of thing you'd get in trouble for leaking?"
22. "Do people upload files? What kind?"
23. "If someone asked you to delete everything about them, could you? Should you?"
24. "Do you need to keep records for a legal reason — accounting, medical, contracts?"
*→ Any sensitive data loads `data-privacy-and-pii`. This is also where you learn whether you need encryption at rest and audit logs.*

#### Block 7 — REALITY
25. "When does this need to be live? This weekend, a month, no rush?"
26. "What can you spend per month to keep it running? $0 is a fine answer."
27. "Will you maintain it yourself, hire someone, or is it throwaway after the demo?"
28. "Is there anything you already pay for or already know that we should use?" *(domain, host, a tool, a language)*
29. "Where should it live: web only, phone app, desktop app, or all?"
30. "Anything you've used that you want this to feel like? Anything you hate in other apps?"

#### How to keep it conversational (examples)

**Good — warm, one question, with a default:**
> "Who's actually opening this? Picture one real person — what are they doing right before they open it, phone or laptop in hand?"
> "Not sure? Just say 'you pick' — I'll assume a normal person on their phone, moderate patience."

**Good — acknowledging, then moving on:**
> "Perfect — so it's ~50 people on a normal day, maybe 500 if a promo hits. That tells me we can keep hosting simple.
> Next, super quick: if it broke for a whole day, is that just annoying, or does it cost you real money?"

**Bad — the exam sheet:**
> "Answer these 8 questions:
> 1. Who is...
> 2. What is the JOB...
> 3. ..."

If the user gives you 3 answers in one message, treat that as a gift — extract all three, acknowledge them together, and ask only the *next* missing piece. Never say "you didn't answer question 4."

### Step 3 — Translate answers into decisions (the money table)

This is where the interview pays off. Every human answer maps to a technical consequence.
Show this table to the user in **plain language**, not in jargon:

| Human said | What it means | What you do |
|---|---|---|
| "Maybe 50 people a day, no rush" | Small, low stakes | One simple server, one database, managed hosting, deploy from main. Do not build for scale. |
| "Could go viral, 10k in a day" | Spiky, public | Stateless app, caching, rate limits, background jobs for slow work, load-tested critical path |
| "If it's down I lose money" | Revenue-critical | Staging environment, automated backups + tested restore, error tracking, uptime check, rollback plan |
| "Contracts / legal trouble" | High stakes | Audit logs, access control, data retention policy, incident runbook, stricter dependency policy |
| "People pay monthly" | Money flows | Never trust the client about price, webhooks with idempotency, dunning, receipts, refund path |
| "Health data / IDs / kids" | Sensitive | Encryption at rest, strict access logs, no PII in logs/URLs/analytics, short retention, delete pipeline |
| "This weekend" | Time-boxed | Boring stack, managed services, no custom infra, cut scope not quality |
| "$0/month" | Free tier only | Serverless/edge free tiers, watch cold starts, no always-on workers, strict usage caps |
| "I'll maintain it myself" | Non-expert owner | Fewer moving parts, everything in one repo, heavy comments, runbook, no exotic tooling |
| "Handing to a dev later" | Transfer | Tests on critical paths, docs, conventional structure, no clever abstractions |
| "It's a portfolio piece" | Public, low stakes | **Still secure it** — public means scanners find you; never expose keys, never skip auth |
| "Works on phones mostly" | Mobile-first | Design mobile-first, touch targets, offline tolerance, image weight matters |
| "Needs an app in the App Store" | Native | Adds review cycles, signing, push, OTA — weeks, not days. Say so now, not at the end. |

### Step 4 — Surface the hidden constraints

Ask explicitly (these are cheap to ask and expensive to discover late):

- "Does this need to connect to anything you already use — a calendar, a CRM, Shopify, QuickBooks, WhatsApp, an email tool?"
- "Do you need it in more than one language?"
- "Is there a legal or industry rule you have to follow?" (HIPAA, PCI, GDPR, school/child rules, government)
- "Who owns the data — you, your customers, or a third party?"
- "Is there any part of this you've already built or already paid for?"

### Step 5 — Write the brief and get a yes

Use the template at `../vibecoder-orchestrator/references/brief-template.md`.
Then close with the sentence that ends every good interview:

```
"Here's what I understood, in one page. If this is right, say 'go' and I'll build it.
If something's off, tell me which line — it's much cheaper to change this sentence
than to change the app later."
```

### Step 6 — Handle "just build it"

When the human refuses the interview (impatient, or just wants to see something):

1. Ask **three** questions only: *Who uses it? What's the one thing it must do? What happens if it breaks?*
2. State your assumptions explicitly using the defaults from the table above.
3. Build the smallest version that is **still safe** — never skip security because the human is in a hurry.
4. Put the assumptions at the top of `docs/HANDOFF.md` so they're confirmed later.

Shortcut version, one message:

```
Got it, building now. Three things I'm assuming — correct me if I'm wrong:
 • ~100 users/day, no viral spikes
 • No payments in v1
 • No sensitive data beyond email addresses
Anything else, I'll ask as I hit it.
```

## Non-negotiables

1. **Exactly 1 question per message.** Never 2, never a list. The only thing worse than 8 is 30 — the user freezes and answers nothing.
2. **Every question offers a default inline.** "Not sure? Just say 'you pick' — I'll assume X."
3. **Acknowledge before you ask the next.** One line to show you heard them, then the next question.
4. **Skip what's already answered.** If you can infer it, state your assumption and move on — don't re-ask.
5. **Never ask a question you can answer by reading the code or the repo.**
6. **Never ask about technology you're paid to decide.**
7. **Ask about consequences, not features.** "What happens if X breaks?" beats "do you need X?"
8. **Write the answers down.** An answer that lives only in chat history is an answer you'll contradict later.
9. **Don't skip DATA and STAKES.** They're the least fun and the most expensive to get wrong — but ask them gently, one at a time like the rest.
10. **Don't gold-plate a "nothing happens if it breaks" project.** Matching effort to stakes *is* seniority.
11. **Allow "skip / you pick / just build it" at any point.** Take the default, note it in the brief, continue. Never guilt-trip.

## Ask the human

Already covered — this skill *is* the question bank. Two meta-questions worth adding at the end:

- "Is there anything you're worried about that I haven't asked?"
- "Is there anything you assumed I'd just know?"

Those two catch the things you didn't know to ask about, roughly half the time.

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Requirements list of features ("I need a dashboard, and auth, and notifications") | You build a feature warehouse; nothing works end to end | Ask what the person is trying to do; derive features |
| Accepting "like Uber but for X" | You copy a $10B architecture into a 2-week project | Ask what the *one* moment matters; clone that, not the app |
| 30-question intake form | Human gives up, answers "whatever you think" | One at a time, conversational |
| Jargon in the questions ("do you need real-time sync?") | Nodding, then disappointment | "Does it matter if the other person sees the update instantly, or is a few seconds fine?" |
| Interviewing forever | Nothing ships | ~7-10 questions max, one by one, then build the smallest real version |
| No defaults offered | Blank stares | Always: "if unsure, I'll do X" |
| Asking the same questions next session | Annoyance, lost trust | Persist answers in `docs/BRIEF.md` and `VIBECODER-PROFILE.md` |
| Treating "it's just a portfolio project" as low stakes | Public = scanned by bots within hours; leaked keys = real bills | Security is stakes-independent |

## Definition of done

- [ ] I can state the user's goal in one sentence, and the human agrees with that sentence
- [ ] I know: who, the one job, normal-day scale, spike scale, stakes, money, data sensitivity, deadline, budget, platform
- [ ] Every technical decision I'm about to make traces back to a line in the brief
- [ ] `docs/BRIEF.md` exists, is one page, and has a human "yes" on it
- [ ] Out-of-scope list is written down (so scope creep is a decision, not a drift)
- [ ] Open questions have an owner and a deadline
- [ ] I have not asked the human a single question containing a word I'd have to explain

## Works with

- `vibecoder-orchestrator` — step 2 of the pipeline
- `stack-selection` — takes the brief and picks the stack from it
- `project-blueprint` — turns the brief into a repo
- `vibe-guardrails` — keeps the tone human throughout
- `saas-architecture` / `mobile-app-delivery` / `desktop-app-delivery` — load when block 7 says so
- `data-privacy-and-pii` — load whenever block 6 is not "nothing sensitive"
