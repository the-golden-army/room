# doc-templates — copy-paste templates for write-documentation

## README.md full template (hosted product + open-source variants)

```markdown
# Name — one-line value

> Plain-English summary: who it's for, what it does, why different.
![Hero](docs/screenshots/hero.png)

## Why this exists
...

## Features
- **Feature** — what + outcome (`src/file.ts:line`)

## Quick start
### For users: Go to https://… → Sign in → Do X in 30s
### For developers: `npm i pkg` + runnable snippet

## How to use
### How to [Goal 1]
1. Step → Screenshot
2. Step
**If it fails:** cause → fix

(Repeats for Goal 2, 3)

## API Reference
| Method | Path | Auth | Example |
|---|---|---|---|

## Examples
...

## FAQ / Troubleshooting

## Run locally (only if open-source — omit for hosted)
### Prerequisites: Node 20+, …
### Setup: `cp .env.example .env && npm ci && npm run dev`

## License
MIT — see LICENSE
```

## docs/USAGE.md template (extended workflows)

Split workflows out of README when >3 workflows.

## docs/API.md template

Document each endpoint with: purpose, auth, request, response, errors.

## Screenshot capture checklist

- [ ] hero.png
- [ ] workflow-1.png … workflow-3.png
- [ ] empty-state.png
- [ ] error-state.png
- Create `docs/screenshots/README.md`:
  "To replace TODOs: open app at https://… , use the workflow steps in README, Cmd+Shift+4, crop to 1280x800."

## Hosted vs Open-source header decision

Hosted SaaS:
> Use at https://your-app.com — no install. **For developers:** API docs below. **For contributors:** see CONTRIBUTING.md (if open-source fork exists).

Open-source tool:
> Install: `npm i -g your-tool` · Docs: usage below · Run locally: prerequisites + setup verified.
```

