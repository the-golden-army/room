---
name: write-documentation
description: Use when the user says "write docs", "write documentation", "write a readme", "document this project" or wants a complete project README. Produces a usage-first, detailed documentation — not just "how to run locally" but how to USE the product: overview, features, workflows, API/CLI reference, examples, FAQ and troubleshooting. Automatically adds a "Run locally / Contribute" section only when the project is an open-source tool, library, or self-hosted app.
metadata:
  category: quality
  version: 1.0.0
  value: "$100"
  group: quality
---

# write-documentation

## Promise

One request → one complete, real README your users can actually follow.

Not a placeholder with badges and `npm install`. A documentation that answers **"what does this do and how do I use it"** — with real features taken from your code, real workflows, real examples, screenshots where they matter, and a local setup section *only* when it makes sense (open-source tool, library, self-hosted product).

A non-technical stakeholder can understand the value. A developer can integrate in 10 minutes. A contributor can run it locally without guessing.

## When to use

- "write docs", "write documentation", "document this project", "write a README"
- Before publishing to GitHub, Product Hunt, npm, PyPI, or a marketplace
- After a build session — turning vibe code into something explainable
- When the current README is empty, outdated, generic, or only says "how to run"
- When a client asks "how do we use this?" and you have no link to send

## When NOT to use

- You only need inline code comments or JSDoc — use `code-review-and-audit`
- You need a launch runbook — use `launch-and-handoff` (this skill focuses on *user* docs, not launch ops)

## The 60-second version

```
1. INVENTORY   Read the codebase → map features, routes, APIs, CLIs, configs (read-only)
2. CLASSIFY    Is this a hosted product, open-source tool, library, or internal tool?
3. ASK         One human question: who uses this and what's the core action?
4. WRITE       Generate README.md → Overview → Features → Usage → Examples → FAQ → (Local setup only if open-source)
5. VERIFY      Check every command, link, env var, and screenshot path exists
```

> **If a feature is documented, it exists in code. No invented endpoints, flags, or env vars.**

## Step 1 — Inventory the project (read-only, no writing yet)

Never write docs from imagination. Read first.

```bash
# 1. Project type & stack
cat package.json 2>/dev/null | grep -E '"name"|scripts|dependencies'
cat pyproject.toml Cargo.toml go.mod 2>/dev/null | head -20
cat README.md 2>/dev/null | head -40  # what exists (often wrong)

# 2. Routes / pages / entry points
find app src pages -type f \( -name "page.tsx" -o -name "route.ts" -o -name "index.tsx" \) 2>/dev/null | sort
grep -rn "app\.(get|post|put|delete)\|router\.\|@app\." src api --include="*.ts" --include="*.js" 2>/dev/null | head -20

# 3. CLI / commands / env
grep -rn "program\.command\|yargs\|argparse\|click\." . --include="*.ts" --include="*.js" --include="*.py" 2>/dev/null | head -20
cat .env.example .env 2>/dev/null
grep -rn "process\.env\|os\.environ" src --include="*.ts" --include="*.py" 2>/dev/null | head -20

# 4. Features: what does the app actually do?
grep -rn "export.*function\|export const" src --include="*.ts" --include="*.tsx" | head -20
ls -la src/features features 2>/dev/null
```

**Write the inventory (`docs/DOCS-INVENTORY.md`):**

| Area | What exists (file:line) | Document it? |
|---|---|---|
| Auth | `src/auth/session.ts:12` — email OTP + OAuth | Yes — "Sign in" workflow |
| Billing | `src/features/billing/route.ts:8` — Stripe checkout + webhooks | Yes — pricing + subscription usage |
| CLI | none | No — not a CLI tool |
| Open-source? | `package.json` bin + MIT license | No → hosted SaaS, skip contributor build steps |

Any feature without a file:line = do not document. Any file:line without docs after = gap.

## Step 2 — Classify the project

Docs shape changes completely by type. Pick one — ask if unclear.

| Type | Primary reader | "How to use" means | Show "Run locally"? |
|---|---|---|---|
| **Hosted product** (SaaS, web app) | End user / customer | Sign up → core workflow → settings → billing | No — link to hosted URL only |
| **Open-source tool** (CLI, framework, SDK) | Developer using it | Install → configure → use API/CLI → examples | **Yes — full local setup** |
| **Library / package** (npm, PyPI) | Developer importing it | `install` → import → API reference → recipes | Yes — but minimal, focus is import+use |
| **Self-hosted** (self-serve deploy) | Operator + end user | Deploy → configure → use | Yes — Docker/env/deploy section |
| **Internal tool** | Team member | Access → workflow → permissions | No — internal URL + who to ask |

Default assumption: if `package.json` has `bin` or `pyproject.toml` has `[tool.cli]` or `LICENSE` is MIT/Apache → treat as open-source tool and include local setup. Otherwise: product usage first.

## Step 3 — Ask the human (one at a time, max 3)

Plain language, never technical lists.

1. "In one sentence, what does this do for the person using it? — e.g. 'book a yoga class in 2 taps' or 'turn any Postgres into a REST API'. Say 'you infer' and I'll draft from code and you edit."

2. "Who is reading this — a non-technical user, a developer integrating your API, or both? — 'you pick' and I'll cover both with a quick-start for each."

3. "Is this meant to be run locally by anyone (open-source / npm / self-hosted) or is it a hosted product where I should just link to the live URL? — 'you pick' and I'll decide from your LICENSE and package.json."

Never ask: "do you want a table of contents?", "what markdown flavor?", "which badge provider?" — your job.

## Step 4 — Write the documentation

### The structure (always in this order)

This is the template. Cut sections that don't apply; never add generic filler.

```markdown
# Project Name — one-line value (not "A Next.js app")

> One-paragraph plain-English summary: who it's for, what it does, why it's different.
> Badges only if real: build passing, version, license. No fake download counts.

![Hero / dashboard screenshot](docs/screenshots/hero.png)

## Why this exists
2-3 lines: the problem it solves, in the user's words.

## Features
- **Feature from code** — one line what + outcome (verifiable file:line)
- **Feature from code** — …
No invented features. Every bullet maps to inventory.

## Quick start (the 60-second "do something useful")

### For end users (hosted product)
1. Go to https://your-app.com → Sign in with …
2. Click X → do Y → see Z

### For developers (API / library / CLI)
```bash
npm i your-package
# or
curl https://api.your-app.com/v1/... -H "Authorization: Bearer $KEY"
```
Plus one runnable snippet that actually works.

## How to use — the workflows
This is the core. Document by workflow, not by page.

### Workflow 1: "Book a class" (or "Create an API key", "Invite a team member")
- What the user does, step by step (with screenshot or GIF)
- What happens behind the scenes (1 line if it helps)
- What can go wrong and what to do

Repeat for top 3-5 workflows. Each workflow = a user goal, not a route name.

## API / CLI / Config reference (if applicable)
- Endpoints: method, path, auth, body → real example request + real response
- CLI flags: `tool --help` output, not guessed
- Env vars: name, required?, example, where to get it

## Examples & recipes
Copy-paste runnable code — one per common case:
- "Send your first request"
- "Handle webhooks"
- "Self-host with Docker" (only if self-hosted/open-source)

## FAQ
Q&A from real support issues or obvious doubts — "Do I get charged?", "Can I cancel?", "Is my data private?"

## Troubleshooting
| Symptom | Cause | Fix (file:line if code-related) |
|---|---|---|

## Run locally — only if open-source / library / self-hosted
If hosted SaaS: replace this whole section with:
> **Self-host?** No — use the hosted version at https://… . Contact us for on-prem.

If open-source, include:

### Prerequisites
- Exact versions: Node 20+, Python 3.11+, Postgres 15+ (from package.json / Dockerfile)

### Setup
```bash
cp .env.example .env   # get keys from …
npm ci && npm run db:migrate && npm run dev
# App at http://localhost:3000
```
One command chain that works. Verified.

### Tests
```bash
npm test
```

## Contributing (only if open-source)
- How to open a PR, run checks, where to file issues. Link to CODE_OF_CONDUCT if exists.

## License & credits
LICENSE file name, author, acknowledgments.
```

### The writing rules

1. **Usage first, setup last.** The first thing a reader sees is what the product does and how to use it — not `git clone`. Local setup is an appendix, not the headline.
2. **Real artifacts only.** Every command was run, every env var appears in `.env.example` or code, every endpoint was grepped. Placeholder `YOUR_API_KEY` is okay once; invented `--flag` is not.
3. **One runnable example beats five paragraphs.** After reading, a developer can do the core action in <2 minutes by copy-paste.
4. **Screenshots are not optional for UI products.** At minimum: hero + one workflow. Use `docs/screenshots/*.png` and a `docs/screenshots/README.md` note "replace placeholders with real captures — see Step 5".
5. **Conditional sections are real conditions.** Don't add "Run locally" to a hosted app "just in case". Don't omit it for an npm package. Follow Step 2 classification.
6. **Plain language headers.** "How to invite your team" beats "Team Management Module". "Didn't get the email?" beats "Error 422: email_not_verified".

### Full template reference

See [`references/doc-templates.md`](references/doc-templates.md) for copy-paste templates for README, USAGE, API, and CLI docs.

## Step 5 — Generate assets & placeholders

After writing `README.md`:

```
[ ] README.md exists and follows structure above
[ ] docs/USAGE.md — extended workflows (if >3 workflows, split out from README)
[ ] docs/API.md or docs/CLI.md — only if project exposes API/CLI
[ ] docs/screenshots/ — at least 1 hero + 1 workflow, or TODO note with capture checklist
[ ] Every npm/pip/cargo command runs without error (verified)
[ ] Every link is relative or verified (no href="#" or example.com placeholders)
[ ] .env.example documents every required env var with comment on where to get it
```

**Screenshots to capture (checklist for the human):**
- `hero.png` — the main screen a new user sees
- `workflow-*.png` — each of the top 3 workflows, mid-action
- `empty-state.png` — what a new user sees before data (if applicable)
- `error-help.png` — the helpful error state (proves polish, from `global-ui-reformat`)

If you can't capture yet, leave `![TODO: capture after deploy](docs/screenshots/todo-hero.png)` with a note — never ship with broken image links.

## Step 6 — Verify (pass/fail)

Run this before calling docs "done":

```
[ ] Every feature bullet has a file:line in DOCS-INVENTORY.md
[ ] Quick-start snippet was copy-pasted and ran (or URL was visited)
[ ] No dead links: grep -r "href=\"#\"\[\|example.com\|TODO" README.md = 0 (except intentional TODO screenshots)
[ ] No invented env vars: every VAR in docs appears in .env.example or code
[ ] Open-source condition honored: hosted product has live URL, not local setup; open-source has prerequisites + setup that works
[ ] TOC matches headers (or auto-generated)
[ ] Tested with a cold reader: "can you do the core action from docs alone in 2 minutes?" — yes
```

## Non-negotiables

1. **No invention.** If you didn't read it in code, don't document it. Every feature, flag, env var, and endpoint has a file:line.
2. **Usage before setup.** README answers "how to use" first. "How to run locally" is last or omitted per Step 2. The user asked for how to *use*, not how to *clone*.
3. **One runnable path.** At least one copy-paste snippet works end-to-end without editing (except a key placeholder).
4. **No demo data / lorem.** Examples use realistic data from the domain, not `foo` / `bar` / `John Doe`. Screenshots show real UI, not empty boxes.
5. **No dead links or broken images.** Every href and ![img] resolves. TODO screenshots are marked explicitly, not silently broken.
6. **Conditional local setup.** Open-source/library/self-hosted → full local setup with verified prerequisites. Hosted/internal → live URL only. Never both as equal priority.
7. **Plain-language workflows.** Document user goals ("Invite your team") not implementation ("POST /teams/:id/members").
8. **FAQ from reality.** FAQ answers real doubts (pricing, privacy, limits, errors) — not generic "What is X?" filler.
9. **Versioned and tested.** Docs are committed with the code that ships. Re-generate on every feature — stale docs are worse than no docs.

## Ask the human

One question at a time, conversational:

1. "Who is this for — end users clicking around, developers calling your API, or both? — say 'you pick' and I'll cover both."
2. "What does someone do here that makes them say 'this was worth it' — like booking, importing, or sharing? — 'you pick' and I'll pull the top workflows from your routes."
3. "Should I include how to run this locally? If it's open-source or a library, I will — otherwise I'll link to your live URL and keep docs focused on using it. Say 'you pick'."

Never ask: "markdown or MDX?", "do you want badges?", "what emoji for headers?" — decide and ship.

## Patterns

### Product vs Tool decision tree

```
LICENSE = MIT/Apache + bin entry or pip package?
  yes → OPEN-SOURCE TOOL → Usage + Run locally + API + Examples + Contributing
  no  → Is there a live URL / hosted deploy?
          yes → HOSTED PRODUCT → Usage + Workflows + Screenshots + FAQ (link to app, no local setup)
          no  → INTERNAL / UNPUBLISHED → Usage + Access + Who to ask
```

### Workflow template (copy-paste)

```markdown
### How to [goal the user cares about]
1. Go to [where] → click [what] — you’ll see [result]
2. Fill [field] — e.g. `name@example.com`, not `foo`
3. Click [action] → [what happens: email arrives, row appears, charge succeeds]

> **Tip:** [one line that saves them a mistake]

![Screenshot](docs/screenshots/workflow-goal.png)

**If it fails:** [symptom] → [why] → [fix with link/file:line]
```

### CLI / API snippet recipe

```bash
# Good: runnable, realistic, commented
curl -X POST https://api.yourapp.com/v1/bookings \
  -H "Authorization: Bearer $YOUR_KEY" \
  -d '{"slot":"2026-10-22T10:00:00Z","class":"yoga"}'
# → {"id":"bk_123","status":"confirmed","at":"2026-10-22T10:00:00Z"}

# Bad: invented, generic, not runnable
tool --do-stuff --flag XYZ
```

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| README that is only `npm install && npm run dev` | Users know how to start, not how to use | Usage + workflows first, local setup last/conditional |
| Documenting features that don't exist | Users try, fail, lose trust | Inventory file:line first, document only what you read |
| Copy-pasting `bin` flags without running `--help` | Wrong flags, broken snippets | Run the CLI, paste real output |
| Env vars in docs not in `.env.example` | "Missing VAR" on first run | Add to `.env.example` with comment, then document |
| Lorem / `John Doe` in examples | Feels fake, vibe-coded | Real domain data: `ali@tunis.tn`, `Yoga — Mon 10am` |
| Broken screenshots `![img](undefined)` | Empty boxes, broken trust | Capture or explicit TODO with checklist |
| Hosted app with mandatory local setup section | Confuses users who just need a URL | Live URL only, "Run locally" omitted or clearly marked "For contributors" |
| Open-source tool with no local setup | Contributors can't start | Full prerequisites + verified setup commands |
| Walls of text, no workflow split | Nobody reads it | One goal per section, steps + screenshot |
| Generic FAQ "What is X? X is a tool…" | Wastes space | Real doubts: pricing, privacy, limits, common errors |

## Definition of done

- [ ] `docs/DOCS-INVENTORY.md` exists — every documented feature maps to file:line
- [ ] `README.md` follows structure: Why → Features → Quick start → Workflows (3-5) → API/CLI (if any) → Examples → FAQ → Troubleshooting → (conditional) Run locally
- [ ] Classification correct: hosted product links to live URL, open-source tool has verified local setup with prerequisites
- [ ] At least one runnable snippet (copy-paste works) and one happy-path workflow a non-technical user can follow from docs alone
- [ ] No invented features, flags, env vars, or endpoints — all verified in code
- [ ] No dead links, no broken images, no `href="#"` — placeholder screenshots marked TODO with capture list
- [ ] `.env.example` lists every required env var with where-to-get-it comment
- [ ] Cold-reader test passed: someone unfamiliar can complete the core action from docs in <2 minutes
- [ ] Docs committed alongside code — not a separate Notion that will rot

## Works with

- `project-blueprint` — where README/USAGE live in the repo layout
- `launch-and-handoff` — this skill writes *user* docs; that one writes the *owner* handoff pack and launch runbook (use both before shipping)
- `vibe-guardrails` — plain language rule (no jargon without translation)
- `ux-writing-and-onboarding` — microcopy that also appears in docs
- `api-features-in-production` — if you document an API, document rate limits and auth honestly
- `deploy-and-environments` — live URL and env source of truth for docs
