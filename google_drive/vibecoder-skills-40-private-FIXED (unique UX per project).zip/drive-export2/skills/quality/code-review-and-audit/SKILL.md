---
name: code-review-and-audit
description: Use to review any code — your own, an agent's, a contractor's, or a codebase you just inherited. Runs eight focused passes (security, correctness, data, UX states, performance, maintainability, operations, tests) in priority order, grades findings by severity, and produces a report a non-technical owner can act on. Also covers the specific failure patterns of AI-generated code and how to triage an unknown repository in an afternoon.
metadata:
  category: quality
  version: 1.0.0
  value: "$100"
  group: quality
---

# code-review-and-audit

## Promise

Nothing ships with a known critical defect, and when someone asks "is this code any good?" you answer with
a report instead of a feeling.

## When to use

- Before merging anything significant
- Before launch (a formal pass, recorded in `docs/SECURITY-AUDIT.md` and `docs/PRODUCTION-READINESS.md`)
- Reviewing AI-generated code (it compiles; it often isn't right)
- Inheriting a codebase — buy/diligence, taking over a project, onboarding
- After an incident ("how did this get through?")
- A client or investor asks for a technical opinion
- You wrote it at 1am and want a second pass

## When NOT to use

- Burning down a production incident (fix first, review after)

## The 60-second version: eight passes, in this order

```
1. UNDERSTAND      what is this code for? (read the brief, not just the diff)
2. SECURITY        ownership checks, injection, secrets, uploads, auth       ← blocks merge
3. CORRECTNESS     does it do what it claims? edge cases, races, nulls        ← blocks merge
4. DATA            schema, constraints, migrations, loss risk                 ← blocks merge
5. UX STATES       loading, empty, error, success, offline                    ← blocks launch
6. PERFORMANCE     N+1, missing indexes, bundle, unbounded queries
7. MAINTAINABILITY naming, duplication, dead code, file size, comments
8. OPERATIONS      logs, error handling, config, deployability, docs
```

Review in that order — a security hole matters more than a naming nit, and running out of time should cost
you style points, not safety.

## Step 1 — Understand before judging

```
[ ] What is this change supposed to do? (if you can't say it in one sentence, ask)
[ ] Is there a brief, ticket, or issue to compare it against?
[ ] What are the critical paths it touches?
[ ] What's the blast radius if it's wrong? (money, data, security, or cosmetic?)
[ ] Run it. Click through it. Don't review code you haven't seen working.
```

**Ten minutes running the app beats an hour reading the diff.**

## Step 2 — The security pass

Highest-yield questions, in order (full detail in `appsec-hardening`):

```
[ ] Does every resource access check that the caller owns it?  (IDOR — #1 real bug)
[ ] Is every input validated with a schema, with bounds?
[ ] Any SQL/command/template built by string concatenation with user input?
[ ] Any secret in the diff, in the build output, or in the client bundle?
[ ] Cookies: HttpOnly + Secure + SameSite? Tokens in localStorage?
[ ] CSRF protection on state-changing routes?
[ ] Uploads: type by content, size cap, renamed, outside web root?
[ ] Any user-supplied URL fetched server-side (SSRF)?
[ ] Webhook endpoints signature-verified?
[ ] Errors generic to users, detailed to logs?
[ ] New dependencies vetted? Lockfile updated?
```

Any 🔴 finding here blocks the merge. Not "note it for later" — blocks.

## Step 3 — The correctness pass

```
[ ] Does it work on the happy path? (verified, not assumed)
[ ] Null/empty/undefined: what happens with no data, no user, no permission?
[ ] Boundaries: 0 items, 1 item, 10,000 items; empty string; max-length string
[ ] Concurrency: what if two requests do this at once? (double-submit, double-charge, race)
[ ] Idempotency: is retry safe for anything irreversible?
[ ] Time: timezones, DST, dates at boundaries, expired tokens, clock skew
[ ] Failure of dependencies: what if the DB/API/email is slow or down?
[ ] Partial failure: if step 2 of 3 fails, is the state coherent?
[ ] Rollback: if this deploy is bad, does the previous version still work with the new schema?
[ ] Off-by-one, wrong variable, copy-paste errors (read slowly, they hide in plain sight)
```

## Step 4 — The data pass

```
[ ] Does the migration have a reverse, or a tested forward fix?
[ ] Is it backward compatible with the currently running code?
[ ] Are constraints in the database (NOT NULL, UNIQUE, CHECK, FK)?
[ ] Are new foreign keys indexed?
[ ] Any destructive operation (DROP, TRUNCATE, DELETE without WHERE)?
[ ] Is a backup taken before a destructive step?
[ ] Money as integer minor units? Time as UTC?
[ ] Does deletion cascade correctly, and delete files/logs/analytics too?
[ ] Any PII added to logs, URLs, or analytics?
```

## Step 5 — The UX-states pass

```
[ ] Loading state exists, in the real layout (skeleton), not a blank page?
[ ] Empty state with an explanation and an action?
[ ] Error state with a human message and a retry?
[ ] Buttons disable while submitting (no double-submit)?
[ ] Timeouts on network calls?
[ ] Input preserved after a validation error?
[ ] Success feedback proportional to the stakes?
[ ] Keyboard accessible and focus-managed? (see accessibility-and-inclusive-design)
[ ] Tested on mobile width and on a throttled connection?
```

## Step 6 — The performance pass

```
[ ] Any query in a loop (N+1)?
[ ] Every list paginated with a cap?
[ ] New columns used in WHERE/ORDER BY — indexed?
[ ] Any expensive work inline that should be a background job?
[ ] New dependencies: what do they add to the bundle?
[ ] Images sized and in a modern format?
[ ] Any cache that could serve stale/wrong data, or cache personalized content?
```

## Step 7 — The maintainability pass

```
[ ] Can you tell what this does from the names alone?
[ ] Any function over ~50 lines, or file over ~300 lines, that should be split?
[ ] Duplicated logic that should be extracted (rule of three: third time, extract)?
[ ] Dead code, commented-out code, console.log, TODO left behind?
[ ] Comments explain WHY, not WHAT?
[ ] Does it follow the project's existing conventions? (see project-blueprint)
[ ] Are there magic numbers/strings that should be named constants?
[ ] Is the error handling consistent with the rest of the codebase?
```

## Step 8 — The operations pass

```
[ ] Are failures logged with enough context to debug (IDs, not whole objects)?
[ ] Would this failure page a human, or is it silent?
[ ] Config/env: any new variable documented in .env.example and set in each environment?
[ ] Is the change observable — can you tell from logs/metrics whether it works?
[ ] Docs updated (README, RUNBOOK, BRIEF, HANDOFF) where relevant?
[ ] Is it behind a feature flag or a kill switch if it's risky?
```

## Grading findings

| Severity | Meaning | Action |
|---|---|---|
| 🔴 **Critical** | Data loss, security breach, money wrong, app unusable | Block. Fix now. |
| 🟠 **Major** | A core path is broken or will break under load/edge cases | Fix before release |
| 🟡 **Minor** | Poor experience, hard to maintain, will confuse someone | Fix soon; backlog it |
| 🔵 **Nit** | Style, naming, preference | Optional; never block on these |
| 💭 **Question** | "Why is it this way?" — often reveals a real issue | Ask, don't assume |

**How to write a finding** — specific, located, actionable:

```
🔴 IDOR — any logged-in user can cancel any booking
File: features/bookings/actions.ts:44
The handler fetches the booking by ID without checking ownership, so changing the ID in the
request cancels someone else's booking.
Fix: use `db.booking.findFirst({ where: { id, userId: user.id } })` and throw 404 when not found.
Verify: with two accounts, cancel A's booking using B's session → must return 404.
```

Never: "this could be better", "consider security", "looks good to me 👍" on a change you didn't run.

## Reviewing AI-generated code: the tells

| Tell | Check specifically for |
|---|---|
| Confident completeness | Does it handle the error path, or only the happy path? |
| Plausible-but-wrong APIs | Does that library function actually exist with that signature? Verify against the docs |
| Invented config options | Does that option do anything? (Silently ignored config is common) |
| Over-abstraction | A factory for one implementation; an interface with one class |
| Copy-pasted security | Auth check on one route and not its siblings |
| Happy-path tests only (if any) | Are there tests for failure, empty, and unauthorized? |
| Hardcoded values | Localhost URLs, test keys, placeholder emails, `TODO` |
| Extra dependencies | A package for something the language already does |
| Silent catches | `catch {}` — the failure disappears |
| Inconsistent with the rest of the repo | Different error shape, different naming, different patterns |
| Very long functions | AI output tends to be one long happy path with no early returns |
| Unbounded everything | No pagination, no size limits, no timeouts |

Verify claims: if the agent says "tests pass", make it show the output. If it says "secure", make it point
at the specific controls.

## Triaging an unknown codebase (one afternoon)

```
1. COMMIT WHAT EXISTS FIRST (a restore point before you touch anything)
2. Secret scan → rotate anything found                                    [30 min, do it first]
3. Find the entry point and the deploy path (README? CI config? Dockerfile?)
4. Map the routes/endpoints: list them all, note which are authenticated
5. Find the database: what tables, what's the data model, is there PII?
6. Count: LOC, dependencies, test files, TODOs
7. Run the 10-minute security self-test (appsec-hardening reference)
8. Run the app and walk the critical paths
9. Write the report: what works, what's dangerous, what's missing, what to fix first
10. Estimate fixes in severity order — the human decides how far to go
```

## The report

```markdown
# Code review — 2026-10-20 — commit a1b2c3d — reviewer: <name>

## Summary
Scope: booking flow + payments (12 files, ~900 lines).
Method: read the diff, ran the app locally, exercised the critical paths, ran the security self-test.

Verdict: REQUEST CHANGES (3 critical, 5 major)

## Critical (blocks merge)
1. 🔴 IDOR — `actions.ts:44` … (file, impact, fix, how to verify)
2. 🔴 Stripe webhook not verified — `route.ts:12` …
3. 🔴 API key committed in `lib/email.ts:3` and present in git history …

## Major (fix before release)
4. 🟠 No loading/error state on the booking list
5. 🟠 `limit` unbounded on `/api/bookings` — dumps the table
…

## Minor / Nits
…

## What's good
- Clean schema with real constraints
- Error contract is consistent
- Tests cover the payment path

## Not reviewed
- Mobile app, infrastructure, third-party integrations

## Recommended order
1. Rotate the leaked key (today)
2. Fix the two critical security items
3. Add the missing UI states
4. Then the rest
```

"Not reviewed" matters. Never let a reader assume coverage you didn't do.

## Non-negotiables

1. **Run the code before reviewing it.**
2. **Security before style.** Always.
3. **Every finding is specific**: file, line, impact, fix, verification.
4. **Critical findings block the merge**, not "note for later".
5. **Verify claims** — "tests pass" means you saw the output.
6. **State what you didn't review.**
7. **Praise what's good** — reviews that only criticize stop getting read.
8. **Nits are labelled nits** and never block.
9. **A review ends with a verdict**: approve, request changes, or reject.
10. **Review the diff, not the person.** Blameless, always.

## Ask the human

1. "What's this code supposed to do? If I get it wrong, my review is worthless." *(always ask first)*
2. "Is there any part you're unsure about?" *(review that hardest)*
3. "How much risk can you take here — is this going out today, or do we have time to fix things properly?"
4. "Do you want me to just find the problems, or to fix them too?"
5. "Is there a deadline or a demo this has to make?" *(changes what's blocking)*

Never ask: "do you want a nit-level review?", "should I check performance too?" — just do all eight passes
and report.

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| "LGTM" without running it | Bugs ship | Run it, always |
| Style nits on a security hole | Wrong priorities | Ordered passes |
| "This is bad" with no location | Unactionable | File, line, fix, verify |
| Reviewing 3000 lines at once | You'll miss everything | Review in chunks under ~400 lines |
| Assuming it works because it compiles | It compiles; it isn't right | Exercise the paths |
| Rubber-stamping AI output | The AI's confidence is not evidence | Verify claims |
| Only criticizing | The author stops listening | Note what's good |
| Endless debate on nits | Wasted time | Label them; move on |
| No verdict | Nothing changes | Approve / request changes / reject |
| Reviewing without the brief | You can't tell correct from incorrect | Ask what it's for |

## Definition of done

- [ ] I ran the code and exercised the critical paths (not just read it)
- [ ] All eight passes completed, or the skipped ones listed
- [ ] Findings graded, located, and actionable, with a verification step for each critical
- [ ] Every 🔴 blocks the merge; every 🟠 has an owner and a date
- [ ] The report says what was reviewed and what wasn't
- [ ] The report ends with a verdict and a recommended order of work
- [ ] Nits are labelled and non-blocking
- [ ] The report is readable by a non-technical owner (plain language in the summary)

## Works with

- **Every other skill** — this is how you check the work
- `appsec-hardening` — pass 2 in depth
- `production-readiness` — the launch version of this review
- `refactor-and-maintainability` — what to do with the findings
- `testing-and-verification` — the tests that would have caught it
- `vibe-guardrails` — how to report findings to a non-engineer
