---
name: refactor-and-maintainability
description: Use when a codebase has become hard to change, when you're tempted to rewrite it, or before/while cleaning up AI-generated code. Covers when NOT to refactor, the safe refactor loop (characterization tests, small reversible steps, one commit each), breaking dependencies with seams, the debt budget, the rewrite-vs-fix test, the strangler pattern for big changes, and the structural habits that keep a vibe-coded project editable six months later.
metadata:
  category: quality
  version: 1.0.0
  value: "$100"
  group: quality
---

# refactor-and-maintainability

## Promise

The code stays changeable. You can add a feature in month six without being afraid of it — and you know
when *not* to touch anything at all.

## When to use

- "This file is too big" / "I'm scared to change this" / "I don't know what this does"
- Every change takes three times longer than it should
- Before adding a feature to messy code (clean the path you're about to walk)
- Tempted to rewrite everything in a new framework
- Onboarding someone else to the codebase
- After `code-review-and-audit` produced a list

## When NOT to use

- Code you don't need to change. Leave it alone. Working code that's ugly is still working code.
- Mid-incident.
- The week before a launch (unless it's a bug fix).

## The 60-second version

```
1. DON'T REFACTOR WHAT YOU DON'T NEED TO CHANGE. Clean the path you're walking, not the whole garden.
2. TESTS FIRST. If there are none, write characterization tests that lock in current behavior
   (including the weird parts) — that's what makes refactoring safe.
3. SMALL STEPS. One behavior-preserving change, one commit, tests green. Every step is revertible.
4. NEVER mix "improve the structure" with "change the behavior" in the same commit.
   You'll never know which one broke it.
5. EXTRACT, DON'T REWRITE. Move code, rename things, pull out functions. Don't retype from scratch.
6. REFACTOR AT A SEAM — a clear boundary (module, function, API) you can test through.
7. DELETE DEAD CODE. It's the cheapest improvement there is.
8. STOP WHEN IT'S GOOD ENOUGH. Perfect is the enemy of shipped.
```

## Step 1 — The decision: should you touch it at all?

```
Refactor when at least one is true:
[ ] You're about to change this code anyway, and it's hard to change safely
[ ] There's a bug here, and you can't find it because the code is unclear
[ ] It's actively costing time (every change here takes hours, not minutes)
[ ] Someone new needs to work in here
[ ] It's duplicated in 3+ places and the copies are drifting apart

Don't refactor when:
[ ] It works and nobody needs to change it
[ ] You're avoiding the feature you should be building (refactoring as procrastination)
[ ] There are no tests and no way to verify behavior (fix that first, or don't start)
[ ] A launch is imminent
[ ] You can't say what "better" would look like
```

The most senior thing you can do is leave working code alone.

## Step 2 — Safety first: characterization tests

Before changing code with no tests, write tests that describe **what it currently does** — bugs included.
They're not a judgment about correctness; they're a safety net.

```ts
// tests/characterization/pricing.test.ts
it("current behavior: weekend bookings get a 10% surcharge AND round up", () => {
  // This looks wrong (rounding up after the surcharge) but it's what production does today.
  expect(priceFor({ day: "saturday", base: 100 })).toBe(110);
});
it("current behavior: an unknown plan falls back to the free tier", () => {
  expect(priceFor({ plan: "nonsense" })).toBe(0);   // plan is not validated upstream, today
});
```

Then:
1. Run them — they pass (they describe today's behavior)
2. Refactor
3. They still pass → you changed structure, not behavior ✅
4. Only *after* that, decide whether to fix the bug — as a separate, deliberate commit with a new test

## Step 3 — The safe refactor loop

```
1. PICK ONE THING.           "extract the price calculation", not "clean up billing"
2. WRITE THE TEST (or run the existing ones)
3. MAKE THE SMALLEST CHANGE that preserves behavior
4. RUN THE TESTS.            Green? Commit. Red? Revert and try again smaller.
5. REPEAT.
6. STOP when it's clear enough to do the thing you actually came to do.
```

Commit messages tell the story: `refactor: extract calculatePrice (no behavior change)`,
`refactor: rename Booking.order to Booking.booking (no behavior change)`. The "(no behavior change)" line
is a promise to your future self and to reviewers.

## Step 4 — Techniques (smallest to largest)

| Technique | Use when | Risk |
|---|---|---|
| **Rename** | A name lies about what it does | Very low (IDE does it) |
| **Extract function** | A block does one clear thing; a function is > 50 lines | Low |
| **Inline** | An abstraction adds nothing | Low |
| **Move file/method** | Code lives in the wrong place | Low |
| **Replace magic values with constants** | The same number/string appears in 3+ places | Low |
| **Guard clauses / early returns** | Deeply nested ifs | Low |
| **Extract module / split file** | A file is > 300-500 lines or mixes concerns | Medium |
| **Introduce an interface / seam** | You need to test around a hard dependency (DB, clock, network) | Medium |
| **Strangler** | Replacing a big subsystem | Medium — but incremental |
| **Rewrite from scratch** | Almost never | Very high |

## Step 5 — Breaking dependencies (seams)

You can't test (or change) code that reaches out to the world directly. Put a seam at the boundary.

```ts
// Before: untestable, unchangeable
export async function createBooking(data) {
  const now = new Date();
  await db.booking.create({ ...data, createdAt: now });
  await sendEmail(data.email, "booked");            // network
  await stripe.charges.create({ amount: data.amount });  // money
}

// After: seams at the boundaries
export async function createBooking(data, deps = { db, email, payments, clock }) {
  const { db, email, payments, clock } = deps;
  const booking = await db.booking.create({ ...data, createdAt: clock.now() });
  await email.send(data.email, "booked");
  await payments.charge(data.amount);
  return booking;
}

// Now the test is trivial:
await createBooking(data, { db: fakeDb, email: fakeEmail, payments: fakePayments, clock: { now: () => FIXED } });
```

Seams to introduce (they're all small and all worth it): a clock, an ID generator, a random source, the
database, outbound HTTP, the file system, and email/payments.

## Step 6 — What "maintainable" means concretely

| Property | Target |
|---|---|
| Function length | Under ~50 lines; if you can't see it all on one screen, split it |
| File length | Under ~300 lines (components can be shorter); over 500 is a warning |
| Function arguments | 3 or fewer; more → pass an object |
| Nesting | 3 levels max; use early returns |
| Cyclomatic complexity | If you can't count the paths, it's too complex |
| Duplication | The rule of three: the third copy gets extracted |
| Dependencies between modules | One direction: UI → features → lib → data |
| Names | A stranger could guess what it does |
| Comments | Explain *why*, never *what* |
| Dead code | Zero. Delete it; git remembers. |

**Maintainability is mostly naming and boundaries.** Code with good names and clear boundaries is
maintainable even when it's not elegant.

## Step 7 — The debt budget

Technical debt is not a moral failure, it's a loan. Manage it:

```
[ ] Every sprint/week, spend ~20% of the time on the code you're already touching
[ ] When you touch a messy file, leave it slightly better than you found it (boy scout rule)
[ ] Keep a visible debt list (docs/DEBT.md): what's ugly, why, what it costs, what fixing would take
[ ] Pay down debt that's on a path you're actively changing
[ ] Never start a debt payment you can't finish — half-refactored is worse than unrefactored
[ ] A debt entry with no cost is a preference, not debt
```

```markdown
# docs/DEBT.md
| Area | Debt | Cost today | Fix estimate | Priority |
|---|---|---|---|---|
| features/billing | Price logic duplicated in 4 places | Every pricing change risks a mismatch | 3h | High |
| lib/pdf | 800-line file, no tests | Fear of touching; invoices are money | 1 day | Medium |
| components | Three button variants | Inconsistent UI | 2h | Low |
```

## Step 8 — Rewrite or refactor?

Only rewrite if **at least two** are true:

- [ ] The current stack blocks a requirement you have **now**, not one you might have
- [ ] Adding a normal feature takes 3x longer than it should, and you can name why
- [ ] You can't hire or get help for the current stack
- [ ] Security or compliance can't be met on it
- [ ] It's small enough to rebuild in under 3 weeks, **and** you have those weeks

Otherwise, use the **strangler pattern**:

```
1. Put a facade/route in front of the old thing
2. Build the new thing alongside it
3. Route one path/endpoint/percentage of traffic to the new one
4. Verify (logs, errors, metrics) — if it's worse, route back
5. Repeat until the old one has no traffic
6. Delete the old one
```

Big-bang rewrites of working software are how solo projects die. Strangling lets you ship value the whole
time and stop at any point.

## Step 9 — Cleanup checklist for AI-generated code

```
[ ] Delete: unused files, unused exports, commented-out code, console.log, TODO/FIXME
[ ] Delete: unused dependencies (npx depcheck)
[ ] Merge: duplicate components, duplicate helpers, three copies of the same fetch wrapper
[ ] Extract: repeated logic into one function; repeated UI into one component
[ ] Split: files over ~500 lines; functions over ~80 lines
[ ] Name: anything vague (handleClick, data, thing, temp, utils, manager, helper)
[ ] Centralize: config, API clients, error handling, logging — one way to do each
[ ] Add: the missing states (loading/empty/error) in every component that fetches
[ ] Add: tests on the critical paths before any further restructuring
[ ] Document: README, BRIEF, DECISIONS, HANDOFF so the next session starts informed
```

Do this in small commits, running the app between each one. Never one "cleanup" commit with 60 files.

## Non-negotiables

1. **Never change structure and behavior in the same commit.**
2. **Tests (or characterization tests) before refactoring untested code.**
3. **Every step is small and revertible**, with a commit.
4. **Don't refactor what you don't need to change.**
5. **Delete dead code** rather than commenting it out.
6. **Extract and move; don't retype.**
7. **Stop when it's good enough** — you're shipping a product, not entering a competition.
8. **A big rewrite needs the two-out-of-five test** — otherwise strangle it.
9. **Debt is tracked, not hidden.**
10. **Half-finished refactoring is worse than none** — finish or revert.

## Ask the human

1. "What are you trying to change in here? Let's clean only the path to that."
2. "Is this code something you touch often, or has it been fine for months?" *(stable code stays)*
3. "How much time do you want me to spend on cleanup versus new features?" *(suggest 80/20)*
4. "Has anything here broken before? That's where the risk is."
5. "Are you thinking about rewriting the whole thing? Let's talk about what's actually slow first."
6. "Will someone else work on this code? That changes how much polish is worth it."

Never ask: "should we extract an interface here?", "what's your complexity budget?", "do you want to
strangle or big-bang?"

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Refactoring and changing behavior together | You can't tell which broke it | Separate commits |
| Refactoring without tests | Silent breakage | Characterization tests first |
| One giant "cleanup" PR | Unreviewable, unrevertable | Small steps, one commit each |
| Rewriting from scratch out of disgust | Months lost, new bugs | Strangler, or targeted extraction |
| Cleaning code nobody touches | Wasted time, added risk | Clean the path you walk |
| Abstraction for one implementation | Complexity with no payoff | Wait for the second use |
| Half-finished refactor left in main | Two ways to do everything | Finish or revert |
| Deleting code you don't understand | You'll delete a required edge case | Test first, then delete |
| Gold-plating | Never ships | Stop at "clear enough" |
| Moving files and changing logic simultaneously | Impossible to review | Move, commit, then change |
| Ignoring the debt list | It becomes a rewrite | 20% per cycle |

## Definition of done

- [ ] The reason for refactoring is written down, and it's not "it's ugly"
- [ ] Tests exist for the behavior being preserved (characterization tests count)
- [ ] Changes are small commits, each behavior-preserving, each green
- [ ] No mixing of structural and behavioral changes
- [ ] Dead code deleted; unused dependencies removed
- [ ] Names are honest; files under ~300 lines; functions under ~50
- [ ] The app was run and the critical paths verified after the refactor
- [ ] `docs/DEBT.md` updated with what's left and why
- [ ] Nothing half-finished left in main
- [ ] The original feature now takes less time to change (or the reason it doesn't is documented)

## Works with

- `code-review-and-audit` — produces the list
- `testing-and-verification` — the safety net
- `project-blueprint` — the structure you're refactoring toward
- `production-readiness` — don't refactor the week of launch
- `stack-selection` — the rewrite question
- `vibe-guardrails` — explaining the tradeoff to a non-engineer
