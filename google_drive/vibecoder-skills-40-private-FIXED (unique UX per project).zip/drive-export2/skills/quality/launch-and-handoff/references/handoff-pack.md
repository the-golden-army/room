# HANDOFF PACK — copy-paste template

Written for the owner, who may not write code. Plain language. Screenshots where they help.
Save as `docs/HANDOFF-PACK.md`.

---

```markdown
# [Product name] — Owner's handbook
Last updated: 2026-10-20 · Built by: [name/company] · Contact: [email]

## 1. What this is
[Two or three sentences a non-technical person could repeat to a friend.
Who it's for, what they can do with it, and what problem it removes.]

## 2. How to use it (the five things you'll do)
| I want to… | Here's how |
|---|---|
| See who signed up | Log in → /admin → Users |
| Add an admin | /admin → Users → Invite → choose "admin" |
| Give someone a refund | /admin → Payments → find the payment → Refund |
| Send a message to all users | /admin → Announcements |
| See today's numbers | /admin → Dashboard |

## 3. Accounts and access
| What | Where to log in | Username | Password | Who has access | MFA |
|---|---|---|---|---|---|
| Domain | [registrar] | [email] | in password manager | you | Yes |
| Hosting | [host] | [email] | in password manager | you, [dev] | Yes |
| Database | [host] | — | in password manager | [dev] | Yes |
| Payments (Stripe) | stripe.com | [email] | in password manager | you | Yes |
| Email (Resend) | resend.com | [email] | in password manager | you, [dev] | Yes |
| Error tracking (Sentry) | sentry.io | [email] | in password manager | you, [dev] | Yes |
| Source code | github.com/[org]/[repo] | — | — | you, [dev] | Yes |
| Admin login for the app | [url]/admin | [email] | in password manager | you | Yes |

All passwords live in [password manager]. Nobody shares a login — one person, one account.
Domain renews on [date]. Hosting bills on the [1st].

## 4. How to put a change live (and undo it)
**Deploy:** push to `main`. The robot tests and deploys it. Watch [url]/admin for 5 minutes.
**Undo:** [the exact command], or in the host's dashboard: Deployments → previous → "Promote to production".
**Never:** edit files on the server, or push straight to main without the checks passing.

## 5. What it costs
| Item | Cost | Notes |
|---|---|---|
| Hosting | $20/mo | Scales with traffic; cap set at $100 |
| Database | $19/mo | Includes backups |
| Email | $0-20/mo | Free under 3,000 emails |
| Error tracking | $0 | Free tier |
| Domain | $12/yr | Renews [date] |
| AI features | ~$15/mo | Capped at $50/mo |
| **Total** | **~$55/mo** | See the bill: [where] |
Alerts are set at 50%, 80% and 100% of $100/mo, and they go to [email].

## 6. Where your data lives
- **Database:** Postgres at [host], in [region]. Backed up daily, kept 30 days.
- **Uploaded files:** [storage], private, served via temporary links.
- **Emails sent:** [provider].
- **Payments:** Stripe holds the card details — we never see or store card numbers.
- **Get a full copy:** /admin → Export (or ask [dev] to run the export job).
- **Delete a user's data completely:** /admin → Users → Delete (removes their account, files,
  and email records; invoices are kept for [7] years because tax law requires it).

## 7. If something breaks
| What you see | First thing to check | Then |
|---|---|---|
| The site won't load | [status page url] | If it's red: [host status page]. Then message [dev]. |
| People can't log in | /admin → Errors (last 15 min) | If there's an error spike, roll back the last deploy. |
| Payments aren't working | Stripe dashboard → Developers → Webhooks → recent deliveries | If deliveries are failing, message [dev] with the event ID. |
| Emails aren't arriving | [provider] dashboard → Logs | Check whether it's one person (typo/spam) or everyone (configuration). |
| It's slow | /admin → Dashboard → response times | If it's been slow since a deploy, roll back. |

**Emergency stop:** set `MAINTENANCE_MODE=true` in the host dashboard → everyone sees a
"back soon" page. This is always safe and always reversible.

## 8. Who to call
1. **[Dev name]** — [email] / [phone] — builds and fixes it. [Response time / availability]
2. **Hosting support** — [url] — [plan level, response time]
3. **Stripe support** — [url] — payments
4. **Domain registrar** — [url] — domain and DNS

## 9. Known issues (not finished, on purpose)
| Issue | Impact | What fixing it takes |
|---|---|---|
| Bulk import isn't built yet | Users add things one at a time | ~1 day |
| Only English | Non-English users see English | ~2 days per language |
| No mobile app | Mobile users use the website | Weeks — decide if it's worth it |
| Reports are slow with >10k rows | Get slow for very large accounts | ~2 days to make it a background job |

## 10. Decisions I made without asking (please review)
- Assumed a maximum of 200 users/day; the app handles more but it hasn't been tested beyond that.
- Assumed payments are in USD only.
- Assumed account deletion should delete everything except invoices.
- Assumed you don't need multiple languages at launch.

## 11. Words you'll see
| Word | What it means here |
|---|---|
| Deploy | Put a new version live |
| Roll back | Put the previous version back (undo) |
| Staging | A private copy of the app for testing |
| Database | Where all the information is stored |
| Backup | A copy of the database you can restore from |
| Migration | A script that reshapes the database without losing data |
| Webhook | Another service telling our app something happened (like a payment) |
| API | How our app talks to other services |
| Log | The diary the app keeps of what it did |
| Cache | Remembering an answer for a short time instead of recalculating it |

## 12. The next 30 days
1. **Week 1:** watch for errors, reply to every user, fix the top 3 issues.
2. **Week 2:** improve the step where people get stuck (currently: [step]).
3. **Week 3:** [feature] — the most-requested thing from the first users.
4. **Week 4:** review costs, review the backup restore, plan the next month.

## Appendix: how to run it locally (for a developer)
cp .env.example .env && npm ci && npm run db:migrate && npm run dev
Node 20+, Postgres 15+. See README.md and docs/RUNBOOK.md.
```
