---
name: launch-and-handoff
description: Use in the days before going live and whenever a project changes hands — to a client, a contractor, another agent, or just future-you. Covers the launch ladder (soft launch → limited → open), the launch-day runbook hour by hour, announcement copy, the handoff pack a non-technical owner needs (access, accounts, costs, runbook, known issues), how to onboard another developer or agent, and the 30-day post-launch plan.
metadata:
  category: quality
  version: 1.0.0
  value: "$100"
  group: quality
---

# launch-and-handoff

## Promise

Launch day is boring and recoverable, and whoever owns this next — a client, a contractor, or you in six
months — can run it without a phone call.

## When to use

- A week before any launch (including a "small" one to 20 people)
- Handing a project to a client or another developer
- Finishing an engagement with an agency or a contractor
- Starting work on someone else's project
- Ending a long build session (the handoff note is the small daily version of this)
- When the human says "I think we're ready"

## When NOT to use

- Mid-development (use `docs/HANDOFF.md` after each session instead)

## The 60-second version: the launch ladder

```
1. SOFT LAUNCH    you + 3-10 people you can text. Goal: find the embarrassing bugs.
2. LIMITED        ~50-200 real users, invited. Goal: find the scaling and confusion bugs.
3. OPEN           anyone can sign up. Goal: growth.
4. PROMOTE        marketing, ads, press, Product Hunt. Last, not first.
```

Skipping rungs is the most common launch mistake. Every rung finds a different class of problem, and the
cost of the problem grows by ~10x at each rung.

Plus two rules: **launch on a Tuesday or Wednesday morning**, and **never launch and then leave the house.**

## Step 1 — The launch runbook

### T-7 days

```
[ ] production-readiness gate run; zero 🔴 open; 🟠 items have owners and dates
[ ] The certificate dated and signed off by the human
[ ] Backups verified; a restore tested within the last quarter
[ ] Rollback rehearsed on staging
[ ] Error tracking + uptime + payment alerts all proven to fire
[ ] The critical paths tested on a real phone and a real desktop, in a private window
[ ] Support channel ready: an email address a human reads, with an auto-reply setting expectations
[ ] Launch announcement written (email, post, or message) — drafted now, sent later
[ ] Known issues list written (you will have some; say them out loud)
[ ] Costs known, caps set, billing alerts on
[ ] Someone else knows you're launching and can be reached
```

### T-1 day

```
[ ] Deploy the release candidate to production, but keep it dark (flag off, or not announced)
[ ] Run the smoke test against production
[ ] Verify: signup works, email arrives (check spam), payment works with a real card
[ ] Check the error tracker is clean for 30 minutes
[ ] Write down the rollback command and keep it visible
[ ] Tell the first users what time it goes live and what to do if something looks wrong
[ ] Sleep
```

### T-0 (launch morning)

```
08:30  Final check: is everything green? errors clean? uptime green?
09:00  DEPLOY (or flip the flag on)
09:05  SMOKE TEST: signup → core action → payment → receipt. On a phone. In a private window.
09:15  WATCH: error tracker, logs, uptime, signups. Twenty quiet minutes.
09:45  ANNOUNCE to the first, smallest audience
10:00  Reply to every message personally. You are support today.
12:00  Check-in: errors, signups, payments, support inbox. Any pattern?
16:00  Check-in again. Fix the top issue.
EOD    Write down what broke and what people were confused by.
```

### T+1 to T+30

```
Day 2    Fix the top 3 issues from day one. Reply to everyone.
Day 3    Review the funnel: where did people drop? Fix that one step.
Day 7    Re-run the quick gate. Update docs/HANDOFF.md with what you learned.
Day 14   Second wave of invites (if limited). Review support themes.
Day 30   Retrospective: what did we build vs what people used? What's the next 30 days?
```

## Step 2 — Announcement copy

Keep it short, concrete, and human. People skim.

```
Subject: It's live — [product] is open

Hi [name],

[Product] is live. You can [the core action] in about [N] minutes.

Start here: [URL]

Two things worth knowing:
 • [The one-line value proposition, in their words]
 • [The honest limitation, if there is one]

If something looks broken, reply to this email — I'm watching it today and I'll
fix it fast.

Thanks for being early.
[Your name]
```

Rules: one link (the one that matters), one action, an honest note about what's not done yet, and a real
route to a human. Never "we're thrilled to announce" with nothing behind it.

## Step 3 — The handoff pack (what a non-technical owner needs)

`docs/HANDOFF-PACK.md` — written in plain language, no unexplained jargon. Full template in
[`references/handoff-pack.md`](references/handoff-pack.md). The twelve things it must contain:

```
1. WHAT IT IS             one paragraph a non-technical person could repeat to a friend
2. HOW TO USE IT          the 5 things an owner does day to day (with screenshots)
3. ACCESS                 every account, where the login lives, who has it, MFA status
4. HOW TO DEPLOY          the exact command, and how to roll back
5. WHAT IT COSTS          monthly, what's fixed, what scales, and where to see the bill
6. WHERE DATA LIVES       database, files, backups, and how to get a copy out
7. WHAT BREAKS AND WHAT TO DO  the top 5 failure modes with the first thing to check
8. WHO TO CALL            you, the host, the payment provider, the domain registrar
9. KNOWN ISSUES           what's not finished, and what it would take to finish it
10. WHAT I ASSUMED        decisions made without confirmation — the owner should review these
11. GLOSSARY              the 15 terms they'll encounter, in plain language
12. THE NEXT 30 DAYS      the recommended order of work
```

The test: hand the pack to someone who has never seen the project and ask them to deploy a change. If they
can't, the pack isn't done.

## Step 4 — Handing to another developer or agent

A technical handoff needs context, not just code:

```markdown
# HANDOFF (engineering) — 2026-10-20

## Read these first, in order
1. docs/BRIEF.md          what this is and who it's for
2. docs/DECISIONS.md      why the stack is what it is
3. docs/SCHEMA.md         the data
4. docs/RUNBOOK.md        how to run, deploy, and recover
5. docs/HANDOFF.md        what happened most recently

## How to run it
cp .env.example .env   # get keys from <where>
npm ci && npm run db:migrate && npm run dev
Requires Node 20+, Postgres 15+.

## Architecture in ten lines
Next.js app → route handlers → Prisma → Postgres. Auth: sessions in HttpOnly
cookies. Payments: Stripe, webhooks at /api/webhooks/stripe. Background jobs:
a `jobs` table + one worker (npm run worker). Deploy: push to main → CI.

## Where the bodies are buried
- `lib/legacy/` is the old pricing path; only `calculateLegacy()` is still called.
- The two session systems: `src/auth/session.ts` is live, `middleware.ts` is dead. Don't remove it yet.
- `jobs` retries are at-least-once; every handler must be idempotent.

## What I'd do next
1. Delete the legacy pricing path once the last invoice from before 2026-09 clears.
2. Add tests to `features/billing/` — it's the riskiest untested area.
3. The PDF export is slow; it should be a background job.

## Don't
- Don't touch the migration in db/migrations/2026_09_* — it's applied in prod and not reversible.
- Don't deploy on Fridays (learned the hard way, see 2026-09-12 in HANDOFF.md).
```

"Where the bodies are buried" is the most valuable section in any handoff. Write it honestly.

## Step 5 — The daily handoff note (the small version)

Every session, even a short one (see `vibe-guardrails`). It's the same discipline, every day, and it's what
makes a six-month project survivable:

```
WHAT CHANGED · WHAT I ASSUMED · WHAT I DIDN'T DO · WHAT TO CHECK · NEXT
```

## Step 6 — Measuring whether it worked

Track four numbers for the first 30 days:

| Metric | Question | Where |
|---|---|---|
| **Signups** | Are people interested? | Your DB |
| **Activation** | Did they do the core action once? | Your DB / analytics |
| **Retention (week 1)** | Did they come back? | Analytics |
| **Support themes** | What confuses people most? | Your inbox |

Then: the gap between signups and activation is where the product is weakest. Fix that before you spend
anything on getting more traffic.

Also collect, qualitatively: the three nicest things people said (use them as testimonials) and the three
most common complaints (fix those first).

## Non-negotiables

1. **Launch through the ladder.** Soft → limited → open → promote.
2. **Launch mid-week, in the morning, and stay available all day.**
3. **The smoke test runs on production immediately after deploy.**
4. **Rollback is ready and rehearsed** before the deploy.
5. **Support is a real human channel** on launch day.
6. **The handoff pack is written for a non-technical owner** and tested on one.
7. **Access, accounts, and costs are documented** — including who owns the domain.
8. **Known issues are written down**, not glossed over.
9. **Assumptions are listed** for the owner to confirm.
10. **Every handoff ends with "the next 30 days"** in priority order.

## Ask the human

1. "Who are the first people who should use this? Can you text them if something's wrong?"
2. "What would make this launch a success for you — 10 users, 100, or your first paying customer?"
3. "Are you going to be around on launch day to answer messages? If not, who is?"
4. "Will you maintain this yourself, or will someone else? What do they need to know?"
5. "Is there anything you're embarrassed isn't finished? Let's write it down so it's a decision, not a surprise."
6. "Do you want me to keep working on this after launch, or is this the handover point?"
7. "How do people contact you when something's wrong — and do you want that on the site?"

Never ask: "do you want a runbook?", "should we do a phased rollout?", "what's your rollback strategy?"

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Launching to everyone at once | Every bug hits at once | The ladder |
| Launching on Friday evening | Ruined weekend, slow response | Tuesday morning |
| Launching and going out | Nobody watching when it breaks | Stay at the desk for the day |
| No smoke test after deploy | You announce a broken app | Test, then announce |
| No rollback plan | A bad deploy becomes an outage | Rehearsed rollback |
| "It's done" with no handoff | The owner is helpless | The twelve-item pack |
| Handoff docs written for engineers only | The owner can't use them | Plain language + screenshots |
| Hiding known issues | Trust destroyed when they surface | List them |
| No support channel | Angry users with nowhere to go | A monitored inbox |
| Credentials in someone's head (or nowhere) | Lockout risk | Documented access list with MFA |
| Launching without telling anyone | Nobody comes | Announce, personally, to real humans |
| Ending the engagement with no "what's next" | The project stalls | A prioritized 30-day plan |

## Definition of done

- [ ] `production-readiness` gate passed, with the certificate signed by the human
- [ ] Launch runbook written (T-7 → T+30) and followed
- [ ] Smoke test run on production immediately after deploy, results recorded
- [ ] Rollback rehearsed and the command visible during the deploy
- [ ] Support channel live and monitored on launch day
- [ ] Announcement sent to the smallest audience first
- [ ] `docs/HANDOFF-PACK.md` complete, in plain language, **tested on someone unfamiliar with the project**
- [ ] Access list: every account, where it lives, who has it, MFA on
- [ ] Known issues and assumptions written down
- [ ] A prioritized 30-day plan exists
- [ ] Four numbers being tracked: signups, activation, retention, support themes

## Works with

- **Everything** — this is the exit door of the whole pack
- `production-readiness` — the gate before the launch
- `reliability-and-incidents` — if launch day goes wrong
- `vibe-guardrails` — the daily handoff note
- `project-blueprint` — where the docs live
- `code-review-and-audit` — the final review pass
