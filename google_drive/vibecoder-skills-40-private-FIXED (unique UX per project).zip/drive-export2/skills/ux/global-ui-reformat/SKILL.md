---
name: global-ui-reformat
description: Use when you paste this skill into ANY codebase to globally reformat the entire UI to production-grade in one pass. Performs a full inventory + upgrade: installs dark mode with system preference and no FOUC, adds skeletons for every loading state, replaces raw server errors with human messages + retry, and guides first-time users with animated onboarding modals and interactive coach marks. Use when the app looks vibe-coded, half-built, inconsistent, or you say "polish everything" or "make it feel like Linear/Stripe".
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# global-ui-reformat

## Promise

One paste. Your entire app goes from demo to production.

You drop this skill into any repo — Next.js, Vite, Remix, plain React — and your AI agent inventories every page, then upgrades the whole UI in one consistent pass:
dark mode that respects the system and never flashes, skeletons where spinners used to be, errors that feel helpful not scary, and onboarding that *shows* users what to do with gentle animations instead of dumping a manual.

No half-pages. No forgotten dark mode. No `500 Internal Server Error` in the face of your user. Every screen feels intentional.

> **Standalone by design:** This skill carries everything it needs. No other skill required. Paste `skills/ux/global-ui-reformat/SKILL.md` into any project — `docs/`, `.cursor/skills/`, `~/.claude/skills/` — and it runs. It invents nothing, it checks existence before writing, and it leaves a single atomic rollback commit.

## When to use

- You just vibe-coded 5 pages and they all look different — sizes, colors, states, errors all inconsistent
- Dark mode is missing, broken, or flashes white on reload
- Pages show spinners, blank screens, or `undefined` while loading
- Errors show `500` / `TypeError: fetch failed` / stack traces to users
- First-time users land and have no idea what to do — no tour, no hints, no empty-state guidance
- Before client demo, investor demo, Product Hunt, or App Store screenshots
- After inheriting any codebase — run inventory first, then polish globally
- You say: "reformat everything", "polish the whole app", "make it production-ready", "add dark mode + skeletons + onboarding"

## When NOT to use

- Pure backend service with no pages to render (nothing to reformat)
- You only want one page touched — use `ux-upgrade-audit` for scoped audits instead (this skill is intentionally global)
- Email templates — dark mode and onboarding work differently there

## The 60-second version

```
1. INVENTORY    Map every route + component in the codebase (read-only, no writes)
2. TOKENS       Install design tokens + dark mode (system + toggle + no FOUC)
3. SKELETONS    Replace every loading blank/spinner with in-layout skeletons
4. ERRORS       Replace raw server errors with human messages + Retry + safe logging (correlation id)
5. ONBOARDING   Add first-run animated modals + spotlight coach marks that explain, not lecture
6. POLISH PASS  Fix inconsistencies (buttons, spacing, type, empty pages) + verify 320px → 1440px + light/dark
```

> **If a page wasn't checked in both light + dark at 320px, it wasn't checked.**

## Steps

### Step 1 — Inventory everything (read-only, no fixes yet)

Before changing a line, map reality. Never assume routes.

```bash
# 1. Framework & styling detection
cat package.json | grep -E "next|vite|remix|react|tailwind|framer-motion"
cat tailwind.config.* app/globals.css app/layout.tsx 2>/dev/null | head -n 60

# 2. Every route / page
find app src/app pages src/pages -type f \( -name "page.tsx" -o -name "page.jsx" -o -name "index.tsx" -o -name "+page.svelte" \) 2>/dev/null | sort

# 3. Every UI component
find components app/components src/components features -type f -name "*.tsx" -o -name "*.jsx" 2>/dev/null | sort

# 4. Current dark mode, skeletons, error handling — what already exists?
grep -rn "darkMode\|data-theme\|prefers-color-scheme\|next-themes" . --include="*.ts" --include="*.tsx" --include="*.js" 2>/dev/null
grep -rn "Skeleton\|Suspense\|isLoading\|loading" app components --include="*.tsx" | head -n 20
grep -rn "catch\|ErrorBoundary\|onRetry\|500\|\"error\"" app --include="*.tsx" | head -n 20

# 5. Dead links / blank pages / lorem — completeness pre-check
grep -rn 'href="#"\|href=""\|Lorem ipsum\|John Doe' app components --include="*.tsx" 2>/dev/null
```

**Write the inventory table** (`docs/UI-REFORMAT-INVENTORY.md`):

| # | Route | File | Has data? | Loading? | Empty? | Error? | Dark OK? | Notes |
|---|---|---|---|---|---|---|---|---|
| 1 | `/` | `app/page.tsx` | hero hardcoded | spinner | none | raw `catch(e).message` | no | no tokens |
| 2 | `/dashboard` | `app/(app)/dashboard/page.tsx` | fetches bookings | blank while load | blank | none | no |  |

Any route with blank/404 while having nav link = CRITICAL finding — tracked for Step 6.

### Step 2 — Install design tokens + dark mode (system-first, no FOUC)

Dark mode is not a color swap. It's a token system with system preference as default, manual override, and zero flash.

**2A — Create `app/globals.css` tokens (or `src/index.css` for Vite):**

```css
/* ✅ tokens — one truth for light + dark */
:root {
  /* ⚠️ Shape only — derive real palette from Step 1 product ancestor + distinctive-visual-style recipe (R1-R5). Never ship #ffffff/#111827 verbatim for two products. */
  /* e.g. booking app (ancestor: calendar card) → --bg:#FFFDFA --primary:#C4340B */
  /* e.g. fitness app (ancestor: signage) → --bg:#0A0A0A --primary:#E8FF2A */
  --bg: #ffffff; --fg: #111827; --muted: #6b7280; --border: #e5e7eb;
  --primary: #111827; --primary-fg: #ffffff; --card: #ffffff; --skeleton: #f3f4f6;
}
[data-theme="dark"] {
  --bg: #0a0a0b; --fg: #f9fafb; --muted: #9ca3af; --border: #27272a;
  --primary: #f9fafb; --primary-fg: #0a0a0b; --card: #18181b; --skeleton: #27272a;
}
/* Tailwind: extend with `bg-[var(--bg)]` or map via tailwind.config */
* { border-color: var(--border); }
body { background: var(--bg); color: var(--fg); transition: background .2s, color .2s; }
@media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
```

**2B — Framework setup:**

**Next.js (App Router) — recommended `next-themes` or tiny custom:**

```tsx
// app/layout.tsx
import { ThemeProvider } from "@/components/theme-provider"
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* FOUC fix — must be blocking, inline, before paint */}
        <script dangerouslySetInnerHTML={{ __html: `
          try{const m=localStorage.getItem('theme');const s=m|| (matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');document.documentElement.setAttribute('data-theme',s)}catch{}`}} />
      </head>
      <body>{children}</body>
    </html>
  )
}
// components/theme-provider.tsx — system + toggle + persist
"use client"; import { createContext, useContext, useEffect, useState } from "react"
const Ctx = createContext<{theme:string,setTheme:(t:string)=>void}>({theme:"light",setTheme:()=>{}})
export function ThemeProvider({ children }: {children:React.ReactNode}) {
  const [theme,setThemeRaw]=useState("light");
  useEffect(()=>{ const s=document.documentElement.getAttribute("data-theme")||"light"; setThemeRaw(s)},[]);
  const setTheme=(t:string)=>{ document.documentElement.setAttribute("data-theme",t); localStorage.setItem("theme",t); setThemeRaw(t)}
  return <Ctx.Provider value={{theme,setTheme}}>{children}</Ctx.Provider>
}
export const useTheme=()=>useContext(Ctx)
```

```tsx
// components/theme-toggle.tsx — accessible, animated, works everywhere
"use client"; import { useTheme } from "./theme-provider"
export function ThemeToggle(){
  const {theme,setTheme}=useTheme();
  return (
    <button aria-label={`Switch to ${theme==="dark"?"light":"dark"} mode`} aria-pressed={theme==="dark"}
      onClick={()=>setTheme(theme==="dark"?"light":"dark")}
      className="h-9 w-9 grid place-items-center rounded-full bg-[var(--card)] border hover:scale-105 transition-transform focus-visible:ring-2">
      <span className="transition-transform duration-300">{theme==="dark"?"☀️":"🌙"}</span>
    </button>
  )
}
```

**Vite / SPA — same tokens + script in `index.html` `<head>` before CSS.**

**Rules (pass/fail):**
- [ ] System preference is default when no manual choice
- [ ] Manual toggle persists in `localStorage` and wins over system
- [ ] No FOUC (inline blocking script in `<head>`)
- [ ] `prefers-reduced-motion` kills transitions for motion-sensitive users
- [ ] All colors use `var(--token)` — zero hardcoded `bg-white` / `text-black` in components (find & replace)
- [ ] Contrast ≥4.5:1 checked in both themes

### Step 3 — Replace every loading state with skeletons (no blank, no jump)

Every data-dependent view gets a skeleton that matches its final layout pixel-for-pixel. No layout shift, no generic spinner.

**3A — Create canonical skeletons `components/ui/skeleton.tsx`:**

```tsx
// lib: reusable, theme-aware, reduced-motion safe
export function Skeleton({ className="" }: {className?:string}) {
  return <div className={`animate-pulse bg-[var(--skeleton)] rounded-lg ${className}`} aria-hidden />
}
// Composed per view — 1:1 with real layout
export function CardSkeleton(){ return <div className="p-4 border rounded-xl space-y-3"><Skeleton className="h-5 w-3/4"/><Skeleton className="h-4 w-full"/><Skeleton className="h-10 w-full"/></div>}
export function ListSkeleton({n=3}:{n?:number}){ return <div className="grid gap-4">{Array.from({length:n}).map((_,i)=><CardSkeleton key={i}/>)}</div>}
export function TableSkeleton(){ return <div className="space-y-2"><Skeleton className="h-10 w-full"/>{Array.from({length:5}).map((_,i)=><Skeleton key={i} className="h-12 w-full"/>)}</div>}
```

**3B — Apply pattern everywhere:**

```tsx
// ❌ vibe-coded loading
if (loading) return <div className="p-8 text-center"><Spinner /> Loading...</div>

// ✅ skeleton — reserves exact layout, shimmer, theme-aware, no CLS
if (loading) return <ListSkeleton n={3} />
if (!data?.length) return <EmptyState title="No bookings yet" action={<Button href="/book">Book your first</Button>} />
```

**Shared rules:**
- Skeleton uses same `height / grid / gap` as real content — measure with DevTools, match
- Shimmer only via `animate-pulse` on `bg-[var(--skeleton)]` — no custom gradients
- Wrap data fetches in `Suspense` with `fallback={<PageSkeleton/>}` where framework supports it
- Delay skeleton 120ms (prevents flicker on fast loads): `const showSkeleton = useDelayed(loading, 120)`

### Step 4 — Replace raw server errors with human errors + retry

Users must never see a server truth. Developers must always be able to find it.

**The law:** Every `catch`, `throw`, `500`, `error.message`, stack trace shown to user = CRITICAL.

**4A — Error mapping (never show the left column to users):**

| Server truth (log only) | User sees |
|---|---|
| `500 Internal Server Error` | "We couldn't save that. Nothing was lost — try again. If it keeps happening, contact support." |
| `TypeError: fetch failed` / `ECONNREFUSED` | "You're offline or we're having trouble connecting. Check your connection and retry." |
| `401 Unauthorized` | "Please sign in again to continue." + sign-in CTA |
| `403 Forbidden` | "You don't have access to that. If you should, ask an admin." |
| `404 Not Found` | "We couldn't find that. It may have been moved or deleted." + back/home |
| `429 Too Many Requests` | "Too many tries — wait a minute and retry." |
| `ZodError / validation` | Field-level: "Enter an email like name@example.com" |
| Stack trace / `e.message` with `prisma` / `postgres` | Never rendered. Logged server-side with `errorId`. |

**4B — Copy-paste pattern `components/ui/error-state.tsx` + `lib/errors.ts`:**

```tsx
// lib/errors.ts — one mapper for the whole app
export type AppError = { title:string; message:string; retryable:boolean; code?:string; errorId?:string }
export function toAppError(e: unknown): AppError {
  const errorId = Math.random().toString(36).slice(2,8).toUpperCase() // correlate with server logs
  // log server truth server-side only — never in JSX
  if (typeof window==="undefined") console.error(`[ERR ${errorId}]`, e)
  const msg = String((e as any)?.message||"")
  if (msg.match(/fetch failed|ECONNREFUSED|Failed to fetch|NetworkError/)) return { title:"Connection trouble", message:"You're offline or we can't reach the server. Check your connection and try again.", retryable:true, errorId }
  if (msg.includes("401")||msg.includes("Unauthorized")) return { title:"Sign in again", message:"Your session expired. Please sign in to continue.", retryable:false, errorId }
  return { title:"Something didn't work", message:"We couldn't complete that. Try again — nothing was lost. If it keeps happening, share this code with support:", retryable:true, errorId }
}
export async function safeFetch<T>(url:string, opts: RequestInit & {retries?:number, timeoutMs?:number}={}): Promise<T> {
  const { retries=2, timeoutMs=10000, ...init }=opts;
  for(let i=0;i<=retries;i++){ const c=new AbortController(); const t=setTimeout(()=>c.abort(),timeoutMs);
    try{ const r=await fetch(url,{...init, signal:c.signal}); if(!r.ok) throw new Error(`${r.status} ${r.statusText}`); return await r.json() as T
    } catch(e){ if(i===retries) throw e; if(String((e as Error).message).includes("401")) throw e; await new Promise(r=>setTimeout(r, 300*2**i))} finally{clearTimeout(t)}}
  throw new Error("unreachable")
}
```

```tsx
// components/ui/error-state.tsx — human, helpful, retryable
export function ErrorState({ error, onRetry }: {error:AppError, onRetry?:()=>void}) {
  return (
    <div role="alert" className="mx-auto max-w-[480px] px-6 py-12 text-center space-y-4">
      <div className="mx-auto h-12 w-12 grid place-items-center rounded-full bg-[var(--skeleton)] text-xl">⚠️</div>
      <h3 className="text-lg font-semibold">{error.title}</h3>
      <p className="text-sm text-[var(--muted)]">{error.message}</p>
      {error.errorId && <p className="text-xs text-[var(--muted)]">Ref: {error.errorId}</p>}
      <div className="flex gap-3 justify-center pt-2">
        {error.retryable && onRetry && <button onClick={onRetry} className="h-10 px-5 rounded-full bg-[var(--primary)] text-[var(--primary-fg)] hover:opacity-90 active:scale-[0.98] transition">Try again</button>}
        <a href="/" className="h-10 px-5 grid place-items-center rounded-full border">Go home</a>
      </div>
    </div>
  )
}
// Usage — preserves input, never loses typed data
function BookingsPage(){
  const [tick,setTick]=useState(0);
  const {data,loading,error}=useAsync(()=>safeFetch("/api/bookings"),[tick]);
  if(loading) return <ListSkeleton/>
  if(error) return <ErrorState error={toAppError(error)} onRetry={()=>setTick(t=>t+1)} />
  return <BookingList data={data}/>
}
```

**Rules:**
- [ ] Zero `alert(e.message)` / `toast.error(String(e))` / `{error.message}` rendering raw server text
- [ ] Every `catch` maps via `toAppError` and renders `ErrorState` with retry when `retryable`
- [ ] Stack traces and DB messages logged server-side with `errorId` shown to user for correlation — never in UI
- [ ] Retry preserves form input (don't clear fields on error) and is debounced (no double-post)

### Step 5 — Onboarding that explains with motion (not a manual)

First-run experience must *show* not tell. Animated spotlights, not walls of text. Respectful, skippable, remembers completion.

**5A — Create `components/onboarding/` system:**

```tsx
// components/onboarding/OnboardingProvider.tsx — first-run gate
"use client"; import { useEffect, useState, createContext, useContext } from "react"
const ONBOARD_KEY="onboard:v1:done"
export function OnboardingProvider({ children, steps }: {children:React.ReactNode, steps: Step[]}) {
  const [open,setOpen]=useState(false);
  useEffect(()=>{ if(!localStorage.getItem(ONBOARD_KEY) && steps.length) {
    const t=setTimeout(()=>setOpen(true), 600); return ()=>clearTimeout(t) // let page settle, then guide
  }},[steps]);
  const complete=()=>{ localStorage.setItem(ONBOARD_KEY,"1"); setOpen(false)}
  return <OnboardingContext.Provider value={{open,setOpen,complete,steps}}>{children}{open && <OnboardingOverlay/>}</OnboardingContext.Provider>
}
// Each user sees it once. Reset via Settings → "Replay tour".
```

**5B — Spotlight coach mark `components/onboarding/CoachMark.tsx`:**

```tsx
// Spotlight + tooltip — moves, explains, animates gently
"use client"; import { useEffect, useRef, useState } from "react"
export function CoachMark({ targetId, title, body, step, total, onNext, onSkip }:
  {targetId:string,title:string,body:string,step:number,total:number,onNext:()=>void,onSkip:()=>void}){
  const [rect,setRect]=useState<DOMRect|null>(null)
  useEffect(()=>{ const el=document.getElementById(targetId); if(!el) return; const u=()=>setRect(el.getBoundingClientRect());
    u(); window.addEventListener("resize",u); window.addEventListener("scroll",u,{passive:true}); return()=>{removeEventListener("resize",u);removeEventListener("scroll",u)}},[targetId])
  if(!rect) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={`Step ${step} of ${total}: ${title}`}>
      {/* dim + spotlight hole */}
      <div className="absolute inset-0 bg-black/60" onClick={onSkip} />
      <div className="absolute rounded-xl border-2 border-white shadow-2xl pointer-events-none transition-all duration-500 motion-reduce:transition-none"
           style={{ left:rect.left-8, top:rect.top-8, width:rect.width+16, height:rect.height+16 }} />
      {/* tooltip — animated, not static */}
      <div className="absolute bg-[var(--card)] border rounded-2xl p-5 shadow-xl max-w-[360px] animate-in fade-in slide-in-from-bottom-2 duration-300 motion-reduce:animate-none"
           style={{ left: Math.min(rect.left, window.innerWidth-380), top: rect.bottom+16 }}>
        <p className="text-xs font-medium tracking-wide uppercase text-[var(--muted)]">Step {step} of {total}</p>
        <h3 className="mt-1 font-semibold">{title}</h3>
        <p className="mt-1 text-sm text-[var(--muted)] leading-relaxed">{body}</p>
        <div className="mt-4 flex items-center gap-2">
          <button onClick={onNext} className="h-9 px-4 rounded-full bg-[var(--primary)] text-[var(--primary-fg)] text-sm font-medium hover:opacity-90 transition-transform active:scale-[0.98]">{step===total?"Got it, let's go":"Next →"}</button>
          <button onClick={onSkip} className="h-9 px-3 text-sm text-[var(--muted)] hover:text-[var(--fg)]">Skip tour</button>
        </div>
        <div className="mt-3 flex gap-1">{Array.from({length:total}).map((_,i)=><span key={i} className={`h-1.5 rounded-full transition-all ${i+1===step?"w-6 bg-[var(--primary)]":"w-2 bg-[var(--border)]"}`}/>)}</div>
      </div>
    </div>
  )
}
```

**5C — Usage — define the tour per app area (keep it to 3-5 steps):**

```tsx
// app/(app)/dashboard/page.tsx — attach ids, then tour
export default function Dashboard(){
  return (
    <OnboardingProvider steps={[
      { targetId:"cta-book", title:"Book a class", body:"Tap here to pick a time and confirm in one step. We hold your spot instantly."},
      { targetId:"nav-schedule", title:"Your schedule", body:"Everything upcoming lives here — reschedule or cancel in one tap."},
      { targetId:"widget-revenue", title:"Earnings at a glance", body:"No spreadsheets — daily total, refunds, and what actually hit your account."},
    ]}>
      <Button id="cta-book" href="/book">Book a class</Button>
      {/* ... */}
    </OnboardingProvider>
  )
}
```

**Also add welcoming first-run modals (2 max, not 5):**

```tsx
// components/onboarding/WelcomeModal.tsx — appears once, animated, explains the *why*
export function WelcomeModal({ open, onComplete }: {open:boolean, onComplete:()=>void}) {
  if(!open) return null;
  return (
    <div className="fixed inset-0 z-40 grid place-items-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300" onClick={onComplete}/>
      <div className="relative w-full max-w-[520px] rounded-[20px] bg-[var(--card)] p-8 shadow-2xl animate-in zoom-in-95 fade-in duration-300 motion-reduce:animate-none">
        <div className="h-12 w-12 rounded-2xl bg-[var(--primary)] text-[var(--primary-fg)] grid place-items-center text-xl">✨</div>
        <h2 className="mt-4 text-2xl font-semibold tracking-tight">Welcome — here's how this works</h2>
        <p className="mt-2 text-[var(--muted)] leading-relaxed">Book classes, track your schedule, and get reminders — all in one place. This tour takes 30 seconds and you can skip anytime.</p>
        <div className="mt-6 space-y-3">
          <div className="flex gap-3 p-3 rounded-xl bg-[var(--skeleton)]"><span>📅</span><div><p className="font-medium text-sm">Pick a time</p><p className="text-sm text-[var(--muted)]">Choose from open slots — we hold it while you confirm.</p></div></div>
          <div className="flex gap-3 p-3 rounded-xl bg-[var(--skeleton)]"><span>✅</span><div><p className="font-medium text-sm">Confirm & pay</p><p className="text-sm text-[var(--muted)]">One tap, secure, receipt instantly.</p></div></div>
        </div>
        <div className="mt-6 flex gap-3">
          <button onClick={onComplete} className="flex-1 h-11 rounded-full bg-[var(--primary)] text-[var(--primary-fg)] font-medium hover:opacity-90 active:scale-[0.98] transition">Show me around →</button>
          <button onClick={onComplete} className="h-11 px-5 rounded-full border text-sm">Skip</button>
        </div>
      </div>
    </div>
  )
}
```

**Rules (onboarding done right):**
- [ ] Max 1 welcome modal + 3-5 spotlight steps — never a 10-step lecture
- [ ] Every step has: spotlight hole + title + 1-sentence body + Next/Skip + progress dots
- [ ] Animated gently: spotlight glides `duration-500`, tooltip slides `fade-in slide-in-from-bottom-2`
- [ ] Respects `prefers-reduced-motion` — all motion disabled when user prefers it
- [ ] Keyboard + screen reader: focus trapped in modal, `Esc` to close, `role="dialog"` + `aria-label`
- [ ] Shown once per user (`localStorage` key versioned `onboard:v1:done`), replayable from Settings/Help → "Replay tour"
- [ ] Uses real app content in examples — no lorem in tour bodies
- [ ] Explain *what this does* and *why* — not just where to click: "We hold your spot instantly" beats "Click this button"

### Step 6 — Global polish pass + verify (320px → 1440px, light + dark)

You have tokens, dark mode, skeletons, human errors, and onboarding. Now make the *rest* consistent.

| Fix | How |
|---|---|
| **Buttons** | One canonical `components/ui/button.tsx` with `variant=size=loading=disabled` — replace all `bg-blue-500 px-2 py-1` orphans |
| **Spacing** | Replace random `gap-2`/`gap-8` with tokens: `gap-4` default, `gap-6` sections, `gap-2` tight groups |
| **Typography** | Scale via tokens `text-sm` / `text-base` / `text-lg` from `globals.css` — no `text-[22px]` one-offs |
| **Empty pages** | Every routed page with empty data → `EmptyState` with action, not blank |
| **Dead links** | `grep -rn 'href="#"' app` must be 0 — remove placeholder links or wire them |

**Verify before "done" — the global checklist:**

```
[ ] Inventory table complete — every route accounted for
[ ] Dark mode: no FOUC, system default, toggle works, all pages checked in both themes
[ ] Light + dark contrast ≥4.5:1 (check with DevTools > Rendering > Emulate)
[ ] Every loading → skeleton (no blank, no spinner-only), no layout jump
[ ] Every error → human message + Retry, no raw 500/stack shown (grep "error.message" in JSX = 0)
[ ] Onboarding: welcome modal + up to 5 spotlight steps, animated, skippable, shown once, replayable
[ ] Every interactive element has hover, focus-visible, and active states
[ ] Drag 320 → 1440: no horizontal scroll, tap targets ≥44px, nav collapses correctly
[ ] Reduced motion: test with "Emulate prefers-reduced-motion" — no animation when set
[ ] Keyboard: Tab through every page, Esc closes every modal, focus returns after close
```

## Non-negotiables

1. **No invented files.** Every `file:line` in any report exists — you read it. No guessed routes.
2. **No raw server errors to users, ever.** `e.message`, `prisma` errors, stack traces → server logs with `errorId` only. Users see `toAppError` + retry.
3. **No FOUC.** Dark mode script is inline blocking in `<head>` — not in `useEffect`.
4. **No loading without skeleton.** Every `isLoading` / `loading` / `Suspense` has a layout-matched skeleton. Blank = bug.
5. **No tour without motion respect.** All onboarding animations honored `prefers-reduced-motion`. Autoplay-free, Esc-dismissible, focus-trapped.
6. **Standalone means self-contained.** Skill creates `components/theme-provider.tsx`, `skeleton.tsx`, `error-state.tsx`, `onboarding/` — no dependency on other skills. It can be the only file you paste.
7. **Inventory before writes.** No file edited before `UI-REFORMAT-INVENTORY.md` exists.
8. **Report before "fix all".** Like `ux-upgrade-audit`, you produce `docs/UI-REFORMAT-REPORT.md` first, then wait for explicit `fix all` — not "sounds good".
9. **Grouped commits.** `chore: checkpoint` → `feat(ui): dark mode` → `feat(ui): skeletons` → `feat(ui): error handling + retry` → `feat(ui): onboarding + polish` → verify.
10. **Plain language in UI.** Error titles and onboarding bodies are human — test by reading aloud. No "ERR-500" as a headline.
11. **No hardcoded colors after reformat.** Every `bg-white` / `text-black` becomes `bg-[var(--bg)]` — search and replace, verify in both themes.
12. **Every new modal/coach mark is accessible.** `role="dialog"`, `aria-label`, focus trap, Esc, return focus — no exceptions.

## Ask the human

**One question at a time** — conversational, never a list.

Ask only what changes taste or scope (max 3 pre-scan + 1 pre-fix):

1. "What vibe should the whole app have — calm like Stripe, warm like Airbnb, or bold like Linear? — Not sure? Say 'you pick' and I'll pick from your app's purpose and tell you."
2. "Any pages I should skip — admin, internal tools, work-in-progress? — Say 'you pick' and I'll reformat everything I find."
3. "For first-time users, what's the ONE thing they must understand to feel successful — like 'book a class' or 'invite your team'? — 'You pick' and I'll infer from the homepage."
4. After report: "Ready to reformat everything? Just say **'fix all'** — I'll run the 5 groups with checkpoints. Or say which group like 'dark mode only'."

**How:** Acknowledge previous ("Got it — calm/Stripe, noted"), then one question with inline default. Never a list. If they already answered in discovery, don't re-ask — assume: "You said it's for bookers on phones, so I'll use calm/professional — correct me if wrong."

Never ask: "hex codes?", "framer-motion or CSS?", "spotlight or tooltip?" — your job.

## Patterns

### Snapshot → System pattern (use before writing tokens)

> **Fix for "same UI twice":** Do NOT default to row 1. Generate 3 candidate palettes from different ancestors below, present them, and let the human pick — or auto-pick the best fit and document the 2 rejected in `docs/STYLE.md`.

| Product | Ancestor | Tokens reflect | Recipe counterpart |
|---|---|---|---|
| Bookings / SaaS | Clean desk + calendar | White/light grey, one near-black, one accent for primary CTAs | R1 Paper & Ink — shift paper to warm #FFFDFA |
| Fintech / Dashboard | Ledger + bank statement | Low saturated, high contrast, accent only for money/success states | R2 Swiss — keep 0 radius, solid shadows |
| Creative / Fitness | Poster + gym floor | Bold accent allowed, dark mode as true near-black | R3 Warm Analog or R5 Minimal |
| Docs / Wiki | Paper + highlighter | Warm paper tint, ink text, yellow/marker accent for highlights | R4 Dense Technical — mono display |
| Social / Marketplace | Menu card + market stall | Warm paper + deep green, serif | R3 Warm Analog — hand-drawn dividers |
| Health / Clinical | Pharmacy form + lab | White/cool grey + trustworthy blue | R4 Dense Technical — tabular, clean |

Pick one, lock `globals.css`, reuse everywhere — and write `REJECTED:` with the 2 not chosen.

### Error copy bank (human, not server)

| Scenario | Title | Message + action |
|---|---|---|
| Load failed (GET) | "We couldn't load that" | "Check your connection and try again. Nothing was lost." [Try again] |
| Save failed (POST/PATCH) | "Didn't save" | "We couldn't save your changes. Try again — we kept what you typed." [Retry] + keep form values |
| Not found | "Not found" | "This page or item doesn't exist — it may have been deleted." [Back] [Home] |
| Offline | "You're offline" | "Some features need connection. We'll sync when you're back." [Retry] |
| Payment | "Payment didn't go through" | "You weren't charged. Try again or use a different card." [Retry] [Help] |

### Onboarding step recipe (keep each step to 25 words)

```
Spotlight: [element with id]
Title: Verb + outcome ("Book a class in one tap")
Body: What + why in one sentence ("Pick a time — we hold it while you confirm, no race.")
CTAs: [Next →] + [Skip tour]
Progress: ●○○ + Esc + focus trap
```

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| Dark mode via `class="dark"` plus `bg-white` hardcoded everywhere | Every component missed = FOUC + invisible text in dark | Tokens via `var()` + `data-theme`, grep replace all hardcoded colors |
| `useEffect` to set theme from `localStorage` | Flashes white every reload — most common dark mode bug | Blocking inline script in `<head>` before paint |
| Spinner in center of blank page | Feels slow, hides layout, CLS on load | Skeleton that *is* the layout |
| `catch(e){ toast.error(e.message) }` | Shows `prisma error: relation "bookings" does not exist` to customer | `toAppError(e)` → `ErrorState` + server log with errorId |
| 500 page with stack trace | Leaks internals, scares users, SEO disaster | Branded error page with retry + errorId + home link |
| Onboarding with 8 modals that auto-play | User closes everything, learns nothing, resents app | 1 welcome + max 5 spotlight steps, skippable, shown once |
| Tour that says "Click here" with no why | Users comply then forget | Explain outcome: "Book here — we hold your spot instantly" |
| Animations that ignore reduced motion | Harms vestibular-sensitive users, fails a11y audit | `@media (prefers-reduced-motion: reduce){ *{animation:none}}` |
| Forgetting to persist theme | User toggles every visit | `localStorage` + `matchMedia` as default, toggle wins forever |
| Global reformat without inventory | Misses orphan pages, leaves 2 truths for buttons | Inventory table first, always |
| One giant commit for whole reformat | Can't revert dark mode without reverting onboarding | Grouped commits per concern |

## Definition of done

- [ ] Inventory `docs/UI-REFORMAT-INVENTORY.md` exists — every route + component mapped before any write
- [ ] Tokens + dark mode in `app/globals.css` — system default, toggle with persistence, no FOUC, pass in both themes
- [ ] Every dark/light color via `var(--token)` — `grep -rn "bg-white\|text-black" app components` → 0 (excluding comments)
- [ ] Every loading state → layout-matched skeleton — no blank/isolated spinner, no CLS
- [ ] Every error → human message + retry — no `error.message` rendered in JSX, server errors logged with errorId only
- [ ] Onboarding: welcome modal + ≤5 animated coach marks — spotlight, title+body, Next/Skip, progress dots, Esc, focus trap, `prefers-reduced-motion` honored, shown once (`onboard:v1:done`), replayable
- [ ] Report `docs/UI-REFORMAT-REPORT.md` exists — findings + before/after + grouped plan — written before any fix
- [ ] "Fix all" only after explicit approval — 5 grouped commits + verification: no dead links, no blank pages, no mock data in `app/`
- [ ] Verified: drag 320 → 1440 no overflow, light + dark checked, keyboard Tab + Esc through all flows, reduced-motion emulation clean
- [ ] No horizontal scroll, tap ≥44px, no `href="#"`, every `catch` mapped, every `isLoading` has skeleton
- [ ] Owner can describe polish in two sentences; first-run user completes core action without help
- [ ] Rollback commit exists: `chore: checkpoint before ui-reformat`

## Works with

- `responsive-mobile-first` — the 320px-first + thumb rules this reformat enforces globally
- `frontend-craft` — the six states (loading/empty/error...) this reformat implements via skeletons + error states
- `ux-upgrade-audit` — same inventory + report + "fix all" pattern; use that for audit-only, this for full transform
- `distinctive-visual-style` — taste anchor; pick ancestor before tokenizing, not after
- `design-system-and-visual-language` — tokens source; this skill *installs* the system that skill defines
- `accessibility-and-inclusive-design` — contrast + keyboard + focus ring + reduced-motion checks that gate "done"
- `ux-writing-and-onboarding` — copy for error states + empty states + tour bodies — words are the polish
- `production-readiness` — launch gate that should run *after* this global reformat

