# Global Reformat — quick checklist

Copy into PR description or `docs/UI-REFORMAT-REPORT.md`.

## Inventory
- [ ] Every route found (`find app pages ...`) → table
- [ ] Every component found
- [ ] Current dark/skeleton/error state grepped

## Tokens + Dark mode
- [ ] `globals.css` tokens `var(--bg)` etc. for light + `[data-theme="dark"]`
- [ ] Inline blocking script in `<head>` — no FOUC
- [ ] System preference default, manual toggle wins + persists
- [ ] All hardcoded `bg-white` / `text-black` replaced with `var(--token)`
- [ ] `prefers-reduced-motion` disables transitions

## Skeletons
- [ ] `components/ui/skeleton.tsx` with Card/List/Table variants
- [ ] Every `isLoading` / `loading` → skeleton (not spinner/blank)
- [ ] Suspense fallbacks where applicable
- [ ] No layout shift (skeleton same height as content)

## Error handling
- [ ] `lib/errors.ts` → `toAppError` + `safeFetch` with retry/timeout
- [ ] `components/ui/error-state.tsx` — human title + message + Retry + errorId
- [ ] Zero `error.message` rendered in JSX (`grep -rn "error.message" app` → 0)
- [ ] Server truth logged server-side only

## Onboarding
- [ ] 1 welcome modal (optional, max 1)
- [ ] 3-5 spotlight coach marks — spotlight hole + title + body + Next/Skip + dots
- [ ] Animated (`fade-in`, `slide-in`) + `prefers-reduced-motion` respected
- [ ] Focus trap, Esc, `role="dialog"`, shown once (`onboard:v1:done`), replayable

## Global polish
- [ ] One canonical `Button` (variant/size/loading/disabled)
- [ ] Spacing tokens unified (gap-4 default)
- [ ] No `href="#"`, no blank pages, no lorem/John Doe in `app/`
- [ ] Verified: 320/375/768/1024/1440 + light/dark + keyboard + reduced-motion + offline

