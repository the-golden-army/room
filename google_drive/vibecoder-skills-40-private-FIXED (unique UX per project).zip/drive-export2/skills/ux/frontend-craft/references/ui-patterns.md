# UI patterns (copy-paste, React + TypeScript)

Drop these in `lib/` and use them everywhere. Consistency is the whole point.

---

## 1. `useAsync` — the every-fetch hook

Handles: loading, error, timeout, abort, stale-response protection, and manual retry.

```tsx
import { useCallback, useEffect, useRef, useState } from "react";

type State<T> = { data: T | null; loading: boolean; error: Error | null };

export function useAsync<T>(
  fn: (signal: AbortSignal) => Promise<T>,
  deps: unknown[] = [],
  { timeoutMs = 10_000 } = {},
) {
  const [state, setState] = useState<State<T>>({ data: null, loading: true, error: null });
  const runId = useRef(0);

  const run = useCallback(async () => {
    const id = ++runId.current;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(new Error("timeout")), timeoutMs);
    setState(s => ({ ...s, loading: true, error: null }));
    try {
      const data = await fn(ctrl.signal);
      if (id === runId.current) setState({ data, loading: false, error: null });
    } catch (e) {
      if (id === runId.current && (e as Error).name !== "AbortError") {
        setState({ data: null, loading: false, error: e as Error });
      }
    } finally {
      clearTimeout(timer);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => { run(); }, [run]);

  return { ...state, retry: run };
}
```

```tsx
function BookingList() {
  const { data, loading, error, retry } = useAsync<Booking[]>(
    (signal) => fetch("/api/bookings", { signal }).then(r => r.json()),
    [],
  );

  if (loading) return <BookingListSkeleton />;
  if (error)  return <ErrorState onRetry={retry} />;
  if (!data?.length) return <EmptyState />;
  return <ul>{data.map(b => <BookingRow key={b.id} booking={b} />)}</ul>;
}
```

---

## 2. `useMutation` — submit with double-submit guard

```tsx
export function useMutation<A extends unknown[], R>(
  fn: (...args: A) => Promise<R>,
  { timeoutMs = 15_000 } = {},
) {
  const [status, setStatus] = useState<"idle" | "pending" | "success" | "error">("idle");
  const [error, setError] = useState<Error | null>(null);
  const inFlight = useRef(false);

  const mutate = useCallback(async (...args: A) => {
    if (inFlight.current) return;                 // ← the double-submit guard
    inFlight.current = true;
    setStatus("pending"); setError(null);
    try {
      const result = await Promise.race([
        fn(...args),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), timeoutMs)),
      ]) as R;
      setStatus("success");
      return result;
    } catch (e) {
      setError(e as Error); setStatus("error"); throw e;
    } finally {
      inFlight.current = false;
    }
  }, [fn]);

  return { mutate, status, isPending: status === "pending", error };
}
```

---

## 3. `<AsyncButton>` — one button component, correct by default

```tsx
export function AsyncButton({
  onClick, children, pendingLabel = "Working…", variant = "primary", ...rest
}: { onClick: () => Promise<unknown>; pendingLabel?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const { mutate, isPending } = useMutation(onClick);
  return (
    <button
      {...rest}
      onClick={() => mutate().catch(() => {})}     // handled in the hook; don't spam the console
      disabled={isPending || rest.disabled}
      aria-busy={isPending}
      className={buttonClass(variant)}
    >
      {isPending && <Spinner className="mr-2 h-4 w-4 animate-spin" aria-hidden />}
      {isPending ? pendingLabel : children}
    </button>
  );
}
```

---

## 4. Slow-network honesty

```tsx
export function useSlowIndicator(active: boolean, thresholdMs = 3000) {
  const [slow, setSlow] = useState(false);
  useEffect(() => {
    if (!active) { setSlow(false); return; }
    const t = setTimeout(() => setSlow(true), thresholdMs);
    return () => clearTimeout(t);
  }, [active, thresholdMs]);
  return slow;
}

// In the component
const slow = useSlowIndicator(isPending);
{slow && <p className="text-sm text-slate-500">Still working — this is taking longer than usual.</p>}
```

---

## 5. Delayed spinner (no flicker on fast responses)

```tsx
export function DelayedSpinner({ delayMs = 200 }: { delayMs?: number }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShow(true), delayMs);
    return () => clearTimeout(t);
  }, [delayMs]);
  if (!show) return null;
  return <Spinner className="h-4 w-4 animate-spin" aria-hidden />;
}
```

---

## 6. Debounced search input

```tsx
export function useDebounced<T>(value: T, delayMs = 300) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), delayMs);
    return () => clearTimeout(t);
  }, [value, delayMs]);
  return v;
}

function Search() {
  const [q, setQ] = useState("");
  const term = useDebounced(q, 300);
  const { data, loading } = useAsync<Result[]>(
    (signal) => fetch(`/api/search?q=${encodeURIComponent(term)}`, { signal }).then(r => r.json()),
    [term],
  );
  return (
    <>
      <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search bookings…"
             aria-label="Search bookings" />
      {loading && <DelayedSpinner />}
      {term && data?.length === 0 && <p>No results for “{term}”.</p>}
    </>
  );
}
```

---

## 7. Persisted draft (never lose typed work)

```tsx
export function useDraft<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : initial; }
    catch { return initial; }
  });
  useEffect(() => {
    const t = setTimeout(() => {
      try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
    }, 500);
    return () => clearTimeout(t);
  }, [key, value]);
  const clear = useCallback(() => { localStorage.removeItem(key); }, [key]);
  return [value, setValue, clear] as const;
}
```

Also warn on navigate-away with unsaved changes:

```tsx
useEffect(() => {
  if (!dirty) return;
  const handler = (e: BeforeUnloadEvent) => e.preventDefault();
  addEventListener("beforeunload", handler);
  return () => removeEventListener("beforeunload", handler);
}, [dirty]);
```

---

## 8. Offline banner + queued writes

```tsx
export function useOnline() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const up = () => setOnline(true), down = () => setOnline(false);
    setOnline(navigator.onLine);
    addEventListener("online", up); addEventListener("offline", down);
    return () => { removeEventListener("online", up); removeEventListener("offline", down); };
  }, []);
  return online;
}

export function OfflineBanner() {
  const online = useOnline();
  if (online) return null;
  return (
    <div role="status" className="bg-amber-100 px-4 py-2 text-sm">
      You're offline. We'll save your changes as soon as you're back.
    </div>
  );
}
```

---

## 9. Error boundary (the last line of defense)

```tsx
"use client";
import { Component, type ReactNode } from "react";

export class ErrorBoundary extends Component<
  { children: ReactNode; fallback?: (reset: () => void) => ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) { return { error }; }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Ship to your error tracker with the component stack
    reportError(error, { componentStack: info.componentStack });
  }

  render() {
    if (!this.state.error) return this.props.children;
    return this.props.fallback?.(() => this.setState({ error: null })) ?? (
      <div role="alert" className="p-6">
        <h2>Something went wrong on this screen.</h2>
        <p>Your data is safe. Try again, or refresh the page.</p>
        <button onClick={() => this.setState({ error: null })}>Try again</button>
      </div>
    );
  }
}
```

Wrap each route section, not just the app root — one broken widget shouldn't blank the page.

---

## 10. Optimistic list update

```tsx
function useOptimisticList<T extends { id: string }>(initial: T[]) {
  const [items, setItems] = useState(initial);
  const [pending, setPending] = useState<Set<string>>(new Set());

  const update = async (id: string, patch: Partial<T>, persist: (p: Partial<T>) => Promise<unknown>) => {
    const snapshot = items;
    setItems(prev => prev.map(i => i.id === id ? { ...i, ...patch } : i));
    setPending(p => new Set(p).add(id));
    try { await persist(patch); }
    catch { setItems(snapshot); toast.error("That change didn't save. Nothing was lost."); }
    finally { setPending(p => { const n = new Set(p); n.delete(id); return n; }); }
  };

  return { items, setItems, update, pending };
}
```

---

## 11. Skeleton that matches the real layout

```tsx
export function TableSkeleton({ rows = 5, cols = 4 }: { rows?: number; cols?: number }) {
  return (
    <div role="status" aria-label="Loading" className="space-y-2">
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="grid gap-4" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
          {Array.from({ length: cols }).map((_, c) => (
            <div key={c} className="h-10 rounded bg-slate-100 animate-pulse" />
          ))}
        </div>
      ))}
    </div>
  );
}
```

Match the real row height exactly. A skeleton that resizes on load is worse than a spinner.

---

## 12. The state checklist component (for reviews)

```tsx
// Every list view should be reviewable against this:
// [ ] loading  → skeleton with the same height as a row
// [ ] empty    → message + primary action
// [ ] error    → message + retry
// [ ] partial  → some items loaded, "load more" works and is disabled while loading
// [ ] success  → rows render, no layout shift
// [ ] stale    → if cached, show when it was fetched
```
