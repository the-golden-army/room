---
name: frontend-craft
description: Use whenever building or reviewing any interactive screen — forms, buttons, lists, dashboards, modals, search, uploads, or anything that waits for a server. Enforces the states that make software feel professional: loading, empty, error, success, offline, and slow — plus double-submit prevention, timeouts, retries, optimistic updates, race-condition handling, and layout stability. This is the difference between an app that looks AI-generated and one that feels like a real product.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# frontend-craft

## Promise

Every screen behaves correctly in every situation — including the ones you didn't think about.
Nothing spins forever, nothing can be clicked twice, nothing loses the user's data, and nothing lies
about what just happened.

## When to use

- Building any screen that fetches, submits, uploads, searches, or waits for anything
- "It feels janky / cheap / slow" feedback
- Before launch — this is a big part of `production-readiness`
- After a user reports "I clicked twice and got charged twice"
- Reviewing AI-generated UI (it almost always ships the happy path only)

## When NOT to use

- Static content with no interaction (but still check empty/error states)

## The 60-second version: the six states

Every piece of a screen that depends on data has **six** states. Build all six, every time.

```
1. LOADING (first time)   skeleton or spinner, in the real layout
2. EMPTY                  "No bookings yet" + the thing to do next
3. ERROR                  what went wrong + a retry button + a way out
4. PARTIAL / SLOW         still usable, with honest progress
5. SUCCESS / DATA         the actual content
6. OFFLINE / STALE        "You're offline" or "Showing data from 10:42"
```

Most AI-generated UI ships state 5 and a spinner. That's why it feels unfinished.

## The button law (the single highest-value rule)

A button that starts something must:

1. **Disable immediately** on click (or guard with an in-flight flag) — no double submits
2. **Show progress** in the button itself ("Saving…"), not just somewhere else
3. **Have a timeout** — after N seconds it either errors or says "this is taking longer than usual"
4. **Re-enable on completion**, success or failure
5. **Never silently do nothing** if the click didn't register

```tsx
function SaveButton({ onSave }: { onSave: () => Promise<void> }) {
  const [state, setState] = useState<"idle" | "saving" | "done" | "error">("idle");

  async function handleClick() {
    if (state === "saving") return;                 // guard: no double submit
    setState("saving");
    try {
      await withTimeout(onSave(), 10_000);          // never wait forever
      setState("done");
      setTimeout(() => setState("idle"), 2000);      // brief confirmation, then reset
    } catch {
      setState("error");                            // stays clickable so they can retry
    }
  }

  return (
    <button onClick={handleClick} disabled={state === "saving"} aria-busy={state === "saving"}>
      {state === "saving" && <Spinner />}
      {state === "saving" ? "Saving…" : state === "done" ? "Saved ✓" : state === "error" ? "Retry" : "Save"}
    </button>
  );
}
```

**Server-side too:** the client guard is UX; idempotency is security. See `api-abuse-defense`.

## The async checklist (apply to every fetch)

| # | Requirement | Why |
|---|---|---|
| 1 | Loading indicator in the **real layout** (skeleton), not a centered spinner over a blank page | Prevents layout jump; feels faster |
| 2 | **Timeout** (8-15s) → error state, not eternal spinner | Users abandon at ~3s |
| 3 | **Retry** with backoff for network/idempotent GETs; never auto-retry a POST that charges money | Saves the user from a blip |
| 4 | **Abort on unmount / on new request** | Prevents stale responses overwriting fresh ones |
| 5 | **Error state with a real message + retry button** | "Something went wrong" alone is a dead end |
| 6 | **Empty state** that explains and offers the next action | Empty is not an error |
| 7 | **Optimistic update** for instant-feeling actions, with rollback on failure | Perceived speed |
| 8 | **No layout shift** when data arrives (reserve space) | Prevents mis-clicks and nausea |
| 9 | **Focus and scroll preserved** after an update | Don't yank the page |
| 10 | **Success feedback** that matches the stakes (toast for small, page change for big) | The user must know it worked |

Copy-paste implementations: [`references/ui-patterns.md`](references/ui-patterns.md).

## Patterns

### 1. Fetch with timeout, abort, and retry

```ts
export async function safeFetch(url: string, opts: RequestInit & { timeoutMs?: number; retries?: number } = {}) {
  const { timeoutMs = 10_000, retries = 2, ...init } = opts;
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...init, signal: ctrl.signal });
      if (!res.ok && res.status >= 500 && attempt < retries) throw new Error(`HTTP ${res.status}`);
      return res;
    } catch (e) {
      lastErr = e;
      if (attempt < retries) await new Promise(r => setTimeout(r, 300 * 2 ** attempt)); // backoff
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastErr;
}
```

Only auto-retry **safe, idempotent** requests (GETs). Never auto-retry a payment.

### 2. Kill the race condition (stale response wins)

```tsx
// Two searches: the first returns last and overwrites the second. Classic bug.
useEffect(() => {
  const ctrl = new AbortController();
  setLoading(true);
  safeFetch(`/api/search?q=${encodeURIComponent(q)}`, { signal: ctrl.signal })
    .then(r => r.json())
    .then(data => { if (!ctrl.signal.aborted) setResults(data); })   // ignore stale
    .catch(e => { if (e.name !== "AbortError") setError(e); })
    .finally(() => { if (!ctrl.signal.aborted) setLoading(false); });
  return () => ctrl.abort();
}, [q]);
```

### 3. Optimistic update with rollback

```tsx
async function toggleComplete(id: string) {
  const prev = items;
  setItems(items.map(i => i.id === id ? { ...i, done: !i.done } : i));   // instant
  try {
    await api.patch(`/todos/${id}`, { done: !prev.find(i => i.id === id)!.done });
  } catch {
    setItems(prev);                                                       // roll back
    toast.error("Couldn't save that change. Nothing was lost.");
  }
}
```

### 4. Skeletons instead of spinners

```tsx
// Reserve the exact final size — no layout shift
{loading
  ? Array.from({ length: 5 }).map((_, i) => (
      <div key={i} className="h-[72px] rounded-lg bg-slate-100 animate-pulse" />
    ))
  : items.map(renderItem)}
```

Use a skeleton when the layout is known (lists, cards, tables). Use a spinner for an unknown-duration
action (button, modal confirm, upload). Never a full-page spinner for a page that already has content —
dim the content and show inline progress instead.

### 5. Error states that are actually useful

```
❌ "Error"  /  "Something went wrong"  /  a raw stack trace  /  a blank white screen

✅ "We couldn't load your bookings.
    [Try again]
    If this keeps happening, email support@example.com — we can see the error on our side."
```

Rules: say what failed in the user's words, say whether their data is safe, give the next action, and
never show a technical message to a user. Log the detail server-side.

### 6. Empty states

```
No bookings yet
Book your first class and it'll show up here.
[ Browse classes ]
```

Three parts: what this is, why it's empty, what to do about it. Distinguish "empty because new" from
"empty because your filter matched nothing" (the second needs a "clear filters" action).

### 7. Forms

| Rule | Why |
|---|---|
| Validate on **blur** and on **submit**; not on every keystroke | Yelling at someone mid-typing is hostile |
| Disable submit only when it's genuinely invalid *after* a submit attempt | A permanently grey button with no reason is a dead end |
| Keep the values on error | Losing typed data is unforgivable |
| Show errors next to the field, with `aria-invalid` + `aria-describedby` | Findable and accessible |
| Field-level messages in plain words | "Enter an email like name@example.com", not "invalid format" |
| Enter submits; the primary action is visually primary | Muscle memory |
| Autofocus the first field on a dedicated form page | Speed |
| Show password requirements up front, not after failure | Respect the user's time |
| Preserve scroll position and focus after a failed submit | Don't make them hunt |

### 8. Lists, tables, search

- Pagination or infinite scroll — but always with a stable item height, or the scroll jumps
- Search: debounce 250-300ms, abort previous requests, show "searching…", handle zero results
- Sort/filter state in the URL so results are shareable and the back button works
- Bulk actions: a selection count, a clear way to deselect, and a confirm for destructive ones
- Row actions: keep them visible on desktop, in a menu on mobile, never hidden behind a mystery icon

### 9. Slow and offline

```tsx
// Honest progress beats a fake spinner
{elapsed > 3000 && <p>This is taking longer than usual — still working…</p>}

// Offline
useEffect(() => {
  const update = () => setOnline(navigator.onLine);
  addEventListener("online", update); addEventListener("offline", update);
  return () => { removeEventListener("online", update); removeEventListener("offline", update); };
}, []);
{!online && <Banner>You're offline. Changes will save when you're back.</Banner>}
```

Queue writes while offline and replay on reconnect (or at minimum, don't lose what they typed — persist
draft form state to `localStorage`).

### 10. Toasts, modals, confirmations

| Use | For | Rules |
|---|---|---|
| Toast | Small, undoable, non-blocking confirmations | Auto-dismiss 4-6s, max 3 on screen, never for errors the user must act on |
| Inline message | Field/row/section-level feedback | Stays until resolved |
| Modal confirm | Destructive or irreversible actions | Name the consequence ("Delete 12 bookings? This can't be undone."), focus the safe option |
| Full page | Big outcomes (payment success, onboarding complete) | Clear headline, next step |

Never stack five toasts. Never use a toast for something the user must read to proceed. Never confirm
something that's easily reversible (it trains people to click through confirmations).

## The vibe-code tells (what makes an app look AI-generated)

| Tell | Fix |
|---|---|
| Every page is a centered spinner, then everything appears at once | Skeletons + progressive loading |
| Buttons that do nothing visible for 2 seconds, then work | Immediate disabled + "…" state |
| A list that renders `{items.map(...)}` with nothing when empty | Empty state with an action |
| `alert("Error!")` or `console.log` error handling | Real error UI + logging |
| Forms that lose everything on a validation error | Keep values; validate on blur |
| Success with zero feedback | Toast or inline confirmation |
| Layout jumps when data arrives | Reserve space |
| Double-clicking charges twice / creates two rows | Disable + server-side idempotency |
| Loading spinner that never stops (no timeout) | Timeout + error + retry |
| Modals that can't be closed with Escape | Keyboard support (see `accessibility-and-inclusive-design`) |
| Refreshing loses unsaved work | Draft persistence |
| Raw JSON or stack traces shown to users | Friendly, generic, logged detail server-side |

## Non-negotiables

1. **Every data-dependent view has loading, empty, error, and success states.** No exceptions.
2. **Every action that can be triggered twice is guarded** — client-side and idempotent server-side.
3. **Every network call has a timeout and a failure path.**
4. **No eternal spinner.** Ever.
5. **Errors are written for humans** and logged for developers.
6. **The user never loses what they typed.**
7. **Optimistic where it's safe, honest where it isn't.**
8. **No layout shift** when content arrives.
9. **Focus and scroll are respected** across updates.
10. **Slow is a state** you design for, not a bug you hope not to have.

## Ask the human

1. "What should someone see the very first time they open this, before they've added anything?"
2. "If this takes a while to load, would you rather see a skeleton outline or a spinner?"
3. "When something goes wrong, do you want a friendly message, or do you want to know the technical reason?"
4. "Should people be able to undo this action, or is it final?"
5. "Is there anything here that people might do in a hurry, on a phone, on bad wifi?" *(designs the offline/timeout behavior)*
6. "What's the one action someone must never accidentally do twice?" *(that one gets idempotency first)*

Never ask: "optimistic or pessimistic updates?", "skeleton or spinner?", "debounce at 250 or 300ms?".

## Anti-patterns

| Anti-pattern | Why it feels bad | Do instead |
|---|---|---|
| `await fetch()` with no try/catch | White screen on failure | Every call has a failure path |
| `disabled={!isValid}` always on | User can't tell why | Validate on blur/submit attempt |
| `window.alert()` for errors | 2005 called | Inline error UI |
| A spinner for 200ms | Flicker | Delay the spinner by 150-200ms |
| No timeout | Infinite spinner on a hung request | `AbortController` + timeout |
| Auto-retrying a POST | Double charges | Retry GETs only; POSTs get a manual retry |
| Fetching on every render | Request storm + race conditions | Effect with proper deps + abort |
| `key={index}` in lists | Wrong rows update | Stable, unique `key` |
| Re-rendering the whole page on every keystroke | Laggy inputs | Debounce, memoize, controlled inputs locally |
| Toasts for everything | Nobody reads them | Reserve for small confirmations |

## Definition of done

- [ ] Every data view: loading (skeleton in-layout), empty (with action), error (with retry), success
- [ ] Every submit button: disables, shows progress, has a timeout, re-enables, can't double-submit
- [ ] All network calls have timeouts, aborts on unmount, and no race conditions
- [ ] Failed submissions preserve the user's input
- [ ] Errors are human-readable; details are logged server-side with a correlation ID
- [ ] Success feedback proportional to the stakes
- [ ] No layout shift on load (`CLS` ≈ 0); no flicker
- [ ] Offline/flaky behavior considered: at minimum the user is told
- [ ] Keyboard-accessible and focus-managed (see `accessibility-and-inclusive-design`)
- [ ] Tested on a throttled connection (DevTools "Slow 3G") — not just on your machine

## Works with

- `accessibility-and-inclusive-design` — every state must be accessible
- `design-system-and-visual-language` — the components you build these states from
- `ux-writing-and-onboarding` — the words in every state
- `backend-api-design` — error contracts that make good error states possible
- `performance-and-caching` — the other half of "feels fast"
- `production-readiness` — this is a large part of the launch gate
