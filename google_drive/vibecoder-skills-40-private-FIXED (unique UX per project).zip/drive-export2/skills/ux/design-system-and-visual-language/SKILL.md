---
name: design-system-and-visual-language
description: Use when starting a new UI, when screens start to look inconsistent, or whenever someone says "make it look good" / "it looks AI-generated". Defines design tokens (color, type, spacing, radius, shadow, motion), the minimum component set with every state, layout rules, and a consistency audit — so five screens built on five different days look like one product instead of five prototypes.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# design-system-and-visual-language

## Promise

One visual language, defined once, used everywhere. Screens stop looking like five different apps, and
every new screen takes a third of the time because the decisions are already made.

## When to use

- Starting any UI (set the tokens on day one — retrofitting is painful)
- "Make it look better / more professional / less AI-generated"
- Screens built at different times don't match
- Adding dark mode, a second theme, or a new section
- Before building a component library or picking a UI kit
- Onboarding a second designer/agent who needs to match the existing look

## When NOT to use

- A one-page internal tool where nobody cares (still use the spacing scale, it's free)

## The 60-second version

```
1. TOKENS FIRST. Colors, spacing, type sizes, radii, shadows — named, not hardcoded.
   Never another `text-[13px]` or `bg-[#3b82f6]`.
2. One type scale (5-6 sizes). One font. Two weights, maybe three.
3. One spacing scale based on 4 or 8px. Everything snaps to it.
4. Semantic color names: `bg-surface`, `text-muted`, `border-danger` — not `bg-gray-100`.
5. Build the 12 components you always need, each with all six states.
6. Breakpoints: mobile-first, three of them. Design the mobile screen first.
7. Motion: 150-300ms, ease-out, and honor "reduce motion".
8. Consistency audit: screenshot every screen side by side and look for drift.
```

## Step 1 — Tokens (do this before the first component)

> **Uniqueness rule:** Never ship the example hexes below verbatim for two projects. Derive colours from the product's ancestor via `distinctive-visual-style` (R1-R5) and shift them — document the ancestor + shift in `docs/STYLE.md`. See `references/style-recipes.md` for 5 starting points.

```css
/* app/tokens.css — one place, named by meaning — EXAMPLE SHAPE, NOT FINAL COLOURS */
:root {
  /* Type: 6 sizes is plenty */
  --font-sans: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --text-xs:   0.75rem;  /* 12px — labels, legal */
  --text-sm:   0.875rem; /* 14px — secondary, table cells */
  --text-base: 1rem;     /* 16px — body. Never smaller for body text. */
  --text-lg:   1.125rem; /* 18px — lead paragraphs */
  --text-xl:   1.375rem; /* 22px — section headings */
  --text-2xl:  1.75rem;  /* 28px — page titles */
  --leading-tight: 1.2;  --leading-normal: 1.55;

  /* Spacing: 4px base, everything snaps */
  --space-1: 0.25rem; --space-2: 0.5rem;  --space-3: 0.75rem; --space-4: 1rem;
  --space-5: 1.5rem;  --space-6: 2rem;    --space-8: 3rem;    --space-12: 4rem;

  /* Radii: pick two, not six */
  --radius-sm: 6px;  --radius-md: 10px;  --radius-full: 999px;

  /* Color: semantic, with a light/dark pair */
  --bg:          #ffffff;  --bg-subtle:  #f8fafc;  --bg-inverse: #0f172a;
  --text:        #0f172a;  --text-muted: #64748b;  --text-inverse: #f8fafc;
  --border:      #e2e8f0;  --border-strong: #cbd5e1;
  --primary:     #2563eb;  --primary-hover: #1d4ed8; --primary-fg: #ffffff;
  --success:     #15803d;  --success-bg: #f0fdf4;
  --warning:     #b45309;  --warning-bg: #fffbeb;
  --danger:      #b91c1c;  --danger-bg:  #fef2f2;   --danger-hover: #991b1b;
  --focus-ring:  #2563eb;

  /* Elevation: two shadows, not seven */
  --shadow-sm: 0 1px 2px rgb(15 23 42 / 0.06);
  --shadow-md: 0 4px 12px rgb(15 23 42 / 0.08);

  /* Motion */
  --dur-fast: 120ms; --dur-base: 200ms; --dur-slow: 320ms; --ease-out: cubic-bezier(.2,.8,.2,1);
}

@media (prefers-color-scheme: dark) {
  :root {
    --bg: #0b1220; --bg-subtle: #111a2e; --text: #e6edf7; --text-muted: #94a3b8;
    --border: #1e293b; --border-strong: #334155;
    --primary: #60a5fa; --primary-fg: #0b1220; --danger: #f87171;
  }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }
}
```

Tailwind mapping (tailwind.config.ts) — semantic names, so dark mode and rebrands are one file:

```ts
export default {
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)", subtle: "var(--bg-subtle)",
        fg: "var(--text)", muted: "var(--text-muted)",
        line: "var(--border)", "line-strong": "var(--border-strong)",
        primary: { DEFAULT: "var(--primary)", hover: "var(--primary-hover)", fg: "var(--primary-fg)" },
        danger: { DEFAULT: "var(--danger)", bg: "var(--danger-bg)", hover: "var(--danger-hover)" },
        success: { DEFAULT: "var(--success)", bg: "var(--success-bg)" },
        warning: { DEFAULT: "var(--warning)", bg: "var(--warning-bg)" },
      },
      borderRadius: { sm: "var(--radius-sm)", md: "var(--radius-md)" },
      boxShadow: { sm: "var(--shadow-sm)", md: "var(--shadow-md)" },
      transitionDuration: { fast: "120ms", base: "200ms", slow: "320ms" },
    },
  },
};
```

## Step 2 — Type

| Rule | Value |
|---|---|
| Font | **One family.** System fonts are fast and look native; one web font max if you need character |
| Sizes | 5-6 total. If you need a 7th, you're solving a hierarchy problem with a size |
| Weights | 2-3 (400, 600, maybe 700). Never 9 weights |
| Body | 16px minimum, line-height 1.5-1.6 |
| Line length | 60-75 characters. Constrain with `max-width: 68ch` |
| Headings | Sized by hierarchy, not decoration. One H1 per page |
| Numbers | Tabular figures (`font-variant-numeric: tabular-nums`) in tables and money |
| Never | All-caps for more than a label, centered body text, underlining non-links |

Hierarchy is made with **size + weight + color + space**, in that order. Not with more colors.

## Step 3 — Color

- **One primary** + neutrals + three semantic colors (success/warning/danger). That's it.
- **60/30/10:** 60% background/neutral, 30% text and secondary surfaces, 10% accent. Color is a signal,
  not decoration — if everything is colorful, nothing stands out.
- **Contrast is not optional:** 4.5:1 for normal text, 3:1 for large text and UI borders.
  Test it: DevTools → Inspect → Contrast, or `https://webaim.org/resources/contrastchecker/`.
- **Never rely on color alone** to convey meaning (red/green is invisible to ~8% of men). Add an icon or text.
- **Dark mode** via semantic tokens from day one. Retrofitting dark mode means touching every file.

## Step 4 — Spacing and layout

- **4px base scale** (4, 8, 12, 16, 24, 32, 48, 64). Pick from the scale; no `13px` padding.
- **Rhythm:** related things are closer (8px), unrelated things are further (24-32px)
- **Containers:** max-width 1200-1280px for app content, 680px for reading, 480px for forms
- **Page padding:** 16px mobile, 24-32px desktop
- **Vertical rhythm:** consistent section spacing (e.g. 32px between sections, 16px within)
- **Breakpoints (three):** `sm: 640px` (large phone/tablet), `lg: 1024px` (laptop). Mobile-first: write the
  mobile styles, then add `sm:` and `lg:` overrides.
- **Design mobile first** because most of your users are on a phone, and it forces you to prioritize.

## Step 5 — The 12 components you always need

Build these once, with **all states**, and reuse them forever:

| Component | States you must build |
|---|---|
| Button | default, hover, focus-visible, active, disabled, loading |
| Input | default, focus, filled, error (with message), disabled, hint |
| Select / dropdown | default, open, selected, error, disabled |
| Checkbox / radio / switch | unchecked, checked, focus, disabled, indeterminate |
| Card / panel | default, hover (if clickable), selected |
| Table | header, row, hover, selected, empty, loading |
| Modal / dialog | open/close animation, backdrop, focus trap, Escape |
| Toast / notification | success, error, info, warning; dismissible |
| Badge / tag | success, warning, danger, neutral |
| Tabs / nav | active, inactive, hover, focus |
| Avatar | image, initials fallback, size variants |
| Skeleton | matches the real component's size |

Every one of them: keyboard-focusable, visible focus ring, and accessible name.
This is where `frontend-craft` and `accessibility-and-inclusive-design` meet the design system.

## Step 6 — Motion

| Interaction | Duration |
|---|---|
| Hover / focus | 100-150ms |
| Dropdown, tooltip | 150-200ms |
| Modal, sheet | 200-300ms |
| Page transition | 200-300ms |
| Anything | Never > 400ms — it starts feeling slow |

- Ease-out for things entering, ease-in for things leaving
- Animate `transform` and `opacity` (cheap), not `height`/`top`/`width` (expensive)
- Motion must communicate: where a thing came from, or that something changed
- Honor `prefers-reduced-motion` (the CSS above does it globally)
- Never animate on every page load "for delight" — delight is a product that works

## Step 7 — Icons and imagery

- One icon set, one style (stroke width matters), one size grid (16/20/24)
- Icons carry meaning only with a label nearby, or an `aria-label`
- Images: explicit dimensions (prevents layout shift), modern formats (WebP/AVIF), responsive `srcset`
- Illustrations/avatars: consistent style; never mix three illustration styles on one site
- Emoji as UI icons: no. They render differently everywhere and look amateur in a product UI

## The "AI-generated look" checklist (avoid all of these)

| Tell | Do instead |
|---|---|
| Purple-blue gradient on everything | One accent color used sparingly |
| Glassmorphism / frosted blobs behind content | Solid surfaces with subtle borders |
| 5 different border radii across one screen | Two, from tokens |
| Every card with a big drop shadow | Borders for structure, shadows for elevation only |
| Centered everything | Left-aligned content, purposeful hierarchy |
| Emoji as icons | A real icon set |
| 8 font sizes and 5 weights on one page | The scale, from tokens |
| Neon-on-dark "hacker aesthetic" for a normal business app | Match the domain, not a mood board |
| Massive hero with 200px of padding and a 3-word headline | Say what it does, above the fold |
| Inconsistent button styles (3 shapes, 4 sizes) | One button component with variants |
| Zero empty states, because design only shows the happy path | Design the empty and error screens too |
| Perfectly equal columns of identical cards with no hierarchy | Vary emphasis; the eye needs an entry point |

## Non-negotiables

1. **No raw values in components.** Every color, size, and space comes from a token.
2. **One type scale, one spacing scale, one primary color.**
3. **Every component has all six states** before it's "done".
4. **Contrast passes 4.5:1** for text.
5. **Visible focus ring on every interactive element.**
6. **Mobile-first, three breakpoints.**
7. **Motion ≤ 400ms and respects reduced motion.**
8. **Semantic color tokens** so theming is a file change, not a refactor.
9. **Images have dimensions** to prevent layout shift.
10. **Screens are reviewed side by side** for drift at least once per milestone.

## Ask the human

1. "What should this feel like — calm and professional, playful, or bold and energetic? Can you name an app you want it to feel like?"
2. "What colors does your brand already use, if any?" *(if none: I'll pick a neutral, professional palette)*
3. "Do you want it to also work in dark mode, or is light fine?"
4. "Who's looking at this — mostly phones, mostly laptops, or a mix?"
5. "Is there a font you already use in your brand materials?"
6. "Do you want it to feel like other apps in your industry, or deliberately different?"

Never ask: "what's your radius token?", "8pt or 4pt grid?", "which easing curve?", "HSL or OKLCH?".

## Anti-patterns

| Anti-pattern | Cost | Do instead |
|---|---|---|
| Hardcoded hex values in 40 files | Rebrand = 40 file edits | Semantic tokens |
| `text-[13px] p-[13px] mt-[7px]` | Nothing lines up | The spacing scale |
| A new button style per screen | Inconsistent, unmaintainable | One component |
| Copying a component from another project with its own colors | Visual drift | Rebuild from tokens |
| Building 30 components before building a screen | Over-engineering | Build what the screen needs, extract on second use |
| Dark mode added later | Every file touched | Tokens from day one |
| Shadows as the only separator | Muddy on dark backgrounds | Borders + subtle elevation |
| Decorative animation everywhere | Feels slow, distracts | Motion with a purpose |
| Ignoring the empty/error screens in design | Those are the screens users hit first | Design all six states |

## Definition of done

- [ ] Token file exists: type, spacing, color, radius, shadow, motion — and components use only tokens
- [ ] One type scale (≤6 sizes), one font, ≤3 weights
- [ ] Spacing snaps to a 4px scale; no arbitrary values
- [ ] Semantic colors with light and dark values; contrast verified at 4.5:1
- [ ] The 12 core components exist with all states, keyboard focus, and accessible names
- [ ] Mobile-first with three breakpoints; the mobile layout was designed, not just shrunk
- [ ] Motion ≤400ms, honors reduced motion
- [ ] Images sized, modern formats, no layout shift
- [ ] Side-by-side screenshot review shows no drift between screens
- [ ] A new screen can be built using existing components only

## Works with

- `frontend-craft` — the states these components implement
- `accessibility-and-inclusive-design` — contrast, focus, semantics
- `ux-writing-and-onboarding` — the words inside these components
- `project-blueprint` — where the component folder lives
- `performance-and-caching` — fonts, images, and bundle size
