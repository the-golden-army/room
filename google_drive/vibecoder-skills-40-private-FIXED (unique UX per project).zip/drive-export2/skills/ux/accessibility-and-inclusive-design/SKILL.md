---
name: accessibility-and-inclusive-design
description: Use on every screen that ships, and any time someone asks about accessibility, WCAG, keyboard support, or screen readers. Covers semantics, keyboard navigation, focus management, forms, contrast, motion, touch targets, zoom, and the five-minute manual test that catches what automated tools miss. Roughly 20 minutes of work per feature, and the difference between "works for everyone" and "silently excludes 15% of your users" (plus enterprise deals and public-sector contracts).
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# accessibility-and-inclusive-design

## Promise

Anyone can use what you build — with a keyboard, a screen reader, one hand, in bright sunlight, at 200%
zoom, or with colour-blindness. And you can prove it with a five-minute test, not a certification.

## When to use

**Every screen, every time.** Build it in, don't bolt it on.

Especially:
- Anything a user interacts with (forms, modals, menus, tables, media)
- Building or buying a component library
- Selling to businesses, governments, universities, or healthcare (they will ask)
- Someone reports "I can't click that" / "the screen reader says button"
- Before launch (part of `production-readiness`)

## When NOT to use

- Never skip it. But you can do the 5-minute version on trivial screens.

## The 60-second version

```
1. Use real HTML: <button>, <a href>, <label>, <nav>, <main>, <h1>-<h3>, <table>.
   A <div onclick> is invisible to a keyboard and a screen reader.
2. Everything interactive is reachable and operable with Tab / Enter / Space / Escape / arrows.
3. Focus is always visible. Never `outline: none` without a replacement.
4. Every form field has a real <label>. Errors are announced and linked to the field.
5. Images have alt text — or `alt=""` if decorative.
6. Contrast: 4.5:1 for text, 3:1 for large text and meaningful borders.
7. Never colour alone: pair it with text or an icon.
8. Announce dynamic changes (toasts, errors, loading) with a live region.
9. Touch targets ≥ 44x44px with spacing.
10. Respect "reduce motion". Don't block zoom.
```

## Step 1 — Semantics (free accessibility)

The browser gives you most of this for free if you don't fight it.

| ❌ | ✅ |
|---|---|
| `<div onclick="save()">Save</div>` | `<button onClick={save}>Save</button>` |
| `<div class="link">` | `<a href="/bookings">Bookings</a>` |
| `<span onClick>` for navigation | `<a>` with a real `href` (middle-click, open-in-new-tab, and screen readers all work) |
| `<div class="heading">` | `<h2>` |
| Text next to an input | `<label for="email">Email</label>` |
| Divs styled as a table | `<table>` with `<th scope="col">` |
| `<div role="button">` | An actual `<button>` |

Landmarks: `<header>`, `<nav>`, `<main>`, `<aside>`, `<footer>`, and one `<h1>` per page with a logical
heading order (h1 → h2 → h3, no skipping levels for visual reasons).

ARIA is the **last** resort, not the first. `role="button"` on a div means you now owe it keyboard handling,
focus, and states that `<button>` had for free.

## Step 2 — Keyboard

| Key | Expected |
|---|---|
| `Tab` / `Shift+Tab` | Moves through interactive elements in a logical (usually visual) order |
| `Enter` | Activates buttons and links |
| `Space` | Activates buttons, toggles checkboxes |
| `Escape` | Closes modals, menus, popovers; returns focus to the trigger |
| `Arrows` | Move within composite widgets (tabs, menus, radio groups, listboxes) |
| `Home`/`End` | First/last item in a list |

Rules:
- **No keyboard trap.** Focus can always move out (except inside a modal, which traps intentionally and
  closes with Escape).
- **Focus order matches visual order.** If you used CSS to rearrange things (`order`, `grid-area`), fix the
  DOM order instead.
- **Skip link** as the first focusable element: "Skip to content" → `#main`.
- **Never remove focus outlines** without replacing them:
  ```css
  :focus-visible { outline: 2px solid var(--focus-ring); outline-offset: 2px; border-radius: var(--radius-sm); }
  ```
- **Custom widgets** (dropdown, combobox, tabs) follow the ARIA Authoring Practices pattern. Don't invent.

## Step 3 — Focus management (the thing SPAs get wrong)

```tsx
// 1. On route change, move focus to the new page's main heading (or announce the new page title)
useEffect(() => {
  mainHeadingRef.current?.focus();      // element needs tabIndex={-1}
}, [pathname]);

// 2. Modal: focus the first useful element on open, trap focus, restore on close
function Modal({ open, onClose, children }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement;
    ref.current?.querySelector<HTMLElement>("input, button, [href]")?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); previous?.focus(); };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div ref={ref} role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <h2 id="modal-title">…</h2>{children}
    </div>
  );
}

// 3. After deleting a row, move focus somewhere sensible (next row, or the list heading).
//    Never leave focus on a removed element — it falls back to <body> and the user is lost.
```

## Step 4 — Forms

```tsx
<label htmlFor="email">Email</label>
<input
  id="email" name="email" type="email"
  autoComplete="email"                       // browsers and password managers can help
  required aria-required="true"
  aria-invalid={!!error}
  aria-describedby={error ? "email-error" : "email-hint"}
/>
<p id="email-hint">We'll only email you about this booking.</p>
{error && <p id="email-error" role="alert">{error}</p>}
```

Rules:
- Every input has a `<label>` (visible, or `aria-label` only if there's genuinely no room — icon buttons)
- Placeholders are **not** labels
- Group radio/checkbox sets in `<fieldset>` with a `<legend>`
- Errors: text (never colour alone), linked via `aria-describedby`, announced with `role="alert"` if they
  appear after an action
- Mark required fields in text, not just with a red asterisk
- `autocomplete` attributes on name/email/address/card fields (huge win, tiny effort)
- Don't disable the submit button until after a submit attempt (a disabled button gives no feedback)

## Step 5 — Images, media, icons

| Case | Alt text |
|---|---|
| Informative image | Describe the content: `alt="Two people shaking hands at the front desk"` |
| Decorative | `alt=""` (empty, not missing) — so screen readers skip it |
| Image inside a link/button | Describe the **action**: `alt="Download invoice"` |
| Chart | Alt text summary + the data available in text nearby |
| Icon with a visible label | `aria-hidden="true"` on the icon |
| Icon-only button | `aria-label="Close"` on the button |
| Video | Captions (not just auto-generated), plus a transcript for long content |
| Audio | Transcript |
| Anything that moves or flashes | Don't autoplay; provide a pause control; no flashing > 3 times/second |

## Step 6 — Colour, contrast, motion

- **Contrast:** 4.5:1 for body text, 3:1 for large text (≥24px or ≥19px bold) and for meaningful UI
  component boundaries (input borders, focus rings, icons that carry meaning)
- **Never colour alone:** "the red row failed" breaks for colour-blind users and in greyscale printing.
  Add text ("Failed") or an icon.
- **Links in body text** should be underlined or otherwise distinguishable without colour
- **Motion:** honour `prefers-reduced-motion` (see `design-system-and-visual-language`)
- **Parallax, autoplaying carousels, and scroll-jacking:** provide a way to stop them
- **Dark mode** should be a real theme, not inverted colours that fail contrast

## Step 7 — Touch, zoom, and reflow

- **Touch targets:** ≥ 44×44 CSS pixels, with ≥ 8px between them. Icon buttons need padding, not just an icon.
- **Never disable zoom:** no `user-scalable=no` or `maximum-scale=1` in the viewport meta tag
- **Reflow at 320px:** content works at 320px wide without horizontal scrolling (except data tables, which
  may scroll horizontally)
- **200% zoom:** usable, no clipped content
- **Orientation:** works in both portrait and landscape (don't lock it)
- **Hover-only interactions** need a tap equivalent. Tooltips on hover = no mobile access: make the info
  visible or tappable.

## Step 8 — Dynamic content

```tsx
// Announce results politely (waits for a pause)
<div role="status" aria-live="polite" aria-atomic="true">
  {loading ? "Loading bookings" : `${bookings.length} bookings found`}
</div>

// Interrupt for things that need attention
<div role="alert">{errorMessage}</div>
```

- Loading/empty/error states must be perceivable non-visually (see `frontend-craft`)
- Toasts: `role="status"` for info, `role="alert"` for errors
- Infinite scroll: announce when new items load, and always provide a "load more" fallback
- Page title updates on route change (screen reader users rely on it)

## The five-minute manual test

Automated tools catch ~30% of issues. Do this before every release:

```
1. KEYBOARD ONLY. Put the mouse down. Tab through the whole screen.
   Can you reach everything? Can you see where you are? Can you operate every control?
   Can you escape every overlay? → Fix anything you can't do.

2. SCREEN READER (60 seconds).
   macOS: Cmd+F5 (VoiceOver). Windows: Ctrl+Alt+N (NVDA).
   Tab through the main flow. Do buttons announce as "button"? Do images announce something useful?
   Does the form tell you which field is which? → Fix what's silent or nonsense.

3. ZOOM to 200%. Anything clipped, overlapping, or unreachable? → Fix.

4. GREYSCALE (DevTools → Rendering → Emulate vision deficiencies → Achromatopsia).
   Can you still tell success from error, selected from unselected? → Add text or icons.

5. AUTOMATED: axe DevTools or Lighthouse accessibility. Fix everything it flags —
   but never treat a green score as "accessible".
```

## Non-negotiables

1. **Real HTML elements, not divs with handlers.**
2. **Keyboard operable, with always-visible focus.**
3. **Every input has a label; every error is announced and linked.**
4. **Contrast passes 4.5:1 / 3:1.**
5. **Never colour alone; never motion alone; never hover alone.**
6. **Focus is managed on route change, on modal open, and after destructive actions.**
7. **Zoom is not disabled; touch targets are ≥44px.**
8. **Alt text on meaningful images; `alt=""` on decorative ones.**
9. **Dynamic changes are announced via live regions.**
10. **The five-minute manual test runs before every release.**

## Ask the human

1. "Do you know if any of your users have trouble seeing, hearing, or using a mouse?" *(if yes, ask which — it focuses the work)*
2. "Are you planning to sell this to companies, schools, governments, or hospitals?" *(they often require it contractually)*
3. "Where are your users? Some countries legally require this for public and commercial services."
4. "Do you want me to make this work with screen readers from the start, or is keyboard support enough for now?" *(recommend: both, it's 20 minutes)*

Never ask: "WCAG 2.1 AA or 2.2 AA?", "should we add ARIA landmarks?", "what's your conformance target?".

## Anti-patterns

| Anti-pattern | Who it breaks | Do instead |
|---|---|---|
| `<div onClick>` | Keyboard + screen reader users entirely | `<button>` |
| `outline: none` with no replacement | Everyone using a keyboard | `:focus-visible` ring |
| Placeholder as the only label | Screen readers, memory, translation | Real `<label>` |
| Colour-only status | ~8% of men, anyone in bright sun | Text/icon too |
| `user-scalable=no` | Low-vision users | Let people zoom |
| Icon-only button with no label | Screen readers announce "button" | `aria-label` or visible text |
| Modal that can't be closed with Escape | Keyboard users get stuck | Escape + focus restore |
| Focus lost after deleting an item | Everyone using a keyboard or reader | Move focus deliberately |
| `tabIndex={0}` on everything | Makes Tab order meaningless | Only interactive elements |
| Auto-playing video with sound | Everyone, plus screen reader users | No autoplay; controls; captions |
| "We'll do accessibility later" | Later is a rewrite | Build it in, 20 min per feature |
| Green Lighthouse score = done | 70% of issues need a human | The five-minute test |

## Definition of done

- [ ] Every interactive element is a real HTML control, keyboard-reachable, with a visible focus ring
- [ ] Full keyboard pass completed with no traps; Escape closes overlays; focus restored after modals
- [ ] Every input has an associated label; errors are text, linked with `aria-describedby`, announced
- [ ] Contrast verified (4.5:1 text / 3:1 large + UI); nothing relies on colour alone
- [ ] Images have meaningful alt text or `alt=""`; media has captions/transcripts where relevant
- [ ] Touch targets ≥44px; spacing adequate
- [ ] Zoom to 200% and 320px width both work; no horizontal scroll of the page
- [ ] `prefers-reduced-motion` honoured; no autoplay with sound
- [ ] Dynamic updates announced via live regions; page titles update on route change
- [ ] axe/Lighthouse run clean **and** the five-minute manual test passed

Full pass/fail audit: [`references/a11y-checklist.md`](references/a11y-checklist.md).

## Works with

- `frontend-craft` — states must be perceivable by everyone
- `design-system-and-visual-language` — tokens, focus rings, contrast, motion
- `ux-writing-and-onboarding` — plain language and meaningful labels
- `production-readiness` — part of the launch gate
- `code-review-and-audit` — the accessibility section of a review
