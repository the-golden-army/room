# Accessibility checklist (pass/fail)

Run per screen, or per feature. ~10 minutes once you're used to it.
`PASS` / `FAIL` / `N/A`. Anything `FAIL` in the **Blocking** group holds the release.

---

## Blocking

```
STRUCTURE
[ ] One <h1> per page; heading levels descend without skipping
[ ] Landmarks present: header / nav / main / footer
[ ] Page <title> is unique and updates on route change
[ ] <html lang="en"> (or the correct language) is set

KEYBOARD
[ ] Every interactive element is reachable with Tab, in visual order
[ ] Focus is visible on every focusable element (:focus-visible ring)
[ ] No keyboard trap (except a modal, which traps intentionally and closes on Escape)
[ ] Enter activates buttons/links; Space activates buttons and toggles checkboxes
[ ] Escape closes modals, menus, popovers, and returns focus to the trigger
[ ] A "Skip to content" link is the first focusable element
[ ] Custom widgets (dropdown, tabs, combobox) support arrow keys per ARIA APG
[ ] Focus moves to the new content after navigation and after deleting an item

SEMANTICS
[ ] Buttons are <button>, links are <a href>, not <div onclick>
[ ] Icon-only controls have an accessible name (visible text or aria-label)
[ ] Decorative icons/images are aria-hidden or alt=""
[ ] Informative images have descriptive alt text
[ ] Data tables use <table> with <th scope>
[ ] Lists are <ul>/<ol>, not a stack of divs

FORMS
[ ] Every input, select and textarea has an associated <label for>
[ ] No placeholder-only labelling
[ ] Related radios/checkboxes are in a <fieldset> with a <legend>
[ ] Required fields marked in text (not colour/asterisk alone)
[ ] Errors: visible text + aria-describedby + aria-invalid + role="alert" when they appear
[ ] autocomplete attributes on name/email/phone/address/payment fields
[ ] Submit is not permanently disabled before any input

CONTRAST & COLOUR
[ ] Body text >= 4.5:1; large text (>=24px / 19px bold) >= 3:1
[ ] Focus ring and input borders >= 3:1 against their background
[ ] No information conveyed by colour alone (errors, status, selected states)
[ ] Links in body text distinguishable without colour
[ ] Checked in dark mode too, if supported
```

## High (fix before marketing / enterprise sales)

```
DYNAMIC CONTENT
[ ] Loading, empty, error and success states are announced (role="status" / role="alert")
[ ] Toasts use role="status" (info) or role="alert" (error)
[ ] Infinite scroll announces new content and offers a "load more" fallback
[ ] Async button states are announced (aria-busy, or a live region)
[ ] Modals: focus trapped, aria-modal, labelled by their heading, background inert

MOTION & MEDIA
[ ] prefers-reduced-motion honoured for all non-essential animation
[ ] Nothing flashes more than 3 times per second
[ ] Autoplaying media: none with sound; any motion has a pause control
[ ] Video has captions; long audio/video has a transcript
[ ] Parallax / scroll-jacking is optional or removed

TOUCH & ZOOM
[ ] Touch targets >= 44x44 CSS px, with >= 8px spacing
[ ] user-scalable=no / maximum-scale=1 NOT present
[ ] Usable at 200% zoom with no clipped content
[ ] No horizontal scrolling at 320px width (tables may scroll horizontally)
[ ] Hover-only interactions have a tap equivalent
[ ] Works in portrait and landscape
```

## Medium (backlog, but real)

```
[ ] Text spacing overrides work (line-height 1.5, paragraph spacing 2em) without clipping
[ ] Content readable at 400% zoom / reflow
[ ] Error messages suggest a correction, not just a failure
[ ] Time limits are adjustable or absent
[ ] Status changes are announced without stealing focus
[ ] Form data survives a validation error
[ ] Heading structure makes sense when read as an outline
[ ] Link text makes sense out of context (no bare "click here" / "read more")
[ ] Language of any foreign-language passage is marked
[ ] Focus order is logical after CSS reordering (order / grid / flex)
[ ] No duplicate IDs anywhere
[ ] PDFs and downloads are themselves accessible, or a HTML alternative exists
```

---

## The 5-minute run (every release)

```bash
# 1. Automated (catches ~30%)
npx axe http://localhost:3000 --tags wcag2a,wcag2aa
npx lighthouse http://localhost:3000 --only-categories=accessibility --view

# 2. Keyboard: mouse down. Tab through. Everything reachable? Focus visible? Escape works?
# 3. Screen reader: macOS Cmd+F5 · Windows NVDA Ctrl+Alt+N · VoiceOver on iOS: Settings shortcut
#    Navigate the main flow. Do buttons say "button"? Do fields say their name?
# 4. Zoom: browser zoom to 200%. Anything clipped?
# 5. Greyscale: DevTools → Rendering → Emulate vision deficiencies → Achromatopsia.
#    Can you still tell success from error?
```

## Recording the result

```markdown
## Accessibility review — 2026-10-20 — commit a1b2c3d
Scope: signup, dashboard, booking flow. Method: manual keyboard + VoiceOver + axe.

Blocking FAILs: 2
1. Modal: focus not trapped, Escape doesn't close it, focus not restored. File: components/Modal.tsx
2. Three icon-only buttons have no accessible name. Files: components/IconButton.tsx usages

High FAILs: 3
- Toast notifications aren't announced (add role="status")
- Chart has no text alternative
- Autocomplete missing on the signup form

Passed: keyboard navigation, contrast (all >= 5.2:1), headings, landmarks, zoom to 200%

Not tested: screen reader on Android, captions (no video yet), 400% zoom
```

"Not tested" is as important as "passed" — never imply coverage you didn't do.
