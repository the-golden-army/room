---
name: distinctive-visual-style
description: Use when designing any web page, landing page, or UI whose look matters — and especially to avoid the AI-generated "vibe coded" look: blue-cyan gradients, dark navy backgrounds, emoji as icons, everything centered, identical rounded cards, glow shadows, fake terminal windows. Teaches how to derive a palette and typographic voice from the product's actual subject, build hierarchy from scale instead of colour, and add one signature element only this product would have. Includes five complete non-slop style recipes and a seven-step "does this look AI?" test.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# distinctive-visual-style

## Promise

Someone lands on the page and knows in three seconds what kind of product this is — and remembers one thing
about it ten seconds after leaving. It does not look like it was generated.

> **Scope:** `design-system-and-visual-language` is about *internal consistency* (tokens, components,
> states). This skill is about *external identity* — making a thing look like it was designed by someone
> with an opinion, for this specific product. Use both; they don't overlap.

## When to use

- Building any public page where being taken seriously matters
- "Make it look good" / "make it look less AI" / "it looks like a template"
- Reviewing a design before launch
- A page has no focal point, or looks like 1,000 other pages
- Choosing colours, fonts, or a layout for a new project

## When NOT to use

- Internal tools where nobody cares (still: no emoji, no gradients — it costs nothing)

## The 60-second version

```
1. DERIVE, DON'T DECORATE. The palette comes from the product's subject, not a mood board.
   Ask: "what physical object or document is this product's ancestor?" Then steal from that.
2. ONE TYPOGRAPHIC VOICE WITH CHARACTER. Two faces max: one with personality (display) + one neutral
   (working). Never two neutral sans-serifs — that is the AI default.
3. HIERARCHY FROM SCALE, NOT COLOUR. Real ratios (1 : 1.6 : 2.6+). If colour is doing the
   hierarchy, the design collapses in greyscale.
4. NEUTRAL 90 / ACCENT 10. One accent, used on maybe 5% of the surface. Not six colours doing six jobs.
5. RULES AND GRIDS, NOT CARDS AND SHADOWS. Hairlines, columns, whitespace. Shadows are for things
   that are genuinely floating.
6. ASYMMETRY. Don't centre everything. A left rail, a ragged right edge, an off-balance grid.
7. ONE SIGNATURE ELEMENT. Something only this product would have. This is what makes it memorable
   and impossible to mistake for a template.
8. CRAFT AT THE SMALL SCALE. Tabular numerals, hung quotes, hover and focus states, a real favicon,
   a real 404, a print stylesheet. AI ships none of these, and their absence is the tell.
```

## Part 1 — The twenty tells of an AI-designed page

Score your page. **Three or more and it reads as generated.**

| # | Tell | Why it happens |
|---|---|---|
| 1 | Blue→cyan or purple→pink gradient text on the headline | "Gradient text" reads as *designed* in isolation |
| 2 | A soft radial glow behind the hero | Every template ships one |
| 3 | Emoji used as icons or section markers (🚀 🔒 ✨) | Free iconography, zero taste |
| 4 | Inter / system-ui for everything, weight 700-800, tight tracking | The statistical average font choice |
| 5 | Everything centred: headline, subhead, buttons, cards | Centring is the safe default |
| 6 | 12-16px border radius on every container | One value applied everywhere |
| 7 | Three identical feature cards, each: icon + bold title + two lines | The safest possible layout |
| 8 | An eyebrow pill above the headline ("✨ Introducing…") | Template furniture |
| 9 | Gradient CTA button with a coloured glow shadow | Two tells in one |
| 10 | A fake browser or terminal window with three dots | Cute, and instantly dated |
| 11 | A trust bar with 3-5 bold numbers in a row | Template furniture |
| 12 | One accent colour doing six jobs (text, button, border, chip, glow, icon) | No colour discipline |
| 13 | Monospace chips/tags used as decoration | Mono-as-style, not mono-as-data |
| 14 | Testimonial cards with circular avatars | Template furniture |
| 15 | No focal point — every element has equal weight | Nothing was prioritised |
| 16 | Drop shadows on flat containers | Shadows without elevation |
| 17 | Every gap is the same (usually 24px) | No rhythm |
| 18 | Every section the same height and shape | No pacing |
| 19 | Gradient mesh / blob backgrounds | 2023 called |
| 20 | Section headings all the same size and colour | No hierarchy |

**Why models converge on this:** they're trained and RLHF'd on a narrow set of high-performing landing
pages, they optimise for "looks designed" rather than "looks specific", and they're given no constraints —
so they return the average of everything they've seen. They also generate *structure before content*, so the
layout is generic and the copy is fitted to it afterwards. And they can't see the result, so errors of
taste compound with nobody to catch them.

**You cannot prompt your way out of this.** "Make it modern and clean" produces the average again. You need
constraints.

## Part 2 — The eight moves

### 1. Derive, don't decorate

Ask: **"What physical object or document is this product's ancestor?"** Then take the palette from it.

| Product | Ancestor | Palette follows |
|---|---|---|
| Accounting tool | Ledger paper, cheque | Cream paper, ink blue, tabular numerals, rules |
| Security product | Its own severity scale | Ink + the red/amber/green it already uses |
| Gym / fitness | Terrazzo, sweat, signage | Off-white, high-contrast black, one hot accent |
| Restaurant | Menu card, letterpress | Warm cream, deep green, serif display |
| Developer tool | Spec sheet, datasheet, manual | Paper or near-black, mono labels, hairline tables |
| Photography | Gallery wall, darkroom | Near-black, generous white space, no chrome |
| Health | Pharmacy, clinical forms | White, cool grey, one trustworthy blue |

This is the whole trick. It produces a palette no template has, and it's *defensible* — you can explain
every colour.

### 2. One typographic voice with character

Two faces, maximum:

- **Display** (headlines): something with a shape. A serif (Georgia, Iowan Old Style, Fraunces, Instrument
  Serif), a distinctive grotesk (Archivo, Space Grotesk, Inter Tight at 900), or a condensed face.
- **Working** (body/UI): neutral and boring on purpose — system-ui, Inter, Söhne.
- **Optional third**: a monospace, used **only for data** (numbers, code, labels), never as decoration.

Rules:
- **Large type wants light weight.** A 64px headline at weight 400 in a serif is more confident than the
  same size at 800 in a sans. Heavy-at-large-size is the AI default.
- Never pair two neutral sans-serifs. That's not a choice, it's a default.
- One display face, used consistently. Not four.

### 3. Hierarchy from scale, not colour

Pick a ratio and commit:

```
Display   64px   (weight 400, tracking -0.02em)
Title     34px   (weight 500)
Heading   21px   (weight 600)
Body      17px   (line-height 1.65)
Label     11px   (mono, uppercase, tracking 0.12em)
```

That's roughly **1 : 1.9 : 3 : 3.8 : 5.8**. AI designs hover around 1 : 1.2 and compensate with colour and
weight, which is why they look loud and flat at the same time.

Test: screenshot it, desaturate it. If the hierarchy survives, it's built on scale. If it collapses, colour
was doing the work.

### 4. Neutral 90 / accent 10

```
90%   paper / ink / greys
10%   ONE accent
```

The accent gets maybe 5% of the painted surface: the primary button, a rule, a number, a severity dot. Not
the headline, not the borders, not the chips, not the glow.

If you need a second colour, make it a *severity* colour with a job (error/status), not decoration.

### 5. Rules and grids, not cards and shadows

- **Hairlines** (1px, low-contrast) separate things. `border-bottom: 1px solid var(--rule)`.
- **Whitespace and columns** create grouping.
- **Cards** (a filled container with a radius and a shadow) are for things that are genuinely discrete:
  a product in a grid, a pricing tier, a dashboard widget. Not for "here is a paragraph".
- **Shadows** only for things that float: modals, popovers, dropdowns, sticky headers.

If every block on the page is a rounded card with a shadow, you've built a deck of identical tiles.

### 6. Asymmetry

- Left-align text. Ragged right. (Centred paragraphs are for wedding invitations.)
- Use an asymmetric grid: a narrow left rail for labels/numbers, a wide column for content.
- Let sections have different heights and rhythms.
- Off-balance the hero: big type on the left, something smaller on the right, or no right at all.

Centred hero + centred subhead + centred buttons + centred row of three cards is the AI signature.

### 7. One signature element

Something only this product would have. It's what makes the page memorable, and it's the single most reliable
cure for "looks like a template".

| Product | Signature |
|---|---|
| Skills library | A numbered index / spec sheet of everything included, set as a dense typographic table |
| Audit product | The severity scale (🔴 🟠 🟡) used as the page's own visual language |
| Booking app | A real availability grid, rendered honestly |
| Analytics | A real chart with real numbers, tiny and dense |
| Marketplace | A price list, set like a menu |
| Developer tool | A genuine transcript, set as text — not a fake terminal window |

### 8. Craft at the small scale

The details AI never ships, and their absence is what your eye is actually noticing:

```
[ ] font-variant-numeric: tabular-nums on every table and price
[ ] Real hover, focus-visible and active states on every interactive thing
[ ] Hanging punctuation on blockquotes and large quotes (“ ”)
[ ] A favicon that isn't a letter in a rounded square
[ ] A 404 page with the same design discipline as the homepage
[ ] Consistent vertical rhythm (a baseline multiple, not "24px everywhere")
[ ] Print styles (or at least: don't look broken when printed)
[ ] Real copy — no lorem, no placeholder numbers, no "Lorem ipsum" in a demo
[ ] Selection colour set (::selection)
[ ] Numbers that are real and specific ("34 skills", not "dozens")
```

## Part 3 — The process

```
1. NAME THE ANCESTOR      "what physical object is this?" → palette direction
2. WRITE THREE RULES      e.g. "no gradients", "no emoji", "no radius above 4px"
                          Constraints are what make it specific. Write them down first.
3. SKETCH THREE DIRECTIONS  in words, not pixels — you must propose 3 DISTINCT directions
                          from references/style-recipes.md, each with different ancestor,
                          palette, type pairing, radius, and layout. Never reuse the same
                          recipe you used on the last project. Present all 3 to the human
                          and ask "which direction?" — do not auto-pick R1.
4. PICK ONE AND COMMIT    Human picks, or if they say "you pick" choose the one whose
                          ancestor best matches THIS product's domain — document why the
                          other two were rejected. Consensus designs are average designs.
5. SET THE SCALE          type + spacing, before any colour
6. ADD COLOUR LAST        neutrals first, then one accent
7. RUN THE SEVEN TESTS    below
8. WRITE THE STYLE BRIEF  so the next person (or agent) stays consistent
```

### Style uniqueness enforcement (no two projects share a style)

This skill fixes the "same UI twice" problem. Two different products must never ship the same palette + type + layout.

**Rules:**
- **Before choosing, check** `docs/STYLE.md` in the current repo — if it exists, you are updating, not picking anew. If this is a new project, check if the human mentions a previous project used R1/R2/etc. — if so, eliminate that recipe from consideration unless they explicitly ask for it.
- **You must generate 3 directions that pass the "different at 10 feet" test:** put them side by side, can a non-designer tell they are different without reading? If not, they are not distinct enough — vary: (a) paper vs ink background, (b) serif display vs grotesk vs mono, (c) hairline-table vs offset-card vs full-bleed, (d) 2px radius vs 0 vs 6px.
- **Never default to R1 Paper & Ink.** It is the most common AI fallback. Only pick it when the ancestor is literally paper/ledger/manual — prove it with one sentence.
- **Derive, don't copy tokens:** the hex values in `references/style-recipes.md` are starting points — shift them to match the product's real ancestor colour (e.g., a booking app's ancestor is a calendar card #FFEEE2, not ledger cream #F5F3EE). Document the shift in `docs/STYLE.md` under PALETTE.
- **Record rejection:** in `docs/STYLE.md`, add `REJECTED:` line listing the 2 directions not chosen and why — this prevents the next agent from reverting to the average.

### The style brief (one page, put it in `docs/STYLE.md`)

```markdown
# Style — <product>

ANCESTOR:        ledger paper + a stamp
PALETTE:         paper #F5F3EE · ink #141310 · mute #6B675E · rule #D9D5CB · accent #C4340B
                 accent is used for: primary button, section numbers, severity dots. Nothing else.
TYPE:            display = Georgia 400 (-0.02em) · body = system-ui 17/1.65 · label = mono 11px
SCALE:           64 / 34 / 21 / 17 / 11
LAYOUT:          12-col, content in cols 1-8, left rail for numbers, hairlines between rows
RADIUS:          2px. Nothing else.
SHADOW:          none. Elevation is expressed with a border and a hairline.
SIGNATURE:       a numbered index of everything in the product, set as a dense table
BANNED:          gradients · emoji · centred body text · radius > 4px · glow shadows ·
                 fake browser/terminal chrome · accent on more than 5% of the surface
```

## Part 4 — The seven tests

Run these before you ship a page. All seven, honestly.

| # | Test | Pass looks like |
|---|---|---|
| 1 | **Squint** — blur your eyes at the page | One thing clearly dominates. If it's a uniform grid of rectangles, fail. |
| 2 | **Logo off** — remove the name and logo | Still recognisably this product. If it could be any of 1,000 SaaS tools, fail. |
| 3 | **Greyscale** — desaturate | Hierarchy survives. If it flattens, colour was doing the work. |
| 4 | **Ten seconds** — show it to someone, then ask what they remember | They name one specific thing. If "nothing" or "it was blue", fail. |
| 5 | **The 2015 test** | Would this have looked modern in 2015? Gradients, glows, glass, drop shadows → yes → fail. |
| 6 | **Read it out loud** | The headline is a real sentence a human would say. Marketing gas → fail. |
| 7 | **The details** | Hover states, focus rings, tabular numbers, favicon, 404, print. Four of six or fail. |

## Non-negotiables

1. **No gradient text. Ever.**
2. **No emoji as design elements.** (In copy, rarely; as icons, never.)
3. **No glow shadows behind the hero.**
4. **One accent colour, on ~5% of the surface.**
5. **A real type ratio (≥1.5 between levels), not weight-and-colour fake hierarchy.**
6. **Left-aligned text, asymmetric layout.**
7. **No fake browser or terminal chrome.**
8. **Shadows only on things that float.**
9. **The palette is derivable from the product** — you can explain every colour in one line.
10. **One signature element** that only this product would have.
11. **Tabular numerals, focus states, favicon, 404.** Non-optional.
12. **The style brief exists**, so the next change doesn't drift back to the average.
13. **No two projects share the same style without explicit human approval** — you proposed 3 directions, human picked one, and you recorded the 2 rejected.
14. **Never ship the example tokens verbatim** — every hex in the final `docs/STYLE.md` is shifted to match THIS product's ancestor, with a one-line justification per colour.

## Ask the human

1. "If this product were a physical object or a printed document, what would it be?" *(drives everything)*
2. "Name a brand or a product whose design you like. What specifically about it — the colours, the density, the type?"
3. "Should this feel calm and authoritative, loud and confident, warm and human, or cold and technical?"
4. "Who's looking at it — developers, consumers, procurement teams, your mum?" *(each forgives different things)*
5. "Is there an existing brand (logo, colours, a font) I have to match?"
6. "Do you want something that looks like everyone else in your category, or deliberately different?" *(recommend: different — same-looking is invisible)*

Never ask: "what hex codes do you want?", "serif or sans-serif?", "which radius?" — decide, show them one
direction, and explain the ancestor it came from.

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| "Modern and clean" as a brief | That's the average, by definition | Name the ancestor and write three constraints |
| Starting from colour | You'll pick the AI palette | Set the type scale first, colour last |
| Four fonts "for variety" | Incoherent | Two: one display, one working |
| A committee design | Averages into slop | One person picks, commits, documents |
| Copying a competitor | Invisible | Deliberately different in one dimension |
| Decorating a template | Always looks like the template | Structure from the content, not from a layout |
| "Make it pop" | Glow, gradient, emoji | Increase contrast or scale instead |
| Cards for everything | A deck of identical tiles | Hairlines, columns, whitespace |
| Centring for balance | Centring for laziness | Asymmetric grid |
| Ignoring the details test | The absence is what reads as AI | Tabular numbers, focus states, favicon, 404 |

## Definition of done

- [ ] The palette is explained by the product's ancestor, in one line each
- [ ] Two type faces: one display with character, one neutral working face
- [ ] Type scale has real ratios (≥1.5 between levels); hierarchy survives greyscale
- [ ] One accent colour on ~5% of the surface
- [ ] Hairlines and columns instead of cards-and-shadows where possible; no shadow on flat surfaces
- [ ] Asymmetric layout; no centred body copy
- [ ] One signature element specific to this product
- [ ] Zero items from the twenty-tell list
- [ ] Details done: tabular numerals, hover/focus/active states, favicon, 404, print
- [ ] All seven tests passed, including "what do you remember in ten seconds?"
- [ ] `docs/STYLE.md` written so the next change doesn't drift — includes `REJECTED:` line with 2 directions not chosen
- [ ] Uniqueness check passed: this palette + type + layout + signature is distinguishable at 10 feet from any other project you've built for this human — not the same hex, not the same display font, not the same layout grid

## Reference

[`references/style-recipes.md`](references/style-recipes.md) — five complete, ready-to-use directions
(colours, type stacks, radius, shadow policy, layout, signature element) that are **not** the AI default,
each with the constraints that keep them intact.

## Works with

- `design-system-and-visual-language` — the tokens and components that implement this
- `ux-writing-and-onboarding` — the words; ugly copy breaks a good layout
- `frontend-craft` — the states these components need
- `seo-and-growth-basics` — landing pages that convert and look like a real company
- `accessibility-and-inclusive-design` — contrast, focus, and the greyscale test
- `code-review-and-audit` — the "does this look AI?" pass on someone else's page
