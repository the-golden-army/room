# Five style recipes that don't look generated

Each is a complete, copy-paste direction: colours with **jobs**, type stacks, radius, shadow policy, layout,
signature element, and the banned list that keeps it from drifting back to the average.

Font stacks are given twice: a **web-font** version (best) and a **system-font** version (zero network
requests, still not the AI default). Use the system one if you can't load web fonts — the *pairing and the
scale* matter more than the specific face.

Every recipe works in both light and dark unless noted. Pick one per product, not per page.

---

## R1 — Paper & Ink (editorial, authoritative)

**Use for:** developer tools, documentation, professional services, anything that needs to feel like it was
written by someone who knows. **The ancestor:** a printed manual, a ledger, a broadsheet.

```css
:root{
  --paper:#F5F3EE;  --ink:#141310;  --mute:#6B675E;  --rule:#D9D5CB;  --rule-soft:#E7E3D9;
  --accent:#C4340B;            /* vermilion — used on ~4% of the surface */
  --sev-red:#C4340B; --sev-amber:#A9701A; --sev-green:#2F6B45;
  --font-display: "Iowan Old Style","Palatino Linotype",Georgia,serif;
  --font-body: system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  --font-mono: ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  --radius:2px;
}
body{background:var(--paper);color:var(--ink);font-family:var(--font-body);font-size:17px;line-height:1.65}
h1{font-family:var(--font-display);font-size:clamp(38px,6.2vw,64px);font-weight:400;
   letter-spacing:-.02em;line-height:1.05}
.label{font-family:var(--font-mono);font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--mute)}
/* structure */
hr,.row{border:0;border-bottom:1px solid var(--rule)}
table{font-variant-numeric:tabular-nums;border-collapse:collapse;width:100%}
th,td{border-bottom:1px solid var(--rule);padding:14px 0;text-align:left}
/* accent jobs: primary button, section numbers, severity dots, one rule. Nothing else. */
.btn-primary{background:var(--ink);color:var(--paper);border-radius:2px;padding:14px 26px}
```

| Property | Value |
|---|---|
| **Type** | Display: serif at **weight 400**, large. Body: neutral sans 17/1.65. Labels: mono 11px, uppercase, tracked. |
| **Scale** | 64 / 34 / 21 / 17 / 11 |
| **Radius** | 2px everywhere, or 0. Nothing rounded. |
| **Shadow** | None. Elevation = a 1px border + a hairline. |
| **Layout** | 12 columns; content in 1-8, a narrow left rail for numbers/labels. Rows separated by hairlines. |
| **Signature** | A **numbered index or spec table** of everything included, set densely in type. |
| **Banned** | Gradients · emoji · centred body copy · radius > 4px · glow · fake chrome · accent on headings |

**Dark variant:** `--paper:#111110; --ink:#EDEAE2; --rule:#2A2823;` — keep the same type and structure.

---

## R2 — Swiss / Brutalist (technical, confident, loud)

**Use for:** infrastructure, security, data products, anything addressing expert users. **The ancestor:**
a 1960s Swiss poster, an engineering drawing.

```css
:root{
  --paper:#FFFFFF; --ink:#000000; --mute:#5A5A5A; --rule:#000000;
  --accent:#0033FF;                       /* or #FF2D00 — one, hard, unmistakable */
  --font-display: "Inter Tight","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-body: "Inter Tight","Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono: ui-monospace,"SF Mono",Menlo,monospace;
  --radius:0px;
}
h1{font-weight:900;font-size:clamp(44px,9vw,104px);line-height:.92;letter-spacing:-.045em;text-transform:none}
.num{font-family:var(--font-mono);font-size:13px}
.card{border:2px solid var(--ink);box-shadow:4px 4px 0 var(--ink)}   /* offset, solid, no blur */
.grid-visible > *{border-left:1px solid var(--rule)}                /* show the columns */
```

| Property | Value |
|---|---|
| **Type** | One grotesk family at extreme weights (900 display / 400 body). Tracking tight at large sizes (-0.04em). |
| **Scale** | 104 / 40 / 22 / 16 / 12 — very wide contrast |
| **Radius** | 0. Hard corners, always. |
| **Shadow** | Solid offset only (`4px 4px 0`), never blurred. |
| **Layout** | Visible grid: 1px column rules, big numbers in the margin, alignment you can check with a ruler. |
| **Signature** | **Oversized numerals** — section numbers, counts, prices set enormous. |
| **Banned** | Gradients · soft shadows · emoji · muted pastels · more than one accent · decorative radius |

---

## R3 — Warm Analog (human, craft, small business)

**Use for:** local business, food, wellness, craft, education, anything where trust is warm rather than
technical. **The ancestor:** a menu card, a letterpress label, a field notebook.

```css
:root{
  --paper:#FBFAF7; --ink:#2A2520; --mute:#7A7368; --rule:#E4DFD4;
  --accent:#B85C38;               /* terracotta */
  --accent-2:#7A8B6F;             /* sage — a supporting neutral-ish, not a second accent */
  --font-display: Fraunces,"Iowan Old Style",Georgia,serif;
  --font-body: "Avenir Next",Avenir,"Segoe UI",system-ui,sans-serif;
  --radius:6px;
}
h1{font-family:var(--font-display);font-weight:500;font-size:clamp(34px,5.4vw,56px);
   letter-spacing:-.015em;font-variation-settings:"SOFT" 40}
.paper-tex{background-image:radial-gradient(rgba(0,0,0,.022) 1px,transparent 1px);background-size:4px 4px}
```

| Property | Value |
|---|---|
| **Type** | A soft serif with optical sizing (Fraunces) + a humanist sans. Warm, slightly loose tracking. |
| **Scale** | 56 / 32 / 20 / 17 / 12 |
| **Radius** | 4-8px — soft but not pill-shaped |
| **Shadow** | Very soft, very large blur, very low opacity — or none. Never crisp. |
| **Layout** | Generous margins, organic breaks, real photography with warm grading. |
| **Signature** | **A hand-drawn or organic rule/divider**, and real photos of real people or objects. |
| **Banned** | Gradients · emoji · pure black · pure white · cold greys · sharp corners |

---

## R4 — Dense Technical / Spec Sheet (dev tools, docs, data)

**Use for:** APIs, SDKs, data products, dashboards, documentation. **The ancestor:** a datasheet, a parts
catalogue, a terminal that respects you.

```css
:root{
  --paper:#FAFAFA; --ink:#0A0A0A; --mute:#6E6E6E; --rule:#E2E2E2; --panel:#F2F2F2;
  --accent:#0F7A4A;                        /* signal green */
  --font-display: ui-monospace,"SF Mono",Menlo,Consolas,monospace;   /* mono IS the display face */
  --font-body: system-ui,-apple-system,"Segoe UI",sans-serif;
  --font-mono: ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --radius:3px;
}
h1{font-family:var(--font-display);font-size:clamp(26px,4vw,40px);font-weight:500;letter-spacing:-.01em}
table{font-variant-numeric:tabular-nums;font-size:14px}
th{font-family:var(--font-mono);font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--mute)}
kbd{font-family:var(--font-mono);font-size:12px;border:1px solid var(--rule);
    border-bottom-width:2px;border-radius:3px;padding:1px 5px;background:var(--panel)}
```

| Property | Value |
|---|---|
| **Type** | **Monospace as the display face**, sans for body. Data is the hero. |
| **Scale** | 40 / 24 / 17 / 14 / 11 — tighter, denser than editorial |
| **Radius** | 3px |
| **Shadow** | None |
| **Layout** | Tables, definition lists, spec rows, hairline separators, tight leading. High information density. |
| **Signature** | **Real data in a real table** — real numbers, real names, real prices. No illustration needed. |
| **Banned** | Gradients · emoji · big empty hero · illustration-for-decoration · centred layouts |

**Dark variant (the good kind of dark):** `--paper:#0A0A0A; --ink:#EDEDED; --rule:#242424; --accent:#3DDC97;`
— note the accent is a *signal* colour on near-black, not a blue-cyan gradient.

---

## R5 — High-Contrast Minimal (premium, fashion, considered)

**Use for:** premium consumer products, portfolios, anything selling taste. **The ancestor:** a gallery
wall, a printed lookbook.

```css
:root{
  --paper:#FFFFFF; --ink:#000000; --mute:#8A8A8A; --rule:#000000;
  --accent:#000000;                    /* the accent IS the ink. Colour comes only from imagery. */
  --font-display: "Instrument Serif",Georgia,"Times New Roman",serif;
  --font-body: "Neue Haas Grotesk",Inter,system-ui,sans-serif;
  --font-mono: ui-monospace,Menlo,monospace;
  --radius:0px;
}
h1{font-family:var(--font-display);font-weight:400;font-size:clamp(48px,11vw,140px);
   line-height:.9;letter-spacing:-.03em}
img{filter:grayscale(100%)} img:hover{filter:none}     /* colour lives in the imagery only */
```

| Property | Value |
|---|---|
| **Type** | One very large serif or grotesk at enormous size, plus tiny sans labels. Extreme contrast. |
| **Scale** | 140 / 28 / 15 / 11 — the widest contrast of any recipe |
| **Radius** | 0 |
| **Shadow** | None |
| **Layout** | Huge white space, full-bleed imagery, content in a narrow measure. Very few elements per screen. |
| **Signature** | **Full-bleed imagery** with generous space around it, and type you can read across a room. |
| **Banned** | Gradients · emoji · cards · decorative colour · more than two elements per viewport |

---

## Choosing

| If the product is… | Recipe |
|---|---|
| A developer tool, a library, documentation, an audit service | **R1 Paper & Ink** (or R4 if data-dense) |
| Infrastructure, security, data, expert users | **R2 Swiss** |
| Local business, food, wellness, education, craft | **R3 Warm Analog** |
| An API, an SDK, a dashboard, a catalogue | **R4 Dense Technical** |
| Premium consumer, portfolio, design-led brand | **R5 High-Contrast Minimal** |

## The universal banned list (applies to all five)

```
✗ gradient text                     ✗ radial glow behind the hero
✗ emoji as icons or section markers ✗ fake browser/terminal chrome
✗ blue→cyan or purple→pink palette  ✗ three identical feature cards
✗ everything centred                ✗ drop shadows on flat surfaces
✗ trust bar with bold numbers       ✗ eyebrow pill above the headline
✗ accent colour doing six jobs      ✗ lorem ipsum or placeholder numbers
```

## Never ship without

```css
/* tabular numbers — the single most-forgotten mark of craft */
table,.price,.stat,.num{font-variant-numeric:tabular-nums}

/* focus that's visible and on-brand */
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}

/* text selection */
::selection{background:var(--ink);color:var(--paper)}

/* print — or at least don't look broken */
@media print{ body{background:#fff;color:#000} .no-print{display:none} }
```
