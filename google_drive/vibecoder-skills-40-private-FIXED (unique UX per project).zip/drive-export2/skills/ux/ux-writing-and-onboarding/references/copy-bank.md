# Copy bank — before / after

Steal the right column. Adapt the vocabulary to the user's domain (use their words, from
`discovery-interview`).

---

## Errors

| Situation | ❌ Generic | ✅ Useful |
|---|---|---|
| Unknown server error | Error / Something went wrong | "Something went wrong on our side. We've been told and we're on it. [Try again]" |
| Network failure | Request failed | "We couldn't reach the server. Check your connection and [try again]." |
| Timeout | Timeout | "This is taking longer than usual. Your work is saved as a draft. [Try again]" |
| Validation, single field | Invalid input | "Enter an email like name@example.com" |
| Validation, multiple | Please correct the errors | "Two things need fixing before you can continue: the email and the date." |
| Validation, password | Password too weak | "Use at least 12 characters. Longer beats complicated." |
| Required field missing | Field required | "Add a name so we know what to call you." |
| File too big | File too large | "That file is 24MB. Upload something under 10MB, or [compress it]." |
| Wrong file type | Invalid file type | "Upload a JPG, PNG or PDF." |
| File upload failed | Upload error | "The upload stopped halfway. Nothing was saved. [Try again]" |
| Permission denied | 403 Forbidden | "You don't have access to this page. Ask an admin, or [go back to the dashboard]." |
| Not found | 404 | "We couldn't find that page. It may have been moved or deleted. [Back to dashboard]" |
| Rate limited | Too many requests | "Too many attempts. Try again in 15 minutes." |
| Session expired | Session invalid | "You've been signed out for your security. [Sign in again]" |
| Payment declined | Payment error | "Your bank declined the card. No money was taken. Try another card, or contact your bank." |
| Insufficient funds | Transaction failed | "Your card doesn't have enough available credit for this. No charge was made." |
| Subscription lapsed | Access denied | "Your plan ended on 3 October. [Renew] to pick up where you left off — your data is all still here." |
| Quota exceeded | Limit reached | "You've used all 50 reports included this month. [Upgrade] or wait until 1 November." |
| Feature unavailable | Not available | "Bulk export is on the Pro plan. [See plans] — your data stays either way." |
| Conflict (someone else changed it) | 409 Conflict | "Someone else updated this while you were editing. [See their version] or [keep mine]." |
| Third-party down | Integration error | "We couldn't reach Stripe just now. Your booking is saved — we'll retry the payment automatically." |
| Maintenance | Down for maintenance | "We're making improvements and will be back at 14:00 UTC. Nothing is lost." |
| Search failed | Search error | "Search is temporarily unavailable. [Refresh] or browse [all categories]." |

## Empty states

| Place | ❌ | ✅ |
|---|---|---|
| New list | "No items" | "No bookings yet. Book your first class and it'll show up here. [Browse classes]" |
| Filtered to nothing | "No results" | "No bookings in October. [Clear the filter] to see all 24." |
| Search, no match | "0 results" | "Nothing matches “yoga”. Check the spelling, or [clear the search]." |
| No notifications | "Empty" | "You're all caught up. We'll let you know when something needs you." |
| No team members | "None" | "It's just you so far. [Invite a teammate] — the first two seats are free." |
| No payment method | "—" | "No card on file. [Add one] so your subscription doesn't interrupt." |
| Error state list | (blank) | "We couldn't load these. [Try again]" |
| No activity | "No data" | "Activity shows up here once people start using your workspace." |
| Empty dashboard | "Welcome!" | "Welcome, Sam. Two things to do: [Connect your calendar] and [Create your first project]." |
| Inbox zero | "" | "Nothing needs your attention. Nice." |

## Loading & progress

| Situation | Copy |
|---|---|
| Quick action (<1s) | (nothing — don't flicker a spinner) |
| Button working | "Saving…" / "Uploading…" / "Booking…" |
| Slow (>3s) | "Still working — this is taking longer than usual." |
| Very slow (>10s) | "This is slower than normal. You can keep this tab open, or we'll email you when it's done." |
| Multi-step | "Step 2 of 3: connecting your calendar" |
| Progress with count | "Importing 240 of 1,180 contacts — about 2 minutes left." |
| Background | "We're processing your report. We'll email you when it's ready (usually under 5 minutes)." |
| Offline | "You're offline. Changes will save when you're back online." |
| Stale data | "Showing data from 10:42. [Refresh]" |
| Retrying | "Reconnecting… attempt 2 of 3" |

## Success

| Stakes | Copy |
|---|---|
| Tiny | "Saved" (inline, fades) |
| Small | "Booking updated." |
| Medium | "Invite sent to sam@example.com. We'll let you know when they accept." |
| Large | "You're booked for Tuesday 14:00. A confirmation is on its way to name@example.com." |
| Money | "Payment of $49.00 received. Your receipt is in your inbox." |
| Irreversible | "Account deleted. If this was a mistake, contact us within 14 days and we can restore it." |

## Confirmations

| Action | Copy |
|---|---|
| Delete one thing | "Delete “Team offsite”? This can't be undone. [Delete] [Keep]" |
| Delete many | "Delete 12 bookings? This can't be undone. [Delete 12 bookings] [Keep them]" |
| Delete account | "Delete your account? Your 3 projects, 48 files and billing history will be permanently removed. Type DELETE to confirm." |
| Cancel subscription | "Cancel your plan? You'll keep access until 1 November, then your data is kept for 30 days before deletion. [Cancel plan] [Keep plan]" |
| Leave with unsaved changes | "You have unsaved changes. [Save and leave] [Discard] [Keep editing]" |
| Overwrite | "This will replace the current version. The old one stays in history for 30 days." |
| Irreversible money action | "Refund $120.00 to Sam? The money leaves your account immediately. [Refund] [Cancel]" |
| Remove teammate | "Remove Sam from the workspace? They'll lose access immediately. [Remove] [Keep]" |

Rule: name the consequence in the title, name the outcome on the buttons, default focus on the safe option.

## Buttons

| ❌ | ✅ |
|---|---|
| Submit | Create booking |
| OK | Got it |
| Yes / No | Delete file / Keep file |
| Confirm | Upgrade to Pro |
| Cancel | Keep editing |
| Continue | Next: choose a plan |
| Click here | Download the invoice |
| Save Changes | Save changes |
| Are you sure? | (replace with the consequence) |
| Send | Send 3 invitations |

## Form labels & help

| ❌ | ✅ |
|---|---|
| "Name" (ambiguous) | "Full name" / "Company name" / "Display name" |
| "Date" | "Booking date" |
| "Value" | "Monthly budget (USD)" |
| Empty help text | "We'll only email you about this booking." |
| "Required" | Mark required fields, or mark the optional ones — pick one and be consistent |
| Password rules after failure | Show them up front: "At least 12 characters." |
| "Submit" on a long form | "Create account" |
| Placeholder as label | Real label above the field. Placeholders disappear and hurt everyone. |

## Onboarding

| Moment | Copy |
|---|---|
| Signup headline | "Create your account" (not "Join the revolution") |
| Signup subtext | "Free for 14 days. No card needed." |
| After signup | "Welcome, Sam. Let's create your first project." |
| Checklist item | "Connect your calendar — 1 min" |
| Checklist progress | "2 of 3 done" |
| Skip | "Skip for now" (never "No thanks, I don't want to be productive") |
| Sample data | "We've added 3 example bookings so you can see how it works. [Clear examples]" |
| First result | "That's your first booking live. [Add another] or [see the schedule]" |
| Nudge email | "Your workspace is waiting — you're one step from your first booking. [Finish setup]" |
| Empty integration | "Connect Google Calendar and bookings will appear automatically. [Connect]" |

## Emails & notifications

| Type | Subject | First line |
|---|---|---|
| Verify | "Confirm your email for Acme" | "Tap the button to confirm. The link expires in 24 hours." |
| Welcome | "Welcome to Acme" | "Here's the one thing to do first: create your first project. [Open Acme]" |
| Receipt | "Your receipt from Acme — $49.00" | "Thanks. Here's your receipt for October." |
| Reset | "Reset your Acme password" | "Use the link within 15 minutes. If this wasn't you, ignore this email." |
| Password changed | "Your password was changed" | "If this wasn't you, [reset it now] — and consider turning on two-factor authentication." |
| Payment failed | "We couldn't take your payment" | "Your subscription is still active. Update your card by 3 October to avoid interruption." |
| Trial ending | "Your trial ends in 3 days" | "Add a card to keep your workspace and all 12 projects. [Add card]" |
| Quota warning | "You've used 80% of your reports" | "50 included, 40 used. [Upgrade] or it'll pause on 1 November." |
| Team invite | "Sam invited you to Acme" | "Join the workspace. The invite expires in 7 days. [Accept]" |
| Security alert | "New sign-in from a new device" | "Chrome on Windows, Tunis. If this was you, ignore this. [Secure my account]" |
| Re-engagement | "Your workspace misses you" | (only if genuinely useful — most of these shouldn't be sent) |

## Words to delete from your UI

`Submit` · `OK` · `Invalid` · `Error` · `Failed` (alone) · `Oops` · `Whoops` · `Please note that` ·
`Kindly` · `Utilize` · `Leverage` · `Seamless` · `Robust` · `Cutting-edge` · `Revolutionary` ·
`Simply` · `Just` (as in "just click") · `Unfortunately` · `Our team has been notified` (unless true) ·
`Please try again later` · `An unexpected error occurred` · `Null` · `undefined` · `NaN` · `[object Object]`

## Words to use instead

| Instead of | Use |
|---|---|
| Utilize / Leverage | Use |
| Commence / Initialize | Start |
| Terminate | End / Stop / Delete |
| Authenticate | Sign in |
| Credentials | Email and password |
| Configure | Set up |
| Provision | Create |
| Migrate | Move |
| Deprecated | Old / no longer supported |
| Execute | Run |
| Persist | Save |
| Terminate session | Sign out |
