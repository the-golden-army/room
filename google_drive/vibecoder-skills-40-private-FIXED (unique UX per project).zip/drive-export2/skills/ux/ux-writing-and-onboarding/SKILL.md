---
name: ux-writing-and-onboarding
description: Use whenever writing anything a user reads — buttons, error messages, empty states, confirmations, emails, notifications, onboarding — and when designing the first five minutes of a product. Turns hostile, vague, or robotic copy into words that tell people what happened, what to do next, and that their data is safe. Includes a before/after copy bank for the 40 strings every app needs.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# ux-writing-and-onboarding

## Promise

Users always know three things: **what happened, what it means for them, and what to do next.**
The cheapest feature you'll ever ship is a good sentence.

## When to use

- Writing any user-facing text (buttons, labels, errors, empties, toasts, emails)
- Designing signup, first-run, or activation flows
- "Users don't understand it" / "nobody completes signup" / "support tickets about X"
- Reviewing copy that an AI generated (usually technically correct, emotionally useless)
- Before launch — copy is part of `production-readiness`

## When NOT to use

- Internal-only tooling (though clear labels still help you at 2am)

## The 60-second version

```
1. Say what happened, in the user's words, not the system's.
2. Say whether their work is safe. (This is the thing people actually panic about.)
3. Give one clear next action. One.
4. Never blame the user. Never use "invalid", "error", "failed" alone.
5. Buttons: verb + the thing. "Create booking", not "Submit" / "OK".
6. Empty states are an opportunity, not an apology: explain + invite.
7. Onboarding: get them to the first real result in under 5 minutes.
8. Write for a distracted, slightly anxious person on a phone. Because that's who's reading.
```

## Part 1 — The rules

### Rule 1: Say what happened, then what to do

| ❌ | ✅ |
|---|---|
| "Error" | "We couldn't save your changes. Your edits are still here — try again in a moment." |
| "Invalid input" | "Enter an email address like name@example.com" |
| "Request failed" | "We couldn't reach the server. Check your connection and try again." |
| "Unauthorized" | "You've been signed out for security. Sign in again to continue." |
| "404" | "We couldn't find that page. It may have been moved or deleted. [Back to dashboard]" |
| "Something went wrong" | "Something went wrong on our side, not yours. We've been notified. [Try again]" |

### Rule 2: Never blame the user

- ❌ "You entered the wrong password" → ✅ "That email and password don't match. Try again, or reset your password."
- ❌ "You must fill in all fields" → ✅ "Add a name and an email to continue."
- ❌ "Invalid file type" → ✅ "Upload a JPG, PNG or PDF — up to 10MB."
- ❌ "Error: user error" → (there is no version of this that's okay)

### Rule 3: Say whether their data is safe

The first question in a user's mind when something breaks. Answer it before they ask.

> "The payment didn't go through. **You haven't been charged.** Update your card and try again."
> "We couldn't load the page. **Nothing you entered was lost.**"

### Rule 4: Buttons are verbs

| ❌ | ✅ |
|---|---|
| Submit / OK / Yes / Confirm | Create booking / Delete 3 files / Send invite / Upgrade plan |
| Click here | (write what happens: "Download the invoice") |
| Cancel (next to "Delete") | Keep it (name the outcome, not the mechanism) |

The button is the last thing people read before they commit. Make it say the consequence.

### Rule 5: Match length to stakes

| Stakes | Example |
|---|---|
| Trivial | "Saved" |
| Normal | "Booking confirmed. We've emailed you the details." |
| Serious | "This permanently deletes 12 bookings and can't be undone. Type DELETE to confirm." |

### Rule 6: Numbers, dates, money

- Format for the user's locale: `1,234.56`, `12 Oct 2026`, `2:30 PM`
- Relative for recent things ("2 hours ago"), absolute for records ("12 October 2026, 14:30")
- Money: always the currency symbol and 2 decimals. Never a bare number
- Never show raw IDs, timestamps, or internal codes to users
- Never "0 results" when a filter is on — say "No bookings match your filters. [Clear filters]"

### Rule 7: Voice

| Do | Don't |
|---|---|
| Short, plain, specific | Jokes in error messages |
| Second person ("your bookings") | Passive voice ("an error was encountered") |
| Consistent terms (pick "booking" or "reservation", never both) | Synonym roulette |
| Sentence case | ALL CAPS, Title Case Everywhere |
| Local spelling consistently (US or UK, not both) | Exclamation marks to sound friendly!!! |

Apologize once, briefly, and only when it's your fault. Then fix it.

## Part 2 — The copy bank

Full before/after list: [`references/copy-bank.md`](references/copy-bank.md). The essentials:

| Situation | Copy |
|---|---|
| Empty list | "No bookings yet. Book your first class and it'll show up here. [Browse classes]" |
| No search results | "Nothing matches “yoga”. Check the spelling, or [clear the search]." |
| Loading (slow) | "Still working — this is taking longer than usual." |
| Offline | "You're offline. We'll save your changes when you're back." |
| Success (small) | "Saved" |
| Success (big) | "You're booked! A confirmation is on its way to name@example.com." |
| Delete confirm | "Delete this booking? This can't be undone. [Delete booking] [Keep it]" |
| Validation | "Add a name — it's how we'll address you in emails." |
| Rate limited | "Too many attempts. Try again in 15 minutes." |
| Session expired | "You've been signed out for your security. [Sign in again]" |
| Payment failed | "Your card was declined. No charge was made. Try another card?" |
| Permission denied | "You don't have access to this page. Ask an admin, or [go back]." |
| Maintenance | "We're updating things and will be back at 14:00 UTC. Nothing is lost." |

## Part 3 — Onboarding (the first five minutes)

**The goal: the first real outcome, as fast as possible.** Not a tour. Not a form. An outcome.

### The rules

1. **Ask the minimum before they can do anything.** Email + password, or Google. Everything else comes later.
2. **No tour before value.** A 6-step modal carousel explaining a product they haven't used is a wall.
3. **Get to the first result in under 5 minutes.** For most products that means: skip the setup wizard,
   land them in the product with a single obvious action.
4. **Progressive disclosure.** Advanced settings appear when needed, not upfront.
5. **One primary action per screen.** The screen should have an obvious next step.
6. **Pre-fill and sample data.** An empty dashboard teaches nothing. Offer 3 demo items they can delete.
7. **Show progress, then stop.** A 3-item checklist ("Add your logo → Invite a teammate → Create your first
   project") works. Anything longer gets abandoned.
8. **Never block on email verification** unless you must — let them in, then nag gently.
9. **Make every step skippable**, and don't punish skipping.
10. **Celebrate the first outcome**, not the signup. "Nice — your first booking is live."

### The shape of a good first run

```
Sign up (email + password, or Google)
   ↓  (no 6-field profile form)
Landing screen with ONE obvious action + 3 sample items
   ↓
They do the thing (create, upload, book, connect)
   ↓
Immediate result + "what next" (2 options, not 8)
   ↓
Email 1 hour later: "Here's how to get more out of X" (only if they haven't done it)
```

### Empty states are onboarding

Every empty area is a chance to teach. An empty projects list saying "No projects" is a dead end.
The same space saying "Projects are where your team's work lives. Create your first one — it takes a minute.
[New project]" teaches and invites.

### Notifications and emails

| Rule | Why |
|---|---|
| Only send what's useful | Every unnecessary notification trains people to ignore you |
| Transactional ≠ marketing | Receipts, resets, security alerts: always sent. Promotions: opt-in only |
| One topic per email | People scan |
| Put the action in the first two lines | Most email is read on a phone, in a preview |
| Unsubscribe in every marketing email | Legal, and basic decency |
| Name the app in the subject | "Your receipt from Acme" not "Invoice" |
| Never email a password or a full card number | Ever |

### The five emails every app needs

1. **Verify your email** — one link, expires in 24h, says what happens next
2. **Welcome** — one thing to do, one link, under 100 words
3. **Receipt** — amount, what for, and a link to the invoice
4. **Password reset** — expires in 15 min, "if this wasn't you, you can ignore this"
5. **Something needs attention** — payment failed, trial ending, quota hit — with the fix one click away

## Non-negotiables

1. **Every error message contains: what happened, that their data is safe, and the next action.**
2. **Buttons are verbs that name the outcome.**
3. **No "invalid", "error", "failed", or "oops" on their own.**
4. **Empty states explain and invite.**
5. **No technical jargon, no codes, no IDs, no stack traces in user-facing text.**
6. **Signup asks for the minimum; everything else comes later.**
7. **First real outcome in under five minutes.**
8. **Every notification is opt-out for transactional, opt-in for marketing.**
9. **One term per concept, used consistently across the whole product.**
10. **Copy is reviewed by reading it out loud, as a distracted stranger would.**

## Ask the human

1. "Who's using this, and what are they usually in the middle of when they open it?" *(sets tone and length)*
2. "Should this sound friendly and casual, or professional and direct?"
3. "What's the one thing you want someone to do the first time they use it?"
4. "Is there anything you'd never say to a customer?" *(brand red lines: no emojis, no exclamation marks, no jargon)*
5. "Do you want people to get emails? If yes, which ones — only the essential ones, or tips and news too?"
6. "Is there a word you use for the main thing in your product? I'll use it everywhere." *(terminology consistency)*

Never ask: "what tone of voice tokens do you want?", "should CTAs be first-person or second-person?" — decide
and show them a sample.

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| "Error: something went wrong" | Tells the user nothing | What + safe? + next step |
| A 6-step onboarding carousel before the product | People close it and are lost | Land them in the product with one action |
| Asking for company size, role, and 4 preferences at signup | Drop-off cliff | Minimum now, rest later |
| "Are you sure? Yes/No" | Meaningless choice | "Delete 3 files? This can't be undone. [Delete] [Keep]" |
| Copy written by listing API field names | Reads like a database | Write what the human calls it |
| Marketing voice in an error message | Insulting when something's broken | Plain, brief, useful |
| Reusing "Submit" on every form | Users don't know what happens | Verb + object |
| Empty dashboard with nothing in it | The user has no idea what to do | Sample data + one action |
| Email with six CTAs | None get clicked | One action |
| "Please try again later" with no timeframe | Frustrating | "Try again in a few minutes" or a status link |
| Inconsistent naming (Booking/Reservation/Order) | Users think they're different things | Pick one, use it everywhere |

## Definition of done

- [ ] Every user-facing string has been read out loud and makes sense to a non-technical person
- [ ] Every error message: what happened + data safe + next action
- [ ] Every button is a verb naming the outcome
- [ ] Every list/area has an empty state with an explanation and an action
- [ ] Signup asks for the minimum; first outcome reachable in under 5 minutes
- [ ] Onboarding is skippable and progressive; no tour-before-value
- [ ] Email/notification set defined: transactional always, marketing opt-in only
- [ ] One term per concept, used consistently
- [ ] Numbers, dates, and money are formatted for the user's locale
- [ ] No jargon, code, IDs, or stack traces anywhere a user can see them

## Works with

- `frontend-craft` — where this copy lives (errors, empties, toasts)
- `design-system-and-visual-language` — the components that hold it
- `accessibility-and-inclusive-design` — copy that works with screen readers and plain language
- `discovery-interview` — the user's own vocabulary for their domain
- `seo-and-growth-basics` — landing page copy that converts
- `saas-architecture` — trial, upgrade, and quota messaging
