---
name: ux-upgrade-audit
description: Use when the UI feels vibe-coded, inconsistent, or half-built — before launch, after an AI build, or when someone says "make it look professional". Runs a full UX scan across every page and component to find weak points in code and UX: misstyled buttons, broken states, inconsistent spacing, bad typography, empty links, and mock data. Produces a severity-graded report with file locations and copy-paste fixes for every issue, then waits for your "fix all" to upgrade the whole app.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# ux-upgrade-audit

## Promise

You get the truth about your UI — every weak point, ranked by how much trust it costs you — in one report.
Every button, font size, spacing gap, color, empty state, and broken link is checked.
For each failure: where it is (`file:line`), what's wrong in plain words, why it matters, and the exact fix you can paste.
Then one command — **"fix all"** — upgrades the whole app, safely, with git checkpoints.

No vibe inspection. No "looks good to me". Pass/fail only.

## When to use

- Before launch, before showing a client, before a demo day
- After an AI built 8 pages in one shot ("it works but looks off")
- Someone says "make it look professional / less AI / more expensive / like Linear/Stripe"
- Buttons look different on every page, text sizes jump randomly, spacing feels off but you can't say why
- You suspect `href="#"`, blank pages, broken images, lorem, or missing loading/empty/error states
- Pull request UX review — catch what a linter can't
- After `responsive-mobile-first` or `distinctive-visual-style` — this is the audit that proves they stuck

## When NOT to use

- No UI yet — run `discovery-interview` + `project-blueprint` first
- Pure backend/API with no pages to audit
- One-line color tweak — just fix it, don't audit

## The 60-second version

```
1. INVENTORY   Every route + every component — map what actually exists
2. AUDIT       8 passes, each pass/fail: buttons → typography → spacing/layout → color → states → responsive → a11y → copy
3. REPORT      Severity-graded findings: file:line + what's wrong + why it matters + exact fix snippet
4. PLAN        "Fix all" plan: grouped by file, estimated diff size, rollback via git
5. FIX ALL     Only after you type "fix all" — apply grouped fixes, commit per group, verify each page renders
```

> **Rule: diagnose first, fix never before "fix all".** The report must exist before any file changes.

## Steps

### Step 1 — Understand what this app is (one question at a time)

Don't guess the taste. Before scanning, learn the product in 2-3 quick questions:

**How to ask (one per turn, with a default, never a list):**

> "Got it — this looks like a booking app. Quick one: who is this for — your customers directly, or an internal team?"
> Not sure? Just say "you pick" — I'll assume customer-facing and judge it like a product, not a dashboard."

> "Perfect, customer-facing. Next: what feeling should it have — calm/professional like Stripe, warm/human like Airbnb, or sharp/technical like Linear? — Not sure? Say 'you pick', I'll pick one that fits and tell you."

> "Last one before I scan: any pages I should skip — admin, deprecated, or still in progress? Just say 'you pick' and I'll audit everything I find."

**Why this matters:** the audit's expected answer changes. A dashboard can be dense; a marketing page cannot. A fintech needs calm + trustworthy; a fitness app can be loud. Without this, "upgrade" means "average".

Record the choice in the report header: `Vibe: calm/professional — chosen because X`.

### Step 2 — Inventory everything (no page hides)

The agent must *read* the codebase, not guess. This is the evidence step.

**What to collect (read-only):**

```bash
# 1. Every route / page (Next.js / Remix / SvelteKit / generic)
find app pages src/app -type f -name "page.tsx" -o -name "page.jsx" -o -name "index.tsx" | sort

# 2. Every component that renders UI
find components features app/components src/components -type f -name "*.tsx" -o -name "*.jsx" | sort

# 3. Every Button / Link usage — your misstyled-button detector's raw data
grep -rn "<Button\|<button\|<Link\|<a \|href=\"#\"\|href=\"\"" app components features --include="*.tsx" --include="*.jsx"

# 4. Every page's imports — detect orphan files / pages never linked in nav
grep -rn "from \"@/components" app --include="*.tsx" | cut -d: -f2 | sort | uniq -c

# 5. Tokens / tailwind config / CSS vars — the source of inconsistency
cat app/globals.css tailwind.config.* 2>/dev/null | head -n 80
cat components/ui/button.tsx 2>/dev/null
```

**Write the inventory table:**

| # | Route | File | Status | Notes |
|---|---|---|---|---|
| 1 | `/` | `app/page.tsx` | exists | hero + 3 feature cards |
| 2 | `/pricing` | `app/pricing/page.tsx` | exists | linked in nav, renders real content |
| 3 | `/dashboard` | `app/(app)/dashboard/page.tsx` | exists | blank when no bookings — no empty state |
| 4 | `/settings` | — | **missing file** | linked in nav as `href="#"` — dead link |
| 5 | `BookButton` | `components/book-button.tsx` | exists | 3 variants, 2 different paddings |

Any route in nav without a file **is a finding by itself** — don't wait for the audit.

### Step 3 — Run the 8 audit passes (each pass/fail, no "looks okay")

Do each pass in order. One pass at a time. For each finding record: file, line, severity, what's wrong, impact in user terms, and the fix.

#### Pass 1 — Buttons & interactive elements (the #1 tell of vibe code)

Every AI-generated app fails here first. Buttons are never consistent.

| Check | Fail if | Severity |
|---|---|---|
| **Variant consistency** | >2 primary styles, or primary buttons use 3 different blues | HIGH |
| **Padding / size** | `px-2 py-1` on one, `px-8 py-4` on another; heights 32px vs 48px mixed | HIGH |
| **States** | No `disabled`, no `loading`, no `hover`, no `focus-visible` | CRITICAL (double-submit + a11y) |
| **Disabled logic** | Button looks enabled while request in-flight | CRITICAL |
| **Tap target** | <44×44px on interactive elements | MEDIUM |
| **Icon-only buttons** | No `aria-label`, no tooltip | MEDIUM |
| **Destructive without confirm** | Delete button with no confirm step | HIGH |
| **Dead links** | `href="#"`, `href=""`, `javascript:void(0)`, missing handler | CRITICAL |

```tsx
// ❌ what vibe code ships — 3 buttons, 3 sizes, no states
<Button className="bg-blue-500 px-2 py-1">Save</Button> // page A
<Button className="bg-blue-600 px-6 py-3">Save</Button> // page B — different blue, different size
<a href="#">View all</a> // dead link

// ✅ what "fix all" produces — one canonical Button with variants
<Button variant="primary" size="md" loading={saving} disabled={saving}>Save</Button>
<Button variant="ghost" size="sm" href="/bookings">View all bookings</Button>
```

#### Pass 2 — Typography & hierarchy

| Check | Fail | Severity |
|---|---|---|
| **Type scale** | 7 different font sizes with no ratio (13,14,15,16,17,18,22 mixed randomly) | HIGH |
| **Hierarchy survives greyscale** | Color doing hierarchy, not scale (desaturate test) | MEDIUM |
| **Heading order** | `h1` → `h3` skipping `h2`, or 3 `h1`s per page | MEDIUM |
| **Line length** | >85ch prose, or 30ch squeezed table | LOW |
| **Body size** | <15px body text | MEDIUM |
| **Font pairing** | 3+ font families loaded | LOW |

#### Pass 3 — Layout, spacing & grid

| Check | Fail | Severity |
|---|---|---|
| **Fixed widths** | `width: 1200px`, `w-[1200px]` — horizontal scroll on mobile | HIGH |
| **Inconsistent gaps** | `gap-2`, `gap-4`, `gap-6`, `gap-8`, `gap-12` randomly | MEDIUM |
| **Centred everything** | Every section centred — classic AI template | LOW (visual) |
| **Inconsistent radius/shadow** | `rounded-xl` here, `rounded-lg` there, mixed shadows | LOW |
| **Cards deck-of-tiles** | Every block is an identical rounded card + shadow | MEDIUM (visual) |
| **Max-width on prose** | Missing `max-w-[65ch]` on long text — unreadable | LOW |

#### Pass 4 — Color & visual style

| Check | Fail | Severity |
|---|---|---|
| **Palette discipline** | 6 blues, accent on 40% of surface | MEDIUM |
| **Gradient text / glows** | Blue→cyan gradient, glow shadows, emoji as icons | MEDIUM (→ slop) |
| **One accent rule** | Accent used on text + border + chip + glow + icon (6 jobs) | MEDIUM |
| **Contrast** | <4.5:1 on body text | HIGH (a11y + legal) |
| **Dark mode / theme** | If toggled: broken colors, invisible text | HIGH if shipped |

#### Pass 5 — States (loading / empty / error / success)

Use `frontend-craft`'s six states as the truth. Each data view is audited:

| Check | Fail | Severity |
|---|---|---|
| **Loading** | Blank screen or centred spinner instead of skeleton in layout | HIGH |
| **Empty** | Blank white screen when no data | CRITICAL (feels broken) |
| **Error** | Raw `Error` / stack trace / "Something went wrong" only | HIGH |
| **Empty is actionable** | "No bookings" with no CTA to create one | MEDIUM |
| **Async button without state** | Never disables, never shows progress, no timeout | CRITICAL |
| **Layout shift** | Content pops in and moves page | MEDIUM |

#### Pass 6 — Responsive completeness (320px test)

| Check | Fail | Severity |
|---|---|---|
| **Horizontal scroll** | Any width 320–1440 has overflow | HIGH |
| **Touch targets** | <44px on phone | MEDIUM |
| **Tables** | Table with horizontal scroll on phone instead of cards | MEDIUM |
| **Nav** | 6 items squished at 375px | MEDIUM |
| **Forms** | Two-column form on phone | MEDIUM |
| **Hidden mess via `display:none`** | Desktop mess just hidden on mobile, not fixed | LOW |

#### Pass 7 — Accessibility (the 5-minute pass that prevents lawsuits)

| Check | Fail | Severity |
|---|---|---|
| **Keyboard** | Can't Tab through page, focus invisible | HIGH |
| **Labels** | Inputs without `<label>` or `aria-label` | HIGH |
| **Images** | `alt=""` on meaningful images or missing `alt` | MEDIUM |
| **Heading + landmarks** | No `<nav>`, `<main>`, `<header>` semantics | LOW |
| **Motion** | Autoplay, no `prefers-reduced-motion` | LOW |

#### Pass 8 — Consistency & code-level weak points

| Check | Fail | Severity |
|---|---|---|
| **Component duplication** | 3 different `Card` implementations, 2 `Modal` copies | HIGH (maintainability + drift) |
| **Hardcoded values** | `style={{color: "#3b82f6"}}` instead of token | MEDIUM |
| **Mock/demo leakage** | `John Doe`, `Lorem ipsum`, `picsum`, hardcoded `mockBookings` in `app/` | CRITICAL (ships fake data) |
| **Dead/orphan files** | Files never imported, routes never linked | LOW |
| **Inconsistent naming** | `btnPrimary`, `primaryBtn`, `PrimaryButton` for same thing | LOW |

### Step 4 — Produce the report (the artifact that justifies "fix all")

Generate `docs/UX-AUDIT.md` (copy-paste below). **No fixes yet — just the report.**

```md
# UX Upgrade Audit — <app> — 2026-10-21

Vibe: calm/professional — for bookers on phones between classes
Routes audited: 8 | Components scanned: 24 | Findings: 17

## Summary (for a non-technical owner)
3 critical, 5 high, 6 medium, 3 polish. Worst page: /dashboard — 4 failures.
Most common: inconsistent button (7 instances, 3 sizes, 2 blues).

## Findings

| ID | Severity | Where | Issue | Impact | Fix |
|---|---|---|---|---|---|
| B1 | 🔴 CRITICAL | `components/book-button.tsx:12` | Primary button missing `disabled` + `loading` — double-tap charges twice | Users + money | Use canonical `<Button>` with `disabled={saving}` + spinner |
| B2 | 🔴 CRITICAL | `app/settings/page.tsx` | Route linked in nav, file missing → dead `href="#"` in `components/nav.tsx:18` | Feels broken | Remove link or build page; never ship `#` |
| T1 | 🟠 HIGH | `app/page.tsx:34` | `text-[22px]` with no scale — hierarchy is random, fails greyscale | Trust/clarity | Use token `text-lg` (21px) from scale |
| ... | ... | ... | ... | ... | ... |

## Details (one block per finding)

### B1 — Misstyled primary button (no disabled/loading state)
- **File:** `components/book-button.tsx:12`
- **Before (actual code):**
  ```tsx
  <button onClick={handleBook} className="bg-blue-500 px-2 py-1 rounded">Book</button>
  ```
- **What's wrong:** 32×24px tap target (too small), no disabled, no spinner — double-click = double booking. Second button elsewhere uses `bg-blue-600 px-6 py-3` — inconsistency.
- **Impact:** Double bookings + lost trust. This is a money bug disguised as a style bug.
- **Fix:**
  ```tsx
  <Button variant="primary" size="md" loading={isSaving} disabled={isSaving} onClick={handleBook}>
    {isSaving ? "Booking…" : "Book this class"}
  </Button>
  ```
- **Effort:** 1 file, ~5 lines.

[repeat for every finding, with actual code — no invented locations]

## Metrics
- Button consistency: 3 variants → 1
- Routes with dead links: 1
- Pages with blank/empty state missing: 2
- Accessibility: focus ring missing on 6 elements, 2 inputs without labels

## Fix plan (grouped for "fix all")
Group A (buttons): B1, B3, B7 → `components/ui/button.tsx` + 4 consumer files — ~40 lines
Group B (routes/links): B2, R1 → `components/nav.tsx`, `app/settings/page.tsx` (new) — ~30 lines
Group C (type/layout): T1, L2, L3 → `app/globals.css`, `app/page.tsx` — ~20 lines
...
Total: ~120 lines across 8 files. All reversible via git.

## "Fix all" — what happens when you approve
1. `git commit` current state as checkpoint: `chore: checkpoint before ux-upgrade`
2. Apply Group A → commit `fix(ux): canonical button + states`
3. Apply Group B → commit `fix(ux): remove dead links, add missing page`
4. Apply Group C → commit `fix(ux): type scale + layout tokens`
5. Verify: every page renders, no dead link, no blank route, no mock data visible
6. Report: what changed, what to check (click these yourself)

Run that by you? Reply **"fix all"** to apply, or name a group ("fix A + C only").

```

**Report rules:**
- Every finding has a **real file:line** from the scan — never invent.
- Before code is **verbatim from the repo**, not paraphrased.
- Each fix is copy-paste ready and names the file it edits.
- Severity is from the table, not vibes. Misstate severity = lose trust.
- No invented APIs, no invented file paths.
- End with the exact prompt: `Reply "fix all" to apply, or "fix A + C only"`, and stop.

### Step 5 — Wait for "fix all" (the contract)

**Do not edit any file before the human says one of:**

- `"fix all"` — apply every group
- `"fix A + C"` / `"fix B only"` — apply named groups
- `"skip"` / `"not now"` — leave the report as deliverable, no files touched

While waiting, answer questions about the report — but don't start fixing.

### Step 6 — Fix all (safe, grouped, reversible)

Only after explicit approval. Do this, in this order — no shortcuts:

```
1. git status — ensure working tree is cleanable; if dirty, stash note in HANDOFF
2. git commit -m "chore: checkpoint before ux-upgrade" — checkpoint (ask to create if nothing to checkpoint)
3. For each approved group, in A→B→C order:
   a. Apply fixes for that group's findings — nothing outside the group, no drive-by refactors
   b. git commit -m "fix(ux): <group name>"
4. Verify: `grep -rn "href=\"#\"\|href=\"\"" app components` → 0 results
           Every route in nav has a file and renders (no blank screen)
           Every data view: check loading/empty/error manually or via grep for <EmptyState>/<ErrorState>
           No mock data: `grep -rn "John Doe\|Lorem ipsum" app` → 0 results
5. Write summary: what changed per group, files touched, lines changed, what to check (URL → expected)
6. If anything fails verification, git revert that group, report what failed and why
```

**Never during "fix all":**
- Change auth, database, or money logic
- Add dependencies without asking
- Fix something not in the report
- Batch all groups into one commit (losing rollback granularity)
- Claim done without the verification grep above

## Non-negotiables

1. **No invented findings.** Every line number exists, every before-snippet was read from the file, every file exists.
2. **No fix without a report.** The report is the deliverable — "fix all" is optional. The report stands alone.
3. **No fix without explicit "fix all".** Not "sounds good", not "go ahead" on the inventory — specifically the phrase "fix all" (or named groups).
4. **Grouped commits, not one giant commit.** One group = one commit = one revert if wrong.
5. **Never hide work.** If you skipped a page, say which. If a check was inconclusive, say "UNKNOWN — manual check: <URL>".
6. **Severity is from the tables, not feelings.** CRITICAL = money/a11y/dead link, HIGH = trust/clarity, etc.
7. **Every button in the app must end up using one canonical `Button` component.** That's the finish line for Pass 1 — not "fewer variants".
8. **No blank pages survive "fix all".** Every route in nav must render real content or be removed from nav.
9. **No mock data survives "fix all".** No John Doe, no Lorem, no hardcoded mock array in `app/`.
10. **Verification is real commands, not claims.** Paste the grep output, don't say "no dead links found".
11. **Plain language in the summary.** The owner doesn't care about `focus-visible` — they care "people can't see where they are on the page with a keyboard".

## Ask the human

**One question at a time** — conversational, never a list.

Ask only when you need taste or scope:

1. "What should this feel like — calm like Stripe, warm like Airbnb, or sharp like Linear? — Not sure? Say 'you pick' and I'll choose from what you've told me."
2. "Any pages I should ignore — admin, deprecated, work-in-progress? — Say 'you pick' and I'll audit everything."
3. "Should I be strict about brand (exact colors/fonts) or focus on consistency and polish? — 'You pick' = consistency first."
4. After report: "Want me to fix everything? Just say 'fix all' — I'll do it grouped and reversible. Or say a group like 'fix A only'."

**How:** Acknowledge ("Got it — calm/professional, noted"), then one question with inline default. Never a list. If they said "just fix it / ship it" at the start, still produce the report first — then ask for "fix all".

Never ask: "what breakpoints?", "Tailwind or CSS?", "grid or flex?" — your job.

## Anti-patterns

| Anti-pattern | Damage | Do instead |
|---|---|---|
| "Looks good!" after scanning 1 page | Missed 3 dead links on page 4 | Inventory every route first |
| Inventing a finding on a file you never read | Loses all trust when human checks the line number | Read the file, quote verbatim |
| Fixing while auditing | Report never matches what shipped; can't revert | Audit first → report → wait → fix |
| One giant "ux: fix everything" commit | Can't revert the button change without reverting the type change | Grouped commits per concern |
| Changing payment/auth in a UX fix | Break money/security with a style change | UX-only scope — buttons, type, spacing, states, copy |
| Adding a design system from scratch | Weeks of drift, nothing ships | Upgrade what exists: one canonical Button, one scale, one palette rule |
| "Fixed, trust me" with no grep | Dead `href="#"` still live, 0 verification | Paste `grep` output, click every nav link |
| Asking "what hex codes do you want?" | Delegates your job to a non-designer | Pick from product's ancestor, show one direction, explain why |
| Skipping the inventory because "I remember the pages" | Missed orphan + dead route | `find` + nav scan every time |
| Shipping with John Doe still in `app/` | Screenshotted, trusted lost | Grep and remove — mocks belong in `scripts/seeds.*` only |

## Definition of done

- [ ] Every route inventoried: route → file → status table exists
- [ ] 8 audit passes run: buttons, type, layout, color, states, responsive, a11y, consistency — each finding has file:line + severity + fix
- [ ] Report `docs/UX-AUDIT.md` exists — summary + findings table + details with before/fix per issue — written before any fix
- [ ] Report ends with exact prompt: `Reply "fix all" to apply`
- [ ] Only after "fix all": grouped commits (one per concern) + verification greps pasted (0 dead links, 0 John Does, 0 blank routes)
- [ ] Every primary button uses one canonical component with `disabled` + `loading` + `focus-visible` — no orphan `bg-blue-500` buttons
- [ ] No blank pages: every nav link resolves to a real page with real content
- [ ] Every data view has loading skeleton, empty with CTA, error with retry — no white screens
- [ ] Responsive at 320, 375, 768, 1024, 1440: no horizontal scroll, tap ≥44px, no hover-only UI
- [ ] No mock/demo data in `app/` — John Doe / Lorem / hardcoded arrays removed
- [ ] Owner can explain the upgrade in two sentences
- [ ] Verification: every page clicked, every link resolved, no blank route, no dead `href="#"`

## Works with

- `responsive-mobile-first` — the 320px-first rules this audit checks
- `frontend-craft` — the loading/empty/error/success states this audit verifies you actually shipped
- `distinctive-visual-style` — the taste this audit judges against (not the template)
- `design-system-and-visual-language` — the tokens this audit enforces
- `ux-writing-and-onboarding` — the copy this audit upgrades
- `accessibility-and-inclusive-design` — the a11y pass that this audit includes
- `project-blueprint` — the route/file structure this audit maps
- `code-review-and-audit` — same report pattern, UX + code; run both before launch
- `production-readiness` — the launch gate that runs this as the final UI pass
