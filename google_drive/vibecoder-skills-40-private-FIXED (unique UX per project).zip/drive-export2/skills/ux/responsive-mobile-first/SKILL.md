---
name: responsive-mobile-first
description: Use on every screen, page, or component that will be seen on a phone — which is every screen. Enforces a true mobile-first build (320px → desktop), fluid type and layout, tap targets that work with a thumb, and a zero-tolerance completeness audit: no empty links, dead buttons, blank pages, missing images, placeholder lorem, fake John Does, or mock data that ships to production. Produces a responsive, production-ready UI that is not "desktop shrunk down" and never half-built.
metadata:
  category: ux
  version: 1.0.0
  value: "$100"
  group: ux
---

# responsive-mobile-first

## Promise

Every page you ship works perfectly on a 320px phone first, then gets better on larger screens — never the reverse. No link goes nowhere, no page is blank, no image is broken, no button is dead, and no demo data ever reaches a real user. Open it on any device and it feels finished.

## When to use

- Building any page, screen, layout, or component — new project, new feature, redesign, or review
- Before you call anything "done" — run this as the last UI gate
- The AI generated a page and you haven't checked it on mobile
- You see `href="#"`, `href=""`, `Lorem ipsum`, "John Doe", `example@email.com`, broken images, or a blank `/dashboard`
- Reviewing a PR, a launch checklist, or an inherited codebase that "works on my laptop"
- Someone says "make it responsive" — this skill *is* the definition

## When NOT to use

- Transactional emails (different responsive rules — but the zero-blank-page rule still applies)
- Internal one-off scripts with no UI
- Native mobile apps already covered by `mobile-app-delivery` — use this for their webviews and marketing pages though

## The 60-second version

```
1. MOBILE FIRST, ALWAYS    Start at 320px. No desktop-first media queries. Ever.
2. FLUID, NOT FIXED        Type, space, and columns scale. No fixed 1200px containers.
3. TOUCH FIRST             44px tap targets, thumb zones, no hover-only actions.
4. CONTENT COMPLETENESS    Every link goes somewhere real. Every page has real content.
5. ZERO FAKE DATA          No lorem, no John Doe, no empty arrays. Wire real data or build the real empty state.
6. TEST ON REAL WIDTHS     320, 375, 768, 1024, 1440 — not just "resize your laptop a bit".
```

> **If the UI wasn't checked at 320px, it wasn't checked.**

## Steps

### Step 1 — Start from the phone (the only correct order)

Build the mobile layout first, then *add* for larger screens. This is not a preference — it's the law for this skill.

**Do:**

```css
/* ✅ mobile-first: base is phone, enhancements are min-width */
.page {
  padding: 16px;
  display: grid;
  gap: 16px;
}
@media (min-width: 768px) {
  .page { grid-template-columns: 240px 1fr; padding: 32px; gap: 32px; }
}
@media (min-width: 1024px) {
  .page { grid-template-columns: 280px 1fr 320px; }
}
```

**Never:**

```css
/* ❌ desktop-first: you're fighting yourself on every phone fix */
.page { width: 1200px; }
@media (max-width: 768px) { /* 47 overrides to undo desktop */ }
```

Rules:

- **No fixed widths.** Use `%`, `max-width`, `min()`, `clamp()`, `fr`, flex `gap`. The only fixed numbers allowed are `max-width: 1280px` on a centered wrapper — never `width: 1200px`.
- **Breakpoints are *enhancements*, not buckets.** Use 2-3: `640px` (phone→tablet), `768-1024px` (tablet→desktop), `1280px` (wide). Don't invent 6 breakpoints to save a bad layout.
- **Columns collapse, they don't hide.** On phone: 1 column. On tablet: sidebar stacks or becomes a drawer. On desktop: columns open. Use CSS Grid with `grid-template-columns` changing per breakpoint — not `display: none` to hide mess.
- **Overflow is a bug.** No horizontal scroll on mobile. Ever. `overflow-x: clip` on the root and hunt the `width: 100vw` + scrollbar offender.

Quick check before you write a line: open DevTools, set to **320px** (iPhone SE), throttle to Slow 4G. Keep it there until the phone layout is perfect. Then widen.

### Step 2 — Make every dimension fluid

Hardcoded sizes are why responsive fails. Use fluid, relative units everywhere.

**Fluid type:**

```css
/* Body scales gently: never microscopic on phone, never shouting on desktop */
:root { font-size: clamp(15px, 1vw + 0.75rem, 17px); }
h1 { font-size: clamp(1.75rem, 5vw, 3rem); line-height: 1.15; }
h2 { font-size: clamp(1.25rem, 3vw, 1.75rem); }
```

**Fluid space:**

```css
.section { padding: clamp(16px, 4vw, 48px); gap: clamp(12px, 2vw, 24px); }
```

**Fluid layout:**

```tsx
// ✅ grid that is responsive without a single media query
<div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
  {items.map(item => <Card key={item.id} {...item} />)}
</div>

// ✅ container queries for components that live in different parents
<div className="@container">
  <div className="grid grid-cols-1 @[520px]:grid-cols-2 gap-4">
    <Stat /><Chart />
  </div>
</div>
```

**Images that never break mobile:**

```tsx
// ❌ fixed width image that overflows or is microscopic
<img width="1200" />

// ✅ responsive, never overflows, never layout-shifts
<img
  src={src}
  srcSet={`${src}?w=400 400w, ${src}?w=800 800w, ${src}?w=1200 1200w`}
  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
  className="w-full h-auto object-cover aspect-[16/10]"
  loading="lazy"
  alt="Describe the image, don't leave it blank"
/>
```

Rules: every image gets `max-width: 100%`, `height: auto`, an `alt`, a reserved `aspect-ratio` (prevents layout jump), and a `srcset`. No `width: 100vw`.

### Step 3 — Design for thumbs, not cursors

Mobile is not "desktop but smaller" — it's a thumb on glass.

| Requirement | Spec | Why |
|---|---|---|
| **Tap target** | ≥ 44×44px, ≥ 8px gap between | Thumbs miss 32px buttons. Fat-finger cost = lost bookings. |
| **Primary action in thumb zone** | Bottom 1/3 of screen on phone | Top nav is unreachable one-handed. |
| **No hover-only UI** | Every hover action has a tap equivalent | Hover doesn't exist on phone. Dropdowns that only open on hover = broken. |
| **Navigation collapses** | Hamburger/drawer or bottom tab bar on <768px | Don't squish 6 nav items into 375px. Stack or hide behind a real menu. |
| **Tables become cards** | On phone: each row → a card with labeled fields | Tables with horizontal scroll are unreadable. |
| **Forms are single-column** | Label above input, full-width, `inputmode` + `autocomplete` | Two-column forms on phone = mis-taps and zoom hell. |
| **No text smaller than 14px** | Body ≥15px, labels ≥13px | Anything smaller fails WCAG and is unreadable on phone in sunlight. |
| **Line length** | 45-75 characters | 120-character lines on desktop exhaust eyes; 35 on phone exhaust thumbs. `max-width: 65ch` on prose. |

```tsx
// ✅ mobile: single column, full-width inputs, big tap targets
<form className="grid gap-4 max-w-[480px]">
  <label className="grid gap-1">
    <span className="text-sm font-medium">Email</span>
    <input type="email" inputMode="email" autoComplete="email"
           className="w-full h-11 px-3 rounded-lg border text-base" />
  </label>
  <button className="h-11 w-full sm:w-auto px-6 text-base font-medium">Continue</button>
</form>
```

### Step 4 — The zero-tolerance completeness audit (fail = not shippable)

Run this before *any* "done". A single fail = the page is not production-ready. No exceptions.

#### 4A — No empty links, dead buttons, or ghost navigation

Every interactive element must **do something real and go somewhere real**.

| Check | Fail | Pass |
|---|---|---|
| Every `<a>` has a real `href` | `href="#"`, `href=""`, `href="javascript:void(0)"`, missing href | `href="/pricing"` or `href="https://..."` that exists |
| Every `<button>` has a handler | `onClick={() => {}}`, `onClick={undefined}`, no onClick but looks clickable | Calls real logic, disables while in-flight, shows progress |
| Every nav item resolves | Click → blank page, 404, or same page | Click → real page with real content |
| No orphan CTAs | "Learn more", "View all", "Get started" that go nowhere | Label says where it goes, and it goes there |
| Footer links checked | 12 links, 8 dead | Every footer link is real or removed |
| Back / breadcrumb works | Goes to blank or loops | Returns to the actual parent |

Fix: if a feature isn't built yet, **don't render the link**. Show the text without link styling + a "Coming soon" note, or hide it. A disabled-looking link that does nothing is worse than no link — it teaches users that your app is broken.

```tsx
// ❌ never ship
<a href="#">Learn more</a>
<a href="">View dashboard</a>
<button>Save</button> // no onClick
<Link href="/settings">Settings</Link> // but /settings is 404

// ✅ every link is real, todo features are honest
{hasSettings ? (
  <Link href="/settings">Settings</Link>
) : (
  <span className="text-slate-500">Settings — coming next week</span>
)}

// ✅ buttons are honest about state
<button onClick={handleSave} disabled={isSaving} aria-busy={isSaving}>
  {isSaving ? "Saving…" : "Save changes"}
</button>
```

**How to audit in 90 seconds:** `Cmd+click every link on the page.` On mobile, tap every tappable thing. Record failures. Fix before commit.

#### 4B — No blank pages, ghost states, or missing components

Every route and every state must render **something intentional**.

| Route/State | What AI usually ships | What production needs |
|---|---|---|
| `/` (home) | blank or lorem hero | Real headline, real value prop, real CTA with a real destination |
| `/pricing`, `/about`, etc. | nav link exists, page is empty or 404 | Real page, or link removed until page exists |
| List with 0 items | blank white screen | "No bookings yet — book your first class" + CTA button to create one |
| List while loading | blank, then pop-in | Skeleton in the real layout (same shape as data) |
| Error (500, offline, 404) | white screen, raw JSON, stack trace, or default Next.js 404 | Friendly message in user's words + what to do + retry/home button + your design system |
| Profile / settings | "Coming soon" in the middle of a real app | Either built, or not in nav until built |
| Image src missing/broken | broken icon or empty box | Fallback: initials, placeholder illustration, or hidden block — never a broken `<img>` |
| Search: no results | "No results" (that's it) | "No results for 'xyz' — try X / clear filters" |

```tsx
// ✅ every route has real content — use this gate in your router/layout
// If a page doesn't exist, don't link to it. If it has no data, show the empty state.
if (!data) return <SkeletonList />;
if (data.length === 0) return <EmptyState action={<Button href="/book">Book your first class</Button>} />;
if (error) return <ErrorState message="We couldn't load your bookings." onRetry={retry} />;
return <BookingList items={data} />;

// ✅ 404 that is on-brand and helpful, not the framework default
export default function NotFound() {
  return (
    <div className="mx-auto max-w-[480px] px-6 py-16 text-center">
      <h1 className="text-2xl font-semibold">This page doesn't exist</h1>
      <p className="mt-2 text-slate-600">Try the dashboard, or tell us what you were looking for.</p>
      <div className="mt-6 flex gap-3 justify-center">
        <Button href="/dashboard">Go to dashboard</Button>
        <Button variant="ghost" href="/">Home</Button>
      </div>
    </div>
  );
}
```

**Rules:**
- **Every route in nav must have a file that exists and renders real content.** Check `app/` or `pages/` — if `/settings` is in the nav, `app/settings/page.tsx` better exist.
- **Every data view needs 5 states:** loading (skeleton), empty (with CTA), error (with retry), success (data), offline/stale. See `frontend-craft` — this skill enforces you actually shipped them.
- **No blank screen is ever acceptable.** A white screen is a bug, not an empty state.

#### 4C — No demo data, mock data, lorem, or fake users

If it ships, it's real data or it's gone. Fake data in production is not "placeholder" — it's a lie that destroys trust and gets screenshotted.

| Banned (never ship) | Why it kills trust | Ship instead |
|---|---|---|
| `Lorem ipsum`, `lorem`, `Placeholder text` | Says "unfinished" in the universal language | Real copy from the brief, or `TBD` hidden behind a feature flag |
| `John Doe`, `Jane Smith`, `Test User`, `Acme Inc` | Users think they're looking at someone else's data | Real seeded data for dev, empty state for prod, or anonymized if needed |
| `example@email.com`, `test@test.com` in UI | Obvious fake | Real email or not rendered |
| Hardcoded arrays in components `const users = [{name: "Alice"}, ...]` | Masks that the API is empty/broken | Fetch from API; on empty → empty state; on error → error state |
| Random images from `picsum`, `unsplash` with ids `1,2,3` | Feels fake, breaks brand | Real product images, or an intentional illustration system |
| `⭐⭐⭐⭐⭐` with no reviews, "10,000 happy customers" invented | Legal risk + scam feel | Real count or removed. Never invent a number. |
| `price: 99.99` placeholders on every card | Price lie | Real price from real source, or no price shown |
| TODO comments rendered as UI | — | — |

```tsx
// ❌ mock data living in the component — ships to production
const bookings = [
  { id: 1, name: "John Doe", date: "2024-01-01" },
  { id: 2, name: "Jane Smith", date: "2024-01-02" },
];
return bookings.map(b => <Card {...b} />);

// ✅ real data path with honest empty state — production-ready
const { data, isLoading, error } = useBookings();
if (isLoading) return <SkeletonList count={3} />;
if (error) return <ErrorState onRetry={refetch} />;
if (!data || data.length === 0) return <EmptyState title="No bookings yet" action={<BookButton />} />;
return data.map(b => <Card key={b.id} {...b} />);

// ✅ seeded data stays in scripts/seeds.ts, never in components
// Run `npm run db:seed` in dev only. Prod starts empty, on purpose.
```

**Where mock data IS allowed:** `scripts/seeds.ts`, `tests/fixtures/`, Storybook stories, and local dev. Guard it behind `process.env.NODE_ENV !== "production"` or a seed script that never runs in prod. Never `import { mockUsers } from "@/data/mock"` inside `app/`.

### Step 5 — Responsive audit (the 15-minute pass you do every time)

After build, before "done", do this on the **real build**, not just in your head.

**1. Width sweep (5 min):** Chrome DevTools → Device Toolbar → Responsive. Drag from 320px to 1440px slowly. Note every breakpoint where something breaks: text overflows, columns collide, nav wraps weirdly, horizontal scroll appears, tap targets shrink.

**2. Thumb test (3 min):** On a real phone or in DevTools with touch emulation, tap every interactive element with your thumb. Can you hit it? Is the hit area big enough? Is the primary action reachable?

**3. Content test (2 min):** Click every link. Does it go somewhere real with real content? Any blank page? Any 404?

**4. Data test (2 min):** With an empty database: are empty states real and helpful? With errors: are error states real and retryable? Any lorem, John Doe, or mock array visible?

**5. Offline/slow test (3 min):** DevTools Network → "Slow 4G" + "Offline". Throttle, reload, navigate. Do you see skeletons then error states with retry — or a white screen?

Record fails as issues. Fix before ship. Add the audit to your PR template:

```md
- [ ] Checked at 320, 375, 768, 1024, 1440
- [ ] No horizontal scroll at any width
- [ ] Every link goes to a real page
- [ ] Every page has real content (no blank/404/lorem)
- [ ] Empty + error + loading states render
- [ ] No mock/demo data visible
- [ ] Tap targets ≥44px, forms single-column on phone
- [ ] Tested throttled + offline
```

## Non-negotiables

1. **Mobile first, no exceptions.** Base CSS is phone. Desktop is `min-width` enhancements. If you wrote `@media (max-width)`, delete and rewrite mobile-first.
2. **No fixed widths.** Nothing is `width: 1200px`. Use fluid units, `max-width` wrappers, `min()`, `clamp()`, grid `fr`.
3. **No dead links or dead buttons.** Every `href` resolves to a real page. Every `button` does a real thing. If it's not built, it's not rendered as a link — period.
4. **No blank pages.** Every route in nav has a file, every file renders real content. Blank is a bug.
5. **No placeholder error pages.** Your 404, 500, offline, and empty states are designed, branded, and helpful — not framework defaults.
6. **No broken images.** Every image has `alt`, `aspect-ratio`, `max-width: 100%`, and a fallback when src is missing.
7. **Zero demo/mock data in production.** No lorem, no John Doe, no hardcoded arrays in `app/`. Real data from the API or honest empty states. Seeded data lives only in `scripts/seeds.*` and runs in dev.
8. **Every data view has 5 states shipped:** loading, empty, error, success, offline. Shipping only "success" is shipping a prototype.
9. **Tap targets ≥44×44px, thumb-reachable primary actions, no hover-only UI.**
10. **Single-column forms on phone, tables → cards on phone.**
11. **No horizontal scroll at any width.** Test it — drag 320→1440.
12. **Test on a real phone or throttled emulation before marking done.** Laptop-only checking is not checking.

## Ask the human

**One question at a time** — conversational, not a form.

Ask when relevant, in this order, each with a default:

1. "What's the most important thing someone does on their phone on this page? Like 'book a class' or 'pay' — I'll make that the primary thumb action. — Not sure? Just say 'you pick' → I'll assume the main CTA."
2. "Are there pages that aren't built yet I should leave *out* of navigation for now, or show as 'Coming soon' without a link?"
3. "For empty screens — like before they've booked anything — what should they see? I'll write a friendly empty state with a button to do the thing. — You pick? I'll make it inviting and on-brand."
4. "Any real content I should use for images and copy — brand photos, actual prices, real testimonials — or should I use honest placeholders (empty states) until you provide them? Never fake them."
5. "Do you want a bottom tab bar on mobile (like Instagram) or a hamburger menu? — You pick? I'll do bottom tabs if it's 3-5 items, hamburger if more."

**How:** Acknowledge ("Got it — so booking is the thumb action, noted"), then one question with its default. Never a list. If they already answered during discovery, don't re-ask: "You said bookings are core, so I'll make 'Book' the thumb-primary — correct me if wrong."

Never ask: "what breakpoints?", "Tailwind or CSS?", "grid or flex?", "12-column or 16?" — those are your job.

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| Desktop-first CSS (`max-width` overrides) | 47 overrides to fix phone; phone always broken | Mobile-first: phone base, `min-width` enhancements |
| Fixed 1200px container | Overflows on phone, horizontal scroll | `max-width: 1280px` centered wrapper + `padding: clamp(16px, 4vw, 32px)` |
| `href="#"` as placeholder | Broken link, bad for SEO/a11y, teaches users your app is broken | No link until the page exists, or honest "Coming soon" text |
| Hardcoded `const data = [{name: "John Doe"}]` in component | Ships fake data to production; masks broken API | Fetch real data → empty state if empty → error state if failed |
| `Lorem ipsum` left in production | Screams unfinished, gets screenshotted, harms SEO | Real copy or no copy — hide the section until copy is ready |
| Tables on mobile | Unreadable sideways scroll | Transform: each row → labeled card on <768px |
| 6 nav items squished on 375px | Overlaps, wraps into 2 rows, unusable | Collapse to hamburger/drawer or bottom tabs on phone |
| Horizontal scroll on mobile | Feels broken; users think page is glitched | `max-width: 100%` everywhere, audit overflow, kill `100vw` |
| Hover-only menus/actions | Don't exist on touch | Always provide tap alternative; use click, not hover |
| 32px buttons, tiny text | Missed taps, unreadable in sunlight | 44px targets, 15px+ body, 8px gap |
| Blank `/settings` with a nav link | User thinks app is broken | Don't link until built, or build the real empty state |
| Default/framework 404 | White screen, wrong brand, no help | Designed 404 with retry/home, same header/footer, your tone |
| Broken `<img>` icon | Ugly, broken feel | Fallback initials/illustration + `onError` handler |
| "Responsive" = shrunk desktop | Microscopic text, 1px tap targets, 6 columns at 320px | 1 col on phone, 2 on tablet, 3+ on desktop — layout changes |
| `width: 100vw` | Triggers horizontal scroll (scrollbar width) | `width: 100%` or `max-width: 100%` |

## Definition of done

- [ ] Phone base at 320px is perfect — then enhanced at 640, 768, 1024, 1280. No `max-width` desktop-first queries.
- [ ] No horizontal scroll at any width from 320 to 2560. Tested by dragging.
- [ ] No fixed widths; type and space use `clamp()` / fluid units; images use `max-width: 100%` + `aspect-ratio` + `srcset`.
- [ ] Tap targets ≥44×44px, 8px gap, primary action in thumb zone, no hover-only UI.
- [ ] Forms are single-column on phone, labels above inputs, full-width, correct `inputmode`/`autocomplete`.
- [ ] Tables are cards on phone; nav collapses to drawer/bottom tabs on phone.
- [ ] **Every link goes to a real page with real content.** Clicked and verified. Zero dead links.
- [ ] **Every route in navigation has a file that exists.** No nav → blank/404.
- [ ] **Every data view has 5 states rendered:** loading (skeleton), empty (with CTA), error (with retry), success, offline.
- [ ] **No demo/mock/placeholder data visible:** no lorem, no John Doe, no hardcoded arrays in `app/`, no fake prices or reviews.
- [ ] **Error pages (404, 500, offline) are branded and helpful** with clear action (home/retry/contact).
- [ ] Images never broken: fallback when src missing, `alt` filled, `aspect-ratio` reserved.
- [ ] Audited at 320, 375, 768, 1024, 1440 + throttled + offline before marking done.
- [ ] Lighthouse mobile performance ≥90 and no CLS >0.1.

## Works with

- `frontend-craft` — the interaction states (loading/empty/error/offline) you must ship for every view
- `distinctive-visual-style` — the visual identity that makes responsive layouts memorable
- `design-system-and-visual-language` — the tokens (spacing, type scale, breakpoints) this skill uses
- `ux-writing-and-onboarding` — the real copy that replaces lorem and the words in empty/error states
- `accessibility-and-inclusive-design` — tap targets, keyboard nav, focus, and the responsive a11y audit
- `production-readiness` — the launch gate that runs this as the final UI pass
- `project-blueprint` — the route/file structure that ensures every nav item has a real page
- `code-review-and-audit` — the automated check for dead links, hardcoded mocks, and fixed widths
