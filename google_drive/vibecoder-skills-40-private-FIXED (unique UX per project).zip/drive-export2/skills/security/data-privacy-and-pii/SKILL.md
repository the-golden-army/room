---
name: data-privacy-and-pii
description: Use whenever an app collects names, emails, phone numbers, location, health data, IDs, payments, messages, or files from real people — and whenever someone asks about GDPR, privacy policy, cookie banners, analytics, "delete my account", or data retention. Produces a data map, defines what you may collect and how long you keep it, keeps personal data out of logs/URLs/analytics, implements a working deletion pipeline, and prepares you for a breach or a customer's privacy review.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# data-privacy-and-pii

## Promise

You know exactly what personal data you hold, why you hold it, where it travels, and how it disappears
when someone asks. No surprises in your inbox, no panic when an enterprise customer sends a questionnaire.

## When to use

- The app collects **anything** from a person: name, email, phone, address, photo, location, IP, device ID
- Payment data, health data, ID documents, children's data, messages between users
- Someone asks: "do you have a privacy policy?", "are you GDPR compliant?", "can you sign a DPA?"
- Adding analytics, session recording, heatmaps, chat widgets, or any third-party script
- Implementing "delete my account" or a data export
- Sending marketing email, or using data for anything beyond delivering the service
- Any EU/UK/California/Brazil user (and honestly, just do it for everyone)

## When NOT to use

- Truly anonymous, no-account, no-collection static sites (but check your analytics)

## The 60-second version

```
1. Collect the minimum. Every field you don't collect is a field you can't lose.
2. Write the data map: what you collect, why, where it lives, who else gets it, how long you keep it.
3. Never put personal data in a URL, a log, an analytics event, or an error report.
4. Encrypt in transit (HTTPS, always) and at rest (the platform default is usually enough to start).
5. Have a retention rule per data type. "Forever" is not a rule, it's a liability.
6. Make deletion real: database AND files AND email tool AND analytics AND logs policy AND backups.
7. Privacy-friendly analytics by default. If you need a cookie banner, you probably added a tracker
   you didn't need.
8. Know who else processes the data (subprocessors) and check they're allowed to.
9. Have a one-page answer ready for: "what happened, who's affected, when did you know, what did you do?"
```

## Step 1 — The data map (30 minutes, do it before writing code)

`docs/DATA-MAP.md`:

| Data | Why you need it | Where it lives | Who else receives it | Keep for | Delete how |
|---|---|---|---|---|---|
| Email | login, receipts | `users.email` | Resend (email), Stripe | Until account deleted | `DELETE /users/:id` cascade |
| Name | receipts, personalization | `users.name` | Stripe | Until account deleted | cascade |
| Password hash | authentication | `users.password_hash` | nobody | Until account deleted | cascade |
| IP address | security, rate limiting | logs | host (Sentry?) | 30 days | log retention job |
| Uploaded photos | the product feature | object storage | nobody | Until user deletes | delete objects + rows |
| Payment card | charging | **Stripe only — never your DB** | Stripe | Stripe's policy | n/a |
| Analytics events | understanding usage | Plausible | Plausible | 14 months | provider deletion API |

If a row has no "why you need it", stop collecting it. If a row has an unknown "who else receives it",
find out — that's your subprocessor list, and it's the thing customers ask about.

## Step 2 — Collect the minimum

| Ask yourself | Example |
|---|---|
| Do you need date of birth, or just "over 18"? | Store a boolean |
| Do you need a full address, or just a country for tax? | Store the country |
| Do you need a phone number, or is email enough? | Drop the phone field |
| Do you need the real name, or will a display name do? | Display name |
| Do you need it at signup, or can it wait until it's used? | Collect later, at the point of need |
| Do you need to keep it after the account closes? | Accounting records: yes, for the legal period. Everything else: no. |

**Special categories** (health, biometrics, race/religion/politics, sexual orientation, union membership,
criminal records, precise location, children under 13-16): treat as high-risk. Encrypt, restrict access,
log every access, minimize retention, and get explicit consent. If you're storing children's data, get
parental consent and read the local rules (COPPA in the US, age 13-16 across the EU).

## Step 3 — Keep personal data out of the places that leak

| Where | Rule | Fix |
|---|---|---|
| **URLs** | Never put email/name/phone in a path or query | `/users/42`, not `/users?email=a@b.com`. URLs end up in logs, history, `Referer`, analytics. |
| **Logs** | Log IDs, not people | `logger.info({ userId: u.id, action: "upgrade" })` — never `logger.info(user)` |
| **Error reports** | Scrub PII before sending | Sentry: `beforeSend` scrubbing, `sendDefaultPii: false` |
| **Analytics** | No PII in event properties | `user_id: 42`, not `email: a@b.com`. Never send form contents. |
| **Third-party scripts** | Every script can read the page | Inventory them; prefer self-hosted; add SRI |
| **Backups** | Encrypted, access-controlled, with a retention window | Old backups eventually delete the deleted |
| **Test data** | Never use production data in dev | Generate fake data |
| **Support tools** | Chat widgets and screen recorders capture a lot | Mask sensitive fields; disable recording on sensitive pages |

```ts
// Structured logging with an allowlist — PII can't sneak in
logger.info("booking.created", { bookingId: b.id, userId: u.id, classId: b.classId, amountCents: b.amountCents });
// ❌ logger.info("booking.created", { booking: b, user: u, req: req.body });
```

```ts
// Sentry scrubbing
Sentry.init({
  dsn: process.env.SENTRY_DSN,
  sendDefaultPii: false,
  beforeSend(event) {
    if (event.request?.data) event.request.data = redact(event.request.data);
    return event;
  },
});
```

## Step 4 — Cookies, consent, and analytics

**The order of preference:**

1. **No tracking at all** — no banner needed, no consent needed
2. **Privacy-friendly analytics** (Plausible, Umami, self-hosted PostHog, Fathom, Simple Analytics):
   aggregate, cookieless, no cross-site profiles. In many jurisdictions this needs no consent banner.
3. **Cookie-based analytics** (GA4 and friends) — needs a banner with a real "reject" option, and it must
   not set cookies before consent
4. **Session recording / heatmaps** — consent required, plus masking. These can capture passwords and
   personal data straight out of the DOM. Ask the human before adding one.

Banner rules that actually matter: no pre-ticked boxes, "reject" as easy as "accept", nothing loads before
consent, consent is as easy to withdraw as to give, and you keep a record of the choice.

Check what your dependencies and frameworks set before you write a banner — the answer is often "nothing
that needs one".

## Step 5 — Storage and encryption

- **In transit:** HTTPS everywhere, TLS 1.2+, HSTS, no mixed content
- **At rest:** the managed platform's default encryption is on for serious hosts. Turn it on if it's optional.
- **Application-level encryption** for the few fields where a database leak would be catastrophic
  (API tokens you store on behalf of users, ID numbers, health notes):

```ts
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
// AES-256-GCM; key from a secret manager; store iv + tag + ciphertext
export function encrypt(plain: string, key: Buffer) {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString("base64");
}
```
- **Passwords:** hashed (argon2id/bcrypt), never encrypted, never reversible
- **Secrets:** secret manager, not the DB
- **Don't roll your own crypto.** Use the platform's primitives.

## Step 6 — Retention and deletion (make it real)

Define a rule per data type, then automate it:

| Data | Retention | Enforced by |
|---|---|---|
| Account data | Until deletion + 30 days | deletion job |
| Session records | 30 days | TTL index / cron |
| Logs | 30-90 days | host log retention |
| Error events | 30-90 days | provider setting |
| Analytics | 14 months (or less) | provider setting |
| Invoices / accounting | 7-10 years (legal requirement) | keep, legally |
| Support tickets | 2 years | provider setting |
| Uploaded files | Until user deletes + 30 days | deletion job |
| Backups | 30 days rolling | host setting — and document that deletion takes up to 30 more days to reach backups |

**The deletion pipeline** — a user deletion must fan out, or it didn't happen:

```ts
export async function deleteUser(userId: string) {
  await db.$transaction([
    db.session.deleteMany({ where: { userId } }),
    db.auditLog.updateMany({ where: { actorId: userId }, data: { actorId: null } }), // keep the fact, drop the link
    db.user.delete({ where: { id: userId } }),     // cascades to owned rows
  ]);
  await storage.deletePrefix(`uploads/${userId}/`);                 // files
  await emailService.deleteContact(userId);                         // email tool
  await analytics.deleteUser(userId);                               // analytics
  await stripe.customers.del(customerId);                           // payment profile (keep invoices for tax)
  await db.deletionLog.create({ data: { subjectId: hash(userId), completedAt: new Date() } });
  // Document: backups purge within 30 days. Log that we did this.
}
```

Keep a **deletion log** (hashed subject, timestamp, what was deleted). That's your proof when someone asks.
Keep invoices/accounting records even after deletion — the law requires it, and your privacy policy should
say so.

## Step 7 — Be ready for requests

| Request | SLA | What you need |
|---|---|---|
| "Send me my data" (access/export) | 30 days (aim for 48h) | An export that produces JSON/CSV of everything tied to the user |
| "Delete my account" | 30 days (aim for immediate) | The pipeline above, self-service in the app |
| "Fix my data" (rectification) | 30 days | Editable profile fields |
| "Stop emailing me" | Immediately | Unsubscribe in every marketing email; keep transactional |
| "Who else has my data?" | 30 days | Your subprocessor list |

Build "download my data" and "delete my account" **into the product**. It takes a day now and a weekend
of panic later if you don't.

## Step 8 — Third parties (subprocessors)

Every service that touches personal data goes on the list: hosting, database, email, payments, error
tracking, analytics, AI providers, support chat, file storage. For each:

- [ ] Named in the privacy policy
- [ ] Has a data processing agreement (DPA) available
- [ ] Stored data location known (relevant for transfers)
- [ ] Retention setting configured (not left at the default "forever")
- [ ] Account access protected (MFA, limited seats)

**AI providers:** check whether they train on your data, their retention window, and where they process it.
Never send personal data you wouldn't want on the front page. See `ai-features-in-production`.

## Step 9 — Breach readiness

One page, written before you need it:

```
1. CONTAIN    revoke credentials, block access, disable the feature
2. ASSESS     what data, whose, how many, how bad (identify the special-category data first)
3. NOTIFY     regulators within 72 hours (GDPR) if there's a risk to people; users "without undue delay"
4. RECORD     timeline, decisions, who did what — a breach register entry
5. FIX        the actual hole, then tell people what you changed
```

If you store passwords properly hashed and have no other data, a database leak is an incident, not a
catastrophe. That's the payoff for doing the boring things.

## Non-negotiables

1. **Collect less than you think you need.** The best-protected data is data you never took.
2. **Never put personal data in a URL, a log, an analytics event, or an error report.**
3. **Every data type has a written retention period.**
4. **Deletion is a pipeline, not a row delete.** Files, email tools, analytics, and backups too.
5. **Privacy-friendly analytics by default.** No tracker without a reason and consent.
6. **Passwords hashed, never encrypted, never logged.**
7. **The privacy policy describes what the code actually does** — not what a template says.
8. **Subprocessors are listed, and their DPA status is known.**
9. **Never use production personal data in development or testing.**
10. **Access to production data is limited, logged, and MFA-protected.**

## Ask the human

1. "What information does this collect about people? Let's list it and drop anything we don't actually need."
2. "Where are your users? Europe and California have specific rules; it's cheaper to build for them from the start."
3. "Is any of it sensitive — health, ID documents, financial details, children, private messages?"
4. "If a customer emailed you tomorrow and said 'delete everything about me', could you? How long would it take?"
5. "Do you want analytics? If yes, do you want the kind that shows a cookie banner, or the private kind that doesn't?"
6. "Do you plan to sell to companies? They'll ask you to sign a data agreement, so let's get the list ready now."
7. "How long do you actually need to keep each type of data?"

Never ask: "lawful basis: consent or legitimate interest?", "do you want a DPA?", "is this a controller or processor?" — decide, explain in one line, and move on.

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| Collecting "just in case" | Every field is a liability | Collect at the point of need |
| Emails in URLs | Leaks into logs, history, referrers | IDs |
| `logger.info(user)` | Passwords, tokens and PII in log storage | Allowlisted structured fields |
| Adding session recording without asking | Captures passwords and personal data | Ask; mask; skip |
| "Delete my account" that only sets `deleted_at` | Data still there, still a breach risk | Real fan-out deletion |
| Backups with no retention window | Deleted data lives forever | 30-day rolling backups, documented |
| Copy-pasted privacy policy | Says things you don't do; that's its own problem | Generate it from your data map |
| Production data in a staging DB | Real people's data in an unsecured place | Seed with fake data |
| Analytics events containing form contents | You're shipping user messages to a third party | Event names and IDs only |
| Forgetting the email tool | "Deleted" users still get marketing | Delete the contact too |
| No idea which countries the servers are in | Answerable question you can't answer | Check and record it |

## Definition of done

- [ ] `docs/DATA-MAP.md` exists: every data type, why, where, who receives it, retention, deletion path
- [ ] Minimum viable collection: no field without a purpose
- [ ] No PII in URLs, logs, analytics events, or error reports (verified by grep and by reading the log output)
- [ ] HTTPS everywhere; encryption at rest enabled; passwords hashed with argon2id/bcrypt
- [ ] Retention configured on: logs, error tracker, analytics, backups
- [ ] "Delete my account" works end to end, including files, email tool, analytics, and payment profile; deletion is logged
- [ ] "Download my data" works
- [ ] Subprocessor list written, with retention settings checked
- [ ] Analytics choice made deliberately; consent banner present only if needed
- [ ] Privacy policy matches the data map
- [ ] Breach one-pager written

## Works with

- `appsec-hardening` — the technical controls
- `auth-and-access` — account deletion, session data
- `secrets-management` — API keys to the services holding the data
- `errors-logs-and-monitoring` — log scrubbing and retention
- `ai-features-in-production` — what you send to model providers
- `saas-architecture` — tenant data isolation and export
- `vibe-guardrails` — the no-leak rules for the agent itself
