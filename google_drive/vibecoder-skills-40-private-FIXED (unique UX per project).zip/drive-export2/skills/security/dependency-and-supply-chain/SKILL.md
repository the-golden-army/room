---
name: dependency-and-supply-chain
description: Use before adding any package, library, or GitHub Action, and whenever dependencies are updated or audited. Covers how to vet a package (maintenance, license, size, install scripts, typosquatting), lockfiles and reproducible installs, automated CVE scanning, safe update cadence, removing dependencies, and CI/CD permissions — because `npm install` is the most powerful remote-code-execution button in a vibe-coded project.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# dependency-and-supply-chain

## Promise

Every line of third-party code in your project is there on purpose, is still maintained, and can't
silently execute on your machine or publish as you in CI.

## When to use

- **Before** `npm install` / `pip install` / `go get` of anything you haven't used before
- Adding a GitHub Action, a CI step, or granting a token to a bot
- "Update dependencies?", Dependabot/Renovate PRs, a CVE headline
- Reviewing an AI-generated project (agents love adding packages)
- Before launch, as part of `production-readiness`
- After any supply-chain news event (a popular package gets hijacked)

## When NOT to use

- Never. But it takes 60 seconds for a well-known package and 10 minutes for an unknown one.

## The 60-second version

```
1. The platform already has it? Use the platform feature before adding a package.
2. Vet before install: maintained recently? popular? real repo? sane download count? license?
3. Check the exact name for typosquats before you type it (cross-env vs crossenv, lodash vs lodahs).
4. Commit the lockfile. Install with `npm ci` / `pip install --require-hashes`, not `npm install`.
5. Turn on automated scanning (Dependabot/Renovate + npm audit / pip-audit / osv-scanner).
6. Never auto-merge updates. Read the changelog, run the tests, then merge.
7. CI tokens: least privilege, short-lived, pinned actions by SHA, no secrets in logs.
8. Fewer dependencies is a security feature. Delete them aggressively.
```

## Step 1 — Before you install: the 60-second vet

| Check | How | Red flag |
|---|---|---|
| Last publish | npm/PyPI page | > 2 years ago with no activity |
| Weekly downloads | npm page | < 1,000 for something "everyone uses" |
| Repository | Does the npm page link to a real, active repo? | No repo, or a repo with 1 star and no commits |
| Maintainer | Who is it? | Brand-new account, or a maintainer who changed recently |
| Open issues | Recent, answered? | Years of unanswered security issues |
| Dependencies | `npm view <pkg> dependencies` | Pulling in 80 packages to center a div |
| Size | bundlephobia (frontend) | 300KB for a date formatter |
| License | `npm view <pkg> license` | Unknown, or AGPL in a commercial product |
| Install scripts | `npm view <pkg> scripts` | `postinstall` that downloads and runs something |
| Name | Read it character by character | `crossenv`, `electorn`, `reqeusts`, `nmp` |

```bash
# The vet, in one command block
npm view <pkg> version time.modified license dependencies repository.url maintainers
npm view <pkg> scripts           # look for preinstall/install/postinstall
npx bundlephobia <pkg>           # frontend weight
open https://deps.dev/npm/<pkg>  # transitive view + advisories
```

**Typosquatting is the #1 real attack on small projects.** An attacker publishes `lodahs` or
`@types/expresss`, gets a few hundred installs from typos and copy-paste, and runs a postinstall script on
every one. Type names carefully, copy from official docs, and check the download count.

## Step 2 — The decision: do you even need it?

Ask before installing, in this order:

1. **Does the language/framework/platform do this natively?** (`Array.groupBy`, `structuredClone`,
   `Intl.DateTimeFormat`, `crypto.randomUUID`, the platform's own auth/storage/queue)
2. **Is there already something in the project that does it?** Two date libraries is worse than one.
3. **Is it ~20 lines you could write?** For simple things, copy the 20 lines with a comment and a link to
   where you got them. You own the maintenance, but you also own the behavior.
4. **Is this a large, boring, security-critical problem?** (auth, crypto, parsing HTML, SQL, file uploads)
   → **Yes, install the well-known library.** Don't write your own.
5. Otherwise: install the most boring, most popular option.

**Never write yourself:** password hashing, JWT verification, HTML sanitization, CSV/PDF/XML parsing of
untrusted input, TLS, encryption. **Feel free to write yourself:** date formatting, a debounce, a classnames
helper, a fetch wrapper.

## Step 3 — Install safely

```bash
# JS
npm install <pkg> --save-exact=false     # then commit package-lock.json
npm ci                                   # in CI and for teammates: install exactly what's locked
npm config set ignore-scripts true       # optional hardening: review before allowing install scripts

# Python
pip install <pkg> && pip freeze > requirements.txt   # pin versions
pip-audit

# Never
npm install <pkg>@latest --force
curl <url> | bash
```

- **Commit the lockfile.** It's the only thing that makes installs reproducible.
- **CI installs from the lockfile** (`npm ci`, not `npm install`). An install that can drift is an install
  that can be poisoned.
- **Review the lockfile diff on every dependency change.** That's where a hijacked transitive package shows
  up. If a PR changes 400 lockfile lines to add one small feature, read it.
- **Private registry / dependency confusion:** if you have internal packages, scope them (`@acme/...`) and
  pin the registry, so a public package with the same name can't win.

## Step 4 — Automated scanning

```yaml
# .github/workflows/security.yml
name: security
on: [push, pull_request]
jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - run: npm audit --audit-level=high
      - run: npx osv-scanner --lockfile=package-lock.json
  secrets:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: gitleaks/gitleaks-action@v2
```

Also enable: **GitHub Dependabot alerts + security updates**, or Renovate if you want grouped PRs.
Python: `pip-audit` / `osv-scanner`. Go: `govulncheck`. Ruby: `bundler-audit`.

Reading an advisory without panicking:

| Question | Answer that means "chill" |
|---|---|
| Is it reachable in my code? | I don't call that function / that code path |
| Is it exploitable in my context? | It needs admin access, or local file access, or a config I don't have |
| Dev or prod dependency? | Dev-only (`eslint`, `vite`) — fix when convenient |
| Is there a fix? | Yes, a patch version |
| Is it actively exploited? | No |

Not every CVE matters. But **critical + reachable + in production code** gets fixed today.

## Step 5 — Update cadence

| Bucket | Action |
|---|---|
| Patch (1.2.3 → 1.2.4) | Weekly/biweekly batch, run tests, merge |
| Minor (1.2 → 1.3) | Monthly; read the changelog for breaking-ish behavior |
| Major (1 → 2) | Planned, with a time box; do it when you have tests on the affected area |
| Security advisory | Today, if reachable in production |
| Ancient (2+ years behind) | Schedule it — the longer you wait, the harder the jump |

Rules:
- **Never auto-merge dependency updates into main.** Renovate/Dependabot PRs run tests; a human merges.
- **Update in a branch**, run the app, check the critical paths.
- **Bundle the updates** ("Dependency updates 2026-10-20") instead of 40 separate PRs.
- **Don't update dependencies as a way to fix a bug you don't understand.** You'll change 12 things and
  learn nothing.

## Step 6 — CI/CD permissions (the part everyone skips)

```yaml
# Least privilege by default
permissions:
  contents: read

jobs:
  build:
    permissions:
      contents: read
      id-token: write      # only if you use OIDC to deploy (preferred over long-lived keys)
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm test
```

Rules:
- Pin third-party Actions **by commit SHA**, not by tag (tags are movable)
- Default `permissions: {}`, grant per job
- **`pull_request_target` + checking out PR code = full repo write access to anyone who opens a PR.** Avoid
  it; if you must, never build untrusted code with a privileged token
- No long-lived cloud keys in CI — use OIDC / short-lived tokens
- Mask secrets; never `echo` them; don't print the full env in a debug step
- Require review for workflow file changes
- Self-hosted runners: don't run untrusted PR code on them

## Step 7 — Reduce the surface

Every dependency is code you didn't write and didn't read, running with full access to your process.

```bash
npx depcheck                     # unused dependencies
npx npm-check-updates            # outdated
npm ls --all | wc -l             # how deep does this go?
npx bundlephobia-cli <pkg>       # frontend cost
```

- Delete unused dependencies the day you notice them (a stale dependency is still an attack surface and
  still gets audit alerts)
- Prefer packages with **zero dependencies** for small utilities
- One date library, one HTTP client, one state library — not three
- For frontend: check the bundle. If a page ships 1.2MB of JS, find out which package did that
- If you depend on a package for 15 lines, vendor the 15 lines with attribution

## The malicious-package checklist

Watch for these patterns when vetting or reviewing a lockfile diff:

- [ ] A package name that differs by one character from a popular one
- [ ] A version published minutes after the maintainer's other packages
- [ ] `preinstall`/`install`/`postinstall` scripts that curl, wget, or `eval`
- [ ] Base64 or hex blobs in the install path
- [ ] A package that suddenly changes maintainer
- [ ] Network calls at import time (not just at call time)
- [ ] Reads `process.env` and exfiltrates (check for `http` calls in the install/lifecycle files)
- [ ] Obfuscated/minified code in a package that shouldn't be minified
- [ ] A dependency you don't recognize appearing in a patch update
- [ ] A "protestware"/sabotage update that intentionally breaks things in certain conditions

If you find one: uninstall, check whether it ran (look for unexpected network calls, files, or env access),
rotate any credentials that were on that machine, and report it.

## Non-negotiables

1. **Vet before install. Never install an unverified name on reflex.**
2. **Lockfile committed; CI installs from it.**
3. **Automated scanning on every PR.**
4. **No auto-merge of dependency updates.**
5. **Review lockfile diffs** — especially unexpected new transitive packages.
6. **CI tokens are least-privilege and short-lived; Actions pinned by SHA.**
7. **Never `curl | bash`, and never run install scripts you haven't looked at.**
8. **Delete unused dependencies promptly.**
9. **Never hand-roll crypto, auth, or sanitization to avoid a dependency.**
10. **Fewer dependencies is a feature.**

## Ask the human

1. "Do you want me to ask before adding a new package, or just add sensible ones and tell you?"
2. "Is this project commercial? Some licenses (AGPL) have strings attached for products you sell."
3. "How often do you want me to update dependencies — every week, or only when there's a security reason?"
4. "Are you okay with automated pull requests that update packages, which you'd approve?"
5. "Is anyone else able to publish or deploy this project?" *(if yes: CI permissions matter a lot)*

Never ask: "pnpm or npm or yarn?", "should we pin with overrides?", "do you want a private registry?" — decide
and explain in one line.

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| `npm install` of whatever the AI suggested | Typosquats, abandoned packages, 80 transitive deps | The 60-second vet |
| No lockfile committed | Every install is different; one hijacked version and you're owned | Commit it; `npm ci` |
| Auto-merging Renovate to main | A malicious patch version ships itself | Human merge, tests green |
| `npm audit fix --force` | Silently upgrades majors and breaks your app | Fix deliberately, read the advisory |
| `curl install.sh | bash` | You just ran a stranger's script as root | Use the official install path |
| Long-lived AWS keys in CI | A leaked token = your whole cloud account | OIDC, short-lived, least privilege |
| `permissions: write-all` in workflows | Any compromised action can push as you | Default read, grant per job |
| 300 dependencies for a landing page | Huge attack surface, huge bundle | Platform features + fewer packages |
| "We'll clean up dependencies later" | Later costs a weekend | Delete as you go |
| Ignoring dev-dependency CVEs forever | They run on your machine and in CI | Fix when convenient, but fix |
| Updating everything at once before launch | You won't know what broke | Continuous small updates |

## Definition of done

- [ ] Every dependency has a reason; unused ones removed
- [ ] Lockfile committed; CI installs with `npm ci` / hashes; installs are reproducible
- [ ] `npm audit` / `pip-audit` / `osv-scanner` runs in CI and is clean at `high`
- [ ] Dependabot or Renovate enabled; updates require a human merge
- [ ] GitHub Actions pinned by SHA; workflow permissions are least-privilege; no long-lived cloud keys
- [ ] Secret scanning in CI and pre-commit
- [ ] No `curl | bash` in setup docs; install paths are official
- [ ] Dependency count and bundle size known, and reviewed when they jump
- [ ] Licenses checked for commercial use

## Works with

- `appsec-hardening` — dependencies are one of the five trust boundaries
- `secrets-management` — CI secrets and token scope
- `deploy-and-environments` — build and pipeline hardening
- `project-blueprint` — where dependency policy lives in the repo
- `performance-and-caching` — bundle size
- `code-review-and-audit` — the dependency section of the audit
