# Auth recipes (copy-paste)

Patterns, not a framework. Adapt names to your stack; keep the *shape*.

---

## 1. Signup with email verification

```ts
// POST /api/auth/signup
const { email, password } = z.object({
  email: z.string().email().max(254).transform(s => s.trim().toLowerCase()),
  password: z.string().min(12).max(64),
}).parse(await req.json());

// rate limit BEFORE doing work
await limiter.consume(`signup:${ip}`, 3, "1h");

const existing = await db.user.findUnique({ where: { email } });
if (existing) {
  // don't reveal existence — send the same email, do nothing else
  await sendEmail(email, "finish-signup-or-reset", { link: `${APP_URL}/forgot-password` });
  return json({ ok: true, message: "Check your email." });   // identical response either way
}

const user = await db.user.create({
  data: { email, passwordHash: await hashPassword(password), emailVerified: false },
});
const token = crypto.randomBytes(32).toString("base64url");
await db.verificationToken.create({
  data: { userId: user.id, tokenHash: await sha256(token), type: "verify_email",
          expiresAt: addHours(new Date(), 24) },
});
await sendEmail(email, "verify", { link: `${APP_URL}/verify?token=${token}` });
return json({ ok: true, message: "Check your email." });
```

```ts
// GET /api/auth/verify?token=...
const hash = await sha256(token);
const rec = await db.verificationToken.findFirst({ where: { tokenHash: hash, usedAt: null } });
if (!rec || rec.expiresAt < new Date()) return redirect("/verify-expired");
await db.$transaction([
  db.user.update({ where: { id: rec.userId }, data: { emailVerified: true } }),
  db.verificationToken.update({ where: { id: rec.id }, data: { usedAt: new Date() } }),
]);
return redirect("/welcome");
```

---

## 2. Login (enumeration-safe, rate limited)

```ts
// POST /api/auth/login
const { email, password } = schema.parse(await req.json());
await limiter.consume(`login:ip:${ip}`, 10, "15m");
await limiter.consume(`login:acct:${email}`, 10, "15m");

const user = await db.user.findUnique({ where: { email } });
const ok = user ? await verifyPassword(user.passwordHash, password) : await dummyVerify(); // same timing

if (!user || !ok) {
  await db.authEvent.create({ data: { email, ip, type: "login_failed" } });
  return json({ error: "Invalid email or password." }, 401);     // identical message
}
if (!user.emailVerified) return json({ error: "Please verify your email first." }, 403);

const sessionId = await createSession(user.id, ip, req.headers.get("user-agent"));
setSessionCookie(res, sessionId);
await db.authEvent.create({ data: { userId: user.id, ip, type: "login_success" } });
return json({ ok: true });
```

`dummyVerify()` runs a real argon2 verify against a fixed hash, so timing doesn't reveal whether the
account exists.

---

## 3. Logout (real logout)

```ts
export async function POST(req: Request) {
  const id = readSessionCookie(req);
  if (id) await db.session.deleteMany({ where: { id: await sha256(id) } });  // server-side death
  return clearSessionCookie(json({ ok: true }));
}
```

---

## 4. Password reset (the takeover-proof version)

```ts
// POST /api/auth/forgot-password  — always the same response
const { email } = z.object({ email: z.string().email() }).parse(body);
await limiter.consume(`reset:ip:${ip}`, 10, "1h");
await limiter.consume(`reset:email:${email}`, 3, "1h");

const user = await db.user.findUnique({ where: { email } });
if (user) {
  const token = crypto.randomBytes(32).toString("base64url");
  await db.passwordReset.create({
    data: { userId: user.id, tokenHash: await sha256(token), expiresAt: addMinutes(new Date(), 15) },
  });
  await sendEmail(email, "reset", { link: `${APP_URL}/reset?token=${token}` });   // never log the link
}
return json({ ok: true, message: "If that email is registered, we've sent a link." });
```

```ts
// POST /api/auth/reset-password
const { token, password } = schema.parse(body);
const rec = await db.passwordReset.findFirst({
  where: { tokenHash: await sha256(token), usedAt: null, expiresAt: { gt: new Date() } },
});
if (!rec) return json({ error: "This link is invalid or has expired." }, 400);

await db.$transaction([
  db.user.update({ where: { id: rec.userId }, data: { passwordHash: await hashPassword(password) } }),
  db.passwordReset.update({ where: { id: rec.id }, data: { usedAt: new Date() } }),
  db.session.deleteMany({ where: { userId: rec.userId } }),      // log out every other device
]);
await sendEmail(rec.user.email, "password-changed", {});          // tell them, in case it wasn't them
return json({ ok: true });
```

Note: the token travels in the URL once. Keep it short-lived, and make sure your logging doesn't capture
full URLs with query strings (or strip them).

---

## 5. OAuth ("sign in with Google") — the safe shape

```ts
// Step 1: redirect
const state = crypto.randomBytes(32).toString("base64url");      // CSRF protection
const verifier = crypto.randomBytes(32).toString("base64url");   // PKCE
const challenge = base64url(sha256(verifier));
await db.oauthState.create({ data: { state, verifier, expiresAt: addMinutes(new Date(), 10) } });
return redirect(`${PROVIDER_AUTH_URL}?client_id=${ID}&redirect_uri=${EXACT_CALLBACK}&response_type=code&scope=openid+email&state=${state}&code_challenge=${challenge}&code_challenge_method=S256`);

// Step 2: callback
const { code, state } = Object.fromEntries(new URL(req.url).searchParams);
const rec = await db.oauthState.findFirst({ where: { state, expiresAt: { gt: new Date() } } });
if (!rec) return redirect("/login?error=state");                  // ← the check people skip

const tokens = await exchangeCodeForTokens(code, rec.verifier);   // PKCE verifier
const profile = await verifyIdToken(tokens.id_token);             // verify signature, iss, aud, exp

// ONLY link accounts with a verified email from the provider
if (!profile.email_verified) return redirect("/login?error=unverified_email");

const user = await db.user.findUnique({ where: { email: profile.email } })
  ?? await db.user.create({ data: { email: profile.email, emailVerified: true, authProvider: "google" } });

await db.oauthState.delete({ where: { id: rec.id } });            // one-time state
const sessionId = await createSession(user.id, ip, ua);
return setSessionCookie(redirect("/dashboard"), sessionId);
```

Checklist: exact redirect URI match registered with the provider; `state` verified and single-use; PKCE;
ID token signature verified; `email_verified` required; account linking only on verified email; client
secret only on the server.

---

## 6. Require-user + role guard (framework-agnostic shape)

```ts
export async function requireUser(req: Request): Promise<User> {
  const id = readSessionCookie(req);
  if (!id) throw new AuthError();
  const session = await db.session.findUnique({ where: { id: await sha256(id) } });
  if (!session || session.expiresAt < new Date()) throw new AuthError();
  if (session.absoluteExpiresAt < new Date()) throw new AuthError();
  const user = await db.user.findUnique({ where: { id: session.userId } });
  if (!user || user.disabledAt) throw new AuthError();
  return user;
}

export async function requireRole(req: Request, role: Role): Promise<User> {
  const user = await requireUser(req);
  if (!user.roles.includes(role)) {
    await db.authEvent.create({ data: { userId: user.id, type: "access_denied", target: role } });
    throw new ForbiddenError();
  }
  return user;
}

// Sliding expiry: touch at most once every few minutes
if (session.expiresAt < addDays(new Date(), 7)) {
  await db.session.update({ where: { id }, data: { expiresAt: addDays(new Date(), 14) } });
}
```

Enforce in two places:
1. **Boundary** — middleware or a layout that guards a whole route group (e.g. `app/(admin)/layout.tsx`)
2. **Data access** — every query scoped by owner/tenant/role

---

## 7. Org / team membership check (SaaS)

```ts
export async function requireOrgMember(req: Request, orgId: string, minRole: OrgRole = "member") {
  const user = await requireUser(req);
  const m = await db.membership.findFirst({ where: { userId: user.id, orgId } });
  if (!m || ROLE_RANK[m.role] < ROLE_RANK[minRole]) throw new NotFoundError();    // 404, not 403
  return { user, membership: m, orgId };
}

// Then every query in the request is scoped:
await db.project.findMany({ where: { orgId, ...filters } });   // never unscoped
```

Better: enforce tenant scoping automatically with a Prisma client extension / SQL row-level security,
so a forgotten `where` clause can't leak across tenants.

---

## 8. API keys for machine access

```ts
// Issue: show the secret ONCE, store only a hash
const secret = `sk_live_${crypto.randomBytes(24).toString("base64url")}`;
await db.apiKey.create({
  data: { name, userId, prefix: secret.slice(0, 12), hash: await sha256(secret),
          scopes: ["read:bookings"], expiresAt: null },
});

// Verify: constant-time compare, check expiry and scope, then rate limit per key
const key = await db.apiKey.findFirst({ where: { prefix: secret.slice(0, 12) } });
if (!key || !timingSafeEqual(await sha256(secret), key.hash)) return 401;
if (!key.scopes.includes(requiredScope)) return 403;
await db.apiKey.update({ where: { id: key.id }, data: { lastUsedAt: new Date() } });
```

---

## 9. MFA enrollment (TOTP)

```ts
// Enroll: show secret + QR, store temporarily, require one valid code before enabling
const secret = speakeasy.generateSecret({ length: 20 });
await db.mfaSecret.upsert({ where: { userId }, create: { userId, secret: encrypt(secret.base32), confirmed: false }, update: {} });

// Confirm
const ok = speakeasy.totp.verify({ secret: decrypt(rec.secret), encoding: "base32", token: userCode, window: 1 });
if (!ok) return json({ error: "That code isn't right." }, 400);
await db.$transaction([
  db.mfaSecret.update({ where: { userId }, data: { confirmed: true } }),
  db.recoveryCode.deleteMany({ where: { userId } }),
  db.recoveryCode.createMany({ data: codes.map(c => ({ userId, hash: sha256(c) })) }), // 8-10 codes
]);
```

Store recovery codes **hashed**, single use, and let the user regenerate them (invalidating the old set).
Offer MFA at signup for admins; never make MFA the *only* path without a recovery route — you'll lock
people out.

---

## 10. The auth test script

```bash
#!/usr/bin/env bash
set -u
APP=https://staging.example.com
email="test+$(date +%s)@example.com"

echo "1. signup"
curl -s -X POST "$APP/api/auth/signup" -H 'content-type: application/json' \
  -d "{\"email\":\"$email\",\"password\":\"correct-horse-battery\"}" | head -c 120; echo

echo "2. signup again (should look identical)"
curl -s -X POST "$APP/api/auth/signup" -H 'content-type: application/json' \
  -d "{\"email\":\"$email\",\"password\":\"correct-horse-battery\"}" | head -c 120; echo

echo "3. login wrong password (expect same shape as unknown user)"
curl -s -o /dev/null -w "%{http_code}\n" -X POST "$APP/api/auth/login" -H 'content-type: application/json' \
  -d "{\"email\":\"nobody@nowhere.test\",\"password\":\"wrongwrongwrong\"}"

echo "4. rate limit: 25 bad logins"
for i in $(seq 1 25); do printf "%s " "$(curl -s -o /dev/null -w '%{http_code}' -X POST "$APP/api/auth/login" -H 'content-type: application/json' -d '{"email":"a@b.co","password":"x"}')"; done; echo

echo "5. protected route without a session (expect 401)"
curl -s -o /dev/null -w "%{http_code}\n" "$APP/api/bookings"

echo "6. cookie flags"
curl -sI "$APP/" | grep -i set-cookie

echo "7. reset request (expect generic message)"
curl -s -X POST "$APP/api/auth/forgot-password" -H 'content-type: application/json' -d '{"email":"nobody@nowhere.test"}' | head -c 120; echo
```

Expect: identical responses for 1/2, 401 for unknown-user login, a `429` inside 25 attempts, `401` for the
protected route, `HttpOnly; Secure; SameSite` on the cookie, and a generic reset message.
