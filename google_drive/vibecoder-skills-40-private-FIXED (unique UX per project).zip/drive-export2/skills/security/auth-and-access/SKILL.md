---
name: auth-and-access
description: Use whenever a project needs login, signup, sessions, roles, admin areas, "sign in with Google", password reset, magic links, MFA, or any "who is this user and what may they do" logic. Covers the flows end to end with copy-paste patterns and the specific mistakes that cause account takeover (enumeration, session fixation, reset token reuse, localStorage JWTs, OAuth state/PKCE, missing ownership checks). Where most real breaches in small apps actually start.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# auth-and-access

## Promise

Users log in safely, stay logged in conveniently, can recover their account without handing it to an
attacker, and can never reach someone else's data. Built on proven patterns, not on a JWT tutorial.

## When to use

- Adding signup / login / logout to anything
- "Sign in with Google/GitHub/Apple"
- Password reset or "forgot password"
- Roles: user, staff, admin, owner — or "some users can see more"
- Teams, organizations, invitations, shared accounts
- Anything behind a paywall or a login wall
- Reviewing whether existing auth is safe
- Adding MFA, SSO, or API keys for customers

## When NOT to use

- Truly public, read-only content with no accounts (but still rate limit forms)

## The 60-second version

```
1. Don't hand-roll it. Managed auth (Clerk, Auth.js, Supabase, Firebase, Django's built-in) or a
   vetted library. Crypto and session handling are the two things you must not improvise.
2. Passwords: argon2id (or bcrypt cost >= 12). Minimum 12 chars. Check against known breaches.
   No forced rotation. No silly composition rules.
3. Sessions: opaque random token in an HttpOnly+Secure+SameSite cookie, stored server-side.
   This beats JWT-in-localStorage on almost every axis.
4. Reset: random 256-bit token, hashed in the DB, 15-minute expiry, single use, logs out all devices.
5. OAuth: verify `state`, use PKCE, exact redirect URI match, only link accounts with verified emails.
6. Authorization: check ownership on EVERY resource access, server-side. Not once, not in the UI.
7. Rate limit login/signup/reset. Log auth events. Alert on spikes.
8. Admin: MFA, a separate route guard, and an audit log.
```

## Step 1 — Choose the approach (decide, don't ask the human)

| Situation | Use | Why |
|---|---|---|
| You want it working today | **Managed auth** (Clerk, Supabase Auth, Auth.js, Firebase Auth, WorkOS) | Sessions, MFA, OAuth, emails, security updates — all done and maintained |
| Python, batteries included | **Django's `django.contrib.auth`** + allauth | Admin, permissions, and sessions come free |
| Learning / full control / no budget and you accept the risk | A vetted library: **Lucia-style sessions**, Passport.js, FastAPI-Users | You still must implement reset, MFA, sessions correctly |
| Enterprise customers | Managed with SAML/SSO (WorkOS, Auth0, Clerk Enterprise) | They will ask for SSO; you can't fake it later |
| API for machines | API keys (hashed, scoped, rotatable) + OAuth2 client credentials | Not user sessions |

**Never:** writing your own password hashing, your own token format, or "just a JWT in localStorage".
The 14 ways that goes wrong are listed below, and each one is an account takeover.

## Step 2 — Passwords (if you store them)

```ts
import argon2 from "argon2";

export async function hashPassword(pw: string) {
  return argon2.hash(pw, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
}
export async function verifyPassword(hash: string, pw: string) {
  try { return await argon2.verify(hash, pw); } catch { return false; }
}
```

Rules (modern NIST-aligned, not 2003-era):

- ✅ Minimum **12 characters**, maximum at least 64 (don't truncate silently)
- ✅ Block passwords found in known breaches (k-anonymity API: send only a hash prefix)
- ✅ Allow pasting (password managers), allow spaces and unicode
- ❌ No forced rotation, no "must contain 1 uppercase and 1 symbol", no security questions
- ❌ Never log the password, never email it, never store it encrypted (hashed only)
- ❌ Never compare with `==` (timing); `verify()` does constant-time comparison for you

Offer passkeys (WebAuthn) and OAuth as the low-friction path. Passwords are a liability you can reduce.

## Step 3 — Sessions

**Recommended default: server-side sessions.**

```
POST /login → verify password → create random 256-bit session id → store hash in DB (with
user id, expiry, IP, user agent) → set cookie: session=<id>; HttpOnly; Secure; SameSite=Lax
```

| | Server-side session | JWT access token |
|---|---|---|
| Logout everywhere | ✅ delete rows | ❌ needs a denylist |
| Revoke a compromised account | ✅ instant | ❌ until expiry |
| Read user data without a DB hit | ❌ | ✅ |
| Leaks via XSS | ❌ (HttpOnly) | ✅ (if in JS storage) |
| Complexity | Low | Medium-high |
| **Verdict** | **Default choice** | Only for stateless APIs / mobile at scale |

If you must use JWTs: ≤15 min access token, refresh token in an HttpOnly cookie with rotation and
reuse detection, RS256/HS256 pinned, verify `exp`/`iss`/`aud`, and keep a server-side revocation list for
logout-everywhere.

```ts
// Session creation (framework-agnostic shape)
const id = crypto.randomBytes(32).toString("base64url");
await db.session.create({
  data: { id: await sha256(id), userId, expiresAt: addDays(new Date(), 14), ip, userAgent },
});
res.setHeader("Set-Cookie", serialize("session", id, {
  httpOnly: true, secure: process.env.NODE_ENV === "production",
  sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 14,
}));
```

**Rules:** rotate the session ID at login (fixes fixation), delete the row on logout (deleting the cookie
is not logout), invalidate all sessions on password change, and never put the session token in a URL.

## Step 4 — The flows (each with its own failure mode)

Copy-paste implementations: [`references/auth-recipes.md`](references/auth-recipes.md).

| Flow | The thing everyone gets wrong | The fix |
|---|---|---|
| **Signup** | No email verification → bots and typos become accounts | Verify email before granting access; rate limit by IP; don't reveal whether an email exists |
| **Login** | Different errors for "no such user" vs "wrong password" | Identical response and timing; rate limit by IP + account; log failures |
| **Logout** | Only clears the cookie | Delete the session server-side; invalidate the token |
| **Reset** | Long-lived, reusable, unhashed tokens; tokens in logs via `Referer` | 256-bit random, hashed in DB, ≤15 min, single use, generic response, then log out all sessions |
| **Change email** | New email not confirmed → attacker takes the account | Send a confirmation to the NEW address; require it before switching; notify the OLD address |
| **Change password** | No current-password check, no session invalidation | Require current password (or a fresh reset), then invalidate other sessions, email the user |
| **OAuth** | Missing `state` (CSRF), no PKCE, loose redirect matching, linking unverified emails | `state` + PKCE, exact redirect URI, only link verified-email accounts |
| **"Remember me"** | Same session, just longer | Separate, clearly weaker session with a shorter privilege window for sensitive actions |
| **Invitations** | Invite link reusable / no expiry / no role check | Single-use, expiring, tied to the invited email, role fixed server-side |
| **API keys** | Stored plaintext, shown once, never rotatable | Store a hash, show once, scope it, allow rotation and revocation, log usage |

## Step 5 — Authorization (who may do what)

Two questions, answered separately on every request:

```
1. AUTHENTICATION: who is calling?        (session/token → user)
2. AUTHORIZATION: may THIS user do THIS to THIS resource?
```

Three patterns; use the simplest that fits:

| Pattern | When | Rule |
|---|---|---|
| **Ownership** | Personal data (my bookings, my invoices) | `where: { id, userId }` — scope the query itself |
| **RBAC (roles)** | Staff/admin/backoffice | Role checked server-side on the route group; never only in the UI |
| **Tenant / org** | Teams, workspaces, B2B | Every query scoped by `orgId`; membership checked on every request |

```ts
// Every protected action, same four beats
const user = await requireUser(req);                                  // 1 authenticate
const { bookingId } = z.object({ bookingId: z.string().uuid() }).parse(body); // 2 validate
const booking = await db.booking.findFirst({ where: { id: bookingId, userId: user.id } }); // 3 authorize
if (!booking) throw new NotFoundError();                              //   (404, not 403: no enumeration)
await db.booking.update({ where: { id: booking.id }, data: { status: "cancelled" } });     // 4 act
```

Enforce at **two** layers: the route boundary (layout/middleware for whole sections) *and* the data
access. One layer gets missed during a refactor; two rarely do.

**Return 404, not 403**, when a resource exists but isn't yours — 403 confirms it exists.

## Step 6 — Privileged accounts

- Admins: MFA **required**, shorter sessions, separate route group, IP restriction if feasible
- Every admin action in an audit log (actor, action, target, before/after, timestamp, IP)
- Break-glass account: one emergency admin, credentials in a sealed place, used only when the IdP is down,
  its use alerting to a human
- No shared logins. Ever. One human = one account.
- Step-up auth (re-enter password or MFA) before: deleting data, changing payouts, changing roles

## Step 7 — Protect it with rate limits and eyes

```
/login           5 attempts / 15 min / IP  +  10 / 15 min / account
/signup          3 / hour / IP
/reset-password  3 / hour / email  +  10 / hour / IP
/mfa/verify      5 / 15 min / session
/change-password 5 / hour / account
```
Log: login success/failure, logout, reset request and use, MFA changes, role changes, new device/location.
Alert on: 20 failed logins in 10 minutes (one human or one attacker), a successful login after 10 failures,
any admin action, any password change from a new country.

## The 14 ways hand-rolled auth gets you breached

1. Passwords stored with a fast hash (MD5/SHA) or reversible encryption
2. Tokens in `localStorage` → any XSS becomes account takeover
3. `SameSite=None` or missing `SameSite` → CSRF on every state change
4. Session not rotated at login → session fixation
5. Logout doesn't invalidate server-side → stolen cookie works forever
6. Reset token predictable, long-lived, unhashed, or reusable
7. Reset flow reveals whether an email is registered
8. No rate limit → credential stuffing with leaked password lists
9. Ownership checked in the UI only → IDOR
10. Role read from the client's request body → self-granted admin
11. JWT verified with `alg` from the token, or not verified at all
12. OAuth without `state` → attacker links their account to the victim's session
13. Email change without confirming the new address → silent takeover
14. No email verification → anyone can sign up as `admin@yourcompany.com`

## Non-negotiables

1. **Never hand-roll crypto or token formats.** Managed or vetted library.
2. **Sessions in HttpOnly+Secure+SameSite cookies**, validated server-side.
3. **Ownership/role checks on every request**, server-side, at two layers.
4. **Rate limits on every credential flow.**
5. **Generic errors; no enumeration.** Same message, same status, same timing.
6. **Reset and email-change flows are atomic, single-use, short-lived, hashed, and log out other devices.**
7. **MFA for privileged accounts.**
8. **Audit log for auth events and privileged actions.**
9. **Never log credentials, tokens, or full request bodies containing them.**
10. **Test the flows yourself** — sign up, log in, log out, reset, try another user's ID.

## Ask the human

1. "Do people need to create an account, or should anyone be able to use it straight away?"
2. "Do you want Google/Apple sign-in, or email and password? (Google is easier for your users and safer for you.)"
3. "Are there different types of users — customers, your staff, admins — and should some see more than others?"
4. "If someone forgets their password, how should they get back in — email link, or a code on their phone?"
5. "Do you need to let several people from one company share an account or a workspace?"
6. "Is there any account that, if hacked, would be catastrophic — yours, an admin, someone with payout access?"
7. "How annoying are you willing to make login in exchange for safety? (Extra codes, email confirmation, device checks.)"

Never ask: "JWT or sessions?", "bcrypt or argon2?", "OAuth2 or OIDC?", "RBAC or ABAC?".

## Anti-patterns

| Anti-pattern | Consequence | Do instead |
|---|---|---|
| "It's just a JWT, I'll write it" | One of the 14 above | Managed auth or a vetted session library |
| Role stored in the client and sent with requests | Anyone is an admin | Server-side role lookup |
| One shared "admin" login | No accountability | One account per human |
| Password reset sends the current password by email | Passwords in inboxes forever | One-time reset link |
| Sessions that never expire | Stolen cookies work for years | Idle + absolute expiry |
| Checking auth only in middleware | A new route forgets the guard | Check at the data layer too |
| Verifying email by a link that also logs you in without a fresh check | Link forwarding = takeover | Single-use link, then log in normally |
| Trusting `X-User-Id` headers | Trivially forged | Derive identity from the session, never a header |
| Skipping email verification "for UX" | Fake accounts, typos, abuse | Verify; it's one extra email |
| Building SSO yourself | SAML is subtle and unforgiving | Managed provider |

## Definition of done

- [ ] Authentication is managed or built on a vetted library; no custom crypto
- [ ] Passwords argon2id/bcrypt, ≥12 chars, breach-checked, never logged
- [ ] Sessions: HttpOnly+Secure+SameSite, rotated on login, invalidated on logout and password change, expiring
- [ ] Login/signup/reset rate limited by IP and account; failures logged; alerts configured
- [ ] Signup verifies email; reset is single-use, hashed, ≤15 min, and logs out other sessions
- [ ] Email change confirms the new address and notifies the old one
- [ ] OAuth (if any) uses `state` + PKCE, exact redirect matching, verified-email linking only
- [ ] Every data access has an ownership or role check, server-side, at two layers
- [ ] Admin/staff accounts: MFA on, separate guard, all actions audited
- [ ] Tested end to end: signup → verify → login → logout → reset → try another user's resource (must fail)
- [ ] `docs/SECURITY-AUDIT.md` sections 2 & 3 pass

## Works with

- `appsec-hardening` — the wider security picture; this is its deepest chapter
- `secrets-management` — where the auth secrets and OAuth client secrets live
- `api-abuse-defense` — rate limits, brute force, bots
- `saas-architecture` — orgs, seats, invitations, tenant isolation
- `data-privacy-and-pii` — what you're allowed to store about a user, and deletion
- `payments-and-billing` — entitlement checks ("does this account actually have access?")
