---
name: secrets-management
description: Use whenever an API key, token, password, connection string, or .env file appears — adding an integration, setting up CI, deploying, rotating credentials, or after a key is exposed. Defines where secrets live in each environment, how to keep them out of git and out of the browser bundle, how to rotate them without downtime, and the exact 30-minute drill when one leaks. Prevents the most common way vibe-coded projects lose money: a key committed to a public repo.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# secrets-management

## Promise

No secret ever ends up in git, in a browser bundle, in a log, or in a chat window — and when one does,
you have a drill that contains it in 30 minutes instead of discovering it on a $4,000 bill.

## When to use

- Adding any third-party service (Stripe, OpenAI, Resend, AWS, a database)
- Setting up CI/CD, a deploy, or a new environment
- "Where do I put my API key?"
- Before making a repo public, or adding a collaborator
- A key was pasted somewhere, committed, or pushed — **run the leak drill now**
- Rotating credentials, or an employee/contractor leaves
- Building a mobile or desktop app (you have nowhere to hide a secret — read the platform section)

## When NOT to use

- Never. If a project has one key, this applies.

## The 60-second version

```
1. The browser is public. Nothing in client code is secret. Ever. Verify by grepping the build.
2. Secrets live in: a secret manager (prod), the host's env settings (staging/prod),
   and a local .env that is gitignored (dev). Nowhere else.
3. .gitignore the .env files BEFORE the first key exists, not after the first mistake.
4. One secret, one place. Three copies is three leaks.
5. Every key is least-privilege and per-environment. No prod key on a laptop.
6. Scan automatically: pre-commit hook + CI. Humans forget; hooks don't.
7. Rotate on a schedule, and immediately when someone leaves or something leaks.
8. Leak response: REVOKE FIRST. Then clean history, then verify, then write it down.
```

## Step 1 — Know what counts as a secret

People leak things they don't think of as secrets:

| Obvious | Not obvious (but just as dangerous) |
|---|---|
| API keys, tokens | Database URLs (they contain the password) |
| Database passwords | Internal URLs and hostnames |
| Private keys / certificates | Webhook signing secrets |
| OAuth client secrets | Signed cookie / session secrets (`AUTH_SECRET`) |
| Cloud access keys | Encryption keys |
| `.env` files | Service account JSON files |
| | Test credentials that work in staging |
| | URLs with tokens in query strings |
| | Screenshots of dashboards, CI logs, or error pages |
| | AI provider keys (these directly spend money) |

## Step 2 — Where secrets live, by environment

| Environment | Where | Rules |
|---|---|---|
| **Local dev** | `.env` (gitignored) + `.env.example` (committed, fake values) | Dev-only keys. Never production data. |
| **CI** | The CI provider's encrypted secrets | Never `echo` them. Mask in logs. Least-privilege token. |
| **Staging** | Host dashboard env vars, or a secret manager | Separate keys from prod, separate database |
| **Production** | Host env vars (fine for small teams) or a secret manager (Vault, AWS Secrets Manager, Doppler, 1Password) | Access logged. Rotation possible without a redeploy. |
| **Mobile app** | **Nowhere.** Route through your server. | Anything in a mobile binary is public. |
| **Desktop app** | OS keychain for user-owned values; server for anything you own | Same rule: the binary is public |
| **Browser** | Only explicitly public values (`NEXT_PUBLIC_ANALYTICS_ID`) | Never a secret, ever |

```bash
# .gitignore — set this up on commit #1
.env
.env.*
!.env.example
*.pem
*.key
service-account*.json
```

```bash
# .env.example — every key present, every value obviously fake
DATABASE_URL=postgresql://user:password@localhost:5432/myapp_dev
STRIPE_SECRET_KEY=sk_test_replace_me
OPENAI_API_KEY=sk-replace-me
AUTH_SECRET=run-openssl-rand-base64-32
```

## Step 3 — The client-bundle rule

Frameworks only expose variables you explicitly mark public. That's the *only* safe way to get a value
into the browser — and it must never be a secret.

```ts
// ✅ server-only (default in Next.js server components, route handlers, server actions)
const key = process.env.STRIPE_SECRET_KEY;

// ⚠️ public — inlined into the JS bundle, readable by anyone
const id = process.env.NEXT_PUBLIC_POSTHOG_KEY;   // fine: it's a public project ID

// ❌ never: NEXT_PUBLIC_STRIPE_SECRET_KEY
```

**Verify, don't assume.** After every build:

```bash
npm run build
grep -rEo "(sk_live_[A-Za-z0-9]{10,}|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)" \
  .next dist build out 2>/dev/null | sort -u
# Empty output is the goal. Any hit = treat as leaked and rotate.

# Also check the source and history
grep -rIn --exclude-dir=node_modules --exclude-dir=.git -E "(api[_-]?key|secret|password|token)\s*[:=]\s*['\"][A-Za-z0-9/+_-]{12,}" .
git log -p --all | grep -iE "(api[_-]?key|secret|password)\s*[:=]" | sort -u | head
```

Add this to CI so a leak fails the build rather than shipping.

## Step 4 — Stop leaks automatically

**Pre-commit hook** (catches it before it's ever in git):

```bash
# .husky/pre-commit  (or a plain .git/hooks/pre-commit)
#!/usr/bin/env sh
if command -v gitleaks >/dev/null; then
  gitleaks protect --staged --redact || { echo "⛔ secret detected in staged changes"; exit 1; }
fi
npm run lint
```

**CI check** (catches it before it merges):

```yaml
- name: Secret scan
  run: |
    docker run --rm -v "$PWD:/repo" zricethezav/gitleaks:latest detect --source /repo --redact --no-git -v
- name: Dependency audit
  run: npm audit --audit-level=high
```

Also: enable the host's secret scanning (GitHub push protection, GitLab secret detection), and never
`--no-verify` past your own hook.

## Step 5 — Least privilege and scoping

Every key should be the weakest thing that still works:

| Service | Do this |
|---|---|
| Cloud (AWS/GCP) | A role for the app, not a root user key. Only the actions it needs. No console access. |
| Database | App user can CRUD, cannot `DROP`/`ALTER` schema in prod (migrations run separately) |
| Stripe | Restricted API keys where available; separate test/live keys |
| AI providers | Per-project key, hard monthly spend cap, separate key per environment |
| Email | Send-only key; separate domain for transactional vs marketing |
| Object storage | A bucket-scoped key with only the needed verbs |
| Third-party CI | Fine-grained token, short expiry, no write access to settings |

And: **spend limits everywhere they exist.** AI keys, serverless platforms, SMS/email. A cap turns a
catastrophe into an annoyance. See `cost-guardrails`.

## Step 6 — Rotation without downtime

Rotation is only scary if you've never done it. Do it once, on a quiet day, before you need to.

```
1. Create the new credential alongside the old one (both valid).
2. Deploy the app reading the new one (env var swap; restart).
3. Verify: the app works, logs show no auth errors for 1-2 hours / one full traffic cycle.
4. Revoke the old credential.
5. Update the inventory (date rotated, by whom).
```

For **dual-accept** secrets (webhook signing keys, JWT secrets) where old tokens are in flight:

```
1. Add the new secret as `CURRENT`; keep the old as `PREVIOUS`.
2. Accept signatures/tokens validated by EITHER.
3. After the longest token lifetime has passed (e.g. 7 days), drop `PREVIOUS` and revoke it.
```

Rotation schedule: immediately on leak or departure; otherwise quarterly for high-value keys
(cloud, database, payment) and annually for the rest. Write it in the inventory.

## Step 7 — The leak drill (30 minutes)

**Speed matters more than elegance. Revoke first, clean up later.**

| Minute | Action |
|---|---|
| 0-5 | **Revoke the key at the provider.** Dashboard → keys → delete/disable. This is the only step that stops the bleeding. |
| 5-10 | Issue a replacement and redeploy/configure it. Confirm the app works. |
| 10-20 | Check for damage: provider usage logs, billing, unusual activity, new resources, sent emails, data access logs. |
| 20-30 | Contain the exposure: if it was in git, assume it's public forever (bots scrape within minutes) — force-push/rewrite history *and* keep the key revoked. If the repo was public, consider the key permanently burned regardless. |
| After | Write it down: what leaked, how, blast radius, what you changed so it can't happen again (hook? scan? process?). |

**Rewriting git history** (only after revoking — it does not un-leak anything, it just reduces spread):

```bash
# Option A: filter-repo (recommended)
git filter-repo --path path/to/secret-file --invert-paths
# Option B: BFG
bfg --delete-files .env
git reflog expire --expire=now --all && git gc --prune=now --aggressive
git push --force-with-lease origin main
# ⚠ Coordinate with everyone who has a clone — they must re-clone.
```

**If the key was pasted into a chat, an issue, a screenshot, or a support ticket:** revoke it, then delete
or redact the message. Assume anything posted publicly is already scraped.

## Step 8 — Keep an inventory

`docs/SECRETS.md` — not the values, just the map. This document is what makes an incident take 10 minutes.

| Secret | Where it lives | Environments | Who has access | Last rotated | What breaks if revoked |
|---|---|---|---|---|---|
| `DATABASE_URL` | Host env (prod), Doppler | dev/stg/prod | you, CI | 2026-09-01 | everything |
| `STRIPE_SECRET_KEY` | Host env | test/live | you | 2026-08-15 | checkout |
| `OPENAI_API_KEY` | Host env | prod only | you | 2026-10-01 | AI features degrade |

## Platform specifics

| Platform | Rule |
|---|---|
| **Mobile** | No secret in the app. Every third-party call goes through your server, which holds the key, authenticates the user, and rate limits. Assume reverse engineers extract everything in the binary. |
| **Desktop** | Same. User-owned values (their own API key) go in the OS keychain, never a plaintext file. |
| **Serverless/edge** | Env vars are fine; make sure they're not echoed into logs or returned by a debug endpoint. |
| **Static sites** | You have no server-side secret storage. Any key in a static site is public. Use a serverless function as a proxy. |
| **Containers** | Don't bake secrets into the image (`ENV SECRET=...` in a Dockerfile is permanent). Mount at runtime. |

## Non-negotiables

1. **Revoke before you investigate.** Everything else is cleanup.
2. **No secret in client code, mobile binaries, or desktop bundles.** Verified by grepping the build.
3. **`.gitignore` before the first key.**
4. **Per-environment credentials.** Production keys never touch a laptop.
5. **Automated scanning:** pre-commit + CI + host push protection.
6. **Every key least-privilege, with a spend limit where available.**
7. **A committed key is a burned key.** Rewriting history doesn't un-leak it.
8. **Log redaction:** never log env vars, request headers wholesale, or full request bodies.
9. **Rotation is rehearsed, not improvised.**
10. **The inventory exists and is current.**

## Ask the human

1. "Is this project going to be public on GitHub, private, or shared with a client?" *(public = zero tolerance, scanning is mandatory)*
2. "Who else needs access to the keys — a co-founder, a contractor, an agency?"
3. "Are you reusing a key you already use somewhere else?" *(if yes: make a new one for this project)*
4. "Do you have a password manager or a secret tool you already use?" *(use theirs, not a new one)*
5. "If a key leaked tonight, would you know how to turn it off in five minutes?" *(if not: write the drill for their specific providers now)*
6. "Are you okay with me adding an automatic check that blocks you from committing a secret by accident?"

Never ask: "Vault or AWS Secrets Manager?", "should this be a KMS key?", "do you want SOPS?".

## Anti-patterns

| Anti-pattern | What happens | Do instead |
|---|---|---|
| Committing `.env` "just for now" | Bots find it in minutes; cloud bills, data loss | Gitignore first; host env vars |
| `NEXT_PUBLIC_` on a secret key | It's in the JS bundle, public forever | Server-side only |
| The same key in dev, CI, staging and prod | One leak owns everything | Per-environment keys |
| Secrets in CI logs (`echo $KEY`) | Logs are readable by more people than you think | Mask; never echo |
| Secrets in Docker images | Permanently in every layer | Runtime env / mounted secrets |
| Key in a URL or query string | Leaks via logs, `Referer`, browser history | Headers or server-side |
| "I'll rotate it later" | Later never comes | Rotate now, it's 5 minutes |
| Screenshotting a dashboard into a ticket | Credentials in your issue tracker | Redact, or use a link |
| Rewriting git history and thinking it's fixed | It's still leaked — the key must be revoked | Revoke first, history second |
| Sharing a key over chat/email | It's in three archives now | Secret manager share link with expiry |

## Definition of done

- [ ] Every secret is in exactly one place per environment; none in code, git, or client bundles
- [ ] `.gitignore` covers `.env*`, keys, certs, and service-account files; `.env.example` is complete
- [ ] Build output grepped for key patterns — clean
- [ ] Pre-commit secret scan + CI secret scan configured and actually blocking
- [ ] Host push protection enabled
- [ ] Every key least-privilege, per-environment, with spend caps where available
- [ ] `docs/SECRETS.md` inventory written: where, who, last rotated, what breaks
- [ ] Rotation procedure tested once (not just written)
- [ ] Logs are redacted: no env dumps, no full request bodies
- [ ] Mobile/desktop: no secret in the binary

## Works with

- `appsec-hardening` — the wider security picture
- `auth-and-access` — session/JWT secrets, rotation implications
- `deploy-and-environments` — where env vars get set per environment
- `dependency-and-supply-chain` — CI permissions and token scope
- `cost-guardrails` — spend limits on keys that can burn money
- `ai-features-in-production` — AI keys are the most expensive thing you'll leak
