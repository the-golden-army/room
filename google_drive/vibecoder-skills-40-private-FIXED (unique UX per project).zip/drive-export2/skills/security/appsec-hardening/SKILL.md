---
name: appsec-hardening
description: Use whenever security matters — building anything public, handling logins, payments, personal data or uploads; when the human says "make it secure", "is this safe", or "production ready"; and before any launch or pentest. Applies the defenses a senior engineer applies by reflex (XSS, CSRF, SSRF, IDOR, SQL injection, path traversal, open redirect, cookie theft, mass assignment, brute force, insecure storage, secrets exposure, misconfigured headers) with copy-paste fixes and a pass/fail audit. This is the skill vibe-coded apps are missing.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# appsec-hardening

## Promise

Take an app that "works on my machine" and make it able to survive a real attacker on the real internet.
Not a vibe — a checklist with code, where every box is pass or fail.

## When to use

**Non-negotiable triggers** (any one means you load this skill):

- Anything reachable from the public internet
- Logins, accounts, sessions, roles, admin areas
- Payments, money, credits, coupons, invoices
- Personal data: names, emails, phone, location, health, IDs, messages, kids
- File uploads, or any user-supplied filename or path
- Any place the app fetches a URL the user gave it
- "Make it secure" / "make it safe" / "is this secure?" / "production ready"
- Preparing for a pentest, an enterprise customer's security review, or a launch
- You wrote code that touches a database, a shell, a template, or an HTML string

## When NOT to use

- Local throwaway scripts with no network, no users, and no data (still don't commit secrets)
- Purely cosmetic changes

## What "make it secure" actually means

When a non-engineer says *"make my app 100% secure"*, they mean:

> "If a professional hacker looks at this, or a customer's security team reviews it, I don't want to be
> embarrassed, lose data, lose money, or get locked out. I want it to keep working and to keep my users safe."

Translated into engineering terms, that's seven promises. Make these seven and you can honestly say
"this is built to a professional standard":

1. **Nobody can see or change someone else's data** (authorization on every single request)
2. **Nobody can run their code in my users' browsers** (XSS, dependency safety)
3. **Nobody can trick my users' browsers into acting for them** (CSRF, clickjacking)
4. **Nobody can use my server as a weapon or a window** (SSRF, injection, file upload)
5. **Passwords and secrets stay secret, even if the database leaks** (hashing, encryption, no secrets in bundles)
6. **Attackers get slowed down and detected** (rate limits, logging, alerts, lockouts)
7. **When something does go wrong, I can see it, stop it, and recover** (logs, backups, rollback, disclosure plan)

Say that to the human in plain words. Then deliver it.

## The 60-second version

Twelve things that prevent ~90% of real-world breaches in small apps:

```
 1. Every request checks "does this user own this thing?" on the SERVER. Always.
 2. Never build SQL by string concatenation. Parameters only.
 3. Never render user content as HTML. Escape it, or sanitize with a real library.
 4. Cookies: HttpOnly + Secure + SameSite=Lax (or Strict). Never tokens in localStorage.
 5. CSRF protection on every state-changing request (SameSite + token for cookie-auth).
 6. Validate and type-check every input at the door. Allowlist, not blocklist.
 7. Never fetch a user-supplied URL from the server without an allowlist (SSRF).
 8. Never use a user-supplied path or filename to touch the filesystem.
 9. Rate limit: login, signup, password reset, "forgot password", and any expensive endpoint.
10. Passwords: argon2id or bcrypt. Never MD5/SHA/plain. Never log them.
11. No secrets in client code. Ever. The browser is public.
12. Errors: generic to users, detailed to your logs. Never stack traces to the user.
```

## The mental model: five trust boundaries

Attacks happen where trust crosses a boundary. Label every boundary and guard it.

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌──────────────┐
│   Browser   │───►│   Network    │───►│   Server    │───►│   Database   │
│  (hostile)  │    │  (hostile)   │    │  (yours)    │    │   (yours)    │
└─────────────┘    └──────────────┘    └─────────────┘    └──────────────┘
     ▲                                        │
     │                                        ▼
  Anything here can               ┌────────────────────┐
  be read & changed               │ Third-party APIs,  │
  by the user.                    │ files, workers     │
  Trust nothing.                  └────────────────────┘
```

**The browser is not your code.** It's a device the attacker owns. Validation, price checks, role checks and
"is this user allowed" checks that happen only in the browser are decorations, not security.

## Steps

### Step 1 — Draw the map (15 minutes, do it first)

Before writing defenses, list:

| Asset | Where it lives | Who may see it | What happens if it leaks |
|---|---|---|---|
| User emails | `users.email` | the user + you | spam, phishing, fines |
| Passwords | `users.password_hash` | nobody, not even you | account takeover everywhere |
| Payment IDs | `subscriptions.*` | the user + you | disputes, fraud |
| API keys | env / secret manager | the server only | bills, data loss |
| Uploaded files | object storage | owner + who they shared with | privacy breach |
| Admin actions | audit log | admins | insider abuse, no forensics |

If you can't fill the "who may see it" column, you're not ready to write code.

### Step 2 — Apply the secure-by-default setup

Do these once, at project start. They're cheap now and expensive later.

**a) Security headers** (middleware — Next.js example):

```ts
// middleware.ts
import { NextResponse, type NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  const csp = [
    "default-src 'self'",
    "script-src 'self' 'nonce-<per-request-random>'",   // no unsafe-inline, no unsafe-eval
    "style-src 'self' 'unsafe-inline'",                 // CSS frameworks often need inline styles
    "img-src 'self' data: https:",
    "connect-src 'self' https://api.stripe.com",
    "frame-ancestors 'none'",                           // clickjacking
    "form-action 'self'",
    "base-uri 'self'",
    "object-src 'none'",
  ].join("; ");

  res.headers.set("Content-Security-Policy", csp);
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  return res;
}
```

CSP is the one header that actually stops most XSS damage. Add it early — retrofitting breaks things.
Use nonces or hashes, **never** `unsafe-inline` for scripts.

**b) Cookie configuration** (the single most-copied mistake):

```ts
// Right
res.setHeader("Set-Cookie", serialize("session", token, {
  httpOnly: true,        // JS can't read it → XSS can't steal the session
  secure: true,          // HTTPS only
  sameSite: "lax",       // blocks most CSRF; use "strict" for admin
  path: "/",
  maxAge: 60 * 60 * 24 * 7,
}));

// Wrong — every one of these is a real breach
document.cookie = `token=${jwt}`;                 // readable by any script
localStorage.setItem("token", jwt);               // readable by any script
{ httpOnly: false, secure: false, sameSite: "none" }
```

**c) One authorization helper, used everywhere:**

```ts
// lib/authz.ts — the shape of every protected action
export async function requireOwnership(userId: string, bookingId: string) {
  const booking = await db.booking.findUnique({ where: { id: bookingId } });
  // Same generic error for "not found" and "not yours" — don't confirm it exists (enumeration)
  if (!booking || booking.userId !== userId) {
    throw new NotFoundError("Booking not found");
  }
  return booking;
}
```

### Step 3 — Guard every write with the same four lines

Every mutation, without exception:

```ts
// features/bookings/actions.ts
export async function cancelBooking(input: unknown) {
  // 1. VALIDATE the shape
  const { bookingId } = cancelSchema.parse(input);

  // 2. AUTHENTICATE — who is calling?
  const user = await requireUser();                 // throws if no valid session

  // 3. AUTHORIZE — are they allowed to do THIS to THIS?
  const booking = await requireOwnership(user.id, bookingId);

  // 4. MUTATE (in a transaction if more than one write)
  await db.$transaction([
    db.booking.update({ where: { id: booking.id }, data: { status: "cancelled" } }),
    db.auditLog.create({ data: { actorId: user.id, action: "booking.cancel", targetId: booking.id } }),
  ]);

  return { ok: true };
}
```

**validate → authenticate → authorize → mutate → record.** Same order in every handler, in every language.
Most breaches are a missing step 3.

### Step 4 — Handle untrusted input at the door

```ts
import { z } from "zod";

const bookingSchema = z.object({
  classId:   z.string().uuid(),
  seats:     z.number().int().min(1).max(10),          // bounds, not just type
  email:     z.string().email().max(254),
  message:   z.string().max(500).optional(),
  redirect:  z.string().url().refine(isSameOriginURL), // blocks open redirect
});

// Never: const { classId } = req.body;  // shape unknown, bounds unknown
```

Rules:
- Validate on the server even if the client validated (client validation is UX, not security)
- Allowlist what's expected; reject everything else (don't strip "bad" characters)
- Reject unknown object keys (`z.strict()`), so attackers can't smuggle extra fields
- Bound everything: length, count, size, depth, price, date ranges
- Never pass user input into: SQL, shell commands, `eval`, template strings, file paths, URL fetches, HTML

### Step 5 — Run the audit

Use [`references/launch-audit.md`](references/launch-audit.md): a pass/fail checklist, ~90 items,
grouped so you can run it in 45 minutes. Red items block launch.

### Step 6 — Verify your fixes

For each fix, prove it:

```bash
# SQL injection attempt on a search field
curl "https://app.example.com/api/search?q=' OR '1'='1"     # expect 400 or empty, never 500 or all rows

# IDOR: use user A's cookie to fetch user B's resource
curl -H "Cookie: session=<userA>" https://app.example.com/api/bookings/<userB-booking-id>
# expect 404

# XSS: submit this as your display name
<img src=x onerror=alert(1)>
# expect it rendered as text, not as an image

# Rate limit: 20 rapid login attempts with wrong passwords
for i in $(seq 1 20); do curl -X POST .../api/login -d '{"email":"a@b.c","password":"wrong"}'; done
# expect 429 before attempt 15

# Path traversal on a download endpoint
curl "https://app.example.com/api/files?name=../../../../etc/passwd"
# expect 400
```

Record the command and the observed result. "I fixed it" is not evidence.

## The vulnerability table (quick reference)

Full detail, per-vulnerability, in [`references/vuln-playbook.md`](references/vuln-playbook.md).

| # | Vulnerability | The one-line defense |
|---|---|---|
| 1 | SQL injection | Parameterized queries / ORM. Never concatenate. |
| 2 | Command injection | Never pass user input to a shell. Use `execFile` with an argument array. |
| 3 | XSS (reflected/stored/DOM) | Escape on output by default; sanitize HTML with DOMPurify; CSP. |
| 4 | CSRF | `SameSite=Lax/Strict` cookies + anti-CSRF token (or double-submit) on state changes. |
| 5 | SSRF | Allowlist hosts/IPs, block private ranges, resolve-then-check, no redirects. |
| 6 | IDOR / broken access control | Ownership check server-side on every resource, every time. |
| 7 | Path traversal / file inclusion | Never use user input as a path. Map IDs → paths. Canonicalize and check prefix. |
| 8 | Open redirect | Allowlist relative paths or same-origin hosts. |
| 9 | File upload attacks | Validate type by content, rename randomly, store outside webroot, serve from a separate origin, cap size. |
| 10 | Brute force / credential stuffing | Rate limit + progressive delay + lockout-ish + MFA + breached-password check. |
| 11 | Account enumeration | Identical response for "no such user" and "wrong password", same timing. |
| 12 | Broken password reset | Single-use token, short expiry, hashed in DB, invalidated on use, no user enumeration. |
| 13 | Session fixation / no rotation | Rotate session ID on login and on privilege change; destroy on logout. |
| 14 | Cookie theft | `HttpOnly` + `Secure` + `SameSite`; never tokens in `localStorage`. |
| 15 | Insecure storage | Passwords argon2id/bcrypt; secrets in a manager; PII encrypted at rest; no plaintext backups. |
| 16 | Secrets in client bundle | Only `NEXT_PUBLIC_`-style vars reach the browser. Verify with `grep` on the build output. |
| 17 | Mass assignment | Never spread `req.body` into a create/update. Pick fields explicitly. |
| 18 | Price/quantity tampering | Compute money on the server from server-side prices. Never trust a client-sent amount. |
| 19 | Race conditions / double-spend | Transactions + unique constraints + idempotency keys. |
| 20 | Information disclosure | Generic errors to users; no stack traces, no `debug: true`, no `.git`, no directory listing. |
| 21 | Missing security headers | CSP, HSTS, `nosniff`, `X-Frame-Options`/`frame-ancestors`, `Referrer-Policy`. |
| 22 | CORS misconfiguration | Explicit origin allowlist. Never `*` with credentials. |
| 23 | Clickjacking | `frame-ancestors 'none'` + `X-Frame-Options: DENY`. |
| 24 | Webhook forgery | Verify the provider signature on every webhook; replay protection via event IDs. |
| 25 | JWT mistakes | Verify algorithm and signature, check expiry/issuer/audience, keep it short-lived, deny `alg: none`. |
| 26 | ReDoS / XXE / prototype pollution | Avoid catastrophic regex on user input; disable external entities; never merge untrusted objects deeply. |
| 27 | Missing audit trail | Log who did what, when, to what. Especially admin and money actions. |
| 28 | Unpatched dependencies | Lockfile + automated updates + `npm audit`/`pip-audit` in CI (see `dependency-and-supply-chain`). |
| 29 | Exposed admin / debug endpoints | Auth + network restrictions; no `/debug`, `/adminer`, `/graphql` introspection in prod. |
| 30 | No monitoring of attacks | Log auth failures, rate-limit hits, and validation failures. Alert on spikes. |

## Non-negotiables

1. **The server decides.** Price, ownership, role, quantity, permissions — all computed server-side.
2. **Deny by default.** New endpoints are private until proven public. New fields are not writable.
3. **Every resource access carries an ownership check**, not just every page.
4. **No secrets in client code, git, logs, URLs, or error messages.** Verify by grepping the build.
5. **Every input is validated at the boundary** with a schema, including webhooks and internal calls.
6. **Errors are generic outward, detailed inward.** One error shape for all auth failures.
7. **Rate limits on anything that costs money, sends email, or accepts credentials.**
8. **Dependencies are pinned and scanned.** No `*` versions. No install-scripts surprises.
9. **An audit log for money, admin, and data-export actions.** You will need it.
10. **Prove each fix with a command.** Untested defenses are decorations.
11. **Security is not a phase and not a feature flag.** It's in the first commit or it's a rewrite later.

## Ask the human

Plain language, no jargon. Ask at the start of any security work:

1. "If someone broke into this, what's the worst thing they could get to? Customer data, money, or just vandalism?"
2. "Are there people with special access — admins, staff, your clients' staff? What should each of them be able to see?"
3. "Is any information here sensitive enough that you'd have to tell people if it leaked?" *(health, IDs, payments, kids' data)*
4. "Do you need to prove to anyone that this is secure — a client's IT team, an insurer, an app store, an investor?"
5. "If you had to delete one customer's data completely, what would that involve, and how fast would you need to do it?"
6. "Would you rather I lock login attempts down hard (annoying for forgetful users) or keep it friendly and watch for attacks?"
7. "Are you planning to let anyone else touch this code or this server later?"

**Never ask:** "should we implement CSRF tokens or rely on SameSite?", "bcrypt or argon2?", "what CSP directives
do you want?". Decide those yourself; use the defaults in the playbook.

## Patterns

### The universal request guard

```ts
// Wrap every route so the four steps can't be forgotten
export const withAuth = (handler: (ctx: { user: User; body: unknown }) => Promise<Response>) =>
  async (req: Request) => {
    try {
      const user = await requireUser(req);                 // 401 if not logged in
      const body = await req.json().catch(() => ({}));
      return await handler({ user, body });                 // handler validates + authorizes
    } catch (e) {
      if (e instanceof AuthError) return json({ error: "Unauthorized" }, 401);
      if (e instanceof NotFoundError) return json({ error: "Not found" }, 404);
      if (e instanceof ValidationError) return json({ error: "Invalid input" }, 400);
      logger.error("unhandled", { error: e });              // detail to logs
      return json({ error: "Something went wrong" }, 500);  // generic to user
    }
  };
```

### Safe external fetch (SSRF-safe)

```ts
import dns from "node:dns/promises";
import net from "node:net";

export async function safeFetch(rawUrl: string) {
  const url = new URL(rawUrl);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("bad protocol");

  const { address } = await dns.lookup(url.hostname);
  const ip = net.parse ? address : address;
  // Block cloud metadata + private ranges (the whole point of SSRF defense)
  if (isPrivateOrMetadata(ip)) throw new Error("blocked address");

  // Re-resolve at connect time or pin the IP, to stop DNS rebinding
  const res = await fetch(url, { redirect: "manual", signal: AbortSignal.timeout(5000) });
  return res;
}
```

### Safe file download (path traversal-safe)

```ts
// Never: fs.readFile(path.join(UPLOAD_DIR, req.query.name))
const file = await db.file.findFirst({ where: { id: fileId, ownerId: user.id } }); // IDOR check too
if (!file) throw new NotFoundError();

const base = path.resolve(UPLOAD_DIR);
const full = path.resolve(base, file.storedName);           // storedName is server-generated
if (!full.startsWith(base + path.sep)) throw new Error("invalid path");  // belt + braces
return sendFile(full);
```

### Safe HTML rendering

```tsx
// Default (safe): React escapes automatically
<p>{user.bio}</p>

// If you truly need rich text:
import DOMPurify from "dompurify";
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(user.bio) }} />
// plus a CSP without unsafe-inline. Sanitize on the way IN and on the way OUT.
```

### Money on the server

```ts
// Right: look up the price; never accept it
const price = await db.plan.findUniqueOrThrow({ where: { id: planId } }).priceCents;
const session = await stripe.checkout.sessions.create({
  line_items: [{ price: price.stripePriceId, quantity: 1 }],   // server-side price ID
  mode: "subscription",
});

// Wrong: trust anything the browser says about money
const { amount } = req.body;  // attacker sets amount = 1 (cent)
```

## Anti-patterns

| Anti-pattern | Why it's a breach | Do instead |
|---|---|---|
| "It's just a portfolio project, security doesn't matter" | Public apps are scanned by bots within hours; leaked keys = real money; your users are real people | Minimum bar applies to everything public |
| Hiding an admin button in the UI | The URL still works | Server-side role check on the route |
| `dangerouslySetInnerHTML` for user content | Stored XSS → session theft | Escape by default; sanitize if you must |
| Tokens in `localStorage` "because it's easier" | Any XSS = full account takeover | HttpOnly cookies |
| `SELECT * FROM x WHERE id = ${id}` | SQL injection | Parameterized query |
| `await fetch(userProvidedUrl)` | SSRF → cloud credentials, internal services | Allowlist + private-range blocking |
| `curl | bash` style install steps in your docs | Supply chain | Pinned versions, lockfiles |
| Trusting `req.body.role` / spreading body into `create()` | Mass assignment → self-granted admin | Explicit field pick-list |
| Returning "user not found" vs "wrong password" | Enumeration | Identical message, identical timing |
| `console.log(user)` / logging whole request objects | Credentials and PII in logs | Structured logs with allowlisted fields |
| Disabling CORS/CSRF/CSP "to make it work" | You removed the lock instead of fixing the key | Fix the config; ask the playbook |
| Rate limit only in the client | Bypassed with curl | Server-side, shared store |
| Security through obscurity (`/admin-panel-x7f`) | Crawlers and leaks find it | Real auth + IP restriction |
| "We'll add security before launch" | It's a rewrite, and launch is Friday | Now, per commit |

## Severity triage (what to fix first)

| Severity | Examples | Action |
|---|---|---|
| 🔴 **Critical — block launch** | SQL/command injection, auth bypass, IDOR on other users' data, secrets committed, unauthenticated admin, no password hashing, SSRF to cloud metadata | Fix now. Do not deploy. |
| 🟠 **High — fix this week** | Stored XSS, missing CSRF on money actions, no rate limit on login, insecure password reset, upload RCE paths, missing webhook signature verification | Fix before real users arrive |
| 🟡 **Medium — fix before marketing** | Missing CSP, verbose errors, missing audit log, long sessions, no MFA for admins, missing security headers, no lockout, enumeration | Fix before you promote it |
| 🔵 **Low — backlog** | Missing `Referrer-Policy`, no subresource integrity, verbose server header, missing `Permissions-Policy` | Batch it |

## Definition of done

You may say "this is built to a professional standard" when **all** are true:

- [ ] Every route that touches data validates input, authenticates, and authorizes — verified by reading each one
- [ ] The IDOR test passes: user A cannot read or modify user B's resources, on every resource type
- [ ] Injection tests pass: `' OR 1=1--`, `<img src=x onerror=alert(1)>`, `; cat /etc/passwd` all fail harmlessly
- [ ] Rate limit test passes on login, signup, reset, and any paid/expensive endpoint
- [ ] No secret anywhere in client bundles, git history, logs, or URLs (proven by grep + history scan)
- [ ] Cookies: `HttpOnly`, `Secure`, `SameSite` set; no tokens in `localStorage`
- [ ] Security headers present (CSP, HSTS, nosniff, frame-ancestors, referrer-policy)
- [ ] Uploads: content-validated, renamed, size-capped, served from a separate origin
- [ ] Passwords hashed with argon2id/bcrypt; reset tokens single-use, hashed, short-lived
- [ ] Money computed server-side; webhooks signature-verified and idempotent
- [ ] Admin and money actions are in an audit log
- [ ] Generic errors to users; stack traces only in your logs
- [ ] Dependencies pinned, scanned, and no known critical CVEs
- [ ] `references/launch-audit.md` run end to end, with every red item either fixed or explicitly accepted in writing by the human

## Works with

- `auth-and-access` — the deep dive on login, sessions, OAuth, roles
- `secrets-management` — where keys live, rotation, leak response
- `api-abuse-defense` — rate limiting, validation, bots, webhook security
- `data-privacy-and-pii` — what data you hold and how to protect it
- `dependency-and-supply-chain` — the packages you didn't write
- `production-readiness` — this skill is the security section of that gate
- `code-review-and-audit` — produces the report you can show a client
- `payments-and-billing`, `ai-features-in-production`, `mobile-app-delivery`, `desktop-app-delivery` — platform-specific attacks
