# Vulnerability playbook

For each: what it is in plain words → how vibe-coded apps get it wrong → the fix → how to test it.

Stacks shown: **TS** (Next.js/Express) and **PY** (FastAPI/Django) where it differs.

---

## A. Injection

### A1. SQL injection
**Plain:** a text box that ends up as part of a database command, so typing `'` changes the command.
**How vibe code does it:** `db.query("SELECT * FROM users WHERE email = '" + email + "'")`.
**Fix:** parameters only. ORMs do this; raw string building never does.

```ts
// ✅ Prisma / Drizzle / parameterized
await db.$queryRaw`SELECT * FROM users WHERE email = ${email}`;
await sql`SELECT * FROM bookings WHERE user_id = ${userId} AND id = ${id}`;
// ❌ await db.query("SELECT * FROM users WHERE email = '" + email + "'");

// ✅ Express + pg
await pool.query("SELECT * FROM users WHERE email = $1", [email]);
```
```py
# ✅ SQLAlchemy
session.execute(text("SELECT * FROM users WHERE email = :e"), {"e": email})
# ❌ f"SELECT * FROM users WHERE email = '{email}'"
```
**Watch:** `ORDER BY`/`LIMIT` can't be parameterized — allowlist the column name.
**Test:** submit `' OR '1'='1`; expect a validation error or no rows, never a 500 or the whole table.

### A2. Command injection
**Plain:** user text ends up in a terminal command on your server.
**How vibe code does it:** "convert this uploaded video" features, PDF tools, `exec("convert " + filename)`.
**Fix:** never use a shell. Pass arguments as an array. Better: don't shell out at all.

```ts
import { execFile } from "node:child_process";
execFile("convert", [inputPath, "-resize", "800x600", outputPath], { timeout: 10_000 });
// ❌ exec(`convert ${inputPath} -resize 800x600 ${outputPath}`)
```
**Test:** filename `; touch /tmp/pwned` → no file created.

### A3. Template injection (SSTI)
**Plain:** user text inside a server-rendered template gets executed as code.
**How vibe code does it:** building an email or page template with user input in the template string.
**Fix:** render templates from files with data passed in; never concatenate input into the template source.
**Test:** `{{ 7*7 }}` → renders as `{{ 7*7 }}`, not `49`.

### A4. NoSQL / ORM operator injection
**Plain:** sending `{"email": {"$gt": ""}}` makes a query match everything.
**Fix:** validate types strictly (zod/pydantic) so objects never arrive where strings are expected;
reject keys starting with `$`.
**Test:** POST `{"email": {"$ne": null}, "password": {"$ne": null}}` to login → 400.

### A5. ReDoS
**Plain:** a regex that takes minutes on a crafted string, freezing your server with one request.
**Fix:** avoid nested quantifiers (`(a+)+`) on user input; cap input length; use a safe-regex check in CI.

---

## B. Cross-site scripting (XSS)

**Plain:** an attacker puts code in your app (a name, a comment, a file name) and it runs in other users'
browsers — stealing sessions, making payments, reading screens.

| Type | Where | Fix |
|---|---|---|
| Reflected | input echoed in a response (search results, error pages) | Escape on output |
| Stored | saved in DB, shown to others (bio, comment, product name) | Escape on output + sanitize on input |
| DOM | JS writes user input into the page (`innerHTML`) | Never `innerHTML`; use `textContent` |
| Markdown/HTML | rich text rendered as HTML | Sanitize with DOMPurify + CSP |

```tsx
// ✅ React/Vue/Svelte escape by default
<p>{user.bio}</p>

// ❌ never with user content
<div dangerouslySetInnerHTML={{ __html: user.bio }} />

// ✅ if rich text is a real requirement
import DOMPurify from "dompurify";
const clean = DOMPurify.sanitize(user.bio, { ALLOWED_TAGS: ["b","i","em","strong","a","p","br"] });
<div dangerouslySetInnerHTML={{ __html: clean }} />
```
```py
# ✅ Jinja2/Django escape by default; ❌ |safe and mark_safe() with user content
# ✅ bleach.clean(user_bio, tags=["b","i","em","strong","a","p","br"])
```
**Also XSS:** `javascript:` in a link `href`, user-controlled CSS, SVG uploads (scripts inside), JSON
embedded in a `<script>` tag without escaping `</script>`, file names echoed into HTML.

**Always:** a Content-Security-Policy without `unsafe-inline`. It's the safety net for the one you missed.

**Test:** set your display name to `<img src=x onerror=alert(document.cookie)>` → it must display as text.

---

## C. Authentication & sessions

### C1. Password storage
```ts
import argon2 from "argon2";            // or bcrypt with cost >= 12
const hash = await argon2.hash(password, { type: argon2.argon2id });
const ok = await argon2.verify(user.passwordHash, password);
```
**Never:** MD5, SHA1, SHA256, encryption (reversible), or your own scheme. Add a breach check
(k-anonymity API or a local list) to reject known passwords.

### C2. Brute force & credential stuffing
```ts
// Per IP + per account, shared store (Redis/Upstash), not in-process memory
const key = `login:${ip}:${email.toLowerCase()}`;
const { success } = await limiter.limit(key, { windowMs: 15 * 60_000, max: 10 });
if (!success) return json({ error: "Too many attempts. Try again in 15 minutes." }, 429);
```
Add progressive delay, and MFA for admins. **Never** a permanent lockout without a recovery path
(it becomes a denial-of-service against your own users).

### C3. Account enumeration
Same message, same status code, same timing, for "no such user" and "wrong password":
`"Invalid email or password."` Generic on **both** login and password reset ("If that email exists, we've sent a link").

### C4. Password reset (the classic account takeover)
```ts
const token = crypto.randomBytes(32).toString("base64url");         // 256 bits, CSPRNG
await db.passwordReset.create({
  data: {
    userId: user.id,
    tokenHash: await sha256(token),      // store the HASH, not the token
    expiresAt: new Date(Date.now() + 15 * 60_000),
  },
});
// On use: hash the incoming token, look up, check expiry AND usedAt == null,
// then invalidate ALL of the user's sessions and mark the token used.
```
**Never:** predictable tokens, 24-hour expiry, tokens in URLs that get logged and leaked via `Referer`,
reset that doesn't log the user out of other devices.

### C5. Session hygiene
- Rotate the session ID on login and on any privilege change (fixes **session fixation**)
- Destroy the session server-side on logout (deleting the cookie isn't logout)
- Invalidate all sessions on password change
- Absolute expiry (7-30 days) + idle expiry; shorter for admin
- Store sessions server-side (DB/Redis) or use signed, short-lived JWTs with a revocation list

### C6. Cookie theft
```
Set-Cookie: session=...; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=604800
```
`HttpOnly` = JS cannot read it. `Secure` = HTTPS only. `SameSite` = not sent on cross-site requests.
**Never** `localStorage.setItem("token", ...)` for session tokens: any XSS then steals the account.

### C7. JWT mistakes
```ts
const { payload } = await jwtVerify(token, secret, {
  algorithms: ["HS256"],        // pin it — never let the token choose ("none", RS→HS confusion)
  issuer: "myapp", audience: "myapp-web",
  clockTolerance: 5,
});
// Check exp/iat, keep TTL <= 15 min for access tokens, refresh via HTTP-only cookie.
```
Never trust `alg` from the token. Never put secrets or PII in a JWT payload (it's base64, not encrypted).

### C8. MFA / 2FA
Required for: admins, anyone touching money, and any account with elevated privileges.
Prefer TOTP (authenticator app) or passkeys/WebAuthn. Have recovery codes, stored hashed, one-time use.

---

## D. Authorization (the #1 real-world bug in AI-generated code)

### D1. IDOR — Insecure Direct Object Reference
**Plain:** changing a number in the URL/request shows someone else's data.
**How vibe code does it:** `GET /api/invoices/:id` fetches by id without checking who owns it.
```ts
// ✅ scope the query by owner
const invoice = await db.invoice.findFirst({ where: { id, userId: user.id } });
if (!invoice) throw new NotFoundError();     // also prevents enumeration

// ❌ const invoice = await db.invoice.findUnique({ where: { id } });
```
Apply to: read, update, delete, export, and **every nested resource** (`/teams/:teamId/members/:id`).

### D2. Missing function-level access control
A route exists (`POST /api/admin/refund`) and checkss that you're logged in — but not that you're an admin.
```ts
// one guard, applied at the boundary
export const requireRole = (role: Role) => (handler) => async (req) => {
  const user = await requireUser(req);
  if (!user.roles.includes(role)) throw new ForbiddenError();
  return handler(req, user);
};
```
Put the check in the layout/middleware for whole sections, **and** in the action itself. Defense in depth.

### D3. Mass assignment
```ts
// ❌ await db.user.update({ where: { id }, data: req.body });   // attacker sends { role: "admin" }
// ✅ pick fields explicitly
const { name, email } = updateSchema.parse(req.body);
await db.user.update({ where: { id: user.id }, data: { name, email } });
```
Also: reject unknown keys (`z.strict()` / Pydantic `extra="forbid"`).

### D4. Tenant isolation (SaaS)
Every query in a multi-tenant app carries the tenant filter. Enforce it in one place:
```ts
// Prisma client extension: inject orgId into every query on tenant-scoped models
prisma.$extends({
  query: { $allModels: { async $allOperations({ model, args, query }) {
    if (TENANT_MODELS.has(model)) args.where = { ...args.where, orgId: currentOrgId.get() };
    return query(args);
  }}},
});
```
Test with two real tenants: log in as A, try to read B's IDs. This must fail everywhere.

### D5. Client-side-only checks
Hiding a button, disabling a field, or checking a role in React is **UX**, not security.
Everything that matters is re-checked on the server. Every time.

---

## E. CSRF, clickjacking, CORS

### E1. CSRF
**Plain:** another site makes your logged-in browser do something on your app without you knowing.
```ts
// Layer 1: SameSite=Lax (or Strict) cookies — blocks most of it for free
// Layer 2: anti-CSRF token on every state-changing request (POST/PUT/PATCH/DELETE)
import { csrf } from "@edge-csrf/nextjs";   // or the framework's built-in protection
// Layer 3: require a custom header (fetch sends it; HTML forms can't) + check Origin/Referer
if (req.method !== "GET" && req.headers.get("origin") !== APP_URL) return new Response(null, { status: 403 });
```
If auth lives in `Authorization: Bearer` headers (not cookies), CSRF risk is much lower — but cookie-based
sessions are the safer default for browsers, so use both layers.

### E2. Clickjacking
`Content-Security-Policy: frame-ancestors 'none'` + `X-Frame-Options: DENY`.

### E3. CORS
```ts
// ✅ explicit allowlist
if (ALLOWED_ORIGINS.includes(origin)) res.setHeader("Access-Control-Allow-Origin", origin);
res.setHeader("Vary", "Origin");
// ❌ Access-Control-Allow-Origin: *  (especially with Allow-Credentials: true — which is invalid anyway)
// ❌ reflecting the Origin header back to everyone
```
CORS is **not** an access-control mechanism for your API. It only relaxes the browser's read restriction.

---

## F. SSRF, redirects, webhooks

### F1. SSRF (Server-Side Request Forgery)
**Plain:** you ask your server to fetch a URL, attacker points it at internal services or the cloud
metadata endpoint → your cloud credentials.
**Where it hides:** "import from URL", webhooks, PDF generators, image resizers, avatar fetchers,
"preview this link", OAuth discovery.
```ts
const BLOCKED = ["169.254.169.254", "127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "::1"];
// 1. only http/https  2. resolve hostname  3. reject private/metadata IPs
// 4. block redirects (redirect: "manual") or re-validate each hop  5. timeout 5s  6. cap response size
```
Safest: allowlist exact domains. If you must allow any URL, do it in a separate egress-restricted service.

### F2. Open redirect
```ts
// ❌ res.redirect(req.query.next)
// ✅ allowlist
const safe = new URL("/dashboard", APP_URL);
if (next && next.startsWith("/") && !next.startsWith("//")) safe.pathname = next;
```
Used for phishing ("login link that looks like your domain") and to leak tokens.

### F3. Webhook forgery
```ts
// Stripe example — verify the signature BEFORE parsing/using the body
const event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET!);
// Then: idempotency — record event.id in a table with a UNIQUE constraint; ignore duplicates
```
Applies to every provider. An unverified webhook endpoint is a free "do anything" API.

---

## G. Files & paths

### G1. Path traversal / local file inclusion
**Plain:** `?file=../../../../etc/passwd` reads files outside the folder.
```ts
const base = path.resolve(UPLOAD_DIR);
const full = path.resolve(base, storedName);       // storedName from DB, not from the user
if (!full.startsWith(base + path.sep)) throw new Error("bad path");
```
Best: never accept a path from the user at all. Accept an ID, look up the stored name in the DB.

### G2. File upload
Checklist:
- [ ] Cap size (and enforce it at the proxy too)
- [ ] Detect type by **content** (magic bytes), not by extension or the client's `Content-Type`
- [ ] Allowlist a few types; reject everything else
- [ ] Generate a random stored name; keep the original only as a display label
- [ ] Store outside the web root, in object storage
- [ ] Serve from a **separate origin** (so a malicious file can't run in your app's context)
- [ ] Serve with `Content-Disposition: attachment` + `X-Content-Type-Options: nosniff`
- [ ] Images: re-encode on upload (strips embedded payloads). SVGs: sanitize or disallow.
- [ ] Never allow user-controlled filenames to reach `unzip`/`tar` extraction (zip-slip)
- [ ] Scan/AV if the files are shared between users

### G3. Arbitrary file write via logs/exports
Any feature that writes a file using user input (CSV export, log viewer, backup tool) can overwrite
your code. Same fix: never build paths from user input.

---

## H. Data exposure

| Leak | Fix |
|---|---|
| Secrets in the client bundle | Only explicitly-public vars reach the browser. Grep the build output for `sk_live_`, `AKIA`, `ghp_`, `eyJ`. |
| Stack traces to users | `debug: false` in prod; one generic error page; details to logs only |
| Verbose API errors | `{"error": "Invalid input"}` not `{"error": "duplicate key value violates unique constraint users_email_key"}` |
| `.git` / backups / `.env` in web root | Block with server config; check `/.git/config`, `/backup.sql`, `/.env` return 404 |
| Directory listing | Disable. Every directory has an `index.html` or returns 404. |
| Debug/admin endpoints in prod | `/adminer`, `/graphql` introspection, `/metrics`, Swagger UI — auth or remove |
| Over-fetching in APIs | Return only the fields the client needs. No `SELECT *` straight to JSON. |
| No pagination limits | Cap `limit` (e.g. 100). An unbound `limit=999999` is a free data dump and a DoS. |
| PII in URLs / logs / analytics | IDs in URLs, not emails. Log `user_id`, not email. Scrub before shipping logs. |
| Unprotected backups | Encrypt, restrict access, test a restore |
| Default credentials | Change before deploy. `admin/admin` gets found. |
| Error-based enumeration | Identical responses; see C3 |

**The 60-second leak check:**
```bash
# In the built output, not the source
npm run build && grep -rEo "(sk_live_[a-zA-Z0-9]{10,}|AKIA[0-9A-Z]{16}|ghp_[a-zA-Z0-9]{20,}|eyJ[A-Za-z0-9_-]{10,})" dist .next 2>/dev/null
# Git history
git log -p --all | grep -iE "api[_-]?key|secret|password|token" | head
# Live
curl -sI https://app.example.com/.git/config | head -1   # must be 404
curl -sI https://app.example.com/.env | head -1          # must be 404
```

---

## I. Business logic & abuse

| Attack | Defense |
|---|---|
| Price tampering | Server computes the amount; client only chooses a plan ID |
| Negative quantity / free credits | Validate `> 0` server-side; integer cents, never floats, for money |
| Coupon reuse | Unique constraints + idempotency keys, not "check then insert" |
| Double submit (double charge) | Idempotency key per user action; disable + dedupe server-side |
| Race condition (TOCTOU) | `SELECT ... FOR UPDATE` / transaction with the right isolation, or a unique constraint that makes the second write fail |
| Free-tier abuse | Per-account quotas on expensive operations (AI calls, emails, exports) |
| Signup spam / fake accounts | Email verification + rate limit + CAPTCHA only if it's actually happening |
| Scraping | Rate limit + pagination caps + ToS; robots.txt is a request, not a control |
| Enumeration via sequential IDs | Use UUIDs/ULIDs, **and** still check ownership (IDs are not a security control) |
| Self-approval flows | Maker-checker: the requester can't approve their own action |

**Money rule, restated:** the client may express *intent* ("buy plan X"), never *terms* (amount, currency, discount).

---

## J. Configuration & transport

```
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'self'; ...        (no unsafe-inline/eval for scripts)
X-Content-Type-Options: nosniff
X-Frame-Options: DENY            (+ frame-ancestors 'none' in CSP)
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Cache-Control: no-store          on responses with private data
```

- **HTTPS everywhere**, including redirects and cookies. Redirect HTTP→HTTPS at the edge.
- **No mixed content** (no `http://` assets on an `https://` page).
- **Disable TRACE**, remove the `Server`/`X-Powered-By` version banner.
- **DNS:** watch for dangling CNAMEs (subdomain takeover) — delete records you no longer use.
- **Email auth:** SPF, DKIM, DMARC on your sending domain (otherwise anyone can send as you).
- **Object storage:** private buckets by default; signed URLs with short expiry for access.
- **Database:** no public IP. TLS on. Least-privilege user (the app can't `DROP DATABASE`).
- **Backups:** encrypted, access-restricted, restore tested (see `reliability-and-incidents`).
- **AI/LLM:** treat model output as untrusted input; see `ai-features-in-production`.

---

## Mobile & desktop specifics (quick)

| Platform | The extra rules |
|---|---|
| Mobile | No secrets in the bundle (they're extractable). Tokens in Keychain/Keystore, not AsyncStorage. Certificate pinning only if you have a reason. Don't log to the device in production. Deep links validate their parameters. |
| Desktop | Don't disable web-security / node integration in the renderer. Validate IPC messages. Sign and notarize. Context isolation on. |
| Both | The API is the security boundary — assume the client is fully compromised. |

---

## The 10-minute self-test

Run this before you say "done":

```bash
# 1. injection
curl -s "$APP/api/search?q=%27%20OR%201%3D1--" | head -c 200
# 2. XSS (then open the page and look for an alert)
curl -s -X POST "$APP/api/profile" -H "$AUTH" -d '{"bio":"<img src=x onerror=alert(1)>"}'
# 3. IDOR (B's id, A's cookie)
curl -s -o /dev/null -w "%{http_code}\n" -H "$COOKIE_A" "$APP/api/bookings/$ID_B"   # want 404
# 4. rate limit
for i in $(seq 1 30); do curl -s -o /dev/null -w "%{http_code} " -X POST "$APP/api/login" -d '{"email":"a@b.co","password":"x"}'; done
# 5. traversal
curl -s -o /dev/null -w "%{http_code}\n" "$APP/api/files?name=../../etc/passwd"     # want 400/404
# 6. secrets in bundle
grep -rEo "sk_live_[a-zA-Z0-9]+|AKIA[0-9A-Z]{16}" .next dist 2>/dev/null | head
# 7. headers
curl -sI "$APP" | grep -iE "content-security-policy|strict-transport|x-frame|x-content-type"
# 8. leaky files
for p in /.git/config /.env /backup.sql /adminer; do echo -n "$p "; curl -s -o /dev/null -w "%{http_code}\n" "$APP$p"; done
```
