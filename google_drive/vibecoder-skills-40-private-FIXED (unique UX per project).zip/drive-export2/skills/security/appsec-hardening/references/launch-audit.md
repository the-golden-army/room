# Pre-launch security audit

Pass/fail. No "consider". 🔴 blocks launch, 🟠 fix before real users, 🟡 fix before marketing, 🔵 backlog.

How to run: 45 minutes. Go top to bottom. Write `PASS`, `FAIL`, or `N/A` next to each line.
Anything `FAIL` gets a ticket with a severity and an owner. Nothing ships with an open 🔴.

Result goes in `docs/SECURITY-AUDIT.md` with the date and the commit it was run against.

---

## 1. Secrets & configuration 🔴

```
[ ] 🔴 No secret in the repo, including git history (scan: gitleaks / trufflehog)
[ ] 🔴 No secret in the built client bundle (grep the build output for sk_live_, AKIA, ghp_, eyJ)
[ ] 🔴 .env and .env*.local are gitignored; .env.example exists and is complete with fake values
[ ] 🔴 Separate credentials per environment; production keys never on a laptop
[ ] 🔴 No credential in a URL, a query string, or a log line
[ ] 🟠 Config is validated at boot (app refuses to start with a missing/bad value)
[ ] 🟠 Every third-party key is least-privilege and scoped to what the app actually does
[ ] 🟡 Rotation procedure written down for each secret (who, how, what breaks)
```

## 2. Authentication 🔴

```
[ ] 🔴 Passwords hashed with argon2id or bcrypt (cost >= 12). Not MD5/SHA/plain/reversible encryption.
[ ] 🔴 Login rate limited by IP *and* by account, in a shared store, not process memory
[ ] 🔴 No account enumeration: identical message, status, and timing for bad user vs bad password
[ ] 🔴 Password reset tokens: 256-bit random, hashed in DB, <= 15 min expiry, single use
[ ] 🔴 Password change/reset invalidates all other sessions
[ ] 🔴 Session ID rotated on login and on privilege change
[ ] 🔴 Logout destroys the session server-side
[ ] 🟠 MFA available; required for admin/staff accounts
[ ] 🟠 Breached/common password check on signup and password change
[ ] 🟠 Accounts can't be taken over by changing email without confirming the new address
[ ] 🟡 Session has both an idle and an absolute expiry; admin sessions are shorter
[ ] 🟡 "Remember me" is a separate, clearly weaker session — and treated as such
```

## 3. Authorization 🔴

```
[ ] 🔴 EVERY endpoint that reads or writes a resource checks ownership server-side (IDOR)
[ ] 🔴 Nested resources check the parent too (/teams/:teamId/docs/:docId → is docId in teamId?)
[ ] 🔴 Admin routes check a role on the server, not just in the UI
[ ] 🔴 No mass assignment: request bodies are validated and fields picked explicitly
[ ] 🔴 Multi-tenant: every query is scoped to the tenant (tested with two real tenants)
[ ] 🔴 Authorization is enforced in the data layer or in every handler — not only in middleware
[ ] 🟠 File/object access checks ownership before serving (not just "do you have the link")
[ ] 🟠 Export/download endpoints are authorized and rate limited
[ ] 🟡 Read-only roles are genuinely read-only
```

## 4. Input handling 🔴

```
[ ] 🔴 Every endpoint validates input with a schema (types, lengths, ranges, formats)
[ ] 🔴 Unknown object keys are rejected
[ ] 🔴 All database access is parameterized / via ORM. Zero string-built SQL.
[ ] 🔴 No user input reaches a shell command, eval, or a template source
[ ] 🔴 Array sizes, string lengths, page sizes and upload sizes are bounded
[ ] 🟠 Numbers used for money/quantity are validated positive and within range
[ ] 🟠 Redirect targets are allowlisted
[ ] 🟡 Regexes on user input are ReDoS-safe
```

## 5. Output & XSS 🔴

```
[ ] 🔴 User content is escaped by default in every rendering path
[ ] 🔴 No dangerouslySetInnerHTML / |safe / innerHTML with unsanitized user content
[ ] 🔴 Rich text, if allowed, is sanitized with a maintained library (DOMPurify / bleach)
[ ] 🔴 User-supplied URLs in href/src are validated (no javascript:, data: for scripts)
[ ] 🔴 JSON embedded in HTML escapes <, >, & and </script
[ ] 🟠 Content-Security-Policy present, without unsafe-inline/unsafe-eval for scripts
[ ] 🟠 Uploaded SVGs are sanitized or rejected
[ ] 🟡 X-Content-Type-Options: nosniff on all responses
```

## 6. CSRF, CORS, clickjacking 🟠

```
[ ] 🟠 Session cookies are SameSite=Lax or Strict
[ ] 🟠 State-changing requests carry an anti-CSRF token and/or a custom header
[ ] 🟠 Origin/Referer checked on state-changing requests
[ ] 🟠 CORS uses an explicit origin allowlist; never * with credentials; Vary: Origin set
[ ] 🟠 X-Frame-Options: DENY and CSP frame-ancestors 'none'
[ ] 🔵 Preflight responses don't allow more methods/headers than needed
```

## 7. Server-side request forgery 🔴

```
[ ] 🔴 Any feature fetching a user-supplied URL validates scheme, resolves the host,
       and blocks private/link-local/metadata IP ranges
[ ] 🔴 Redirects are not followed, or each hop is re-validated
[ ] 🔴 Requests to third parties have a timeout and a response size cap
[ ] 🟠 Prefer an allowlist of permitted domains
[ ] 🟠 Webhook destinations (user-configured) are validated the same way
```

## 8. File handling 🔴

```
[ ] 🔴 Uploads: size capped, type checked by CONTENT, extension allowlisted
[ ] 🔴 Stored with a server-generated random name, outside the web root
[ ] 🔴 No user input ever becomes part of a filesystem path
[ ] 🔴 Served from a separate origin with nosniff and Content-Disposition
[ ] 🟠 Images re-encoded on upload
[ ] 🟠 Archives are not extracted with user-controlled paths (zip-slip)
[ ] 🟡 Old/unused uploads are deletable and actually deleted on request
```

## 9. Money & business logic 🔴

```
[ ] 🔴 Prices, taxes and discounts computed server-side from server-side data
[ ] 🔴 Webhooks signature-verified before use
[ ] 🔴 Webhook handlers are idempotent (event IDs recorded with a UNIQUE constraint)
[ ] 🔴 Checkout/charge endpoints are idempotent (double-click can't double-charge)
[ ] 🔴 Money stored as integer minor units; no floats
[ ] 🟠 Refund/cancel paths are authorized and logged
[ ] 🟠 Quotas per account on expensive operations (AI calls, emails, exports, storage)
[ ] 🟠 Race conditions handled with transactions/unique constraints, not check-then-act
[ ] 🟡 Admin actions require re-authentication or step-up for the destructive ones
```

## 10. Data exposure & privacy 🟠

```
[ ] 🟠 Generic error messages to users; stack traces only in server logs
[ ] 🟠 debug mode off in production
[ ] 🟠 No PII in URLs, logs, analytics events, or error reports
[ ] 🟠 Logs are structured and scrubbed (no passwords, tokens, full card numbers, emails)
[ ] 🟠 APIs return only needed fields; pagination is capped
[ ] 🟠 /.git, /.env, /backup, /adminer, /graphql introspection are not publicly reachable
[ ] 🟠 Directory listing disabled
[ ] 🟠 Backups encrypted, access restricted, and a restore has been tested
[ ] 🟠 Deletion works end to end: DB + files + email tool + analytics + logs policy
[ ] 🟡 Retention periods defined for each data type
[ ] 🟡 Third-party scripts inventoried; SRI or self-hosted; no surprise trackers
[ ] 🟡 Privacy policy matches what the software actually does
```

## 11. Headers & transport 🟠

```
[ ] 🟠 HTTPS enforced; HTTP redirects to HTTPS; HSTS with a long max-age
[ ] 🟠 No mixed content (no http:// assets on an https page)
[ ] 🟠 Cache-Control: no-store on responses containing private data
[ ] 🟡 Referrer-Policy: strict-origin-when-cross-origin
[ ] 🟡 Permissions-Policy denies unused powerful features
[ ] 🔵 Server/X-Powered-By version banners removed
[ ] 🔵 SPF, DKIM and DMARC configured for the sending domain
```

## 12. Dependencies & build 🟠

```
[ ] 🟠 Lockfile committed; installs are deterministic (npm ci / pip install -r with hashes)
[ ] 🟠 No known critical/high CVEs in the dependency tree
[ ] 🟠 No dependency added this week without a reason (check for typosquats)
[ ] 🟠 CI has least-privilege tokens; no secrets in build logs
[ ] 🟡 Automated dependency update PRs, reviewed not auto-merged
[ ] 🟡 `npm audit` / `pip-audit` / `osv-scanner` runs in CI
[ ] 🔵 Build is reproducible and doesn't need network access to install-scripts
```

## 13. Observability of attacks 🟡

```
[ ] 🟡 Failed logins, rate-limit hits, and validation failures are logged with context
[ ] 🟡 Alerts on: spike in 401/403/429, spike in errors, webhook failure streak
[ ] 🟡 Audit log for: login, password change, role change, money actions, data export, deletion
[ ] 🟡 Logs are retained long enough to investigate (30+ days)
[ ] 🟡 Someone's email address is on those alerts
```

## 14. Platform extras

```
[Mobile] 🔴 No secret in the app binary; tokens in Keychain/Keystore
[Mobile] 🟠 Deep link parameters validated; universal links configured
[Mobile] 🟠 No sensitive data in device logs or crash reports
[Desktop] 🔴 Context isolation on; node integration off in the renderer; IPC validated
[Desktop] 🟠 Installers signed and notarized; updater verifies signatures
[AI]      🔴 Model output treated as untrusted; never eval'd or interpolated into SQL/HTML/shell
[AI]      🟠 Per-user token spend caps; prompt-injection resistance tested
```

---

## Scoring

| Result | Meaning |
|---|---|
| Any 🔴 FAIL | **Do not launch.** Fix it. This is the whole point of the audit. |
| Any 🟠 FAIL | Launch only to a small, known group. Fix within a week. |
| Any 🟡 FAIL | Launch, but fix before you promote the product publicly. |
| All PASS | You can honestly tell a customer you followed a professional checklist. |

## The report

```markdown
# Security audit — 2026-10-20 — commit a1b2c3d

Scope: web app + API + Stripe webhooks. Method: manual review + the 10-minute self-test.

## Summary
- 🔴 Critical: 2  🟠 High: 5  🟡 Medium: 9  🔵 Low: 4
- Launch decision: NOT READY (2 critical open)

## Critical
1. `POST /api/bookings/:id/cancel` doesn't check ownership — any user can cancel any booking.
   Fix: `requireOwnership()` in the handler. File: features/bookings/actions.ts:44
2. Stripe webhook handler doesn't verify the signature.
   Fix: `stripe.webhooks.constructEvent(rawBody, sig, secret)` before parsing. File: app/api/webhooks/stripe/route.ts:12

## High
...

## Accepted risks (signed off by <human name>, <date>)
- No MFA at launch. Accepted: user base is <50 known people. Revisit at 500 users.

## Not tested
- Load testing, mobile app, third-party penetration test.
```

"Not tested" matters as much as "passed". Never let a reader assume coverage you didn't do.
