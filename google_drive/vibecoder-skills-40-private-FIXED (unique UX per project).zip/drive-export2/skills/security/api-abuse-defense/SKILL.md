---
name: api-abuse-defense
description: Use when building or exposing any API, form, webhook, or public endpoint — and whenever the concern is bots, spam, scraping, brute force, overuse, or "someone is hammering my app". Covers rate limiting that actually works across instances, input validation at the door, request size and timeout limits, webhook signature verification, CORS, SSRF-safe outbound fetches, per-account quotas on expensive operations, and the logging that tells you you're under attack.
metadata:
  category: security
  version: 1.0.0
  value: "$100"
  group: security
---

# api-abuse-defense

## Promise

Your app behaves politely for real users and becomes expensive, slow, and useless for attackers —
without ever locking out a legitimate customer.

## When to use

- Building any public endpoint (API route, form, webhook receiver, search, upload)
- Adding AI, email, SMS, PDF, export, or search features (things that cost money per call)
- "Someone is spamming my form" / "my bill exploded" / "my app is slow all of a sudden"
- Exposing an API to customers or third parties
- Before launch, as part of `production-readiness`
- Adding a public search, public profile pages, or anything crawlable

## When NOT to use

- Internal admin endpoints already behind auth and IP restriction (still validate input)

## The 60-second version

```
1. Validate every input with a schema at the door. Reject unknown fields. Bound everything.
2. Rate limit in a SHARED store (Redis/Upstash), keyed by user + IP + endpoint.
   In-process counters are useless the moment you have more than one instance.
3. Return 429 with Retry-After. Log every limit hit.
4. Cap request body size, upload size, pagination limit, and response time.
5. Quota expensive operations per account per day (AI, email, exports, SMS, PDF).
6. Verify webhook signatures; make handlers idempotent.
7. Never fetch a user-supplied URL without an allowlist (SSRF).
8. Log and alert on: 429 spikes, 401/403 spikes, validation-failure spikes.
```

## Step 1 — Rate limiting that actually works

The classic vibe-code mistake: a counter in a `Map` in memory. It resets on every deploy, isn't shared
between instances, and vanishes when you scale to two servers.

```ts
// ✅ shared store (Upstash/Redis), sliding window, multiple keys
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();
const tiers = {
  login:      new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(10, "15 m") }),
  signup:     new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(3,  "1 h") }),
  reset:      new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(5,  "1 h") }),
  api:        new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(120, "1 m") }),
  expensive:  new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(10, "1 h") }),
};

export async function guard(name: keyof typeof tiers, identifier: string) {
  const { success, limit, remaining, reset } = await tiers[name].limit(identifier);
  return { ok: success, headers: {
    "RateLimit-Limit": String(limit),
    "RateLimit-Remaining": String(remaining),
    "RateLimit-Reset": String(reset),
    "Retry-After": String(Math.max(1, Math.ceil((reset - Date.now()) / 1000))),
  }};
}
```

**Key by more than one thing.** IP alone is shared by offices and mobile carriers; user alone doesn't stop
pre-auth attacks. Use combinations:

| Endpoint | Key |
|---|---|
| Login / reset / signup | `ip` **and** `email` (both limited) |
| Authenticated API | `userId` (primary) + `ip` (secondary, much higher limit) |
| Expensive ops (AI, export) | `userId` + a daily quota |
| Anonymous public API | `ip` + a global cap; consider requiring a key |
| Webhook | Trust the provider; rate limit unknown sources |

**Tune it like this:**
- Authenticated APIs: 5-10x what a real user does in a minute
- Login: 5-10 per 15 min per account, 20 per 15 min per IP
- Signup: 3-5 per hour per IP
- Expensive ops: a daily quota per account (this is the one that saves your invoice)
- Never a hard permanent block without a support path

**Response:** `429` + `Retry-After` + a human message ("Too many attempts, try again in a minute").
Log it with the key, endpoint, and UA. A spike in 429s is your early warning system.

**Defense in depth:** platform-level limits (Cloudflare/Vercel WAF, nginx `limit_req`) catch volumetric
attacks before they reach your code. App-level limits catch the abuse that looks like normal traffic.

## Step 2 — Validate at the door

```ts
import { z } from "zod";

const createBooking = z.object({
  classId: z.string().uuid(),
  seats: z.number().int().min(1).max(10),
  note: z.string().max(500).optional(),
}).strict();          // ← unknown keys are rejected (blocks smuggling extra fields)

export async function POST(req: Request) {
  const parsed = createBooking.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return json({ error: "Invalid input", issues: parsed.error.flatten() }, 400);
  }
  ...
}
```

Rules:
- Validate **everything**: body, query params, path params, headers you use, webhook payloads
- Bound: string length, array length, number range, date range, page size, file size
- Allowlist where possible (status: `"active" | "cancelled"`, sort columns, redirect targets)
- Reject unknown keys
- Validate as early as possible — before auth lookups, before DB work, before spending money

## Step 3 — Bound the resources a single request can consume

| Resource | Cap | Why |
|---|---|---|
| Body size | 1MB (JSON), larger only for uploads | Memory + parsing DoS |
| Upload size | Per-type cap, enforced at the proxy too | Storage + bandwidth bills |
| Pagination | `limit <= 100`, default 20 | Unbounded `limit` = free data dump + DB death |
| Query depth / complexity | GraphQL: depth ≤ 10, cost analysis | Nested query bombs |
| Response time | 10-30s hard timeout, then abort | Slow endpoints tie up workers |
| Concurrency | Queue or cap concurrent expensive ops | One user shouldn't monopolize |
| Search term length | ≤ 200 chars | ReDoS + DB load |
| Export rows | Cap, or stream to a file and email it | Memory exhaustion |
| Redirects followed | 0 or a validated allowlist | SSRF |

```ts
// Next.js: cap the body size on a route
export const config = { api: { bodyParser: { sizeLimit: "1mb" } } };
// Express
app.use(express.json({ limit: "1mb" }));
// Always also set it at the proxy/CDN, so oversized requests never reach your app.
```

## Step 4 — Quota the expensive things

Anything that costs you money or CPU per call gets a **per-account daily quota**, not just a rate limit:

| Feature | Typical cap | What to do when exceeded |
|---|---|---|
| AI/LLM calls | 20-100/day/user (or a credit budget) | Friendly message + upgrade prompt |
| Transactional email | Tied to provider quota; alert at 80% | Queue and retry |
| SMS / WhatsApp | Strict: it costs real cents | Hard stop |
| PDF/report generation | 10/day | Queue it, email when ready |
| Data export | 3/day | Rate limit + notify |
| File storage | Per-plan GB cap | Block new uploads, keep reads |
| Search | Generous for authed users | Consider caching |

Implement the quota **before** the call that spends money, and record usage atomically:

```ts
// Increment usage and check the cap in one atomic operation
const used = await redis.incr(`quota:ai:${userId}:${today}`);
await redis.expire(`quota:ai:${userId}:${today}`, 86400 * 2);
if (used > plan.aiCallsPerDay) {
  await redis.decr(`quota:ai:${userId}:${today}`);   // don't count the rejected call
  return json({ error: "You've used today's AI credits. Resets at midnight UTC." }, 429);
}
```

## Step 5 — Webhooks (verify + dedupe)

```ts
export async function POST(req: Request) {
  const raw = await req.text();                       // raw body — signature needs the exact bytes
  const sig = req.headers.get("stripe-signature")!;

  let event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return new Response("invalid signature", { status: 400 });   // 400, no detail to the caller
  }

  // Idempotency: providers retry. Process each event exactly once.
  try {
    await db.processedWebhook.create({ data: { id: event.id } });
  } catch {
    return new Response("duplicate", { status: 200 });           // already handled, exit happily
  }

  await handle(event);                                 // wrap in try/catch; return 500 so they retry
  return new Response(null, { status: 200 });
}
```

Rules: raw body (not parsed), timing-safe compare (the SDK does it), constant 200 for duplicates,
500 only when a retry could plausibly succeed, and log the event ID for support.

## Step 6 — SSRF-safe outbound requests

Never fetch a URL a user gave you without the checks. See `appsec-hardening` for the full code:

```
scheme allowlist (http/https) → resolve host → reject private/link-local/metadata IPs →
block or re-validate redirects → timeout (5s) → cap response size → don't return raw errors
```

Also applies to: "import from URL", link previews, PDF generators, avatar fetchers, user-configured
webhook destinations, and OAuth discovery endpoints.

## Step 7 — Bots, spam, and fake accounts

Escalate; don't start with CAPTCHA (it hurts real users and doesn't stop determined attackers).

```
1. Honeypot field      hidden input, real users never fill it → bots do. Free and effective.
2. Timing check        form submitted < 2s after page load → almost certainly a bot
3. Rate limits         per IP on signup/contact/checkout
4. Email verification  kills most fake-account problems in one step
5. Duplicate detection same email/phone/IBAN/content repeated → flag
6. Content checks      links in the first message, gibberish, known spam patterns
7. CAPTCHA             only after you're actually being targeted
8. Manual review queue for anything that survives 1-7
```

For scraping: rate limits + capped pagination + `robots.txt` + ToS. If it's a business problem, a
CDN/WAF with bot management is cheaper than building one.

## Step 8 — See the attack

Log every rejection with enough context to act:

```ts
logger.warn("rate_limited", { endpoint, key, ip, userId: user?.id ?? null, ua, count });
logger.warn("validation_failed", { endpoint, issues: parsed.error.issues.slice(0, 5), ip });
logger.warn("auth_failed", { email: hash(email), ip, ua });        // hash the email, don't store it raw
```

Alert on (start simple; tune after the first false alarm):

| Signal | Threshold | Meaning |
|---|---|---|
| 429s | 100 in 10 min | Someone is probing or your limits are too tight |
| 401/403s | 50 in 10 min | Credential stuffing or IDOR probing |
| Validation failures | 200 in 10 min | Scanner or fuzzer |
| Signups | 20 in 1 hour | Fake-account farm |
| Expensive-op usage | 80% of a user's quota | About to cost you money |
| Error rate | >2% of requests | Something is broken or being broken |

## Non-negotiables

1. **Rate limits live in a shared store**, not process memory.
2. **Every input is schema-validated at the door**, with bounds and no unknown keys.
3. **Every request has a size, time, and pagination cap.**
4. **Anything that costs money has a per-account daily quota.**
5. **Webhooks are signature-verified and idempotent.**
6. **No user-supplied URL is fetched without allowlisting.**
7. **429 responses include `Retry-After` and are logged.**
8. **Limits never lock out a legitimate user permanently** — there's always a recovery path.
9. **Fail closed on the expensive paths** (if the quota store is down, don't grant unlimited AI calls).
10. **Alerts go to a human inbox**, not just a dashboard nobody opens.

## Ask the human

1. "Is there any part of this that costs you money each time it's used — AI, emails, texts, reports?"
2. "If someone automated using your app all day, what's the most they could cost you?"
3. "Do you expect random people on the internet to find this, or mostly people you invite?"
4. "How annoying are you willing to be to suspicious users — a gentle slowdown, or a hard block?"
5. "If you got 10,000 visitors in an hour, would that be a great day or a disaster?"
6. "Are you worried about competitors copying your content, or about fake signups, or about costs?" *(different problems, different fixes)*

Never ask: "token bucket or sliding window?", "should this be at the edge or in the app?", "which WAF ruleset?".

## Anti-patterns

| Anti-pattern | Why it fails | Do instead |
|---|---|---|
| Rate limit counter in a `Map` in memory | Resets on deploy, per-instance, useless when scaled | Redis/Upstash, or the platform's limiter |
| One global limit for everything | Legit users blocked while attackers use other endpoints | Per-endpoint tiers |
| Limiting only by IP | Shared NAT punishes offices; distributed attacks sail through | IP **and** user **and** per-endpoint |
| No limit because "we're small" | Bots don't care how small you are | Limits from day one, generous to start |
| Blocking with no `Retry-After` | Clients retry immediately, making it worse | `429` + `Retry-After` + clear message |
| Validating only in the client | curl doesn't run your React | Server-side schema validation |
| Unbounded `limit`/`pageSize` | `?limit=1000000` dumps the DB | Cap at 100 |
| Trusting a webhook because "it's HTTPS" | Anyone can POST to a public URL | Signature verification |
| Returning detailed validation errors on auth endpoints | Helps attackers enumerate | Generic on auth, detailed elsewhere |
| No logging on rejections | You'll never know you were attacked | Log + alert on spikes |
| CAPTCHA on every form | Kills conversion, still beaten by humans | Progressive: honeypot → timing → CAPTCHA |
| Failing open when the limiter is down | Unlimited spend during an outage | Fail closed on expensive paths |

## Definition of done

- [ ] Every public endpoint is schema-validated, with bounded inputs and no unknown keys
- [ ] Rate limits in a shared store, tiered per endpoint, keyed by IP + user; `429` includes `Retry-After`
- [ ] Body size, upload size, pagination, and timeouts are capped
- [ ] Every money-consuming operation has a per-account daily quota that fails closed
- [ ] Webhooks: raw-body signature verification + idempotency by event ID
- [ ] Outbound user-supplied fetches are allowlisted and private-IP-blocked
- [ ] Honeypot + timing checks on public forms; email verification on signup
- [ ] Rejections are logged; alerts wired for 429/401/validation spikes
- [ ] Load-tested: your limits hold under a burst, and legit traffic isn't affected
- [ ] A documented path for a wrongly-blocked user to get unblocked

## Works with

- `appsec-hardening` — the full vulnerability picture
- `auth-and-access` — brute force, credential stuffing, lockout policy
- `data-privacy-and-pii` — what not to log when you log abuse
- `cost-guardrails` — quotas are how you cap the invoice
- `performance-and-caching` — caching is the cheapest abuse defense
- `ai-features-in-production` — the most expensive endpoint you'll ever expose
- `third-party-integrations` — retries, timeouts, circuit breakers
