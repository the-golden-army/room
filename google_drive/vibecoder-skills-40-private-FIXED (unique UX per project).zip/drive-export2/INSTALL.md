# Installing vibecoder-skills

Each skill is a folder containing a `SKILL.md` file with `name` + `description` frontmatter.
That's the open convention used by Claude Code, Codex CLI, Cursor, Windsurf, Cline, Amp, OpenCode and friends.
Nothing here is vendor-locked.

```
skills/
  core/vibecoder-orchestrator/SKILL.md
  security/appsec-hardening/SKILL.md
  ...
```

## Option 1 — the installer script

```bash
# Claude Code (global: ~/.claude/skills)
./scripts/install.sh --agent claude

# Claude Code (this project only: .claude/skills)
./scripts/install.sh --agent claude --project /path/to/my-app

# Cursor (.cursor/skills)
./scripts/install.sh --agent cursor --project /path/to/my-app

# Codex CLI (~/.codex/skills, also appends a router to AGENTS.md)
./scripts/install.sh --agent codex

# Windsurf / Cline / Amp / generic
./scripts/install.sh --agent windsurf
./scripts/install.sh --agent cline
./scripts/install.sh --agent amp
./scripts/install.sh --agent generic --project /path/to/my-app

# Everything, flattened into one folder (symlinks, so updates are instant)
./scripts/install.sh --agent all --project /path/to/my-app

# Copy instead of symlink (for zipping / committing into a project)
./scripts/install.sh --agent claude --copy
```

Add `--only security,core` to install just some groups.
Add `--skills appsec-hardening,frontend-craft` to install named skills.

## Option 2 — manual (30 seconds)

Agents look for skills in a skills directory. Copy the leaf folders (the ones holding `SKILL.md`) into it,
flattened — the group folders (`core/`, `security/`) are for humans, not for the loader:

```bash
# Claude Code
mkdir -p ~/.claude/skills
find skills -name SKILL.md -exec dirname {} \; | while read d; do
  cp -r "$d" ~/.claude/skills/
done
```

## Option 3 — no installation at all

If your agent has no skills system, it will still read project instructions. Add the router to your
`AGENTS.md` / `CLAUDE.md` / `.cursorrules` and reference the skills by path:

```markdown
# AGENTS.md
Before writing code for this project, read `skills/core/vibecoder-orchestrator/SKILL.md` and follow it.
```

## Recommended: install the orchestrator everywhere

The single highest-value install is **[`vibecoder-orchestrator`](skills/core/vibecoder-orchestrator/SKILL.md)**.
It reads any request ("add payments", "make it secure", "deploy this") and tells the agent which other skills
to load before it starts. Everything else can be lazy-loaded from the repo on demand.

## Verify it works

Ask your agent:

> I want to build a small booking app for my gym. What do you need to know first?

If it installed correctly, you'll get 5-8 plain-language questions about members, payments and peak hours —
not a list of tech choices. If you get a Next.js scaffold instead, the skills aren't loaded.
