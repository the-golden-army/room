# Changelog

All notable changes to `vibecoder-skills`.

## 1.2.0 — 2026-10-21

### Added
- `ux/responsive-mobile-first` — zero-tolerance mobile-first production UI. 320px-first, fluid type/layout, 44px tap targets, thumb zones, and a completeness audit: no dead links, blank routes, broken images, or demo mock data.
- `engineering/database-efficiency` — lean schema design in production. Teaches 2-column like tables not 7, smallest correct types, index intent vs bloat, provider selection (Postgres/Supabase/Neon/PlanetScale/Turso), resource ceilings, and zero-risk retention/archiving.
- `ux/ux-upgrade-audit` — complete UX upgrade scan. Inventories every page, runs 8 pass/fail audits (buttons, type, layout, color, states, responsive, a11y, consistency), produces a severity-graded report with file:line + fix snippets, then upgrades the app on your "fix all".
- `ux/global-ui-reformat` — standalone global reformatter. One paste upgrades any codebase: system-aware dark mode with no FOUC, skeletons for every loading state, human error messages with retry (never raw 500s), and animated onboarding with spotlight coach marks + welcome modals. 320px→1440px light/dark verified.
- `quality/write-documentation` — usage-first documentation writer. Say "write docs" → gets full README: why, features (file:line-verified), quick start, workflows with screenshots, API/CLI reference, examples, FAQ, troubleshooting — and adds "Run locally" ONLY if open-source tool/library/self-hosted; hosted products link to live URL instead. No invented features, one runnable snippet, no dead links.

### Fixed
- `ux/distinctive-visual-style` — **"same UI twice" fix:** process now requires proposing 3 distinct directions (different ancestor/palette/type/radius/layout from R1-R5) and human pick, with `REJECTED:` recorded in `docs/STYLE.md`. New non-negotiables: never ship example tokens verbatim, never reuse same recipe without approval, uniqueness check at 10 feet.
- `ux/global-ui-reformat` + `ux/design-system-and-visual-language` — tokens examples marked as shape-only; must derive product-specific palette from ancestor + distinctive-visual-style, with 2 rejected directions documented. Prevents copy-paste #ffffff/#111827 repetition.

## 1.1.0 — 2026-10-20

### Added
- `ux/distinctive-visual-style` — the anti-slop skill. The twenty tells of an AI-designed page, eight
  moves to derive a real visual identity from the product instead of decorating it, seven tests to run
  before shipping, and `references/style-recipes.md` with five complete non-default style systems
  (Paper & Ink, Swiss, Warm Analog, Dense Technical, High-Contrast Minimal), each with real CSS
  variables, type stacks, a scale, a shadow policy and a banned list.

### Changed
- Sales page (`site/index.html`) rebuilt from scratch on the Paper & Ink system — it had every tell the
  new skill warns about.
- `dont-get-hacked` bundle now ships a root `SKILL.md` pack manifest, so it can be uploaded to a
  marketplace that autofills from a root `SKILL.md` (`dist/store/agensi/security-pack.zip`).

## 1.0.0 — 2026-10-20

The initial release: **34 skills, 7 groups.**

### core (5)
- `vibecoder-orchestrator` — the conductor: routes any request to the right skills and enforces
  understand → choose → design → build → verify → ship → maintain. Includes a brief template and the
  full skill index.
- `discovery-interview` — plain-language discovery in seven blocks, with an answer-to-decision map that
  turns human answers into technical choices.
- `stack-selection` — situation-driven stack decisions, the bias checklist, lock-in scoring, and nine
  ready-made stack recipes.
- `vibe-guardrails` — how an agent must behave with a non-engineer: plain language, no silent skips,
  no leaks, autonomy tiers, the handoff note. Includes a 90-term translation glossary.
- `project-blueprint` — repo layout, naming, module boundaries, the five documents, with copy-paste
  README / `.env.example` / `.gitignore` / runbook templates.

### security (6)
- `appsec-hardening` — the flagship. A vulnerability playbook (injection, XSS, auth, authorization,
  CSRF/CORS, SSRF, files, data exposure, business logic, config) plus a ~90-item pass/fail pre-launch audit.
- `auth-and-access` — sessions, passwords, OAuth, reset, RBAC, tenancy, and ten copy-paste recipes.
- `secrets-management` — env discipline, client-bundle rule, least privilege, rotation, and the
  30-minute leak drill.
- `api-abuse-defense` — rate limiting that works, input validation, quotas, webhook security, bots, SSRF.
- `data-privacy-and-pii` — data map, no-PII-logging, retention, and a deletion pipeline that fans out.
- `dependency-and-supply-chain` — vetting, lockfiles, scanning, and CI permissions.

### ux (5)
- `frontend-craft` — the six states, the button law, async discipline, and twelve copy-paste patterns.
- `design-system-and-visual-language` — tokens, type, colour, spacing, the twelve components, motion,
  and the "AI-generated look" checklist.
- `ux-writing-and-onboarding` — copy rules, the first five minutes, and a 100+ string before/after bank.
- `accessibility-and-inclusive-design` — semantics, keyboard, focus, forms, contrast, and the five-minute
  manual test.

### engineering (6)
- `production-readiness` — the launch gate, demo-vs-product, and a launch certificate.
- `backend-api-design` — one contract, honest status codes, pagination, idempotency.
- `data-model-and-migrations` — schema, indexes, expand/contract migrations, and restore-tested backups.
- `testing-and-verification` — the 12 tests that matter, the verification ladder, a smoke-test script.
- `errors-logs-and-monitoring` — four layers: errors, structured logs, signals, alerts that mean something.
- `performance-and-caching` — budgets, N+1, caching layers with invalidation, and a 10x load test.

### delivery (6)
- `deploy-and-environments` — four environments, the CI pipeline, DNS/TLS, zero-downtime, rollback.
- `reliability-and-incidents` — backups, kill switches, severity levels, comms templates, postmortems.
- `payments-and-billing` — the ten money rules, webhooks, dunning, disputes, and a go-live checklist.
- `third-party-integrations` — wrappers, timeouts, retries, circuit breakers, degradation.
- `cost-guardrails` — caps, quotas, AI spend, and cost per active user.
- `seo-and-growth-basics` — indexability, metadata, privacy-respecting analytics, landing pages.

### platform (4)
- `mobile-app-delivery` — Expo/RN, secure storage, offline, push, OTA, and the store rules that reject apps.
- `desktop-app-delivery` — Tauri/Electron, sandboxing, signing, notarization, signed auto-update.
- `ai-features-in-production` — injection defense, structured output, cost caps, streaming, evals.
- `saas-architecture` — tenant isolation that fails closed, entitlements, backoffice, audit log.

### quality (3)
- `code-review-and-audit` — eight passes in priority order, severity grading, AI-code tells, report template.
- `refactor-and-maintainability` — the safe loop, characterization tests, seams, debt budget, rewrite test.
- `launch-and-handoff` — the launch ladder, hour-by-hour runbook, and the twelve-item owner's handoff pack.

### Also in this release
- `scripts/install.sh` — installs into Claude Code, Cursor, Codex, Windsurf, Cline, Amp, or a generic
  folder; supports `--only`, `--skills`, `--copy`, `--force`.
- `_shared/VIBECODER-PROFILE.md` — the one-page profile the human fills in once so the agent stops
  re-asking and stops treating a founder like a staff engineer.
- `AGENTS.md` — repo router and the rules for adding a skill.

## Conventions going forward

- Skill `name` frontmatter is a stable identifier. Never rename an existing skill.
- Every skill keeps the same body skeleton: Promise → When to use → 60-second version → Steps →
  Non-negotiables → Ask the human → Anti-patterns → Definition of done → Works with.
- Every skill asks questions a non-engineer can answer.
- Changes to a skill bump its own `version` in frontmatter; the pack version bumps on any release.
